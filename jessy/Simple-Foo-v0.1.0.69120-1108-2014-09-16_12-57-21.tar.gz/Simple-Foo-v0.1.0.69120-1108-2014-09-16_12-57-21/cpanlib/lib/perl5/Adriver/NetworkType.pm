package Adriver::NetworkType;

use strict;
use warnings;

use constant NULL_NETWORK            => 0;
use constant POOL_NETWORK            => 1;
use constant SIMPLE_NETWORK          => 2;
use constant SIMPLE_EXCHANGE_NETWORK => 3;
use constant RLE_NETWORK             => 4;

1;
