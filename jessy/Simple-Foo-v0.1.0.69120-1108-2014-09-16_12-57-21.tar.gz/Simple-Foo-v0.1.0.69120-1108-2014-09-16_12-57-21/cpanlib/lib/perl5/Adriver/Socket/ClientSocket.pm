package Adriver::Socket::ClientSocket;

use strict;
our $VERSION = '0.0300';

use Adriver::Loader;
use Carp;
use Params::Validate qw(:all);
use Adriver::Socket::Exceptions;

validation_options(on_fail => sub { Adriver::Socket::Exceptions::ParamsValidation->throw( error => $_[0]); } );

sub new
{
    validate_pos(@_,
        { type => SCALAR },
        { type => SCALAR },
        { type => SCALAR,
            optional => 1,
            callbacks => {
                'port number (1, 0xFFFF)' => sub { ($_[0] =~ m/^\d+$/o) and (int($_[0]) > 0 && int($_[0]) <= 65535) }
            }
        });
    my ($self, $host, $port) = @_;

    client_so_loader('RLE::ClientSocket');
    my $client_socket = bless {}, $self;
    if ($port)
    {
        $port = int ($port);
        $client_socket->{'socket'} = RLE::ClientSocket->new($host, $port) or
            Adriver::Socket::Exceptions->throw(error=>"Couldn't create socket object with host='$host' and port='$port'");
    }
    else
    {
        $client_socket->{'socket'} = RLE::ClientSocket->new($host) or
            Adriver::Socket::Exceptions->throw(error=>"Couldn't create socket object with host='$host'");
    }
    # Store host and port if we want to get it later
    $client_socket->{'host'} = $host;
    $client_socket->{'port'} = $port;
    $client_socket->{'connected'} = 0; #FALSE socket is not connected
    return $client_socket;
}

sub connect
{
    validate_pos(@_, { type => OBJECT });
    my $self = shift;
    if (not $self->{'connected'})
    {
        $self->{'socket'}->connect or
            Adriver::Socket::Exceptions->throw(error=>"Couldn't connect to '${\($self->host)}:${\($self->port)}'");
        $self->{'connected'} = 1; # TRUE socket is connected
    }
    return $self;
}

sub fd
{
    validate_pos(@_, { type => OBJECT });
    my $self = shift;
    return $self->{'connected'} ? $self->{'socket'}->fd : undef;
}

sub GetCaps
{
    validate_pos(@_, { type => OBJECT });
    my $self = shift;
    return $self->{'socket'}->GetCaps;
}

sub is_connected
{
    validate_pos(@_, { type => OBJECT });
    return shift->{'connected'} ? 1 : 0;
}

# Accessors for initial configuration
sub host
{
    validate_pos(@_, { type => OBJECT });
    return shift->{'host'};
}

sub port
{
    validate_pos(@_, { type => OBJECT });
    return shift->{'port'}
}

1;

__END__


=head1 NAME

    Adriver::Socket::ClientSocket - lets you connect to database via socket.


=head1 SYNOPSIS

    use Adriver::Socket::ClientSocket;
    use Adriver::Socket::Exceptions;

    eval
    {
        my $client_socket = new Adriver::Socket::ClientSocket($host, $port);
        $client_socket->connect;

        if ($client_socket->is_connected)
        {
            print "Successfully connected to '${\($client_socket->host)}::${\($client_socket->port)}'\n";
        }
        else
        {
            print "Couldn't connected to '${\($client_socket->host)}::${\($client_socket->port)}'\n";
        }

        my $fd   = $client_socket->fd;
        my $caps = $client_socket->GetCaps;
    };

    if (my $e = Exception::Class->caught('Adriver::Socket::Exceptions'))
    {
        die "Caught Adriver::Socket::Exceptions: '", $e->error, "\n", $e->trace->as_string, "\n";
    }
    elsif ($e = Exception::Class->caught('Exception::Class::Base'))
    {
        die "Caught unknown exception: '", $e->error, "\n", $e->trace->as_string, "\n";
    }
    elsif ($e = Exception::Class->caught)
    {
        die "$e";
    }


=head1 DESCRIPTION

    This module provides you the way to communicate with databases via socket.
    In internal implementation we work with RLE::ClientSocket object.
    And in fact we use this module as a wrapper under RLE::ClientSocket module.


=head1 CLASS INTERFACE

=head2 new($host, $port) : Adriver::Socket::ClientSocket object

    Create the new object of class.

B<host>

    This is a host address where database is accessible.

B<port>

    This is a port number on which listeners of the database is accessible. This is optional parameter,
    default port number determined into RLE::ClientSocket module.

B<Exceptions>

    Adriver::Socket::Exceptions::ParamsValidation
    Adriver::Socket::Exceptions


=head1 OBJECT INTERFACE

=head2 connect() : self Adriver::Socket::ClientSocket object

    This method translates call to RLE::ClientSocket method of the same name and
    performs connecting to the database.

B<Exceptions>

    Adriver::Socket::Exceptions::ParamsValidation
    Adriver::Socket::Exceptions

=head2 is_connected() : 1 or 0

    This method returns 1 if connect() method was called already and 0 otherwise.

B<Exceptions>

    Adriver::Socket::Exceptions::ParamsValidation

=head2 host() : $host_address

    This method returns host address with which this object was created.

B<Exceptions>

    Adriver::Socket::Exceptions::ParamsValidation

=head2 port() : $port_number

    This method returns port number with which this object was created.

B<Exceptions>

    Adriver::Socket::Exceptions::ParamsValidation

=head2 fd() : $file_descriptor

    This method returns the file descriptor of created socket.

B<Exceptions>

    Adriver::Socket::Exceptions::ParamsValidation

=head2 GetCaps() : $InfoHashRef

    This method returns a reference on a hash with some system information like ServerVersion, PerlClientVersion and other.

B<Exceptions>

    Adriver::Socket::Exceptions::ParamsValidation


=head1 SEE ALSO

    RLE::ClientSocket
    Adriver::Socket::Exceptions

