package Adriver::Socket::GeoSocket;

use strict;
our $VERSION = '0.0300';
use Adriver::Socket::ClientSocket;
use Carp;
use Params::Validate qw(:all);
use Adriver::Socket::Exceptions;

validation_options(on_fail => sub { Adriver::Socket::Exceptions::ParamsValidation->throw( error => $_[0]); } );

# Create empty geo db connect
sub new
{
    validate_pos(@_, { type => SCALAR }, { type => ARRAYREF, callbacks => {
        'check args' => sub {
            foreach my $cfgrec(@{$_[0]}) {
                return 0 if (exists $cfgrec->{'port'} && not ($cfgrec->{'port'} =~ m/^\d+$/o) or (int($cfgrec->{'port'}) <= 0) or ($cfgrec->{'port'} > 65535));
                return (exists $cfgrec->{'host'} && $cfgrec->{'host'} =~ m/^([-\@\w.])+$/o) && (exists $cfgrec->{'start_IP'} && $cfgrec->{'start_IP'} =~ m/^\d+$/o) && (exists $cfgrec->{'stop_IP'} && $cfgrec->{'stop_IP'} =~ m/^\d+$/o);
            }
            return 1;
        }
    } });
    my ($self, $args) = @_;

    my $geo_socket = bless {}, $self;
    $geo_socket->{'config'} = $args;
    $geo_socket->{'connected'} = 0;

    return $geo_socket;
}

sub connect {
    validate_pos(@_, { type => OBJECT });
    my $self = shift;
    if (not $self->is_connected)
    {
        foreach my $geo_host (@{$self->{'config'}})
        {
            $geo_host->{'client_socket'} =
                new Adriver::Socket::ClientSocket($geo_host->{'host'}, $geo_host->{'port'});
            $geo_host->{'client_socket'}->connect();
            $self->_push_back({
                'socket'=>$geo_host->{'client_socket'}->fd,
                'start_IP'=>$geo_host->{'start_IP'},
                'stop_IP'=>$geo_host->{'stop_IP'},
            });
        }
        $self->{'connected'} = 1;
    }
    return $self;
}

# Return connect
sub fd
{
    validate_pos(@_, { type => OBJECT });
    my $self = shift;
    return $self->is_connected ? $self->{'connect'} : undef;
}

# Is it was connected
sub is_connected
{
    validate_pos(@_, { type => OBJECT });
    return shift->{'connected'} ? 1 : 0;
}

# Return connection configuration
# List of {host, port, ip range}
sub config
{
    validate_pos(@_, { type => OBJECT });
    return shift->{'config'};
}

# Add one more host config to the server list
# List item is
# {
#    'socket'=> client_socket->fd, # connected socket descriptor
#    'start_IP'=> start_IP,
#     'stop_IP'=> stop_IP
# }

sub _push_back
{
    validate_pos(@_, { type => OBJECT }, 1);
    my ($self, $geo_host) = @_;
    push @{$self->{'connect'}}, $geo_host;
    return 1;
}


1;


__END__


=head1 NAME

    Adriver::Socket::GeoSocket - lets you connect to Geo database via sockets.


=head1 SYNOPSIS

    use Adriver::Socket::GeoSocket;
    use Adriver::Socket::Exceptions;
    use Data::Dumper;

    eval
    {
        my @db_servers;
        push @db_servers, {host => 'f2.x', port => 16000, start_IP=> 0, stop_IP => 4294967295};
        my $geo_socket = Adriver::Socket::GeoSocket->new(\@db_servers);

        $geo_socket->connect;
        if ($geo_socket->is_connected)
        {
            print "Successfully connected to Geo DB\n";
        }
        else
        {
            print "Couldn't connected to Geo DB with your config\n";
            print Dumper($geo_socket->config);
        }

        my $fd = $geo_socket->fd;
        print Dumper($fd);
    };

    if (my $e = Exception::Class->caught('Adriver::Socket::Exceptions'))
    {
        die "Caught Adriver::Socket::Exceptions: '", $e->error, "\n", $e->trace->as_string, "\n";
    }
    elsif ($e = Exception::Class->caught('Exception::Class::Base'))
    {
        die "Caught unknown exception: '", $e->error, "\n", $e->trace->as_string, "\n";
    }
    elsif ($e = Exception::Class->caught)
    {
        die "$e";
    }


=head1 DESCRIPTION

    This module provides you the way to establish connection with Geo database via sockets.
    In internal implementation we work with Adriver::Socket::ClientSocket module.


=head1 CLASS INTERFACE

=head2 new(\@config) : Adriver::Socket::GeoSocket object

    Create the new object of class.

=head3 config

    This is an array with connection parameters to each separate host of Geo database.
    Each array element is a hash reference with next keys.

B<host>

    This is a host address where database is accessible.

B<port>

    This is a port number on which listeners of the database is accessible. This is optional parameter,
    default port number determined into RLE::ClientSocket module.

B<start_IP>

    This is lower bound of IP addresses range available on separate database host.

B<stop_IP>

    This is upper bound of IP addresses range available on separate database host.

=head3 Exceptions

    Adriver::Socket::Exceptions::ParamsValidation


=head1 OBJECT INTERFACE

=head2 connect() : self Adriver::Socket::ClientSocket object

    This method establishes a connection to each host presented at config array.
    Connection performed by creating Adriver::Socket::ClientSocket socket.

B<Exceptions>

    Adriver::Socket::Exceptions::ParamsValidation

=head2 is_connected() : 1 or 0

    This method returns 1 if connect() method was called already and 0 otherwise.

B<Exceptions>

    Adriver::Socket::Exceptions::ParamsValidation

=head2 fd() : $array_ref

    This method returns an array reference. Each element of this array corresponding to each element of config array
    and represent a hash with next keys:

B<socket>

    This is a file descriptor returned by fd() method of Adriver::Socket::ClientSocket object. See documentation on
    Adriver::Socket::ClientSocket module for more information.

B<start_IP>

    This is lower bound of IP addresses range available on separate database host.

B<stop_IP>

    This is upper bound of IP addresses range available on separate database host.

B<Exceptions>

    Adriver::Socket::Exceptions::ParamsValidation

=head2 config() : $array_ref

    This method returns you a reference on array. This is the same config array that you passed when was creating this object.
    But if you have called connect() method already in each array element will be one more field - client_socket, which stores a
    reference to Adriver::Socket::ClientSocket object created when we were connecting to corresponding host.

B<Exceptions>

    Adriver::Socket::Exceptions::ParamsValidation


=head1 PRIVATE OBJECT INTERFACE

=head2 _push_back($hash_ref)

    Push back the new element to array returned by fd() method.

B<Exceptions>

    Adriver::Socket::Exceptions::ParamsValidation


=head1 SEE ALSO

    Adriver::Socket::ClientSocket
    Adriver::Socket::Exceptions

