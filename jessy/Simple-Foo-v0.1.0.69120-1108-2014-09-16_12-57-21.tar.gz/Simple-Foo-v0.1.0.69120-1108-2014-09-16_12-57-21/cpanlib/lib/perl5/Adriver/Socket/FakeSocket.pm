package Adriver::Socket::FakeSocket;

use strict;
our $VERSION = '0.0300';

sub new {
    my $self = {};
    my $that = shift;
    my $class = ref($that)||$that;
    bless($self, $class);
    $self->{'connect'} = shift;
    return $self;
}

sub fd {
    my $self = shift;
    return $self->{'connect'};
}

1;

__END__


=head1 NAME

    Adriver::Socket::FakeSocket - lets you create fake socket object.


=head1 SYNOPSIS

    use Adriver::Socket::FakeSocket;

    my $fake_socket = new Adriver::Socket::FakeSocket();
    $client_socket->connect;

    my $fd = $fake_socket->fd;


=head1 DESCRIPTION

    This module helps to create fake socket object for test purpose or another cases.


=head1 CLASS INTERFACE

=head2 new() : Adriver::Socket::FakeSocket object

    Create the new object of class.


=head1 OBJECT INTERFACE

=head2 fd() : self Adriver::Socket::FakeSocket object

    This method returns fake socket object itself.


