package Adriver::Socket::StatSocket;

use strict;
our $VERSION = '0.0300';
use Adriver::Loader;
use Carp;
use Params::Validate qw(:all);
use Adriver::Socket::Exceptions;

validation_options(on_fail => sub { Adriver::Socket::Exceptions::ParamsValidation->throw( error => $_[0]); } );

# Create stat connect
sub new
{
    validate_pos(@_, { type => SCALAR }, { type => SCALAR, regex => qr/^([-\@\/\$\~\w.])+$/ });
    my ($self, $args) = @_;

    my $stat_socket = bless {}, $self;
    $stat_socket->{'config'} = $args;
    client_so_loader('RLE::InitStatFace');
    $stat_socket->{'connect'} = RLE::InitStatFace->new($stat_socket->{config});

    return $stat_socket;
}

# Accessors
sub connect
{
    validate_pos(@_, { type => OBJECT });
    return shift->{'connect'};
}

sub fd
{
    validate_pos(@_, { type => OBJECT });
    return shift->{'connect'};
}

sub config
{
    validate_pos(@_, { type => OBJECT });
    return shift->{'config'};
}

1;

__END__


=head1 NAME

    Adriver::Socket::StatSocket - lets you connect to Stat database via socket.


=head1 SYNOPSIS

    use Data::Dumper;
    use Adriver::Socket::StatSocket;
    use Adriver::Socket::Exceptions;

    eval
    {
        my $config_file = 'stat4perl.conf';

        my $stat_socket = new Adriver::Socket::StatSocket($config_file);
        print Dumper($stat_socket);

        if ($stat_socket->connect)
        {
            print "Successfully connected to Stat database with config '${\($stat_socket->config)}'\n";

            my $init_stat_face = $stat_socket->fd;
            print "My connect object:\n";
            print Dumper($init_stat_face);
        }
        else
        {
            print "Couldn't connect to Stat database with config '${\($stat_socket->config)}'\n";
        }
    };

    if (my $e = Exception::Class->caught('Adriver::Socket::Exceptions'))
    {
        die "Caught Adriver::Socket::Exceptions: '", $e->error, "\n", $e->trace->as_string, "\n";
    }
    elsif ($e = Exception::Class->caught('Exception::Class::Base'))
    {
        die "Caught unknown exception: '", $e->error, "\n", $e->trace->as_string, "\n";
    }
    elsif ($e = Exception::Class->caught)
    {
        die "$e";
    }


=head1 DESCRIPTION

    This module provides the way to establish connection with Stat database with RLE::InitStatFace module.


=head1 CLASS INTERFACE

=head2 new($config_file) : Adriver::Socket::StatSocket object

    Create the new object of class.

B<config_file>

    This is a path to configuration file with connection parameters.

B<Exceptions>

    Adriver::Socket::Exceptions::ParamsValidation


=head1 OBJECT INTERFACE

=head2 connect() : RLE::InitStatFace object

    This method returns you the internal RLE::InitStatFace object.

B<Exceptions>

    Adriver::Socket::Exceptions::ParamsValidation

=head2 fd() : RLE::InitStatFace object

    This method returns the internal RLE::InitStatFace object.
    In fact this method duplicates connect() method or vise versa.

B<Exceptions>

    Adriver::Socket::Exceptions::ParamsValidation

=head2 config() : $config_file path

    This method returns the path to configuration file used in new() constructor.

B<Exceptions>

    Adriver::Socket::Exceptions::ParamsValidation


=head1 SEE ALSO

    RLE::InitStatFace

