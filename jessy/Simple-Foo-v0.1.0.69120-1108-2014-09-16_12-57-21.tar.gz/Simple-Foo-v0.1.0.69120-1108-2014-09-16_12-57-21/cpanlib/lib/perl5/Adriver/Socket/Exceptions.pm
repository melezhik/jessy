package Adriver::Socket::Exceptions;

use Adriver::Exceptions;

use Exception::Class (

    # Socket Exceptions
    'Adriver::Socket::Exceptions' =>
    {
        isa         => 'Adriver::Exceptions',
        description => 'Database Connection errors',
    },
        # Exceptions if Params Validation
        'Adriver::Socket::Exceptions::ParamsValidation' =>
        {
            isa         => 'Adriver::Socket::Exceptions',
            description => 'Exception evaluated from Params::Validate',
        },

);

1;

__END__


=head1 NAME

    Adriver::Socket::Exceptions - this module describes some socket exceptions.
    This class is inherited from Adriver::Exceptions class.


=head1 SYNOPSIS

    use Adriver::Socket::Exceptions;


=head1 EXCEPTIONS API

B<Adriver::Socket::Exceptions>

    Base exception class for socket errors.

B<Adriver::Socket::Exceptions::ParamsValidation>

    Params::Validate exception.


=head1 SEE ALSO

    Adriver::Exceptions

