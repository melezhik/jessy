package Adriver::Loader;

use strict;
use warnings;

use Carp;
use Params::Validate qw(:all);

use Adriver::DBI::Exceptions;

use base qw(Exporter);

our @EXPORT = qw(client_so_loader);

validation_options(on_fail => sub { Adriver::DBI::Exceptions::ParamsValidation->throw(error => $_[0]); });

{
    # Hash of loaded modules
    my $clients_so = {};
    # An old default version
    my $def_version = '0.02';

    sub client_so_loader
    {
        validate_pos(@_, { type => SCALAR }, { type => SCALAR | UNDEF, optional => 1});

        my $module = shift;
        my $version = shift || $def_version;

        # Load if not loaded
        if(!$clients_so->{$module})
        {
            eval "use $module $version";
            if (!$@)
            {
                $clients_so->{$module} = 1;
            }
            else
            {
                # If error - DIE! with message from eval
                Adriver::DBI::Exceptions->throw(error => $@);
            }
        }
        return $module;
    }
}

1;

__END__


=head1 NAME

    Adriver::Loader - provides dinamic loading of modules which necessary for database communication.


=head1 SYNOPSIS
    
    use Adriver::Loader;

    client_so_loader($module_name, $module_version);


=head1 DESCRIPTION

    Some thing like this should already exists or may be we don't really need it at all.
    Right now this is an attemt to reimplement old loading model and it may be easyly droped in future.

    This module exports in your namespace client_so_loader procedure helped you to load needed modules.


=head1 INTERFACE

=head2 client_so_loader($module_name, $module_version) : $module_name

    Load specified module. You can concrete module's version. To load module procedure uses pragma 'use'.

B<module_name>

    This is name of the module you want to load.

B<module_version>

    This is version of module. It's optional parameter, by default we use version number '0.02'.

B<Exceptions>

  Adriver::DBI::Exceptions::ParamsValidation
  Adriver::DBI::Exceptions


