package  Adriver::Bar;
use version; our $VERSION = version->declare('v0.1.0');
1;





