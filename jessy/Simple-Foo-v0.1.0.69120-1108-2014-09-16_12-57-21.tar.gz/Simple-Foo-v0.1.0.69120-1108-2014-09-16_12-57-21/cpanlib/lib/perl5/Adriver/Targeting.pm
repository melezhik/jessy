package Adriver::Targeting;

use strict;
use warnings;

use base qw( Exporter );

our @EXPORT_OK = qw(
    DAY_HOUR DAY_MONTH GEO DATES ORG MNO CAT DIRECT SUBNET SLICE BROWSER OS IP KEYWORD TRAIT CONTEXT CUSTOM MANUFACTURER
    ORG_NUM MAX_DIRECT_TARGETING_NUM PROFILE_NAME_LEN SLICE_NUM BROWSER_NUM OS_NUM CAT_NUM
    PROFILE_ENABLE_UU_REPORTING
    POLICY_ALLOW POLICY_DENY PROHIBITED_ALLOW PROHIBITED_DENY AND OR NOP INVERSE_ON INVERSE_OFF
    REVERT_POLICY REVERT_PROHIBITED SEARCH_TARGETING AUDITORY_TARGETING DEMOGRAPHY_TARGETING DATE_TARGETING
    BLOCK_NOP BLOCK_OPEN BLOCK_CLOSE RULE_TYPE_EMPTY RULE_TYPE_FULL RULE_TYPE_SUBSTR RULE_TYPE_RANGE
);

our %EXPORT_TAGS = (
    TargetingType => [ qw( DAY_HOUR DAY_MONTH GEO DATES ORG MNO CAT DIRECT SUBNET SLICE BROWSER OS IP KEYWORD TRAIT CONTEXT CUSTOM MANUFACTURER ) ],
    Limits        => [ qw( ORG_NUM MAX_DIRECT_TARGETING_NUM PROFILE_NAME_LEN SLICE_NUM BROWSER_NUM OS_NUM CAT_NUM ) ],
);

# targeting type used for chain number encoding
#
use constant
{
    SEARCH_TARGETING     => 1,
    AUDITORY_TARGETING   => 2,
    DEMOGRAPHY_TARGETING => 3,
    DATE_TARGETING       => 4,
};

use constant
{
    DAY_HOUR     => 0,
    DAY_MONTH    => 1,
    GEO          => 2,
    DATES        => 3,
    ORG          => 4,
    MNO          => 5,
    CAT          => 6,
    DIRECT       => 7,
    NET          => 8,
    SLICE        => 9,
    BROWSER      => 10,
    OS           => 11,
    IP           => 12,
    KEYWORD      => 13,
    TRAIT        => 14,
    CONTEXT      => 15,
    CUSTOM       => 16,
    MANUFACTURER => 17,
};

use constant
{
    ORG_NUM                  => 256,
    MAX_DIRECT_TARGETING_NUM => 32,
    PROFILE_NAME_LEN         => 50,
    SLICE_NUM                => 32,
    BROWSER_NUM              => 32,
    OS_NUM                   => 32,
    CAT_NUM                  => 256,
};

use constant PROFILE_ENABLE_UU_REPORTING  => 0;

use constant
{
    POLICY_ALLOW     => 1,
    POLICY_DENY      => 2,

    PROHIBITED_ALLOW => 0,
    PROHIBITED_DENY  => 1,

    AND              => 2,
    OR               => 1,
    NOP              => 0,

    INVERSE_ON       => 1,
    INVERSE_OFF      => 0,

    BLOCK_NOP        => 0,
    BLOCK_OPEN       => 1,
    BLOCK_CLOSE      => 2,
};

use constant
{
    RULE_TYPE_EMPTY  => 0,
    RULE_TYPE_FULL   => 1,
    RULE_TYPE_SUBSTR => 2,
    RULE_TYPE_RANGE  => 3,
};

# use constant
# {
#     TRAIT_SEARCH_ALLOW_CHAIN_ID => 1,
#     TRAIT_SEARCH_DENY_CHAIN_ID  => 2,
#     TRAIT_AUD_ALLOW_CHAIN_ID    => 3,
#     TRAIT_AUD_DENY_CHAIN_ID     => 4,
# };

sub REVERT_POLICY {
    my $policy = shift;
    return $policy == POLICY_ALLOW ? POLICY_DENY : POLICY_ALLOW;
}

sub REVERT_PROHIBITED {
    my $prohibited = shift;
    return $prohibited == PROHIBITED_ALLOW ? PROHIBITED_DENY : PROHIBITED_ALLOW;
}

1;
