package Adriver::ErrorCodes;

use strict;
use warnings;

sub ERROR_PACKET()                             { 0x20000000                 }

# etdb/DatabaseExceptions.hh:
sub TA_NO_HANDLER()                            { ERROR_PACKET() + 1         }
sub TA_NO_BUFFER_SPACE()                       { ERROR_PACKET() + 2         }
sub TA_DISABLED()                              { ERROR_PACKET() + 3         }
sub TA_UNKNOWN_COMMAND()                       { ERROR_PACKET() + 4         }

sub TA_RLE3CONFIG()                            { ERROR_PACKET() +0x0100     }

sub TA_RLE3CONFIG_UNKNOWN()                    { TA_RLE3CONFIG() + 1        }

sub TA_GEO_HOUR()                              { ERROR_PACKET() + 0x0200    }

sub TA_GEO_HOUR_UNKNOWN()                      { TA_GEO_HOUR() + 1          }
sub TA_GEO_HOUR_BAD_GEO_RANGE()                { TA_GEO_HOUR() + 2          }
sub TA_GEO_HOUR_BAD_HOUR_RANGE()               { TA_GEO_HOUR() + 3          }

sub TA_GEO_STAT()                              { ERROR_PACKET() + 0x0300    }

sub TA_GEO_STAT_UNKNOWN()                      { TA_GEO_STAT() + 1          }
sub TA_GEO_STAT_BAD_SID()                      { TA_GEO_STAT() + 2          }
sub TA_GEO_STAT_ALREADY_EXISTS()               { TA_GEO_STAT() + 3          }
sub TA_GEO_STAT_BAD_GEO_RANGE()                { TA_GEO_STAT() + 4          }

sub TA_GEO()                                   { ERROR_PACKET() + 0x0400    }

sub TA_GEO_UNKNOWN()                           { TA_GEO() + 1               }
sub TA_GEO_BAD_IP_PAIR()                       { TA_GEO() + 2               }
sub TA_GEO_BAD_IP_RANGE()                      { TA_GEO() + 3               }
sub TA_GEO_IP_NOT_FOUND()                      { TA_GEO() + 4               }
sub TA_GEO_BAD_IP_ORDER()                      { TA_GEO() + 5               }
sub TA_GEO_NO_SERVER()                         { TA_GEO() + 6               }
sub TA_GEO_NO_SERVER_FOR_PAIR()                { TA_GEO() + 7               }

sub TA_IDDB()                                  { ERROR_PACKET() + 0x0500    }

sub TA_IDDB_UNKNOWN()                          { TA_IDDB() + 1              }
sub TA_IDDB_UNKNOWN_ID()                       { TA_IDDB() + 2              }
sub TA_IDDB_USED_ID()                          { TA_IDDB() + 3              }

sub TA_CITY()                                  { ERROR_PACKET() + 0x0600    }
sub TA_COUNTRY()                               { ERROR_PACKET() + 0x0700    }
sub TA_ISP()                                   { ERROR_PACKET() + 0x0800    }
sub TA_ORG()                                   { ERROR_PACKET() + 0x0900    }
sub TA_SITE_ZONE()                             { ERROR_PACKET() + 0x0a00    }

sub TA_SITE_ZONE_UNKNOWN()                     { TA_SITE_ZONE() + 1         }
sub TA_SITE_ZONE_UNKNOWN_SID()                 { TA_SITE_ZONE() + 2         }
sub TA_SITE_ZONE_URL_NOT_FOUND()               { TA_SITE_ZONE() + 3         }
sub TA_SITE_ZONE_UNKNOWN_SZID()                { TA_SITE_ZONE() + 4         }
sub TA_SITE_ZONE_ALIAS_ALREADY_EXISTS()        { TA_SITE_ZONE() + 5         }
sub TA_SITE_ZONE_BAD_PAGE_ZONE()               { TA_SITE_ZONE() + 6         }

sub TA_USER()                                  { ERROR_PACKET() + 0x0b00    }

sub TA_USER_LOGIN_NOT_FOUND()                  { TA_USER() + 1              }
sub TA_USER_LOGIN_ALREADY_IN_USE()             { TA_USER() + 2              }

sub TA_SITE()                                  { ERROR_PACKET() + 0x0c00    }
sub TA_OBJECT_OWNERS()                         { ERROR_PACKET() + 0x0d00    }

sub TA_OBJECT_OWNERS_UNKNOWN()                 { TA_OBJECT_OWNERS() + 1     }
sub TA_OBJECT_OWNERS_BAD_USER_ID()             { TA_OBJECT_OWNERS() + 2     }
sub TA_OBJECT_OWNERS_BAD_OBJECT_ID()           { TA_OBJECT_OWNERS() + 3     }
sub TA_OBJECT_OWNERS_BAD_OBJECT_TYPE()         { TA_OBJECT_OWNERS() + 4     }
sub TA_OBJECT_OWNERS_ALREADY_EXISTS()          { TA_OBJECT_OWNERS() + 5     }

sub TA_DELEGATED_OBJECTS()                     { ERROR_PACKET() + 0x0e00    }

sub TA_DELEGATED_OBJECTS_UNKNOWN()             { TA_DELEGATED_OBJECTS() + 1 }
sub TA_DELEGATED_OBJECTS_ALREADY_EXISTS()      { TA_DELEGATED_OBJECTS() + 2 }
sub TA_DELEGATED_OBJECTS_NOT_FOUND()           { TA_DELEGATED_OBJECTS() + 3 }

sub TA_LINKS()                                 { ERROR_PACKET() + 0x0f00    }

sub TA_LINKS_UNKNOWN()                         { TA_LINKS() + 1             }
sub TA_LINKS_ALREADY_EXISTS()                  { TA_LINKS() + 2             }
sub TA_LINKS_NOT_FOUND()                       { TA_LINKS() + 3             }

sub TA_EXPOSURES()                             { ERROR_PACKET() + 0x1000    }

sub TA_EXPOSURES_UNKNOWN()                     { TA_EXPOSURES() + 1         }
sub TA_EXPOSURES_NO_SERVER()                   { TA_EXPOSURES() + 2         }

sub TA_AD()                                    { ERROR_PACKET() + 0x1100    }
sub TA_BANNER()                                { ERROR_PACKET() + 0x1200    }
sub TA_PROFILE()                               { ERROR_PACKET() + 0x1300    }
sub TA_SLICE()                                 { ERROR_PACKET() + 0x1400    }

# sub TA_SLICE_UNKNOWN()                         { TA_IDDB_UNKNOWN()          }
# sub TA_SLICE_UNKNOWN_ID()                      { TA_IDDB_UNKNOWN_ID()       }
sub TA_SLICE_CANT_CHOOSE()                     { TA_IDDB() + 3              }
sub TA_SLICE_CANT_CHOOSE_NUMERIC()             { TA_IDDB() + 4              }
sub TA_SLICE_CANT_CHOOSE_PERCENT()             { TA_IDDB() + 5              }
sub TA_SLICE_FORWARDING()                      { TA_IDDB() + 6              }
sub TA_SLICE_NO_SLICES()                       { TA_IDDB() + 7              }
sub TA_SLICE_BAD_SITE_OWN_SLICES()             { TA_IDDB() + 8              }

sub TA_UNIQUE_USERS()                          { ERROR_PACKET() + 0x1500    }

sub TA_UNIQUE_USERS_UNKNOWN()                  { TA_UNIQUE_USERS() + 1      }
sub TA_UNIQUE_USERS_FILE()                     { TA_UNIQUE_USERS() + 2      }
sub TA_UNIQUE_USERS_USER_NOT_FOUND()           { TA_UNIQUE_USERS() + 3      }
sub TA_UNIQUE_USERS_BAD_SERVER()               { TA_UNIQUE_USERS() + 4      }
sub TA_UNIQUE_USERS_BANNER_NOT_FOUND()         { TA_UNIQUE_USERS() + 5      }

sub TA_ERROR_MESSAGE()                         { ERROR_PACKET() + 0x1600    }

sub TA_ERROR_MESSAGE_UNKNOWN()                 { TA_ERROR_MESSAGE() + 1     }
sub TA_ERROR_MESSAGE_BAD_ERROR_ID()            { TA_ERROR_MESSAGE() + 2     }
sub TA_ERROR_MESSAGE_ALREADY_EXISTS()          { TA_ERROR_MESSAGE() + 3     }

sub TA_COMMENT()                               { ERROR_PACKET() + 0x1700    }

sub TA_COMMENT_UNKNOWN()                       { TA_COMMENT() + 1           }
sub TA_COMMENT_NO_COMMENT()                    { TA_COMMENT() + 2           }
sub TA_COMMENT_BAD_OBJECT_TYPE()               { TA_COMMENT() + 3           }
sub TA_COMMENT_ALREADY_EXISTS()                { TA_COMMENT() + 4           }

sub TA_SIMPLE_NETWORK()                        { ERROR_PACKET() + 0x1800    }
sub TA_SIMPLE_NETWORK_AD()                     { ERROR_PACKET() + 0x1900    }
sub TA_SIMPLE_EXCHANGE_NETWORK()               { ERROR_PACKET() + 0x1a00    }
sub TA_SIMPLE_EXCHANGE_NETWORK_AD()            { ERROR_PACKET() + 0x1b00    }
sub TA_SIMPLE_EXCHANGE_NETWORK_SITE()          { ERROR_PACKET() + 0x1c00    }

sub TA_RLE_NETWORK()                           { ERROR_PACKET() + 0x1d00    }

sub TA_RLE_NETWORK_BAD_CAT_ID()                { TA_RLE_NETWORK() + 1       }

sub TA_RLE_NETWORK_AD()                        { ERROR_PACKET() + 0x1e00    }

sub TA_RLE_NETWORK_SITE()                      { ERROR_PACKET() + 0x1f00    }

sub TA_RLE_NETWORK_SITE_UNKNOWN()              { TA_RLE_NETWORK_SITE() + 1  }
sub TA_RLE_NETWORK_SITE_BAD_KEY()              { TA_RLE_NETWORK_SITE() + 2  }
sub TA_RLE_NETWORK_SITE_ALREADY_EXISTS()       { TA_RLE_NETWORK_SITE() + 3  }

sub TA_STAT_OPTIONS()                          { ERROR_PACKET() + 0x2000    }

sub TA_STAT_OPTIONS_UNKNOWN()                  { TA_STAT_OPTIONS() + 1      }
sub TA_STAT_OPTIONS_BAD_OBJECT_ID()            { TA_STAT_OPTIONS() + 2      }
sub TA_STAT_OPTIONS_BAD_OBJECT_TYPE()          { TA_STAT_OPTIONS() + 3      }
sub TA_STAT_OPTIONS_ALREADY_EXISTS()           { TA_STAT_OPTIONS() + 4      }

sub TA_MIRROR_ROUTING()                        { ERROR_PACKET() + 0x2100    }

sub TA_MIRROR_ROUTING_UNKNOWN()                { TA_MIRROR_ROUTING() + 1    }
sub TA_MIRROR_ROUTING_BAD_TRIPLE()             { TA_MIRROR_ROUTING() + 2    }
sub TA_MIRROR_ROUTING_BAD_IP_RANGE()           { TA_MIRROR_ROUTING() + 3    }
sub TA_MIRROR_ROUTING_TRIPLE_NOT_FOUND()       { TA_MIRROR_ROUTING() + 4    }
sub TA_MIRROR_ROUTING_BAD_IP_ORDER()           { TA_MIRROR_ROUTING() + 5    }
sub TA_MIRROR_ROUTING_MIRROR_NOT_FOUND()       { TA_MIRROR_ROUTING() + 6    }

sub TA_BAD_IP()                                { ERROR_PACKET() + 0x2200    }

sub TA_BAD_IP_UNKNOWN()                        { TA_BAD_IP() + 1            }
sub TA_BAD_IP_BAD_IP_PAIR()                    { TA_BAD_IP() + 2            }
sub TA_BAD_IP_BAD_IP_RANGE()                   { TA_BAD_IP() + 3            }
sub TA_BAD_IP_IP_NOT_FOUND()                   { TA_BAD_IP() + 4            }
sub TA_BAD_IP_BAD_IP_ORDER()                   { TA_BAD_IP() + 5            }

sub TA_SITE_TARGETING()                        { ERROR_PACKET() + 0x2300    }

sub TA_SITE_TARGETING_UNKNOWN()                { TA_SITE_TARGETING() + 1    }
sub TA_SITE_TARGETING_UNKNOWN_PROFILE()        { TA_SITE_TARGETING() + 2    }
sub TA_SITE_TARGETING_UNKNOWN_CHAIN()          { TA_SITE_TARGETING() + 3    }
sub TA_SITE_TARGETING_UNKNOWN_RULE()           { TA_SITE_TARGETING() + 4    }
sub TA_SITE_TARGETING_RULE_ALREADY_EXISTS()    { TA_SITE_TARGETING() + 5    }

sub TA_KEYWORD_TARGETING()                     { ERROR_PACKET() + 0x2400    }

sub TA_KEYWORD_TARGETING_UNKNOWN()             { TA_KEYWORD_TARGETING() + 1 }
sub TA_KEYWORD_TARGETING_UNKNOWN_PROFILE()     { TA_KEYWORD_TARGETING() + 2 }
sub TA_KEYWORD_TARGETING_UNKNOWN_CHAIN()       { TA_KEYWORD_TARGETING() + 3 }
sub TA_KEYWORD_TARGETING_UNKNOWN_RULE()        { TA_KEYWORD_TARGETING() + 4 }
sub TA_KEYWORD_TARGETING_RULE_ALREADY_EXISTS() { TA_KEYWORD_TARGETING() + 5 }

sub TA_IP_TARGETING()                          { ERROR_PACKET() + 0x2500    }

sub TA_IP_TARGETING_UNKNOWN()                  { TA_IP_TARGETING() + 1      }
sub TA_IP_TARGETING_UNKNOWN_PROFILE()          { TA_IP_TARGETING() + 2      }
sub TA_IP_TARGETING_UNKNOWN_CHAIN()            { TA_IP_TARGETING() + 3      }
sub TA_IP_TARGETING_UNKNOWN_RULE()             { TA_IP_TARGETING() + 4      }
sub TA_IP_TARGETING_RULE_ALREADY_EXISTS()      { TA_IP_TARGETING() + 5      }

sub TA_DATES_TARGETING()                       { ERROR_PACKET() + 0x2600    }

sub TA_DATES_TARGETING_UNKNOWN()               { TA_DATES_TARGETING() + 1   }
sub TA_DATES_TARGETING_UNKNOWN_PROFILE()       { TA_DATES_TARGETING() + 2   }
sub TA_DATES_TARGETING_UNKNOWN_CHAIN()         { TA_DATES_TARGETING() + 3   }
sub TA_DATES_TARGETING_UNKNOWN_RULE()          { TA_DATES_TARGETING() + 4   }
sub TA_DATES_TARGETING_RULE_ALREADY_EXISTS()   { TA_DATES_TARGETING() + 5   }

sub TA_CONTEXT_URLS()                          { ERROR_PACKET() + 0x2700    }
sub TA_CONTEXT_TARGETING()                     { ERROR_PACKET() + 0x2800    }

sub TA_CONTEXT_TARGETING_UNKNOWN()             { TA_CONTEXT_TARGETING() + 1 }
sub TA_CONTEXT_TARGETING_UNKNOWN_PROFILE()     { TA_CONTEXT_TARGETING() + 2 }
sub TA_CONTEXT_TARGETING_UNKNOWN_CHAIN()       { TA_CONTEXT_TARGETING() + 3 }
sub TA_CONTEXT_TARGETING_UNKNOWN_RULE()        { TA_CONTEXT_TARGETING() + 4 }
sub TA_CONTEXT_TARGETING_RULE_ALREADY_EXISTS() { TA_CONTEXT_TARGETING() + 5 }

sub TA_CONTEXT_WEIGHTS_URL()                   { ERROR_PACKET() + 0x2900    }
sub TA_RETARGETING()                           { ERROR_PACKET() + 0x2A00    }
sub TA_TRAIT_TARGETING()                       { ERROR_PACKET() + 0x2B00    }

sub TA_TRAIT_TARGETING_UNKNOWN()               { TA_TRAIT_TARGETING() + 1   }
sub TA_TRAIT_TARGETING_UNKNOWN_PROFILE()       { TA_TRAIT_TARGETING() + 2   }
sub TA_TRAIT_TARGETING_UNKNOWN_CHAIN()         { TA_TRAIT_TARGETING() + 3   }
sub TA_TRAIT_TARGETING_UNKNOWN_RULE()          { TA_TRAIT_TARGETING() + 4   }
sub TA_TRAIT_TARGETING_RULE_ALREADY_EXISTS()   { TA_TRAIT_TARGETING() + 5   }

sub TA_UNIQUE_USERS_TRAIT()                    { ERROR_PACKET() + 0x2C00    }
sub TA_MACRO()                                 { ERROR_PACKET() + 0x10000   }

sub TA_MACRO_UNKNOWN()                         { TA_MACRO() + 1             }
sub TA_MACRO_CANT_CHOOSE_BANNER()              { TA_MACRO() + 2             }
sub TA_MACRO_CANT_CHOOSE_PROFILE()             { TA_MACRO() + 3             }
sub TA_MACRO_BAD_REQUEST()                     { TA_MACRO() + 4             }
sub TA_MACRO_CREDIT_LOW()                      { TA_MACRO() + 5             }
sub TA_MACRO_BAD_CLICK()                       { TA_MACRO() + 6             }
sub TA_MACRO_NO_MIRROR()                       { TA_MACRO() + 7             }
sub TA_MACRO_CHEAT()                           { TA_MACRO() + 8             }
sub TA_MACRO_LOW_CREDIT()                      { TA_MACRO() + 9             }
sub TA_MACRO_URL_CHECK_FAILED()                { TA_MACRO() + 10            }
sub TA_MACRO_NO_SITE_CAT()                     { TA_MACRO() + 11            }
sub TA_MACRO_CANT_CHOOSE_AD()                  { TA_MACRO() + 12            }
sub TA_MACRO_BAD_NETWORK_TYPE()                { TA_MACRO() + 13            }
sub TA_MACRO_POOL_STACK_OVERFLOW()             { TA_MACRO() + 14            }
sub TA_MACRO_AD_DISABLED()                     { TA_MACRO() + 15            }
sub TA_MACRO_MAX_DEPTH()                       { TA_MACRO() + 16            }
sub TA_MACRO_AD_BAD()                          { TA_MACRO() + 17            }

1;
