package Adriver::BannerComponentType;

use strict;
use warnings;

use constant PICTURE => 0;
use constant TEXT    => 1;
use constant HTML    => 2;

1;
