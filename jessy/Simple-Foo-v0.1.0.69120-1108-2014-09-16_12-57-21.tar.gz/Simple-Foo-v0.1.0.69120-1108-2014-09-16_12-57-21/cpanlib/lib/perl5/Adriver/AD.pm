package Adriver::AD;

use strict;
use warnings;

use Readonly;

# Engine enables ( ENABLES_AD_ )
Readonly my %ENABLES => (

    HIDDEN                        => 0,
    MUST_UPLOAD_DEFAULT_BANNERS   => 1,
    COMM_INTERFACE                => 2,
    DEFAULT_BANNERS_WITH_MIN_MAX  => 3,
    CAN_TRANSFER_FROM             => 4,
    CAN_TRANSFER_TO               => 5,
    LOCATION_BANNER               => 6,
    TARG_DAYHOUR                  => 7,
    POSTMOD_BANNER                => 8,
    TARG_DAYMONTH                 => 9,
    TARG_GEO                      => 10,
    TARG_ORG                      => 11,
    TARG_ISP                      => 12,
    TARG_ID                       => 13,
    TARG_SLICE                    => 14,
    TARG_SITE_CATS                => 15,
    MANY_SITES                    => 16,
    MANY_SLICES_FROM_SITE         => 17,
    SLICES_FROM_OWN_SITES         => 18,
    DELEGATE                      => 19,
    OWN_CAN_TRANSFER_FROM         => 20,
    OWN_CAN_TRANSFER_TO           => 21,
    UNIQUE_AD_FROM_USER           => 22,
    SLICES_IN_REPAD               => 23,
    ANY_SITE_PRIORITY             => 24,
    DISABLE_NEGATIVE_BALANCE      => 25,

    UU_REPORT                     => 26,
    KGHS                          => 27,

    NO_SITE_CRED                  => 28,
    RESTRICTED_MODE               => 29,
    EXPOSURE                      => 30,
    CLICK                         => 31,

    RLE_PROFILES                  => 32,
    RLE_BANNER_MAXES              => 33,
    TARG_RLE_GEO_LITE             => 34,
    RLE_BANNER_STAT               => 35,
    RLE_PROFILE_STAT              => 36,
    RLE_AD_STAT                   => 37,
    TARG_RLE_BROWSERS             => 38,
    NEED_HELP                     => 39,
    RLE_SITE_STAT                 => 40,
    RLE_STOP                      => 41,
    ONLY_CLICK_BANNERS            => 42,
    ADMIN_ENABLE_UU_REPORT        => 43,
    BANNER_UU_REPORT              => 44,
    SALE                          => 45,
    CAN_USE_RETARGETING           => 46,
    TARG_RLE_OSES                 => 47,
    RLE_ANALYZE_STAT              => 48,
    CAN_CHANGE_PRIO_TARG          => 49,
    TARG_KEYWORD                  => 50,
    TARG_CONNECTION               => 51,
    CAN_DISABLE_POPUNDER_LOGO     => 52,
    SHOW_UU_REPORT                => 53,
    CTR_ROBOT                     => 54,
    REPAYMENT                     => 55,
    NO_SITE_OWNER_RESTRICT        => 56,
    PAY_FOR_EVENT0                => 57,
    DETAILED_PROFILE_SETTINGS     => 58,
    HIDE_BANNERS_FROM_SITE_OWNERS => 59,
    ENABLE_NEW_UU                 => 60,
    HIDE_PROFILE_PROBLEM_ICONS    => 61,
    TARG_IP                       => 62,
    MAY_USE_NETVIDEO              => 63,
    CREDITS_CONVERTED             => 64,
    TARG_TIME                     => 65,
    REPAYMENT_ALLOWED             => 66,
    REPAYMENT_DENIED              => 67,
    SHOW_UU_REACH                 => 68,
    TARG_TRAIT                    => 69,
    TT_REPORT                     => 70,
    TARG_CUSTOM                   => 71,
    LEAD                          => 72,
    TARG_AUDIT                    => 73,
    TARG_SEARCH                   => 74,
    USE_GOOGLEMETRIC              => 75,
    FULL_TRAIT_TARG               => 76,
    TARG_MANUFACTURER             => 77,
    BIJOU                         => 78,

);

Readonly my %ENABLE_NAMES => reverse %ENABLES;

sub GET_ENABLE_NAME {
    my $index = shift;
    return $ENABLE_NAMES{$index};
}

sub GET_ENABLE_INDEX {
    my $name = shift;
    return $ENABLES{$name};
}

sub SET_UU_REPORTING {
    my $ad = shift;
    $ad->{enables}->[$ENABLES{UU_REPORT}] = (
            $ad->{uniqueUserMaxShows}->[0]
         or $ad->{uniqueUserMaxShows}->[1]
         or $ad->{uniqueUserMaxShows}->[2]
         or $ad->{uniqueUserMaxClicks}
         or $ad->{uniqueUserMinInterval} ) ? 1 : 0;
    return $ad;
}

{
    no strict 'refs';
    foreach my $enable (keys %ENABLES)
    {
        *{__PACKAGE__ . "::$enable"} = sub () { $ENABLES{$enable} };
    }
}

1;
