package Adriver::ErrorMessage;

use strict;
use warnings;

use Adriver::ErrorCodes;

{

    my $code2msg =
    {
        Adriver::ErrorCodes::TA_NO_HANDLER()                            => 'ETDB No Handler',
        Adriver::ErrorCodes::TA_NO_BUFFER_SPACE()                       => 'ETDB No Buffer space',
        Adriver::ErrorCodes::TA_DISABLED()                              => 'ETDB Database disabled',
        Adriver::ErrorCodes::TA_UNKNOWN_COMMAND()                       => 'ETDB Unknown command',

        Adriver::ErrorCodes::TA_RLE3CONFIG_UNKNOWN()                    => 'RLE3CONFIG: unknown',

        Adriver::ErrorCodes::TA_GEO_HOUR_UNKNOWN()                      => 'GEOHOUR: unknown',
        Adriver::ErrorCodes::TA_GEO_HOUR_BAD_GEO_RANGE()                => 'GEOHOUR: bad geo range',
        Adriver::ErrorCodes::TA_GEO_HOUR_BAD_HOUR_RANGE()               => 'GEOHOUR: bad hour range',

        Adriver::ErrorCodes::TA_GEO_STAT_UNKNOWN()                      => 'GEOSTAT: unknown',
        Adriver::ErrorCodes::TA_GEO_STAT_BAD_SID()                      => 'GEOSTAT: bad sid',
        Adriver::ErrorCodes::TA_GEO_STAT_ALREADY_EXISTS()               => 'GEOSTAT: already exists',
        Adriver::ErrorCodes::TA_GEO_STAT_BAD_GEO_RANGE()                => 'GEOSTAT: bad geo range',

        Adriver::ErrorCodes::TA_GEO_UNKNOWN()                           => 'GEO: unknown',
        Adriver::ErrorCodes::TA_GEO_BAD_IP_PAIR()                       => 'GEO: bad ip pair',
        Adriver::ErrorCodes::TA_GEO_BAD_IP_RANGE()                      => 'GEO: bad ip range',
        Adriver::ErrorCodes::TA_GEO_IP_NOT_FOUND()                      => 'GEO: ip not found',
        Adriver::ErrorCodes::TA_GEO_BAD_IP_ORDER()                      => 'GEO: bad ip order',
        Adriver::ErrorCodes::TA_GEO_NO_SERVER()                         => 'GEO: no server',
        Adriver::ErrorCodes::TA_GEO_NO_SERVER_FOR_PAIR()                => 'GEO: no server for pair',

        Adriver::ErrorCodes::TA_IDDB_UNKNOWN()                          => 'IDDB: unknown request to ID-database',
        Adriver::ErrorCodes::TA_IDDB_UNKNOWN_ID()                       => 'IDDB: unknow ID',
        Adriver::ErrorCodes::TA_IDDB_USED_ID()                          => 'IDDB: ID already used',

        Adriver::ErrorCodes::TA_SITE_ZONE_UNKNOWN()                     => 'SITEZONE: unknown',
        Adriver::ErrorCodes::TA_SITE_ZONE_UNKNOWN_SID()                 => 'SITEZONE: unknown sid',
        Adriver::ErrorCodes::TA_SITE_ZONE_URL_NOT_FOUND()               => 'SITEZONE: url not found',
        Adriver::ErrorCodes::TA_SITE_ZONE_UNKNOWN_SZID()                => 'SITEZONE: unknown szid',
        Adriver::ErrorCodes::TA_SITE_ZONE_ALIAS_ALREADY_EXISTS()        => 'SITEZONE: alias already exists',
        Adriver::ErrorCodes::TA_SITE_ZONE_BAD_PAGE_ZONE()               => 'SITEZONE: bad page zone',

        Adriver::ErrorCodes::TA_USER_LOGIN_NOT_FOUND()                  => 'USERDB: login not found',
        Adriver::ErrorCodes::TA_USER_LOGIN_ALREADY_IN_USE()             => 'USERDB: login already in use',

        Adriver::ErrorCodes::TA_OBJECT_OWNERS_UNKNOWN()                 => 'OBJECTOWNERS: unknown',
        Adriver::ErrorCodes::TA_OBJECT_OWNERS_BAD_USER_ID()             => 'OBJECTOWNERS: bad user id',
        Adriver::ErrorCodes::TA_OBJECT_OWNERS_BAD_OBJECT_ID()           => 'OBJECTOWNERS: bad object id',
        Adriver::ErrorCodes::TA_OBJECT_OWNERS_BAD_OBJECT_TYPE()         => 'OBJECTOWNERS: bad object type',
        Adriver::ErrorCodes::TA_OBJECT_OWNERS_ALREADY_EXISTS()          => 'OBJECTOWNERS: already exists',

        Adriver::ErrorCodes::TA_DELEGATED_OBJECTS_UNKNOWN()             => 'DELEGATEDOBJECTS: unknown',
        Adriver::ErrorCodes::TA_DELEGATED_OBJECTS_ALREADY_EXISTS()      => 'DELEGATEDOBJECTS: already exists',
        Adriver::ErrorCodes::TA_DELEGATED_OBJECTS_NOT_FOUND()           => 'DELEGATEDOBJECTS: not found',

        Adriver::ErrorCodes::TA_LINKS_UNKNOWN()                         => 'LINKS: unknown',
        Adriver::ErrorCodes::TA_LINKS_ALREADY_EXISTS()                  => 'LINKS: already exists',
        Adriver::ErrorCodes::TA_LINKS_NOT_FOUND()                       => 'LINKS: not found',

        Adriver::ErrorCodes::TA_EXPOSURES_UNKNOWN()                     => 'EXPOSURES: unknown',
        Adriver::ErrorCodes::TA_EXPOSURES_NO_SERVER()                   => 'EXPOSURES: no server',

        Adriver::ErrorCodes::TA_SLICE_CANT_CHOOSE()                     => 'SLICE: cant choose',
        Adriver::ErrorCodes::TA_SLICE_CANT_CHOOSE_NUMERIC()             => 'SLICE: cant choose numeric',
        Adriver::ErrorCodes::TA_SLICE_CANT_CHOOSE_PERCENT()             => 'SLICE: cant choose percent',
        Adriver::ErrorCodes::TA_SLICE_FORWARDING()                      => 'SLICE: forwarding',
        Adriver::ErrorCodes::TA_SLICE_NO_SLICES()                       => 'SLICE: no slices',
        Adriver::ErrorCodes::TA_SLICE_BAD_SITE_OWN_SLICES()             => 'SLICE: bad site own slices',

        Adriver::ErrorCodes::TA_UNIQUE_USERS_UNKNOWN()                  => 'UNIQUEUSERS: unknown',
        Adriver::ErrorCodes::TA_UNIQUE_USERS_FILE()                     => 'UNIQUEUSERS: file',
        Adriver::ErrorCodes::TA_UNIQUE_USERS_USER_NOT_FOUND()           => 'UNIQUEUSERS: user not found',
        Adriver::ErrorCodes::TA_UNIQUE_USERS_BAD_SERVER()               => 'UNIQUEUSERS: bad server',
        Adriver::ErrorCodes::TA_UNIQUE_USERS_BANNER_NOT_FOUND()         => 'UNIQUEUSERS: banner not found',

        Adriver::ErrorCodes::TA_ERROR_MESSAGE_UNKNOWN()                 => 'ERRORMESSAGE: unknown',
        Adriver::ErrorCodes::TA_ERROR_MESSAGE_BAD_ERROR_ID()            => 'ERRORMESSAGE: bad error id',
        Adriver::ErrorCodes::TA_ERROR_MESSAGE_ALREADY_EXISTS()          => 'ERRORMESSAGE: already exists',

        Adriver::ErrorCodes::TA_COMMENT_UNKNOWN()                       => 'COMMENT: unknown',
        Adriver::ErrorCodes::TA_COMMENT_NO_COMMENT()                    => 'COMMENT: no comment',
        Adriver::ErrorCodes::TA_COMMENT_BAD_OBJECT_TYPE()               => 'COMMENT: bad object type',
        Adriver::ErrorCodes::TA_COMMENT_ALREADY_EXISTS()                => 'COMMENT: already exists',

        Adriver::ErrorCodes::TA_STAT_OPTIONS_UNKNOWN()                  => 'STATOPTIONS: unknown',
        Adriver::ErrorCodes::TA_STAT_OPTIONS_BAD_OBJECT_ID()            => 'STATOPTIONS: bad object id',
        Adriver::ErrorCodes::TA_STAT_OPTIONS_BAD_OBJECT_TYPE()          => 'STATOPTIONS: bad object type',
        Adriver::ErrorCodes::TA_STAT_OPTIONS_ALREADY_EXISTS()           => 'STATOPTIONS: already exists',

        Adriver::ErrorCodes::TA_RLE_NETWORK_BAD_CAT_ID()                => 'RLE_NETWORK: unknown category ID',

        Adriver::ErrorCodes::TA_RLE_NETWORK_SITE_UNKNOWN()              => 'RLE_NETWORK_SITE: unknown',
        Adriver::ErrorCodes::TA_RLE_NETWORK_SITE_BAD_KEY()              => 'RLE_NETWORK_SITE: bad key',
        Adriver::ErrorCodes::TA_RLE_NETWORK_SITE_ALREADY_EXISTS()       => 'RLE_NETWORK_SITE: key already exists',

        Adriver::ErrorCodes::TA_MIRROR_ROUTING_UNKNOWN()                => 'MIRRORROUTING: unknown',
        Adriver::ErrorCodes::TA_MIRROR_ROUTING_BAD_TRIPLE()             => 'MIRRORROUTING: bad triple',
        Adriver::ErrorCodes::TA_MIRROR_ROUTING_BAD_IP_RANGE()           => 'MIRRORROUTING: bad ip range',
        Adriver::ErrorCodes::TA_MIRROR_ROUTING_TRIPLE_NOT_FOUND()       => 'MIRRORROUTING: triple not found',
        Adriver::ErrorCodes::TA_MIRROR_ROUTING_BAD_IP_ORDER()           => 'MIRRORROUTING: bad ip order',
        Adriver::ErrorCodes::TA_MIRROR_ROUTING_MIRROR_NOT_FOUND()       => 'MIRRORROUTING: mirror not found',

        Adriver::ErrorCodes::TA_BAD_IP_UNKNOWN()                        => 'BADIP: unknown',
        Adriver::ErrorCodes::TA_BAD_IP_BAD_IP_PAIR()                    => 'BADIP: bad ip pair',
        Adriver::ErrorCodes::TA_BAD_IP_BAD_IP_RANGE()                   => 'BADIP: bad ip range',
        Adriver::ErrorCodes::TA_BAD_IP_IP_NOT_FOUND()                   => 'BADIP: ip not found',
        Adriver::ErrorCodes::TA_BAD_IP_BAD_IP_ORDER()                   => 'BADIP: bad ip order',

        Adriver::ErrorCodes::TA_SITE_TARGETING_UNKNOWN()                => 'SITE_TARGETING: unknown',
        Adriver::ErrorCodes::TA_SITE_TARGETING_UNKNOWN_PROFILE()        => 'SITE_TARGETING: unknown profile',
        Adriver::ErrorCodes::TA_SITE_TARGETING_UNKNOWN_CHAIN()          => 'SITE_TARGETING: unknown chain',
        Adriver::ErrorCodes::TA_SITE_TARGETING_UNKNOWN_RULE()           => 'SITE_TARGETING: unknown rule',
        Adriver::ErrorCodes::TA_SITE_TARGETING_RULE_ALREADY_EXISTS()    => 'SITE_TARGETING: rule already exists',

        Adriver::ErrorCodes::TA_KEYWORD_TARGETING_UNKNOWN()             => 'KEYWORDTARGETING: unknown',
        Adriver::ErrorCodes::TA_KEYWORD_TARGETING_UNKNOWN_PROFILE()     => 'KEYWORDTARGETING: unknown profile',
        Adriver::ErrorCodes::TA_KEYWORD_TARGETING_UNKNOWN_CHAIN()       => 'KEYWORDTARGETING: unknown chain',
        Adriver::ErrorCodes::TA_KEYWORD_TARGETING_UNKNOWN_RULE()        => 'KEYWORDTARGETING: unknown rule',
        Adriver::ErrorCodes::TA_KEYWORD_TARGETING_RULE_ALREADY_EXISTS() => 'KEYWORDTARGETING: rule already exists',

        Adriver::ErrorCodes::TA_IP_TARGETING_UNKNOWN()                  => 'IPTARGETING: unknown',
        Adriver::ErrorCodes::TA_IP_TARGETING_UNKNOWN_PROFILE()          => 'IPTARGETING: unknown profile',
        Adriver::ErrorCodes::TA_IP_TARGETING_UNKNOWN_CHAIN()            => 'IPTARGETING: chain',
        Adriver::ErrorCodes::TA_IP_TARGETING_UNKNOWN_RULE()             => 'IPTARGETING: rule',
        Adriver::ErrorCodes::TA_IP_TARGETING_RULE_ALREADY_EXISTS()      => 'IPTARGETING: rule already exists',

        Adriver::ErrorCodes::TA_DATES_TARGETING_UNKNOWN()               => 'DATESTARGETING: unknown',
        Adriver::ErrorCodes::TA_DATES_TARGETING_UNKNOWN_PROFILE()       => 'DATESTARGETING: unknown profile',
        Adriver::ErrorCodes::TA_DATES_TARGETING_UNKNOWN_CHAIN()         => 'DATESTARGETING: unknown chain',
        Adriver::ErrorCodes::TA_DATES_TARGETING_UNKNOWN_RULE()          => 'DATESTARGETING: unknown rule',
        Adriver::ErrorCodes::TA_DATES_TARGETING_RULE_ALREADY_EXISTS()   => 'DATESTARGETING: rule already exists',

        Adriver::ErrorCodes::TA_CONTEXT_TARGETING_UNKNOWN()             => 'CONTEXTTARGETING: unknown',
        Adriver::ErrorCodes::TA_CONTEXT_TARGETING_UNKNOWN_PROFILE()     => 'CONTEXTTARGETING: unknown profile',
        Adriver::ErrorCodes::TA_CONTEXT_TARGETING_UNKNOWN_CHAIN()       => 'CONTEXTTARGETING: unknown chain',
        Adriver::ErrorCodes::TA_CONTEXT_TARGETING_UNKNOWN_RULE()        => 'CONTEXTTARGETING: unknown rule',
        Adriver::ErrorCodes::TA_CONTEXT_TARGETING_RULE_ALREADY_EXISTS() => 'CONTEXTTARGETING: rule already exists',

        Adriver::ErrorCodes::TA_TRAIT_TARGETING_UNKNOWN()               => 'TRAITTARGETING: unknown',
        Adriver::ErrorCodes::TA_TRAIT_TARGETING_UNKNOWN_PROFILE()       => 'TRAITTARGETING: unknown profile',
        Adriver::ErrorCodes::TA_TRAIT_TARGETING_UNKNOWN_CHAIN()         => 'TRAITTARGETING: unknown chain',
        Adriver::ErrorCodes::TA_TRAIT_TARGETING_UNKNOWN_RULE()          => 'TRAITTARGETING: unknown rule',
        Adriver::ErrorCodes::TA_TRAIT_TARGETING_RULE_ALREADY_EXISTS()   => 'TRAITTARGETING: rule already exists',

        Adriver::ErrorCodes::TA_MACRO_UNKNOWN()                         => 'MACRO: unknown',
        Adriver::ErrorCodes::TA_MACRO_CANT_CHOOSE_BANNER()              => 'MACRO: cant choose banner',
        Adriver::ErrorCodes::TA_MACRO_CANT_CHOOSE_PROFILE()             => 'MACRO: cant choose profile',
        Adriver::ErrorCodes::TA_MACRO_BAD_REQUEST()                     => 'MACRO: bad request',
        Adriver::ErrorCodes::TA_MACRO_CREDIT_LOW()                      => 'MACRO: credit low',
        Adriver::ErrorCodes::TA_MACRO_BAD_CLICK()                       => 'MACRO: bad click',
        Adriver::ErrorCodes::TA_MACRO_NO_MIRROR()                       => 'MACRO: no mirror',
        Adriver::ErrorCodes::TA_MACRO_CHEAT()                           => 'MACRO: cheat',
        Adriver::ErrorCodes::TA_MACRO_LOW_CREDIT()                      => 'MACRO: low credit',
        Adriver::ErrorCodes::TA_MACRO_URL_CHECK_FAILED()                => 'MACRO: url check failed',
        Adriver::ErrorCodes::TA_MACRO_NO_SITE_CAT()                     => 'MACRO: no site cat',
        Adriver::ErrorCodes::TA_MACRO_CANT_CHOOSE_AD()                  => 'MACRO: cant choose ad',
        Adriver::ErrorCodes::TA_MACRO_BAD_NETWORK_TYPE()                => 'MACRO: bad network type',
        Adriver::ErrorCodes::TA_MACRO_POOL_STACK_OVERFLOW()             => 'MACRO: pool stack overflow',
        Adriver::ErrorCodes::TA_MACRO_AD_DISABLED()                     => 'MACRO: ad disabled',
        Adriver::ErrorCodes::TA_MACRO_MAX_DEPTH()                       => 'MACRO: max depth',
        Adriver::ErrorCodes::TA_MACRO_AD_BAD()                          => 'MACRO: ad bad',
    };

    # construct error message from Error code and messages
    sub error_message
    {
        my $e = shift;
        my $message = '';
        $message = join ' ', @{ $e->{'messages'} } if ( defined $e->{'messages'} );
        return $code2msg->{ $e->{'code'} }
            ? 'Error ' . $code2msg->{ $e->{'code'} } . ': ' . $message
            : 'Error ' . $e->{'code'} . ': ' . ( $message || 'unknown' );
    }

}

1;
