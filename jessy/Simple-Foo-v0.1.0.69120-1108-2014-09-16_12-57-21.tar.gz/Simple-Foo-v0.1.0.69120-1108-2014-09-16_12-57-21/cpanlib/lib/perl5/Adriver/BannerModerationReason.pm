package Adriver::BannerModerationReason;

use strict;
use warnings;

use Readonly;

Readonly my %REASON_BY_NAME => (
    NEW_BANNER => {
        code => 0,
        desc => 'new banner',
    },
    NEW_URL => {
        code => 1,
        desc => 'new url',
    },
    NEW_ALT => {
        code => 2,
        desc => 'new alt',
    },
    NEW_LOC => {
        code => 3,
        desc => 'new location',
    },
    UPLOAD_BANNER => {
        code => 4,
        desc => 'new components (reloaded)',
    },
    SITE_NAKR => {
        code => 5,
        desc => 'exp cheating (on site) suspects',
    },
    NO_AUTO_CAT => {
        code => 6,
        desc => 'automatic categorization impossible',
    },
    AUTO_CAT => {
        code => 7,
        desc => 'automatic categorization',
    },
    CAZINO => {
        code => 8,
        desc => 'gambling games',
    },

);

Readonly my %REASON_BY_CODE => map { $REASON_BY_NAME{$_}->{code} => { name => $_, desc => $REASON_BY_NAME{$_}->{desc} } } keys %REASON_BY_NAME;

{
    no strict 'refs';
    foreach my $reason (keys %REASON_BY_NAME)
    {
        *{__PACKAGE__ . "::$reason"} = sub () { $REASON_BY_NAME{$reason}->{code} };
    }
}

sub GET_REASON_NAME {
    my $code = shift;
    return $REASON_BY_CODE{$code}->{name};
}

sub GET_REASON_CODE {
    my $name = shift;
    return $REASON_BY_NAME{$name}->{code};
}

sub GET_REASON_DESC {
    my $param = shift;
    return ($param =~ /^\d+$/) ? $REASON_BY_CODE{$param}->{desc} : $REASON_BY_NAME{$param}->{desc};
}

1;
