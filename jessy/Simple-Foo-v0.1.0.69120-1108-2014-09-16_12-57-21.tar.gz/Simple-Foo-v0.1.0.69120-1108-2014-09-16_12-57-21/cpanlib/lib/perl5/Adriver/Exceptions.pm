package Adriver::Exceptions;

use strict;
use warnings;

use Exception::Class (

    # Adriver Exceprions
    'Adriver::Exceptions' =>
    {
        description => 'Base class for Adriver exceptions',
    }

);

Adriver::Exceptions->Trace(1);

1;
