package Adriver::DBI::Targeting::Trait;

use strict;

sub ALLOW           () { return 0; }
sub DENY            () { return 1; }
sub NOP             () { return 0; }
sub OR              () { return 1; }
sub AND             () { return 2; }
sub DEFAULT_CHAINID () { return 1; }

# 'prohibited' => BOOL (ALLOW = 0, DENY (prohibited) = 1)
# 'operation'  => INT  (NO_OPERATION = 0, OR = 1, AND = 2)

1;
