package Adriver::NetSite;

use strict;
use warnings;

# Engine enables ( ENABLES_NETSITE_ )
use constant
{

  OWNER_CAN_CHANGE_CAT      => 0,
  OWNER_CAN_CHANGE_ADTAR    => 1,
  MUST_CHECK_URLES          => 2,
  DONT_WARN_IF_HTTP_ALIAS   => 3,
  RLE_SHOW_ALIASES          => 4,
  NO_GOLD                   => 5,
  NAKR_TRUSTED              => 6,
  OWNER_CAN_CHANGE_CATTAR   => 7,
  OWNER_CAN_CHANGE_LABELTAR => 8,
  CREDITS_CONVERTED         => 9,
  CREDITS_CONVERTED_AGAIN   => 10,
  MAY_TWO_BANNERS           => 11,
  AD_CAT_TARG_LOGIC         => 30,

};

1;
