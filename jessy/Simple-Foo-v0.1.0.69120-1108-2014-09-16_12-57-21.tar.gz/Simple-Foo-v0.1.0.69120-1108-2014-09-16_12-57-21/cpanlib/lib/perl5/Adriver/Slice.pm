package Adriver::Slice;

use strict;
use warnings;

use Readonly;

# Slice types
use constant PERCENT => 1;
use constant NUMBER  => 2;
use constant DEFAULT => 3;
use constant DRAIN   => 4;

# Engine enables ( ENABLES_SLICE_ )
Readonly my %ENABLES => (

    STOPPED_BY_PB      => 0,
    NO_NET_SITE_UPDATE => 1,
    DSP                => 2,
    INVERTED_SITEZONE  => 30,
    PERCENT_REBALANCE  => 31,

);

Readonly my %ENABLE_NAMES => reverse %ENABLES;

sub GET_ENABLE_NAME {
    my $index = shift;
    return $ENABLE_NAMES{$index};
}

sub GET_ENABLE_INDEX {
    my $name = shift;
    return $ENABLES{$name};
}

{
    no strict 'refs';
    foreach my $enable (keys %ENABLES)
    {
        *{__PACKAGE__ . "::$enable"} = sub () { $ENABLES{$enable} };
    }
}

1;
