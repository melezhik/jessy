package Adriver::ObjectType;

use strict;
use warnings;

# Define object types accordingly with C++ code convention

use constant UNKNOWN                    => 0;
use constant AD                         => 1;
use constant SITE                       => 2;
use constant PROFILE                    => 3;
use constant BANNER                     => 4;
use constant SLICE                      => 5;
use constant EXCHANGE_NETWORK           => 6;
use constant USER                       => 7;
use constant POOL                       => 8;
use constant SIMPLE_NETWORK             => 9;
use constant SIMPLE_NETWORK_AD          => 10;
use constant SIMPLE_EXCHANGE_NETWORK    => 11;
use constant SIMPLE_EXCHANGE_NETWORK_AD => 12;
use constant RLE_NETWORK                => 13;
use constant RLE_NETWORK_AD             => 14;

1;
