package Adriver::UserType;

use strict;
use warnings;

# 0 - Admin
# 1 - AA
# 2 - SimpleAdmin
# 4 - PB
# 8 - Guest

use constant ADMIN        => 0;
use constant AA           => 1;
use constant SIMPLE_ADMIN => 2;
use constant PB           => 4;
use constant GUEST        => 8;

1;
