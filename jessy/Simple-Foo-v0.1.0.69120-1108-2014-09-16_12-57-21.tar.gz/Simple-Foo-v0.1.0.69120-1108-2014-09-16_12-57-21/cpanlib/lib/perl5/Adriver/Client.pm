package Adriver::Client;

use strict;
use warnings;

use Carp;
use Params::Validate qw(:all);

use Adriver::DBI::Exceptions;

validation_options(on_fail => sub{ Adriver::DBI::Exceptions::ParamsValidation->throw(error => $_[0]); });

#
# new ({class=>'RLE::ADClient', socket=> $client_socket})
# needs a redisign think about insede-out class schema
#

sub new
{
    validate_pos(@_, { type => SCALAR }, { type => HASHREF });

    my ($class, $args_ref) = @_;
    my $client = bless {}, $class;
    $client->{'sock'} = $args_ref->{'socket'};
    $client->{'client_class'} = $args_ref->{'class'};
    eval "use $client->{'client_class'}";
    $client->{'client'} = $client->{'client_class'}->new($client->{'sock'}->fd());
    if ( not defined $client->{'client'} )
    {
        Adriver::DBI::Exceptions->throw(error => "Client constructraction $client->{'client_class'} failed.");
    }
    return $client;
}

sub client
{
    validate_pos(@_, { type => OBJECT });
    my $self = shift;
    return $self->{'client'};
}

sub DESTROY
{
    my $self = shift;
    delete $self->{'client'};
    delete $self->{'sock'};
    delete $self->{'client_class'};
    return;
}

1;

__END__


=head1 NAME

    Adriver::Client - this module used to unify creating various Adriver::DBI::Clients classes objects and access to them.


=head1 DESCRIPTION

    You should not use this module directly. It's used inside Adriver::DBI::Base class.


=head1 CLASS INTERFACE

=head2 new($config) : Adriver::Client object

    Create the new object of class. Also here we create internal object of some Adriver::DBI::Client class here.

B<config>

    This is a hash reference with next keys:
    <socket> - this is an object returned by get_connect() method of Adriver::DatabaseConnect::BaseConnect object;
    <class>  - this is a name of some Adriver::DBI::Client class we want to create.

B<Exceptions>

    Adriver::DBI::Exceptions::ParamsValidation
    Adriver::DBI::Exceptions


=head1 OBJECT INTERFACE

=head2 client() : some Adriver::DBI::Client class object

    This method returns created in new() constructor object of some Adriver::DBI::Client class.

B<Exceptions>

    Adriver::DBI::Exceptions::ParamsValidation

=head2 DESTROY

    Destructor deletes all internal information.


=head1 SEE ALSO

    Adriver::DBI::Base
    Adriver::DBI::Exceptions
    Adriver::DatabaseConnect::BaseConnect

