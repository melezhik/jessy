package Adriver::Site;

use strict;
use warnings;

# Engine enables ( ENABLES_SITE_ )
use constant
{

    FORCE_DRAIN                   => 5,
    DELETED                       => 6,
    MERGED                        => 7,
    MAYNOT_USE_COMMISSION_TRAFFIC => 8,
    ADD_SLICES_ENABLED            => 9,
    SLICES_TARG_TRAIT             => 10,
    SLICES_TARG_ORG               => 11,
    SLICES_TARG_IP                => 12,
    SLICES_TARG_CUSTOM            => 13,
    SHOW_SZ_FILTER                => 14,
    FIXED_SZ_PRIORITY             => 15,
    UNUSED                        => 16,
    TT_REPORT                     => 27,
    DRAIN_CLICK_DONT_USE_SITE_URL => 28,
    STAT_REPORT                   => 29,
    BANNER_TARGET                 => 30,
    UU_REPORT                     => 31,

};

1;
