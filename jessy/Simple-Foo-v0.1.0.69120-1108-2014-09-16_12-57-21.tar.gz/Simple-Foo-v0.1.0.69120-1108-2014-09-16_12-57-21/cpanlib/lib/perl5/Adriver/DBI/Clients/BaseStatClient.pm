package Adriver::DBI::Clients::BaseStatClient;

use strict;
our $VERSION = '0.0300';
use Carp;
use Params::Validate qw(:all);
use base qw ( Adriver::DBI::Clients::Base );

validation_options(on_fail => sub { Adriver::DBI::Exceptions::ParamsValidation->throw( error => $_[0]); } );

#### List of common methods for StatClients
#
## Get begindate, enddate and diff (in weeks)
#
# GetDaysCount (HASHREF ClientElemRequestParamsHashRef)
#
## Get total stat for Elem
#
# GetTotal(HASHREF ClientElemRequestParamsHashRef)
#
## Get total stats for list of Elems with ElemIDs
#
# GetTable(ARRAYREF of INT ElemIDs, HASHREF ClientElemRequestParamsHashRef)
#
## Get geo stat for Elem
## If GeoIDs specified only for this GeoIDs
## If GeoIDs empty for all GeoIDs
#
# GetGeo(ARRAYREF of INT GeoIDs, HASHREF ClientElemRequestParamsHashRef)
#
## By days
#
# GetMonthDay(HASHREF ClientElemRequestParamsHashRef)
#
## Average by weekday
#
# GetWeekDay(HASHREF ClientElemRequestParamsHashRef)
#
## Average by dayhour
#
# GetDayHour(HASHREF ClientElemRequestParamsHashRef)
#
## UNKNOWN (?Universal stat request?)
#
# GetUniStat(HASHREF ClientElemRequestParamsHashRef)
#
## UNKNOWN (?Geo stat by days?)
#
# GetGeoDays(HASHREF ClientElemRequestParamsHashRef)
#
#### Input Data Info
#
# StatRequestHashRef
#
####

sub GetDaysCount
{
    validate_pos(@_, { type => OBJECT }, { type => HASHREF });
    my ($self, @args) = @_;

    my $result;
    eval { $result = $self->{client}->GetDaysCount(@args); };
    if (my $e = Adriver::DBI::Exceptions::DBError->caught())
    {
        Adriver::DBI::Exceptions::Clients->throw(
            error  => Adriver::ErrorMessage::error_message($e),
            code   => $e->{code},
            method => 'GetDaysCount',
            args   => \@args
        );
    }

    return $result;
}

sub GetTotal
{
    validate_pos(@_, { type => OBJECT }, { type => HASHREF });
    my ($self, @args) = @_;

    my $result;
    eval { $result = $self->{client}->GetTotal(@args); };
    if (my $e = Adriver::DBI::Exceptions::DBError->caught())
    {
        Adriver::DBI::Exceptions::Clients->throw(
            error  => Adriver::ErrorMessage::error_message($e),
            code   => $e->{code},
            method => 'GetTotal',
            args   => \@args
        );
    }

    return $result;
}

sub GetTable
{
    validate_pos(@_, { type => OBJECT }, { type => ARRAYREF }, { type => HASHREF });
    my ($self, @args) = @_;

    my $result;
    eval { $result = $self->{client}->GetTable(@args); };
    if (my $e = Adriver::DBI::Exceptions::DBError->caught())
    {
        Adriver::DBI::Exceptions::Clients->throw(
            error  => Adriver::ErrorMessage::error_message($e),
            code   => $e->{code},
            method => 'GetTable',
            args   => \@args
        );
    }

    return $result;
}

sub GetGeo
{
    validate_pos(@_, { type => OBJECT }, { type => ARRAYREF }, { type => HASHREF });
    my ($self, @args) = @_;

    my $result;
    eval { $result = $self->{client}->GetGeo(@args); };
    if (my $e = Adriver::DBI::Exceptions::DBError->caught())
    {
        Adriver::DBI::Exceptions::Clients->throw(
            error  => Adriver::ErrorMessage::error_message($e),
            code   => $e->{code},
            method => 'GetGeo',
            args   => \@args
        );
    }

    return $result;
}

sub GetMonthDay
{
    validate_pos(@_, { type => OBJECT }, { type => HASHREF });
    my ($self, @args) = @_;

    my $result;
    eval { $result = $self->{client}->GetMonthDay(@args); };
    if (my $e = Adriver::DBI::Exceptions::DBError->caught())
    {
        Adriver::DBI::Exceptions::Clients->throw(
            error  => Adriver::ErrorMessage::error_message($e),
            code   => $e->{code},
            method => 'GetMonthDay',
            args   => \@args
        );
    }

    return $result;
}

sub GetWeekDay
{
    validate_pos(@_, { type => OBJECT }, { type => HASHREF });
    my ($self, @args) = @_;

    my $result;
    eval { $result = $self->{client}->GetWeekDay(@args); };
    if (my $e = Adriver::DBI::Exceptions::DBError->caught())
    {
        Adriver::DBI::Exceptions::Clients->throw(
            error  => Adriver::ErrorMessage::error_message($e),
            code   => $e->{code},
            method => 'GetWeekDay',
            args   => \@args
        );
    }

    return $result;
}

sub GetDayHour
{
    validate_pos(@_, { type => OBJECT }, { type => HASHREF });
    my ($self, @args) = @_;

    my $result;
    eval { $result = $self->{client}->GetDayHour(@args); };
    if (my $e = Adriver::DBI::Exceptions::DBError->caught())
    {
        Adriver::DBI::Exceptions::Clients->throw(
            error  => Adriver::ErrorMessage::error_message($e),
            code   => $e->{code},
            method => 'GetDayHour',
            args   => \@args
        );
    }

    return $result;
}

sub GetUniStat
{
    validate_pos(@_, { type => OBJECT }, { type => HASHREF });
    my ($self, @args) = @_;

    my $result;
    eval { $result = $self->{client}->GetUniStat(@args); };
    if (my $e = Adriver::DBI::Exceptions::DBError->caught())
    {
        Adriver::DBI::Exceptions::Clients->throw(
            error  => Adriver::ErrorMessage::error_message($e),
            code   => $e->{code},
            method => 'GetUniStat',
            args   => \@args
        );
    }

    return $result;
}

sub GetGeoDays
{
    validate_pos(@_, { type => OBJECT }, { type => HASHREF });
    my ($self, @args) = @_;

    my $result;
    eval { $result = $self->{client}->GetGeoDays(@args); };
    if (my $e = Adriver::DBI::Exceptions::DBError->caught())
    {
        Adriver::DBI::Exceptions::Clients->throw(
            error  => Adriver::ErrorMessage::error_message($e),
            code   => $e->{code},
            method => 'GetGeoDays',
            args   => \@args
        );
    }

    return $result;
}

1;


__END__


=head1 NAME

    Adriver::DBI::Clients::BaseStatClient - this is a base class for Stat clients classes.


=head1 DESCRIPTION

    You should not use this module directly.
    This module is inherited from Adriver::DBI::Clients::Base class.


=head1 OBJECT INTERFACE

=head2 GetDaysCount($ClientElemRequestParamsHashRef)

    Get begindate, enddate and diff (in weeks).

B<Exceptions>

    Adriver::DBI::Exceptions::ParamsValidation
    Adriver::DBI::Exceptions::Clients

=head2 GetTotal($ClientElemRequestParamsHashRef)

    Get total stat for Elem.

B<Exceptions>

    Adriver::DBI::Exceptions::ParamsValidation
    Adriver::DBI::Exceptions::Clients

=head2 GetTable($ElemIDs, $ClientElemRequestParamsHashRef)

    Get total stats for list of Elems with ElemIDs.

B<ElemIDs>

    ARRAYREF of INT ElemIDs.

B<Exceptions>

    Adriver::DBI::Exceptions::ParamsValidation
    Adriver::DBI::Exceptions::Clients

=head2 GetGeo($GeoIDs, $ClientElemRequestParamsHashRef)

    Get geo stat for Elems.
    If GeoIDs specified only for this GeoIDs.
    If GeoIDs empty for all GeoIDs.

B<GeoIDs>

    ARRAYREF of INT GeoIDs.

B<Exceptions>

    Adriver::DBI::Exceptions::ParamsValidation
    Adriver::DBI::Exceptions::Clients

=head2 GetMonthDay($ClientElemRequestParamsHashRef)

    By days.

B<Exceptions>

    Adriver::DBI::Exceptions::ParamsValidation
    Adriver::DBI::Exceptions::Clients

=head2 GetWeekDay($ClientElemRequestParamsHashRef)

    Average by weekday.

B<Exceptions>

    Adriver::DBI::Exceptions::ParamsValidation
    Adriver::DBI::Exceptions::Clients

=head2 GetDayHour($ClientElemRequestParamsHashRef)

    Average by dayhour.

B<Exceptions>

    Adriver::DBI::Exceptions::ParamsValidation
    Adriver::DBI::Exceptions::Clients

=head2 GetUniStat($ClientElemRequestParamsHashRef)

    UNKNOWN (?Universal stat request?).

B<Exceptions>

    Adriver::DBI::Exceptions::ParamsValidation
    Adriver::DBI::Exceptions::Clients

=head2 GetGeoDays($ClientElemRequestParamsHashRef)

    UNKNOWN (?Geo stat by days?) 

B<Exceptions>

    Adriver::DBI::Exceptions::ParamsValidation
    Adriver::DBI::Exceptions::Clients


=head1 SEE ALSO

    Adriver::DBI::Exceptions
    Adriver::DBI::Clients::Base

