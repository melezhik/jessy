package Adriver::DBI::Clients::RLENetworkSiteClient;

use strict;
our $VERSION = '0.0300';
use Carp;
use Params::Validate qw(:all);
use base qw ( Adriver::DBI::Clients::Base );

validation_options(on_fail => sub { Adriver::DBI::Exceptions::ParamsValidation->throw( error => $_[0]); } );

sub package { 'RLE::RLENetwork::RLENetworkSiteClient' }

#### Functions
#
## Get networksite with RLENetworkSiteID from RLENetworkID
#
# (HASHREF RLENetworkSiteHashRef) get(INT RLENetworkID, INT RLENetworkSiteID)
#
## Get all networksites from network
#
# getall(INT RLENetworkID)
#
## Set, add or remove networksite
#
# (INT 1) set(HASHREF RLENetworkSiteHashRef)
# (INT 1) add(HASHREF RLENetworkSiteHashRef)
# (INT 1) remove(HASHREF RLENetworkSiteHashRef)
#
## Increment exposures or click in networksite with SiteID
## DONOT USE THIS METHODS IN IFACES! SPECIAL SYSTEM CALLS!
#
# (INT 1) exposure(INT RLENetworkID, INT RLENetworkSiteID)
# (INT 1) click(INT RLENetworkID, INT RLENetworkSiteID)
#
## Sets exposures or click counter in networksite with SiteID from NetworkID
#
# (INT 1) set_exposures_counter(INT RLENetworkID, INT RLENetworkSiteID, HASHREF CounterHashRef)
# (INT 1) set_clicks_counter(INT RLENetworkID, INT RLENetworkSiteID, HASHREF CounterHashRef)
#
## Get networksites for mask RLENetworkSiteHashRefMask
#
# (ARRAYREF of HASHREF RLENetworkSiteHashRefs) get_ex(INT NetworkId | ARRAYREF of ARRAYs (INT RLENetworkID, INT RLENetworkSiteID), RLENetworkSiteHashRefMask)
#
## Get top-list for counter, specified in CounterHashRefMask ("counter" => 1)
## Its highly recommended to set to 1 only one counter
## (if you set many, func will use only one)
## Input params:
## Number - number of elements in output
## From - from what element we get Number of RLENetworkSites
## SortOrder - sort order  FORWARD = 0 (ASC), REVERSE = 1 (DESC) ?
## If list of the ADIDs is not empty, func get toplist from this list,
## otherwise from all network.
## Flags - Arrayref of the flags (see Input Data Info for details) for RLENetworkSiteHashRefMask
## ReqTemplHashRef - HashRef with options for query
#
# (ARRAYREF of HASHREF RLENetworkSiteHashRefs) get_top_exposures(INT RLENetworkID | ARRAYREF of ARRAYs (INT RLENetworkID, INT RLENetworkSiteID), HASHREF CounterHashRef, HASHREF ReqTemplHashRef, ARRAYREF of INT Flags, INT Number, INT From, BOOL SortOrder)
# (ARRAYREF of HASHREF RLENetworkSiteHashRefs) get_top_clicks   (INT RLENetworkID | ARRAYREF of ARRAYs (INT RLENetworkID, INT RLENetworkSiteID), HASHREF CounterHashRef, HASHREF ReqTemplHashRef, ARRAYREF of INT Flags, INT Number, INT From, BOOL SortOrder)
#
## Rotate counter in all ads
## DONOT USE THIS METHODS IN IFACES! SPECIAL SYSTEM CALLS!
#
# (void) rotate_daily()
# (void) rotate_weekly()
#
#### Input Data Info
#
# RLENetworkSiteHashRefMask => {
#     siteID   => INT
#     priority => INT
#     catID    => INT
#     siteName => STRING
#     pay_rate => INT
# }
#
# ReqTemplHashRef => {
#     catID            => INT
#     priority         => INT
#     fixed_pay_rate   => BOOL (fixed - 1, not - 0)
#     adTargetingLogic => INT ( 0 - AD_TARG_DISABLE, 1 - AD_TARG_REJECT, 2 - AD_TARG_ACCEPT )
#     enable           => BOOL
# }
#
## 0 - AD_TARG_DISABLE: ad targeting in rlenetworksite is off
## 1 - AD_TARG_REJECT: ad targeting is on, ad in adTargeting array is rejected
## 2 - AD_TARG_ACCEPT: ad targeting is on, only ad in adTargeting array is accepted
#
# Flags ARRAYREF (6) BOOL
#
## FlagListL:
## CAT            0
## PRIORITY       1
## FIXED_PAY_RATE 2
## AD_TARGETING   3
## ENABLE         4
## NETWORKID      5
#
# CounterHashRef => {
#     'today'     => INT
#     'yesterday' => INT
#     'week'      => INT
#     'last_week' => INT
#     'total'     => INT
# }
#
# RLENetworkSiteHashRef => {
#     'siteID'             => INT
#     'networkID'          => INT
#     'siteName'           => STRING
#     'catID'              => INT
#     'priority'           => INT
#     'enable'             => BOOL
#     'enables'            => ARRAYREF(32) BOOL
#     'creationTime'       => INT
#     'fixed_pay_rate'     => BOOL (?INT)
#     'pay_rate'           => INT
#     'click_pay_rate'     => INT
#     'subevent0_pay_rate' => INT
#     'adTargetingLogic'   => INT (?BOOL)
#     'adTargeting'        => ARRAYREF(32) INT
#     'bannerLabels'       => ARRAYREF(32) INT
#     'bannerCats'         => ARRAYREF(256) INT (?BOOL)
#     'exposures'          => CounterHashRef
#     'clicks'             => CounterHashRef
# }
#
####


sub get
{
    validate_pos(@_, { type => OBJECT },
        { type => SCALAR, regex => qr/^\d+$/ }, # INT RLENetworkID
        { type => SCALAR, regex => qr/^\d+$/ }, # INT RLENetworkSiteID
    );
    my ($self, @args) = @_;

    my $result;
    eval { $result = $self->{client}->get(@args); };
    if (my $e = Adriver::DBI::Exceptions::DBError->caught())
    {
        Adriver::DBI::Exceptions::Clients->throw(
            error  => Adriver::ErrorMessage::error_message($e),
            code   => $e->{code},
            method => 'get',
            args   => \@args
        );
    }

    return $result;
}

sub getall
{
    validate_pos(@_, { type => OBJECT },
        { type => SCALAR, regex => qr/^\d+$/ }, # INT RLENetworkID
    );
    my ($self, @args) = @_;

    my $result;
    eval { $result = $self->{client}->getall(@args); };
    if (my $e = Adriver::DBI::Exceptions::DBError->caught())
    {
        Adriver::DBI::Exceptions::Clients->throw(
            error  => Adriver::ErrorMessage::error_message($e),
            code   => $e->{code},
            method => 'getall',
            args   => \@args
        );
    }

    return $result;
}

sub set
{
    validate_pos(@_, { type => OBJECT },
        { type => HASHREF }, # HASHREF RLENetworkSiteHashRef
    );
    my ($self, @args) = @_;

    my $result;
    eval { $result = $self->{client}->set(@args); };
    if (my $e = Adriver::DBI::Exceptions::DBError->caught())
    {
        Adriver::DBI::Exceptions::Clients->throw(
            error  => Adriver::ErrorMessage::error_message($e),
            code   => $e->{code},
            method => 'set',
            args   => \@args
        );
    }

    return $result;
}

sub add
{
    validate_pos(@_, { type => OBJECT },
        { type => HASHREF }, # HASHREF RLENetworkSiteHashRef
    );
    my ($self, @args) = @_;

    my $result;
    eval { $result = $self->{client}->add(@args); };
    if (my $e = Adriver::DBI::Exceptions::DBError->caught())
    {
        Adriver::DBI::Exceptions::Clients->throw(
            error  => Adriver::ErrorMessage::error_message($e),
            code   => $e->{code},
            method => 'add',
            args   => \@args
        );
    }

    return $result;
}

sub remove
{
    validate_pos(@_, { type => OBJECT },
        { type => HASHREF }, # HASHREF RLENetworkSiteHashRef
    );
    my ($self, @args) = @_;

    my $result;
    eval { $result = $self->{client}->remove(@args); };
    if (my $e = Adriver::DBI::Exceptions::DBError->caught())
    {
        Adriver::DBI::Exceptions::Clients->throw(
            error  => Adriver::ErrorMessage::error_message($e),
            code   => $e->{code},
            method => 'remove',
            args   => \@args
        );
    }

    return $result;
}

sub exposure
{
    validate_pos(@_, { type => OBJECT },
        { type => SCALAR, regex => qr/^\d+$/ }, # INT RLENetworkID
        { type => SCALAR, regex => qr/^\d+$/ }, # INT RLENetworkSiteID
    );
    my ($self, @args) = @_;

    my $result;
    eval { $result = $self->{client}->exposure(@args); };
    if (my $e = Adriver::DBI::Exceptions::DBError->caught())
    {
        Adriver::DBI::Exceptions::Clients->throw(
            error  => Adriver::ErrorMessage::error_message($e),
            code   => $e->{code},
            method => 'exposure',
            args   => \@args
        );
    }

    return $result;
}

sub click
{
    validate_pos(@_, { type => OBJECT },
        { type => SCALAR, regex => qr/^\d+$/ }, # INT RLENetworkID
        { type => SCALAR, regex => qr/^\d+$/ }, # INT RLENetworkSiteID
    );
    my ($self, @args) = @_;

    my $result;
    eval { $result = $self->{client}->click(@args); };
    if (my $e = Adriver::DBI::Exceptions::DBError->caught())
    {
        Adriver::DBI::Exceptions::Clients->throw(
            error  => Adriver::ErrorMessage::error_message($e),
            code   => $e->{code},
            method => 'click',
            args   => \@args
        );
    }

    return $result;
}

sub set_exposures_counter
{
    validate_pos(@_, { type => OBJECT },
        { type => SCALAR, regex => qr/^\d+$/ }, # INT RLENetworkID
        { type => SCALAR, regex => qr/^\d+$/ }, # INT RLENetworkSiteID
        { type => HASHREF },                    # HASHREF CounterHashRef
    );
    my ($self, @args) = @_;

    my $result;
    eval { $result = $self->{client}->set_exposures_counter(@args); };
    if (my $e = Adriver::DBI::Exceptions::DBError->caught())
    {
        Adriver::DBI::Exceptions::Clients->throw(
            error  => Adriver::ErrorMessage::error_message($e),
            code   => $e->{code},
            method => 'set_exposures_counter',
            args   => \@args
        );
    }

    return $result;
}

sub set_clicks_counter
{
    validate_pos(@_, { type => OBJECT },
        { type => SCALAR, regex => qr/^\d+$/ }, # INT RLENetworkID
        { type => SCALAR, regex => qr/^\d+$/ }, # INT RLENetworkSiteID
        { type => HASHREF },                    # HASHREF CounterHashRef
    );
    my ($self, @args) = @_;

    my $result;
    eval { $result = $self->{client}->set_clicks_counter(@args); };
    if (my $e = Adriver::DBI::Exceptions::DBError->caught())
    {
        Adriver::DBI::Exceptions::Clients->throw(
            error  => Adriver::ErrorMessage::error_message($e),
            code   => $e->{code},
            method => 'set_clicks_counter',
            args   => \@args
        );
    }

    return $result;
}

sub get_ex
{
    validate_pos(@_, { type => OBJECT },
        { type => SCALAR | ARRAYREF },          # INT NetworkId | ARRAYREF of ARRAYs (INT RLENetworkID, INT RLENetworkSiteID)
        { type => HASHREF },                    # HASHREF RLENetworkSiteHashRefMask
    );
    my ($self, @args) = @_;

    my $result;
    eval { $result = $self->{client}->get_ex(@args); };
    if (my $e = Adriver::DBI::Exceptions::DBError->caught())
    {
        Adriver::DBI::Exceptions::Clients->throw(
            error  => Adriver::ErrorMessage::error_message($e),
            code   => $e->{code},
            method => 'get_ex',
            args   => \@args
        );
    }

    return $result;
}

sub get_top_exposures
{
    validate_pos(@_, { type => OBJECT },
        { type => SCALAR | ARRAYREF }, # INT NetworkId | ARRAYREF of ARRAYs (INT RLENetworkID, INT RLENetworkSiteID)
        { type => HASHREF },           # HASHREF CounterHashRef
        { type => HASHREF },           # HASHREF ReqTemplHashRef
        { type => ARRAYREF },          # ARRAYREF of INT Flags
        { type => SCALAR },            # INT Number
        { type => SCALAR },            # INT From
        { type => SCALAR },            # BOOL SortOrder
    );
    my ($self, @args) = @_;

    my $result;
    eval { $result = $self->{client}->get_top_exposures(@args); };
    if (my $e = Adriver::DBI::Exceptions::DBError->caught())
    {
        Adriver::DBI::Exceptions::Clients->throw(
            error  => Adriver::ErrorMessage::error_message($e),
            code   => $e->{code},
            method => 'get_top_exposures',
            args   => \@args
        );
    }

    return $result;
}

sub get_top_clicks
{
    validate_pos(@_, { type => OBJECT },
        { type => SCALAR | ARRAYREF }, # INT NetworkId | ARRAYREF of ARRAYs (INT RLENetworkID, INT RLENetworkSiteID)
        { type => HASHREF },           # HASHREF CounterHashRef
        { type => HASHREF },           # HASHREF ReqTemplHashRef
        { type => ARRAYREF },          # ARRAYREF of INT Flags
        { type => SCALAR },            # INT Number
        { type => SCALAR },            # INT From
        { type => SCALAR },            # BOOL SortOrder
    );
    my ($self, @args) = @_;

    my $result;
    eval { $result = $self->{client}->get_top_clicks(@args); };
    if (my $e = Adriver::DBI::Exceptions::DBError->caught())
    {
        Adriver::DBI::Exceptions::Clients->throw(
            error  => Adriver::ErrorMessage::error_message($e),
            code   => $e->{code},
            method => 'get_click_exposures',
            args   => \@args
        );
    }

    return $result;
}

sub rotate_daily
{
    validate_pos(@_, { type => OBJECT });
    my ($self, @args) = @_;

    my $result;
    eval { $result = $self->{client}->rotate_daily(@args); };
    if (my $e = Adriver::DBI::Exceptions::DBError->caught())
    {
        Adriver::DBI::Exceptions::Clients->throw(
            error  => Adriver::ErrorMessage::error_message($e),
            code   => $e->{code},
            method => 'rotate_daily',
            args   => \@args
        );
    }

    return $result;
}

sub rotate_weekly
{
    validate_pos(@_, { type => OBJECT });
    my ($self, @args) = @_;

    my $result;
    eval { $result = $self->{client}->rotate_weekly(@args); };
    if (my $e = Adriver::DBI::Exceptions::DBError->caught())
    {
        Adriver::DBI::Exceptions::Clients->throw(
            error  => Adriver::ErrorMessage::error_message($e),
            code   => $e->{code},
            method => 'rotate_weekly',
            args   => \@args
        );
    }

    return $result;
}

1;


__END__


=head1 NAME

    Adriver::DBI::Clients::RLENetworkSiteClient - this module provides methods to work with
    RLE network sites database.


=head1 DESCRIPTION

    This module is inherited from Adriver::DBI::Clients::Base class.


=head1 SYNOPSIS

    use Adriver::DBI;
    use Adriver::DatabaseConnect::Adriver;
    use Adriver::Exceptions;

    my $host = 'f2.x';
    my $port = 16000;

    eval
    {
        my $dbh = Adriver::DBI->new( Adriver::DatabaseConnect::Adriver->new({host => $host, port => $port}) );

        my $site = $dbh->RLENetworkSite->get($RLENetworkID, $RLENetworkSiteID);
        print Dumper($site);

        my $sites = $dbh->RLENetworkSite->getall($RLENetworkID);
        print Dumper($sites);
    };

    if (my $e = Exception::Class->caught('Adriver::Exceptions'))
    {
        die "Caught Adriver::Exceptions: '", $e->error, "'\n", $e->trace->as_string, "\n";
    }
    elsif ($e = Exception::Class->caught('Exception::Class::Base'))
    {
        die "Caught unknown exception: '", $e->error, "'\n", $e->trace->as_string, "\n";
    }
    elsif ($e = Exception::Class->caught)
    {
        die "$e";
    }


=head1 OBJECT INTERFACE

=head2 get($RLENetworkID, $RLENetworkSiteID) : $RLENetworkSiteHashRef

    Get networksite with RLENetworkSiteID from RLENetworkID.

B<RLENetworkID>

    This is the integer identifier of RLE network.

B<RLENetworkSiteID>

    This is the integer identifier of RLE network site.

B<RLENetworkSiteHashRef>

    This is a hash reference with next structure:

    RLENetworkSiteHashRef =>
    {
        'siteID'             => INT
        'networkID'          => INT
        'siteName'           => STRING
        'catID'              => INT
        'priority'           => INT
        'enable'             => BOOL
        'enables'            => ARRAYREF(32) BOOL
        'creationTime'       => INT
        'fixed_pay_rate'     => BOOL (?INT)
        'pay_rate'           => INT
        'click_pay_rate'     => INT
        'subevent0_pay_rate' => INT
        'adTargetingLogic'   => INT (?BOOL)
        'adTargeting'        => ARRAYREF(32) INT
        'bannerLabels'       => ARRAYREF(32) INT
        'bannerCats'         => ARRAYREF(256) INT (?BOOL)
        'exposures'          => CounterHashRef
        'clicks'             => CounterHashRef
    }

    where

    CounterHashRef =>
    {
        'today'     => INT
        'yesterday' => INT
        'week'      => INT
        'last_week' => INT
        'total'     => INT
    }

B<Exceptions>

    Adriver::DBI::Exceptions::ParamsValidation
    Adriver::DBI::Exceptions::Clients

=head2 getall($RLENetworkID) : ARRAYREF of $RLENetworkSiteHashRef

    This method returns a list of all RLE network sites from network.

B<RLENetworkID>

    This is the integer identifier of RLE network.

B<RLENetworkSiteHashRef>

    This is a hash reference with next structure:

B<Exceptions>

    Adriver::DBI::Exceptions::ParamsValidation
    Adriver::DBI::Exceptions::Clients

=head2 set($RLENetworkSiteHashRef) : 1

    This method updates given site in database.

B<RLENetworkSiteHashRef>

    This is the same hash reference as described in get() method.

B<Exceptions>

    Adriver::DBI::Exceptions::ParamsValidation
    Adriver::DBI::Exceptions::Clients

=head2 add($RLENetworkSiteHashRef) : 1

    This method adds the new site in database.

B<RLENetworkSiteHashRef>

    This is the same hash reference as described in get() method.

B<Exceptions>

    Adriver::DBI::Exceptions::ParamsValidation
    Adriver::DBI::Exceptions::Clients

=head2 remove($RLENetworkSiteHashRef) : 1

    This method removes site from database.

B<RLENetworkSiteHashRef>

    This is the same hash reference as described in get() method.

B<Exceptions>

    Adriver::DBI::Exceptions::ParamsValidation
    Adriver::DBI::Exceptions::Clients

=head2 exposure($RLENetworkID, $RLENetworkSiteID) : 1

    This method icrements the number of site exposures.
    DONOT USE THIS METHODS IN IFACES! SPECIAL SYSTEM CALLS!

B<RLENetworkID>

    This is the integer identifier of RLE network.

B<RLENetworkSiteID>

    This is the integer identifier of RLE network site.

B<Exceptions>

    Adriver::DBI::Exceptions::ParamsValidation
    Adriver::DBI::Exceptions::Clients

=head2 click($RLENetworkID, $RLENetworkSiteID) : 1

    This method icrements the number of site clicks.
    DONOT USE THIS METHODS IN IFACES! SPECIAL SYSTEM CALLS!

B<RLENetworkID>

    This is the integer identifier of RLE network.

B<RLENetworkSiteID>

    This is the integer identifier of RLE network site.

B<Exceptions>

    Adriver::DBI::Exceptions::ParamsValidation
    Adriver::DBI::Exceptions::Clients

=head2 set_exposures_counter($RLENetworkID, $RLENetworkSiteID, $CounterHashRef) : 1

    This method sets the counter of site exposures.

B<RLENetworkID>

    This is the integer identifier of RLE network.

B<RLENetworkSiteID>

    This is the integer identifier of RLE network site.

B<CounterHashRef>

    This is the same hash reference as described in get() method.

B<Exceptions>

    Adriver::DBI::Exceptions::ParamsValidation
    Adriver::DBI::Exceptions::Clients

=head2 set_clicks_counter($RLENetworkID, $RLENetworkSiteID, $CounterHashRef) : 1

    This method sets the counter of site clicks.

B<RLENetworkID>

    This is the integer identifier of RLE network.

B<RLENetworkSiteID>

    This is the integer identifier of RLE network site.

B<CounterHashRef>

    This is the same hash reference as described in get() method.

B<Exceptions>

    Adriver::DBI::Exceptions::ParamsValidation
    Adriver::DBI::Exceptions::Clients

=head2 get_top_exposures($RLENetworkID | ARRAYREF of ARRAYs ($RLENetworkID, $RLENetworkSiteID), $CounterHashRefMask, $ReqTemplHashRef, $Flags, $Number, $From, $SortOrderFlag) : ARRAYREF of $RLENetworkSiteHashRef

    Get top-list for counter, specified in CounterHashRefMask ("counter" => 1)
    Its highly recommended to set to 1 only one counter (if you set many, func will use only one)
    If list of the sites is not empty, func get toplist from this list,
    otherwise from all network.

B<RLENetworkID>

    This is the integer identifier of RLE network.

B<RLENetworkSiteID>

    This is the integer identifier of RLE network site.

B<CounterHashRefMask>

    This is a hash reference with next structure:

    CounterHashRefMask =>
    {
        'today'     => BOOL
        'yesterday' => BOOL
        'week'      => BOOL
        'last_week' => BOOL
        'total'     => BOOL
    }

B<ReqTemplHashRef>

    This is a hash reference with options for query. It has next structure:

    ReqTemplHashRef =>
    {
        catID            => INT
        priority         => INT
        fixed_pay_rate   => BOOL (fixed - 1, not - 0)
        adTargetingLogic => INT ( 0 - AD_TARG_DISABLE, 1 - AD_TARG_REJECT, 2 - AD_TARG_ACCEPT )
        enable           => BOOL
    }

B<Flags>

    This is the array reference of integer flags.

     Flags ARRAYREF (6) BOOL

     FlagListL:
     CAT             0
     PRIORITY        1
     FIXED_PAY_RATE  2
     AD_TARGETING    3
     ENABLE          4
     NETWORKID       5

B<Number>

    This is the number of elements in output.

B<From>

    From what element we get Number of RLENetworkSites.

B<SortOrderFlag>

    Sort order: FORWARD = 0 (ASC), REVERSE = 1 (DESC) ?

B<RLENetworkSiteHashRef>

    This is the same hash reference as described in get() method.

B<Exceptions>

    Adriver::DBI::Exceptions::ParamsValidation
    Adriver::DBI::Exceptions::Clients

=head2 get_top_clicks($RLENetworkID | ARRAYREF of ARRAYs ($RLENetworkID, $RLENetworkSiteID), $CounterHashRefMask, $ReqTemplHashRef, $Flags, $Number, $From, $SortOrderFlag) : ARRAYREF of $RLENetworkSiteHashRef

    Get top-list for counter, specified in CounterHashRefMask ("counter" => 1)
    Its highly recommended to set to 1 only one counter (if you set many, func will use only one)
    If list of the sites is not empty, func get toplist from this list,
    otherwise from all network.

B<RLENetworkID>

    This is the integer identifier of RLE network.

B<RLENetworkSiteID>

    This is the integer identifier of RLE network site.

B<CounterHashRefMask>

    This is the same hash reference as described in get_top_exposures() method.

B<ReqTemplHashRef>

    This is the same hash reference as described in get_top_exposures() method.

B<Flags>

    This is the array reference of integer flags as in get_top_exposures() method.

B<Number>

    This is the number of elements in output.

B<From>

    From what element we get Number of RLENetworkSites.

B<SortOrderFlag>

    Sort order: FORWARD = 0 (ASC), REVERSE = 1 (DESC) ?

B<RLENetworkSiteHashRef>

    This is the same hash reference as described in get() method.

B<Exceptions>

    Adriver::DBI::Exceptions::ParamsValidation
    Adriver::DBI::Exceptions::Clients

=head2 get_ex($RLENetworkID | ARRAYREF of ARRAYs ($RLENetworkID, $RLENetworkSiteID), $RLENetworkSiteHashRefMask) : ARRAYREF of $RLENetworkSiteHashRef

    This method gets sites appropriate to mask RLENetworkSiteHashRefMask.
    If the list of sites is specified, procedure searchs sites from them.

B<RLENetworkID>

    This is the integer identifier of RLE network.

B<RLENetworkSiteID>

    This is the integer identifier of RLE network site.

B<RLENetworkSiteHashRefMask>

    This is a hash reference with next structure:

    RLENetworkSiteHashRefMask =>
    {
        siteID   => INT
        priority => INT
        catID    => INT
        siteName => STRING
        pay_rate => INT
    }

B<RLENetworkSiteHashRef>

    This is the same hash reference as described in get() method.

B<Exceptions>

    Adriver::DBI::Exceptions::ParamsValidation
    Adriver::DBI::Exceptions::Clients

=head2 rotate_daily() : undef

    This procedure rotates daily counters.
    DONOT USE THIS METHODS IN IFACES! SPECIAL SYSTEM CALLS!

B<Exceptions>

    Adriver::DBI::Exceptions::ParamsValidation
    Adriver::DBI::Exceptions::Clients

=head2 rotate_weekly() : undef

    This procedure rotates weekly counters.
    DONOT USE THIS METHODS IN IFACES! SPECIAL SYSTEM CALLS!

B<Exceptions>

    Adriver::DBI::Exceptions::ParamsValidation
    Adriver::DBI::Exceptions::Clients


=head1 SEE ALSO

    Adriver::DBI::Clients::Base
    Adriver::DBI::Exceptions

