package Adriver::DBI::Clients::DelegatedObjectsClient;

use strict;
our $VERSION = '0.0300';
use Carp;
use Params::Validate qw(:all);
use base qw ( Adriver::DBI::Clients::Base );

validation_options(on_fail => sub { Adriver::DBI::Exceptions::ParamsValidation->throw( error => $_[0]); } );

sub package { 'RLE::DelegatedObjectsClient' }

#### Functions
#
## Get list of the objects, delegated from OwnerID to UserID with ObjectType
#
# (ARRAYREF of HASHREF DelegatedObjectHashRefs) get_object(INT UserID, INT OwnerID, INT ObjectType)
#
## Get list of the delegeted to UserID objects (with optional ObjectType)
#
# (ARRAYREF of HASHREF DelegatedObjectHashRefs) get_user(INT UserID [, INT ObjectType] )
#
## Get list of the delegeted from OwnerID objects (with optional ObjectType)
#
# (ARRAYREF of HASHREF DelegatedObjectHashRefs) get_owner(INT OwnerID [, INT ObjectType])
#
## Add or Remove Delegated object
#
# (INT 1) add(HASHREF DelegatedObjectHashRef)
# (INT 1) remove(HASHREF DelegatedObjectHashRef)
#
#### Input Data Info
#
## ASK Voy! (he hase some info about hashparams (rights array))
#
# DelegatedObjectHashRef =>
# {
#     'objectID'   => 'int',
#     'objectType' => 'int',
#     'ownerID'    => 'int',
#     'userID'     => 'int'
#     'rights'     => ['int', ''],
# }
#
####

sub get_object
{
    validate_pos(@_, { type => OBJECT },
        { type => SCALAR, regex => qr/^\d+$/ }, # INT UserID
        { type => SCALAR, regex => qr/^\d+$/ }, # INT OwnerID
        { type => SCALAR, regex => qr/^\d+$/ }, # INT ObjectType
    );
    my ($self, @args) = @_;

    my $result;
    eval { $result = $self->{client}->get_object(@args); };
    if (my $e = Adriver::DBI::Exceptions::DBError->caught())
    {
        Adriver::DBI::Exceptions::Clients->throw(
            error  => Adriver::ErrorMessage::error_message($e),
            code   => $e->{code},
            method => 'get_object',
            args   => \@args
        );
    }

    return $result;
}

sub get_user
{
    validate_pos(@_, { type => OBJECT },
        { type => SCALAR, regex => qr/^\d+$/ },                # INT UserID
        { type => SCALAR, regex => qr/^\d+$/, optional => 1 }, # INT ObjectType
    );
    my ($self, @args) = @_;

    my $result;
    eval { $result = $self->{client}->get_user(@args); };
    if (my $e = Adriver::DBI::Exceptions::DBError->caught())
    {
        Adriver::DBI::Exceptions::Clients->throw(
            error  => Adriver::ErrorMessage::error_message($e),
            code   => $e->{code},
            method => 'get_user',
            args   => \@args
        );
    }

    return $result;
}

sub get_owner
{
    validate_pos(@_, { type => OBJECT },
        { type => SCALAR, regex => qr/^\d+$/ },                # INT OwnerID
        { type => SCALAR, regex => qr/^\d+$/, optional => 1 }, # INT ObjectType
    );
    my ($self, @args) = @_;

    my $result;
    eval { $result = $self->{client}->get_owner(@args); };
    if (my $e = Adriver::DBI::Exceptions::DBError->caught())
    {
        Adriver::DBI::Exceptions::Clients->throw(
            error  => Adriver::ErrorMessage::error_message($e),
            code   => $e->{code},
            method => 'get_owner',
            args   => \@args
        );
    }

    return $result;
}

sub add
{
    validate_pos(@_, { type => OBJECT },
        { type => HASHREF }, # HASHREF DelegatedObjectHashRef
    );
    my ($self, @args) = @_;

    my $result;
    eval { $result = $self->{client}->add(@args); };
    if (my $e = Adriver::DBI::Exceptions::DBError->caught())
    {
        Adriver::DBI::Exceptions::Clients->throw(
            error  => Adriver::ErrorMessage::error_message($e),
            code   => $e->{code},
            method => 'add',
            args   => \@args
        );
    }

    return $result;
}

sub remove
{
    validate_pos(@_, { type => OBJECT },
        { type => HASHREF }, # HASHREF DelegatedObjectHashRef
    );
    my ($self, @args) = @_;

    my $result;
    eval { $result = $self->{client}->remove(@args); };
    if (my $e = Adriver::DBI::Exceptions::DBError->caught())
    {
        Adriver::DBI::Exceptions::Clients->throw(
            error  => Adriver::ErrorMessage::error_message($e),
            code   => $e->{code},
            method => 'remove',
            args   => \@args
        );
    }

    return $result;
}

sub getall
{
    validate_pos(@_, { type => OBJECT },
        { type => OBJECT, isa => 'Adriver::DBI::ForceGetall', optional => 1 }, # FORCE GETALL
    );
    my ($self, @args) = @_;

    unless (scalar @args == 1 and (pop @args)->access_granted)
    {
        Adriver::DBI::Exceptions->throw( error => 'Calling getall method' );
    }

    my $result;
    eval { $result = $self->{client}->getall(@args); };
    if (my $e = Adriver::DBI::Exceptions::DBError->caught())
    {
        Adriver::DBI::Exceptions::Clients->throw(
            error  => Adriver::ErrorMessage::error_message($e),
            code   => $e->{code},
            method => 'getall',
            args   => \@args
        );
    }

    return $result;
}

1;


__END__


=head1 NAME

    Adriver::DBI::Clients::DelegatedObjectsClient - this module provides methods to work with
    Adriver delegated objects database.


=head1 DESCRIPTION

    Using this module you can delegate objects, get information about their owners and users.
    This module is inherited from Adriver::DBI::Clients::Base class.


=head1 SYNOPSIS

    use Adriver::DBI;
    use Adriver::DatabaseConnect::Adriver;
    use Adriver::DBI::ForceGetall;
    use Adriver::Exceptions;

    my $host = 'f2.x';
    my $port = 16000;

    eval
    {
        my $dbh = Adriver::DBI->new( Adriver::DatabaseConnect::Adriver->new({host => $host, port => $port}) );

        my $owner_id = 78071;
        my $objects = $dbh->DelegatedObjects->get_owner($owner_id);
        print Dumper($objects);

        my $user_id = 98278;
        $objects = $dbh->DelegatedObjects->get_user($user_id);
        print Dumper($objects);

        my $object_type = 1;
        my $object = $dbh->DelegatedObjects->get_object($user_id, $owner_id, $object_type);
        print Dumper($object);

        my $objects = $dbh->DelegatedObjects->getall(FORCE_GETALL);
        print Dumper($objects);
    };

    if (my $e = Exception::Class->caught('Adriver::Exceptions'))
    {
        die "Caught Adriver::Exceptions: '", $e->error, "\n", $e->trace->as_string, "\n";
    }
    elsif ($e = Exception::Class->caught('Exception::Class::Base'))
    {
        die "Caught unknown exception: '", $e->error, "\n", $e->trace->as_string, "\n";
    }
    elsif ($e = Exception::Class->caught)
    {
        die "$e";
    }


=head1 OBJECT INTERFACE

=head2 get_object($user_id, $owner_id, $object_type) : ARRAYREF of $DelegatedObjectHashRef

    Get list of the objects with specified object type, delegated from owner to user.

B<user_id>

    User identifier.

B<owner_id>

    Owner identifier.

B<object_type>

    Integer object type. All available object types listed in Adriver::ObjectType module, see it's documentation
    for more information.

B<DelegatedObjectHashRef>

    This is a hash reference with next structure:

    DelegatedObjectHashRef =>
    {
        'objectID'   => INT,
        'objectType' => INT,
        'ownerID'    => INT,
        'userID'     => INT
        'rights'     => ARRAYREF(256) INT,
    }

B<Exceptions>

    Adriver::DBI::Exceptions::ParamsValidation
    Adriver::DBI::Exceptions::Clients

=head2 get_user($user_id, [$object_type, ]) : ARRAYREF of $DelegatedObjectHashRef

    This method returns a list of objects delegeted to user (with optional object type).

B<user_id>

    User identifier.

B<object_type>

    Object type.

B<DelegatedObjectHashRef>

    This is the same hash reference as described in get_object() method.

B<Exceptions>

    Adriver::DBI::Exceptions::ParamsValidation
    Adriver::DBI::Exceptions::Clients

=head2 get_owner($owner_id, [$object_type, ]) : ARRAYREF of $DelegatedObjectHashRef

    This method returns a list of objects delegeted from owner (with optional object type).

B<owner_id>

    Owner identifier.

B<object_type>

    Object type.

B<DelegatedObjectHashRef>

    This is the same hash reference as described in get_object() method.

B<Exceptions>

    Adriver::DBI::Exceptions::ParamsValidation
    Adriver::DBI::Exceptions::Clients

=head2 add($DelegatedObjectHashRef) : 1

    This method adds the delegated object.

B<DelegatedObjectHashRef>

    This is the same hash reference as described in get_object() method.

B<Exceptions>

    Adriver::DBI::Exceptions::ParamsValidation
    Adriver::DBI::Exceptions::Clients

=head2 remove($DelegatedObjectHashRef) : 1

    This method removes delegated object from database.

B<DelegatedObjectHashRef>

    This is the same hash reference as described in get_object() method.

B<Exceptions>

    Adriver::DBI::Exceptions::ParamsValidation
    Adriver::DBI::Exceptions::Clients

=head2 getall($object) : ARRAYREF of $DelegatedObjectHashRef

    This method can get all delegated objects in database. Be very careful the amount of data can be significant.

B<object>

    This is object of Adriver::DBI::ForceGetall class.

B<DelegatedObjectHashRef>

    This is the same hash reference as described in get_object() method.

B<Exceptions>

    Adriver::DBI::Exceptions::ParamsValidation
    Adriver::DBI::Exceptions::Clients


=head1 SEE ALSO

    Adriver::DBI::Clients::Base
    Adriver::DBI::Exceptions
    Adriver::ObjectType
    Adriver::DBI::ForceGetall

