package Adriver::DBI::Clients::DatesTargetingClient;

use strict;
our $VERSION = '0.0300';
use Carp;
use Params::Validate qw(:all);
use base qw ( Adriver::DBI::Clients::Base );

validation_options(on_fail => sub { Adriver::DBI::Exceptions::ParamsValidation->throw( error => $_[0]); } );

sub package { 'RLE::DatesTargetingClient' }

#### Functions
#
## Get chains for ProfileID
#
# (ARRAYREF of INT ChainIDs) get_chains(INT ProfileID)
#
## Get rules for ChainID of the ProfileID
#
# (ARRAYREF of HASHREF DatesTargetingHashRef) get_rules(INT ProfileID, INT ChainID)
#
## Get all datestargetings
## DONOT USE THIS METHOD IN IFACES!
#
# getall()
#
## Set, add or remove DatesTargeting
#
# (INT 1) set(HASHREF DatesTargetingHashRef)
# (INT 1) add(HASHREF DatesTargetingHashRef)
# (INT 1) remove(HASHREF DatesTargetingHashRef)
#
#### Input Data Info
#
# DatesTargetingHashRef =>
# {
#     'profileID'        => INT
#     'chainID'          => INT
#     'ruleID'           => INT
#     'policy'           => INT (? BOOL)
#     'useDate'          => BOOL
#     'useDayWeek'       => BOOL
#     'useDayWeekHours'  => BOOL
#     'useDayMonth'      => BOOL
#     'useDayMonthHours' => BOOL
#     'startDate'        => INT
#     'stopDate'         => INT
#     'dayWeek'          => ARRAYREF(7) BOOL
#     'dayWeekHours'     => ARRAYREF(7x24) BOOL
#     'dayMonth'         => ARRAYREF(31) BOOL
#     'dayMonthHours'    => ARRAYREF(24) BOOL
# }
#
####

sub get_chains
{
    validate_pos(@_, { type => OBJECT },
        { type => SCALAR, regex => qr/^\d+$/ }, # INT ProfileID
    );
    my ($self, @args) = @_;

    my $result;
    eval { $result = $self->{client}->get_chains(@args); };
    if (my $e = Adriver::DBI::Exceptions::DBError->caught())
    {
        Adriver::DBI::Exceptions::Clients->throw(
            error  => Adriver::ErrorMessage::error_message($e),
            code   => $e->{code},
            method => 'get_chains',
            args   => \@args
        );
    }

    return $result;
}

sub get_rules
{
    validate_pos(@_, { type => OBJECT },
        { type => SCALAR, regex => qr/^\d+$/ }, # INT ProfileID
        { type => SCALAR, regex => qr/^\d+$/ }, # INT ChainID
    );
    my ($self, @args) = @_;

    my $result;
    eval { $result = $self->{client}->get_rules(@args); };
    if (my $e = Adriver::DBI::Exceptions::DBError->caught())
    {
        Adriver::DBI::Exceptions::Clients->throw(
            error  => Adriver::ErrorMessage::error_message($e),
            code   => $e->{code},
            method => 'get_rules',
            args   => \@args
        );
    }

    return $result;
}

sub getall
{
    validate_pos(@_, { type => OBJECT },
        { type => OBJECT, isa => 'Adriver::DBI::ForceGetall', optional => 1 }, # FORCE GETALL
    );
    my ($self, @args) = @_;

    unless (scalar @args == 1 and (pop @args)->access_granted)
    {
        Adriver::DBI::Exceptions->throw( error => 'Calling getall method' );
    }

    my $result;
    eval { $result = $self->{client}->getall(@args); };
    if (my $e = Adriver::DBI::Exceptions::DBError->caught())
    {
        Adriver::DBI::Exceptions::Clients->throw(
            error  => Adriver::ErrorMessage::error_message($e),
            code   => $e->{code},
            method => 'getall',
            args   => \@args
        );
    }

    return $result;
}

sub set
{
    validate_pos(@_, { type => OBJECT },
        { type => HASHREF }, # HASHREF DatesTargetingHashRef
    );
    my ($self, @args) = @_;

    my $result;
    eval { $result = $self->{client}->set(@args); };
    if (my $e = Adriver::DBI::Exceptions::DBError->caught())
    {
        Adriver::DBI::Exceptions::Clients->throw(
            error  => Adriver::ErrorMessage::error_message($e),
            code   => $e->{code},
            method => 'set',
            args   => \@args
        );
    }

    return $result;
}

sub add
{
    validate_pos(@_, { type => OBJECT },
        { type => HASHREF }, # HASHREF DatesTargetingHashRef
    );
    my ($self, @args) = @_;

    my $result;
    eval { $result = $self->{client}->add(@args); };
    if (my $e = Adriver::DBI::Exceptions::DBError->caught())
    {
        Adriver::DBI::Exceptions::Clients->throw(
            error  => Adriver::ErrorMessage::error_message($e),
            code   => $e->{code},
            method => 'add',
            args   => \@args
        );
    }

    return $result;
}

sub remove
{
    validate_pos(@_, { type => OBJECT },
        { type => HASHREF }, # HASHREF DatesTargetingHashRef
    );
    my ($self, @args) = @_;

    my $result;
    eval { $result = $self->{client}->remove(@args); };
    if (my $e = Adriver::DBI::Exceptions::DBError->caught())
    {
        Adriver::DBI::Exceptions::Clients->throw(
            error  => Adriver::ErrorMessage::error_message($e),
            code   => $e->{code},
            method => 'remove',
            args   => \@args
        );
    }

    return $result;
}

1;


__END__


=head1 NAME

    Adriver::DBI::Clients::DatesTargetingClient - this module provides methods to work with
    Adriver dates targeting database.


=head1 DESCRIPTION

    Using this module you can tune dates targeting for profile.
    This module is inherited from Adriver::DBI::Clients::Base class.


=head1 SYNOPSIS

    use Adriver::DBI;
    use Adriver::DatabaseConnect::Adriver;
    use Adriver::Exceptions;

    my $host = 'f2.x';
    my $port = 16000;

    eval
    {
        my $dbh = Adriver::DBI->new( Adriver::DatabaseConnect::Adriver->new({host => $host, port => $port}) );

        my $profile_id = 241790;
        my $chains = $dbh->DatesTargeting->get_chains($profile_id);
        print Dumper($chains);

        my $chain_id = 2;
        my $rules = $dbh->DatesTargeting->get_rules($profile_id, $chain_id);
        print Dumper($rules);

        my $db_info = $dbh->DatesTargeting->GetCaps();
        print Dumper($db_info);

        my $rules = $dbh->DatesTargeting->getall(FORCE_GETALL);
        print Dumper($rules);
    };

    if (my $e = Exception::Class->caught('Adriver::Exceptions'))
    {
        die "Caught Adriver::Exceptions: '", $e->error, "'\n", $e->trace->as_string, "\n";
    }
    elsif ($e = Exception::Class->caught('Exception::Class::Base'))
    {
        die "Caught unknown exception: '", $e->error, "'\n", $e->trace->as_string, "\n";
    }
    elsif ($e = Exception::Class->caught)
    {
        die "$e";
    }


=head1 OBJECT INTERFACE

=head2 get_chains($profile_id) : ARRAYREF of $chain_id

    Get list of chains for specified profile.

B<profile_id>

    This is the identifier of profile.

B<chain_id>

    This is the identifier of chain.

B<Exceptions>

    Adriver::DBI::Exceptions::ParamsValidation
    Adriver::DBI::Exceptions::Clients

=head2 get_rules($profile_id, $chain_id) : ARRAYREF of $DatesTargetingHashRef

    This method returns a list of all dates targeting for specified profile and chain.

B<profile_id>

    This is the identifier of profile.

B<chain_id>

    This is the identifier of chain.

B<DatesTargetingHashRef>

    This is a hash reference with next structure:

    DatesTargetingHashRef =>
    {
        'profileID'        => INT
        'chainID'          => INT
        'ruleID'           => INT
        'policy'           => INT (? BOOL)
        'useDate'          => BOOL
        'useDayWeek'       => BOOL
        'useDayWeekHours'  => BOOL
        'useDayMonth'      => BOOL
        'useDayMonthHours' => BOOL
        'startDate'        => INT
        'stopDate'         => INT
        'dayWeek'          => ARRAYREF(7) BOOL
        'dayWeekHours'     => ARRAYREF(7x24) BOOL
        'dayMonth'         => ARRAYREF(31) BOOL
        'dayMonthHours'    => ARRAYREF(24) BOOL
    }

B<Exceptions>

    Adriver::DBI::Exceptions::ParamsValidation
    Adriver::DBI::Exceptions::Clients

=head2 getall($object) : ARRAYREF of $DatesTargetingHashRef

    This method can get all dates targeting. Be careful the amount of data can be significant.
    DONOT USE THIS METHOD IN IFACES!

B<object>

    This is object of Adriver::DBI::ForceGetall class.

B<DatesTargetingHashRef>

    This is the same hash reference as described in get_rules() method.

B<Exceptions>

    Adriver::DBI::Exceptions::ParamsValidation
    Adriver::DBI::Exceptions::Clients

=head2 set($DatesTargetingHashRef) : 1

    This method updates given date targeting in database.

B<DatesTargetingHashRef>

    This is the same hash reference as described in get_rules() method.

B<Exceptions>

    Adriver::DBI::Exceptions::ParamsValidation
    Adriver::DBI::Exceptions::Clients

=head2 add($DatesTargetingHashRef) : 1

    This method adds the new date targeting in database.

B<DatesTargetingHashRef>

    This is the same hash reference as described in get_rules() method.

B<Exceptions>

    Adriver::DBI::Exceptions::ParamsValidation
    Adriver::DBI::Exceptions::Clients

=head2 remove($DatesTargetingHashRef) : 1

    This method removes date targeting from database.

B<DatesTargetingHashRef>

    This is the same hash reference as described in get_rules() method.

B<Exceptions>

    Adriver::DBI::Exceptions::ParamsValidation
    Adriver::DBI::Exceptions::Clients


=head1 SEE ALSO

    Adriver::DBI::Clients::Base
    Adriver::DBI::Exceptions
    Adriver::DBI::ForceGetall

