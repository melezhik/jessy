package Adriver::DBI::Base;

use strict;
our $VERSION = '0.0300';
use Carp;
use Adriver::Client;
use Adriver::DBI::Exceptions;
use Params::Validate qw(:all);

validation_options(on_fail => sub { Adriver::DBI::Exceptions::ParamsValidation->throw(error => $_[0]); });

# Generate DB accessors methods

sub ACCESSORS
{
    validate_pos(@_, { type => OBJECT | SCALAR }, { type => HASHREF });
    my ($self, $accessors) = @_;
    my $package = ref $self || $self;
    return if $package eq __PACKAGE__;
    while( my( $sub_name, $params ) = each( %$accessors ) )
    {
        no strict "refs";
        my $s = $package . "::" . $sub_name;
        *{$s} = sub {
            my $self = shift;
            return $self->get_client($params->{class_name});
        };
    }
    return 1;
}

# PRIVATE
sub get_client
{
    validate_pos(@_, { type => OBJECT }, { type => SCALAR });
    my ($self, $name) = @_;
    if (!$self->{'dbclient_inst'}->{$name}) {
        $self->{'dbclient_inst'}->{$name} = Adriver::Client->new({'class' => $name, 'socket' => $self->{'connect'}->get_connect()});
    }
    return $self->{'dbclient_inst'}->{$name}->client();
}

1;

__END__


=head1 NAME

    Adriver::DBI::Base - this module contains some common methods for all DBI modules
    provided interface for communication with various databases.


=head1 DESCRIPTION

    You should not use this module directly. It's used like as a basic class for various DBI modules
    and implemets some common methods for them.


=head1 CLASS INTERFACE

=head2 ACCESSORS($accessors) : 1 or nothing

    This method generates accessors methods for a defiant class. If trying to call this method from
    this class it returns nothing otherwise - 1. This method can be called and as object method.

B<accessors>

    This is a hash with accessors list. Each key of this hash is a accessor's name and value is a
    reference to a hash with one key - class_name and value - real class name, for example:

    my $accessors = {
         User            =>  { class_name => 'Adriver::DBI::Clients::UserClient',           },
         RLENetwork      =>  { class_name => 'Adriver::DBI::Clients::RLENetworkClient',     },
         RLENetworkAD    =>  { class_name => 'Adriver::DBI::Clients::RLENetworkADClient',   },
         RLENetworkSite  =>  { class_name => 'Adriver::DBI::Clients::RLENetworkSiteClient', },
         AD              =>  { class_name => 'Adriver::DBI::Clients::ADClient',             },
         Banner          =>  { class_name => 'Adriver::DBI::Clients::BannerClient',         },
    };

    In result, when you'll call accessor method you'll get object of class <class_name>.

B<Exceptions>

    Adriver::DBI::Exceptions::ParamsValidation


=head1 PRIVATE OBJECT INTERFACE

=head2 get_client($class_name) : some Adriver::DBI::Client class object 

    This method is called from accessors to get real object of class_name. If object doesn't exist yet it creates it
    otherwise it returns already created object. Each object of class_name is created inside Adriver::Client class object,
    for more information about Adriver::Client class see documentation on it.

B<Exceptions>

    Adriver::DBI::Exceptions::ParamsValidation


=head1 SEE ALSO

    Adriver::Client
    Adriver::DBI::Exceptions

