package Adriver::DBI::Clients::RLE3ConfigClient;

use strict;
our $VERSION = '0.0300';
use Carp;
use Params::Validate qw(:all);
use base qw ( Adriver::DBI::Clients::BaseID );

validation_options(on_fail => sub { Adriver::DBI::Exceptions::ParamsValidation->throw( error => $_[0]); } );

sub package { 'RLE::RLE3ConfigClient' }

## Methods
#
#  HOWTO Use Rle3Config
#
# 1. Get config (or its part from server)
#   getConfig() - All configs
#   get_replies_conf_fast() - partial configs
#   get_banner_conf_fast()
#   get_*_conf_fast()
#
# 2. Get data from local storage
#   hash getBannerConf()
#   hash getMirrorsConf()
#   hash getAllConf()
#   hash getTnsConf()
#   ....
#
# 3. Modification
#
# 4. Set (Save) data to server
#    setBannerConf(BannerConfHashRef)
#    setMirrorsConf(MirrorsConfHashRef)
#    setAllConf(RLE3ConfigurationHashRef)
#    setTnsConf(TnsConfHashRef)
#    set_mirror_counter(mirrorID, CounterHashRef)
#    setConfig()
#    set_replies_conf_fast() and others set local state to server
#       looks like this methods have no sense here because perl client can not modify
#       state of C++ config structure directly
#
# NB: all set_*_fast methods are disabled!!!
#
#
# Get Banners config
# RLE3ConfigClient::getBannerConf()
# return BannerConfHashRef
#
# Set Banners Conf
# RLE3ConfigClient::setBannerConf(BannerConfHashRef)
# return  status
#     undef  error
#     true   OK
#
# RLE3ConfigClient::getMirrorsConf()
# return MirrorsConfHashRef
#
# RLE3ConfigClient::setMirrorsConf(MirrorsConfHashRef)
# return  status
#     undef  error
#     true   OK
#
# RLE3ConfigClient::getAllConf()
# return AllConfHashRef
#
# RLE3ConfigClient::setAllConf(RLE3ConfigurationHashRef)
# return  status
#     undef  error
#     true   OK
#
# RLE3ConfigClient::getTnsConf()
# return TnsConfHashRef
#
# RLE3ConfigClient::setTnsConf(TnsConfHashRef)
# return  status
#     undef  error
#     true   OK
#
# RLE3ConfigClient::getConfig()
# return  status
#     undef  error
#     true   OK
#
# RLE3ConfigClient::setConfig()
# return  status
#     undef  error
#     true   OK
#
#
# RLE3ConfigClient::isChanged()
# return INT status
#
#
#
# RLE3ConfigClient::get_version()
# return int version
#
#
# RLE3ConfigClient::get_replies_conf_fast()
# returns
#    undef some error
#    true  OK
#
#
# RLE3ConfigClient::set_replies_conf_fast()
# returns
#    undef some error
#    true  OK
#
# RLE3ConfigClient::get_events_conf_fast()
# returns
#    undef some error
#    true  OK
#
# RLE3ConfigClient::set_events_conf_fast()
# returns
#    undef some error
#    true  OK
#
# RLE3ConfigClient::get_banner_conf_fast()
# returns
#    undef some error
#    true  OK
#
# RLE3ConfigClient::set_banner_conf_fast()
# returns
#    undef some error
#    true  OK
#
# RLE3ConfigClient::get_geozones_conf_fast()
# returns
#    undef some error
#    true  OK
#
# RLE3ConfigClient::set_geozones_conf_fast()
# returns
#    undef some error
#    true  OK
#
# RLE3ConfigClient::get_stat_conf_fast()
# returns
#    undef some error
#    true  OK
#
# RLE3ConfigClient::set_stat_conf_fast()
# returns
#    undef some error
#    true  OK
#
# status RLE3ConfigClient::get_exposure_preprocessing_conf_fast()
# returns
#    undef some error
#    true  OK
#
# RLE3ConfigClient::set_tns_conf_fast()
# returns
#    undef some error
#    true  OK
#
# RLE3ConfigClient::get_tns_conf_fast()
# returns
#    undef some error
#    true  OK
#
# RLE3ConfigClient::set_exposure_preprocessing_conf_fast()
# returns
#    undef some error
#    true  OK
#
# RLE3ConfigClient::get_mirrors_conf_fast()
# returns
#    undef some error
#    true  OK
#
# RLE3ConfigClient::set_mirrors_conf_fast()
# returns
#    undef some error
#    true  OK
#
# RLE3ConfigClient::exposure_mirror(mirrorID)
#   int mirrorID;
# returns
#    undef some error
#    true  OK
#
# RLE3ConfigClient::set_mirror_counter(mirrorID, CounterHashRef)
#   int mirrorID;
#   HashRef CounterHashRef;
# returns
#    undef some error
#    true  OK
#
# RLE3ConfigClient::rotate_daily_mirrors()
# returns
#    undef some error
#    true  OK
#
# RLE3ConfigClient::rotate_weekly_mirrors()
# returns
#    undef some error
#    true  OK
##

sub getBannerConf
{
    validate_pos(@_, { type => OBJECT });
    my ($self, @args) = @_;

    my $result;
    eval { $result = $self->{client}->getBannerConf(@args); };
    if (my $e = Adriver::DBI::Exceptions::DBError->caught())
    {
        Adriver::DBI::Exceptions::Clients->throw(
            error  => Adriver::ErrorMessage::error_message($e),
            code   => $e->{code},
            method => 'getBannerConf',
            args   => \@args
        );
    }

    return $result;
}

sub setBannerConf
{
    validate_pos(@_, { type => OBJECT },
        { type => HASHREF }                 # BannerConfHashRef
    );
    my ($self, @args) = @_;

    my $result;
    eval { $result = $self->{client}->setBannerConf(@args); };
    if (my $e = Adriver::DBI::Exceptions::DBError->caught())
    {
        Adriver::DBI::Exceptions::Clients->throw(
            error  => Adriver::ErrorMessage::error_message($e),
            code   => $e->{code},
            method => 'setBannerConf',
            args   => \@args
        );
    }

    return $result;
}

sub getMirrorsConf
{
    validate_pos(@_, { type => OBJECT });
    my ($self, @args) = @_;

    my $result;
    eval { $result = $self->{client}->getMirrorsConf(@args); };
    if (my $e = Adriver::DBI::Exceptions::DBError->caught())
    {
        Adriver::DBI::Exceptions::Clients->throw(
            error  => Adriver::ErrorMessage::error_message($e),
            code   => $e->{code},
            method => 'getMirrorsConf',
            args   => \@args
        );
    }

    return $result;
}

sub setMirrorsConf
{
    validate_pos(@_, { type => OBJECT },
        { type => HASHREF }                 # MirrorsConfHashRef
    );
    my ($self, @args) = @_;

    my $result;
    eval { $result = $self->{client}->setMirrorsConf(@args); };
    if (my $e = Adriver::DBI::Exceptions::DBError->caught())
    {
        Adriver::DBI::Exceptions::Clients->throw(
            error  => Adriver::ErrorMessage::error_message($e),
            code   => $e->{code},
            method => 'setMirrorsConf',
            args   => \@args
        );
    }

    return $result;
}

sub getAllConf
{
    validate_pos(@_, { type => OBJECT });
    my ($self, @args) = @_;

    my $result;
    eval { $result = $self->{client}->getAllConf(@args); };
    if (my $e = Adriver::DBI::Exceptions::DBError->caught())
    {
        Adriver::DBI::Exceptions::Clients->throw(
            error  => Adriver::ErrorMessage::error_message($e),
            code   => $e->{code},
            method => 'getAllConf',
            args   => \@args
        );
    }

    return $result;
}

sub setAllConf
{
    validate_pos(@_, { type => OBJECT },
        { type => HASHREF }                 # RLE3ConfigurationHashRef
    );
    my ($self, @args) = @_;

    my $result;
    eval { $result = $self->{client}->setAllConf(@args); };
    if (my $e = Adriver::DBI::Exceptions::DBError->caught())
    {
        Adriver::DBI::Exceptions::Clients->throw(
            error  => Adriver::ErrorMessage::error_message($e),
            code   => $e->{code},
            method => 'setAllConf',
            args   => \@args
        );
    }

    return $result;
}

sub getTnsConf
{
    validate_pos(@_, { type => OBJECT });
    my ($self, @args) = @_;

    my $result;
    eval { $result = $self->{client}->getTnsConf(@args); };
    if (my $e = Adriver::DBI::Exceptions::DBError->caught())
    {
        Adriver::DBI::Exceptions::Clients->throw(
            error  => Adriver::ErrorMessage::error_message($e),
            code   => $e->{code},
            method => 'getTnsConf',
            args   => \@args
        );
    }

    return $result;
}

sub setTnsConf
{
    validate_pos(@_, { type => OBJECT },
        { type => HASHREF }                 # TnsConfHashRef
    );
    my ($self, @args) = @_;

    my $result;
    eval { $result = $self->{client}->setTnsConf(@args); };
    if (my $e = Adriver::DBI::Exceptions::DBError->caught())
    {
        Adriver::DBI::Exceptions::Clients->throw(
            error  => Adriver::ErrorMessage::error_message($e),
            code   => $e->{code},
            method => 'setTnsConf',
            args   => \@args
        );
    }

    return $result;
}

sub getConfig
{
    validate_pos(@_, { type => OBJECT });
    my ($self, @args) = @_;

    my $result;
    eval { $result = $self->{client}->getConfig(@args); };
    if (my $e = Adriver::DBI::Exceptions::DBError->caught())
    {
        Adriver::DBI::Exceptions::Clients->throw(
            error  => Adriver::ErrorMessage::error_message($e),
            code   => $e->{code},
            method => 'getConfig',
            args   => \@args
        );
    }

    return $result;
}

sub setConfig
{
    validate_pos(@_, { type => OBJECT });
    my ($self, @args) = @_;

    my $result;
    eval { $result = $self->{client}->setConfig(@args); };
    if (my $e = Adriver::DBI::Exceptions::DBError->caught())
    {
        Adriver::DBI::Exceptions::Clients->throw(
            error  => Adriver::ErrorMessage::error_message($e),
            code   => $e->{code},
            method => 'setConfig',
            args   => \@args
        );
    }

    return $result;
}

sub isChanged
{
    validate_pos(@_, { type => OBJECT });
    my ($self, @args) = @_;

    my $result;
    eval { $result = $self->{client}->isChanged(@args); };
    if (my $e = Adriver::DBI::Exceptions::DBError->caught())
    {
        Adriver::DBI::Exceptions::Clients->throw(
            error  => Adriver::ErrorMessage::error_message($e),
            code   => $e->{code},
            method => 'isChanged',
            args   => \@args
        );
    }

    return $result;
}

sub get_version
{
    validate_pos(@_, { type => OBJECT });
    my ($self, @args) = @_;

    my $result;
    eval { $result = $self->{client}->get_version(@args); };
    if (my $e = Adriver::DBI::Exceptions::DBError->caught())
    {
        Adriver::DBI::Exceptions::Clients->throw(
            error  => Adriver::ErrorMessage::error_message($e),
            code   => $e->{code},
            method => 'get_version',
            args   => \@args
        );
    }

    return $result;
}

sub get_replies_conf_fast
{
    validate_pos(@_, { type => OBJECT });
    my ($self, @args) = @_;

    my $result;
    eval { $result = $self->{client}->get_replies_conf_fast(@args); };
    if (my $e = Adriver::DBI::Exceptions::DBError->caught())
    {
        Adriver::DBI::Exceptions::Clients->throw(
            error  => Adriver::ErrorMessage::error_message($e),
            code   => $e->{code},
            method => 'get_replies_conf_fast',
            args   => \@args
        );
    }

    return $result;
}

# sub set_replies_conf_fast
# {
#     validate_pos(@_, { type => OBJECT });
#     my ($self, @args) = @_;
# 
#     my $result;
#     eval { $result = $self->{client}->set_replies_conf_fast(@args); };
#     if (my $e = Adriver::DBI::Exceptions::DBError->caught())
#     {
#         Adriver::DBI::Exceptions::Clients->throw(
#             error  => Adriver::ErrorMessage::error_message($e),
#             code   => $e->{code},
#             method => 'set_replies_conf_fast',
#             args   => \@args
#         );
#     }
# 
#     return $result;
# }

sub get_events_conf_fast
{
    validate_pos(@_, { type => OBJECT });
    my ($self, @args) = @_;

    my $result;
    eval { $result = $self->{client}->get_events_conf_fast(@args); };
    if (my $e = Adriver::DBI::Exceptions::DBError->caught())
    {
        Adriver::DBI::Exceptions::Clients->throw(
            error  => Adriver::ErrorMessage::error_message($e),
            code   => $e->{code},
            method => 'get_events_conf_fast',
            args   => \@args
        );
    }

    return $result;
}

# sub set_events_conf_fast
# {
#     validate_pos(@_, { type => OBJECT });
#     my ($self, @args) = @_;
# 
#     my $result;
#     eval { $result = $self->{client}->set_events_conf_fast(@args); };
#     if (my $e = Adriver::DBI::Exceptions::DBError->caught())
#     {
#         Adriver::DBI::Exceptions::Clients->throw(
#             error  => Adriver::ErrorMessage::error_message($e),
#             code   => $e->{code},
#             method => 'set_events_conf_fast',
#             args   => \@args
#         );
#     }
# 
#     return $result;
# }

sub get_banner_conf_fast
{
    validate_pos(@_, { type => OBJECT });
    my ($self, @args) = @_;

    my $result;
    eval { $result = $self->{client}->get_banner_conf_fast(@args); };
    if (my $e = Adriver::DBI::Exceptions::DBError->caught())
    {
        Adriver::DBI::Exceptions::Clients->throw(
            error  => Adriver::ErrorMessage::error_message($e),
            code   => $e->{code},
            method => 'get_banner_conf_fast',
            args   => \@args
        );
    }

    return $result;
}

# sub set_banner_conf_fast
# {
#     validate_pos(@_, { type => OBJECT });
#     my ($self, @args) = @_;
# 
#     my $result;
#     eval { $result = $self->{client}->set_banner_conf_fast(@args); };
#     if (my $e = Adriver::DBI::Exceptions::DBError->caught())
#     {
#         Adriver::DBI::Exceptions::Clients->throw(
#             error  => Adriver::ErrorMessage::error_message($e),
#             code   => $e->{code},
#             method => 'set_banner_conf_fast',
#             args   => \@args
#         );
#     }
# 
#     return $result;
# }

sub get_geozones_conf_fast
{
    validate_pos(@_, { type => OBJECT });
    my ($self, @args) = @_;

    my $result;
    eval { $result = $self->{client}->get_geozones_conf_fast(@args); };
    if (my $e = Adriver::DBI::Exceptions::DBError->caught())
    {
        Adriver::DBI::Exceptions::Clients->throw(
            error  => Adriver::ErrorMessage::error_message($e),
            code   => $e->{code},
            method => 'get_geozones_conf_fast',
            args   => \@args
        );
    }

    return $result;
}

# sub set_geozones_conf_fast
# {
#     validate_pos(@_, { type => OBJECT });
#     my ($self, @args) = @_;
# 
#     my $result;
#     eval { $result = $self->{client}->set_geozones_conf_fast(@args); };
#     if (my $e = Adriver::DBI::Exceptions::DBError->caught())
#     {
#         Adriver::DBI::Exceptions::Clients->throw(
#             error  => Adriver::ErrorMessage::error_message($e),
#             code   => $e->{code},
#             method => 'set_geozones_conf_fast',
#             args   => \@args
#         );
#     }
# 
#     return $result;
# }

sub get_stat_conf_fast
{
    validate_pos(@_, { type => OBJECT });
    my ($self, @args) = @_;

    my $result;
    eval { $result = $self->{client}->get_stat_conf_fast(@args); };
    if (my $e = Adriver::DBI::Exceptions::DBError->caught())
    {
        Adriver::DBI::Exceptions::Clients->throw(
            error  => Adriver::ErrorMessage::error_message($e),
            code   => $e->{code},
            method => 'get_stat_conf_fast',
            args   => \@args
        );
    }

    return $result;
}

# sub set_stat_conf_fast
# {
#     validate_pos(@_, { type => OBJECT });
#     my ($self, @args) = @_;
# 
#     my $result;
#     eval { $result = $self->{client}->set_stat_conf_fast(@args); };
#     if (my $e = Adriver::DBI::Exceptions::DBError->caught())
#     {
#         Adriver::DBI::Exceptions::Clients->throw(
#             error  => Adriver::ErrorMessage::error_message($e),
#             code   => $e->{code},
#             method => 'set_stat_conf_fast',
#             args   => \@args
#         );
#     }
# 
#     return $result;
# }

sub get_exposure_preprocessing_conf_fast
{
    validate_pos(@_, { type => OBJECT });
    my ($self, @args) = @_;

    my $result;
    eval { $result = $self->{client}->get_exposure_preprocessing_conf_fast(@args); };
    if (my $e = Adriver::DBI::Exceptions::DBError->caught())
    {
        Adriver::DBI::Exceptions::Clients->throw(
            error  => Adriver::ErrorMessage::error_message($e),
            code   => $e->{code},
            method => 'get_exposure_preprocessing_conf_fast',
            args   => \@args
        );
    }

    return $result;
}

# sub set_exposure_preprocessing_conf_fast
# {
#     validate_pos(@_, { type => OBJECT });
#     my ($self, @args) = @_;
# 
#     my $result;
#     eval { $result = $self->{client}->set_exposure_preprocessing_conf_fast(@args); };
#     if (my $e = Adriver::DBI::Exceptions::DBError->caught())
#     {
#         Adriver::DBI::Exceptions::Clients->throw(
#             error  => Adriver::ErrorMessage::error_message($e),
#             code   => $e->{code},
#             method => 'set_exposure_preprocessing_conf_fast',
#             args   => \@args
#         );
#     }
# 
#     return $result;
# }

sub get_tns_conf_fast
{
    validate_pos(@_, { type => OBJECT });
    my ($self, @args) = @_;

    my $result;
    eval { $result = $self->{client}->get_tns_conf_fast(@args); };
    if (my $e = Adriver::DBI::Exceptions::DBError->caught())
    {
        Adriver::DBI::Exceptions::Clients->throw(
            error  => Adriver::ErrorMessage::error_message($e),
            code   => $e->{code},
            method => 'get_tns_conf_fast',
            args   => \@args
        );
    }

    return $result;
}

# sub set_tns_conf_fast
# {
#     validate_pos(@_, { type => OBJECT });
#     my ($self, @args) = @_;
# 
#     my $result;
#     eval { $result = $self->{client}->set_tns_conf_fast(@args); };
#     if (my $e = Adriver::DBI::Exceptions::DBError->caught())
#     {
#         Adriver::DBI::Exceptions::Clients->throw(
#             error  => Adriver::ErrorMessage::error_message($e),
#             code   => $e->{code},
#             method => 'set_tns_conf_fast',
#             args   => \@args
#         );
#     }
# 
#     return $result;
# }

sub get_mirrors_conf_fast
{
    validate_pos(@_, { type => OBJECT });
    my ($self, @args) = @_;

    my $result;
    eval { $result = $self->{client}->get_mirrors_conf_fast(@args); };
    if (my $e = Adriver::DBI::Exceptions::DBError->caught())
    {
        Adriver::DBI::Exceptions::Clients->throw(
            error  => Adriver::ErrorMessage::error_message($e),
            code   => $e->{code},
            method => 'get_mirrors_conf_fast',
            args   => \@args
        );
    }

    return $result;
}

# sub set_mirrors_conf_fast
# {
#     validate_pos(@_, { type => OBJECT });
#     my ($self, @args) = @_;
# 
#     my $result;
#     eval { $result = $self->{client}->set_mirrors_conf_fast(@args); };
#     if (my $e = Adriver::DBI::Exceptions::DBError->caught())
#     {
#         Adriver::DBI::Exceptions::Clients->throw(
#             error  => Adriver::ErrorMessage::error_message($e),
#             code   => $e->{code},
#             method => 'set_mirrors_conf_fast',
#             args   => \@args
#         );
#     }
# 
#     return $result;
# }

sub exposure_mirror
{
    validate_pos(@_, { type => OBJECT });
    my ($self, @args) = @_;

    my $result;
    eval { $result = $self->{client}->exposure_mirror(@args); };
    if (my $e = Adriver::DBI::Exceptions::DBError->caught())
    {
        Adriver::DBI::Exceptions::Clients->throw(
            error  => Adriver::ErrorMessage::error_message($e),
            code   => $e->{code},
            method => 'exposure_mirror',
            args   => \@args
        );
    }

    return $result;
}

sub set_mirror_counter
{
    validate_pos(@_, { type => OBJECT },
        { type => SCALAR, regex => qr/^\d+$/ },     # int mirrorID
        { type => HASHREF }                         # HashRef CounterHashRef
    );
    my ($self, @args) = @_;

    my $result;
    eval { $result = $self->{client}->set_mirror_counter(@args); };
    if (my $e = Adriver::DBI::Exceptions::DBError->caught())
    {
        Adriver::DBI::Exceptions::Clients->throw(
            error  => Adriver::ErrorMessage::error_message($e),
            code   => $e->{code},
            method => 'set_mirror_counter',
            args   => \@args
        );
    }

    return $result;
}

sub rotate_daily_mirrors
{
    validate_pos(@_, { type => OBJECT });
    my ($self, @args) = @_;

    my $result;
    eval { $result = $self->{client}->rotate_daily_mirrors(@args); };
    if (my $e = Adriver::DBI::Exceptions::DBError->caught())
    {
        Adriver::DBI::Exceptions::Clients->throw(
            error  => Adriver::ErrorMessage::error_message($e),
            code   => $e->{code},
            method => 'rotate_daily_mirrors',
            args   => \@args
        );
    }

    return $result;
}

sub rotate_weekly_mirrors
{
    validate_pos(@_, { type => OBJECT });
    my ($self, @args) = @_;

    my $result;
    eval { $result = $self->{client}->rotate_weekly_mirrors(@args); };
    if (my $e = Adriver::DBI::Exceptions::DBError->caught())
    {
        Adriver::DBI::Exceptions::Clients->throw(
            error  => Adriver::ErrorMessage::error_message($e),
            code   => $e->{code},
            method => 'rotate_weekly_mirrors',
            args   => \@args
        );
    }

    return $result;
}

1;


__END__


=head1 NAME

    Adriver::DBI::Clients::RLENetworkClient - this module provides methods to work with
    RLE networks database.


=head1 DESCRIPTION

    This module is inherited from Adriver::DBI::Clients::BaseID class.


=head1 SYNOPSIS

    use Adriver::DBI;
    use Adriver::DatabaseConnect::Adriver;
    use Adriver::Exceptions;

    my $host = 'f2.x';
    my $port = 16000;

    eval
    {
        my $dbh = Adriver::DBI->new( Adriver::DatabaseConnect::Adriver->new({host => $host, port => $port}) );

        my $db_info = $dbh->RLE3Config->GetCaps();
        print Dumper($db_info);

        my $res = $dbh->RLE3Config->getAllConf();
        print Dumper($res);

        my $res = $dbh->RLE3Config->getBannerConf();
        print Dumper($res);
    };

    if (my $e = Exception::Class->caught('Adriver::Exceptions'))
    {
        die "Caught Adriver::Exceptions: '", $e->error, "'\n", $e->trace->as_string, "\n";
    }
    elsif ($e = Exception::Class->caught('Exception::Class::Base'))
    {
        die "Caught unknown exception: '", $e->error, "'\n", $e->trace->as_string, "\n";
    }
    elsif ($e = Exception::Class->caught)
    {
        die "$e";
    }


=head1 USAGE

=head2 1. Get config (or its part from server)

B<getConfig() - All configs>

B<get_replies_conf_fast() - partial configs>

B<get_banner_conf_fast()>

B<get_*_conf_fast()>

=head2 2. Get data from local storage

B<hash getBannerConf()>

B<hash getMirrorsConf()>

B<hash getAllConf()>

B<hash getTnsConf()>

B<...>

=head2 3. Modification

=head2 4. Set (Save) data to server

B<setBannerConf(BannerConfHashRef)>

B<setMirrorsConf(MirrorsConfHashRef)>

B<setAllConf(RLE3ConfigurationHashRef)>

B<setTnsConf(TnsConfHashRef)>

B<set_mirror_counter(mirrorID, CounterHashRef)>

B<setConfig()>

B<set_replies_conf_fast()>

and others set local state to server.

Looks like this methods have no sense here because perl client can not modify
state of C++ config structure directly.

B<NB: all set_*_fast methods are disabled!!!>


=head1 OBJECT INTERFACE

=head2 getBannerConf() : $BannerConfHashRef

    Get Banners config.

B<Exceptions>

    Adriver::DBI::Exceptions::ParamsValidation
    Adriver::DBI::Exceptions::Clients

=head2 setBannerConf($BannerConfHashRef) : $status

    Set Banners Conf.

B<status>

    undef - error
    true  - OK

B<Exceptions>

    Adriver::DBI::Exceptions::ParamsValidation
    Adriver::DBI::Exceptions::Clients

=head2 getMirrorsConf() : $MirrorsConfHashRef

B<Exceptions>

    Adriver::DBI::Exceptions::ParamsValidation
    Adriver::DBI::Exceptions::Clients

=head2 setMirrorsConf($MirrorsConfHashRef) : $status

B<status>

    undef - error
    true  - OK

B<Exceptions>

    Adriver::DBI::Exceptions::ParamsValidation
    Adriver::DBI::Exceptions::Clients

=head2 getAllConf() : $AllConfHashRef

B<Exceptions>

    Adriver::DBI::Exceptions::ParamsValidation
    Adriver::DBI::Exceptions::Clients

=head2 setAllConf($RLE3ConfigurationHashRef) : $status

B<status>

    undef - error
    true  - OK

B<Exceptions>

    Adriver::DBI::Exceptions::ParamsValidation
    Adriver::DBI::Exceptions::Clients

=head2 getTnsConf() : $TnsConfHashRef

B<Exceptions>

    Adriver::DBI::Exceptions::ParamsValidation
    Adriver::DBI::Exceptions::Clients

=head2 setTnsConf($TnsConfHashRef) : $status

B<status>

    undef - error
    true  - OK

B<Exceptions>

    Adriver::DBI::Exceptions::ParamsValidation
    Adriver::DBI::Exceptions::Clients


=head2 getConfig() : $status

B<status>

    undef - error
    true  - OK

B<Exceptions>

    Adriver::DBI::Exceptions::ParamsValidation
    Adriver::DBI::Exceptions::Clients

=head2 setConfig() : $status

B<status>

    undef - error
    true  - OK

B<Exceptions>

    Adriver::DBI::Exceptions::ParamsValidation
    Adriver::DBI::Exceptions::Clients

=head2 isChanged() : $status

B<status>

    Integer.

B<Exceptions>

    Adriver::DBI::Exceptions::ParamsValidation
    Adriver::DBI::Exceptions::Clients

=head2 get_version() : $version

B<version>

    Integer.

B<Exceptions>

    Adriver::DBI::Exceptions::ParamsValidation
    Adriver::DBI::Exceptions::Clients

=head2 get_replies_conf_fast() : $status

B<status>

    undef - error
    true  - OK

B<Exceptions>

    Adriver::DBI::Exceptions::ParamsValidation
    Adriver::DBI::Exceptions::Clients

=head2 set_replies_conf_fast() : $status

B<status>

    undef - error
    true  - OK

B<Exceptions>

    Adriver::DBI::Exceptions::ParamsValidation
    Adriver::DBI::Exceptions::Clients

=head2 get_events_conf_fast() : $status

B<status>

    undef - error
    true  - OK

B<Exceptions>

    Adriver::DBI::Exceptions::ParamsValidation
    Adriver::DBI::Exceptions::Clients

=head2 set_events_conf_fast() : $status

B<status>

    undef - error
    true  - OK

B<Exceptions>

    Adriver::DBI::Exceptions::ParamsValidation
    Adriver::DBI::Exceptions::Clients

=head2 get_banner_conf_fast() : $status

B<status>

    undef - error
    true  - OK

B<Exceptions>

    Adriver::DBI::Exceptions::ParamsValidation
    Adriver::DBI::Exceptions::Clients

=head2 set_banner_conf_fast() : $status

B<status>

    undef - error
    true  - OK

B<Exceptions>

    Adriver::DBI::Exceptions::ParamsValidation
    Adriver::DBI::Exceptions::Clients

=head2 get_geozones_conf_fast() : $status

B<status>

    undef - error
    true  - OK

B<Exceptions>

    Adriver::DBI::Exceptions::ParamsValidation
    Adriver::DBI::Exceptions::Clients

=head2 set_geozones_conf_fast() : $status

B<status>

    undef - error
    true  - OK

B<Exceptions>

    Adriver::DBI::Exceptions::ParamsValidation
    Adriver::DBI::Exceptions::Clients

=head2 get_stat_conf_fast() : $status

B<status>

    undef - error
    true  - OK

B<Exceptions>

    Adriver::DBI::Exceptions::ParamsValidation
    Adriver::DBI::Exceptions::Clients

=head2 set_stat_conf_fast() : $status

B<status>

    undef - error
    true  - OK

B<Exceptions>

    Adriver::DBI::Exceptions::ParamsValidation
    Adriver::DBI::Exceptions::Clients

=head2 get_exposure_preprocessing_conf_fast() : $status

B<status>

    undef - error
    true  - OK

B<Exceptions>

    Adriver::DBI::Exceptions::ParamsValidation
    Adriver::DBI::Exceptions::Clients

=head2 set_exposure_preprocessing_conf_fast() : $status

B<status>

    undef - error
    true  - OK

B<Exceptions>

    Adriver::DBI::Exceptions::ParamsValidation
    Adriver::DBI::Exceptions::Clients

=head2 get_tns_conf_fast() : $status

B<status>

    undef - error
    true  - OK

B<Exceptions>

    Adriver::DBI::Exceptions::ParamsValidation
    Adriver::DBI::Exceptions::Clients

=head2 set_tns_conf_fast() : $status

B<status>

    undef - error
    true  - OK

B<Exceptions>

    Adriver::DBI::Exceptions::ParamsValidation
    Adriver::DBI::Exceptions::Clients

=head2 get_mirrors_conf_fast() : $status

B<status>

    undef - error
    true  - OK

B<Exceptions>

    Adriver::DBI::Exceptions::ParamsValidation
    Adriver::DBI::Exceptions::Clients

=head2 set_mirrors_conf_fast() : $status

B<status>

    undef - error
    true  - OK

B<Exceptions>

    Adriver::DBI::Exceptions::ParamsValidation
    Adriver::DBI::Exceptions::Clients

=head2 exposure_mirror($mirrorID) : $status

B<mirrorID>

    Integer.

B<status>

    undef - error
    true  - OK

B<Exceptions>

    Adriver::DBI::Exceptions::ParamsValidation
    Adriver::DBI::Exceptions::Clients

=head2 set_mirror_counter($mirrorID, $CounterHashRef) : $status

B<mirrorID>

    Integer.

B<status>

    undef - error
    true  - OK

B<Exceptions>

    Adriver::DBI::Exceptions::ParamsValidation
    Adriver::DBI::Exceptions::Clients

=head2 rotate_daily_mirrors() : $status

B<status>

    undef - error
    true  - OK

B<Exceptions>

    Adriver::DBI::Exceptions::ParamsValidation
    Adriver::DBI::Exceptions::Clients

=head2 rotate_weekly_mirrors() : $status

B<status>

    undef - error
    true  - OK

B<Exceptions>

    Adriver::DBI::Exceptions::ParamsValidation
    Adriver::DBI::Exceptions::Clients


=head1 SEE ALSO

    Adriver::DBI::Clients::BaseID
    Adriver::DBI::Exceptions

