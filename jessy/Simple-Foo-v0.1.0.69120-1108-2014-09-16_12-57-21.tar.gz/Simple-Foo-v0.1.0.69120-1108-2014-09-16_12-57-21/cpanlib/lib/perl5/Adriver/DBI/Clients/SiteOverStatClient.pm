package Adriver::DBI::Clients::SiteOverStatClient;

use strict;
our $VERSION = '0.0300';
use Carp;
use Params::Validate qw(:all);
use base qw ( Adriver::DBI::Clients::BaseStatClient );

validation_options(on_fail => sub { Adriver::DBI::Exceptions::ParamsValidation->throw( error => $_[0]); } );

sub package { 'RLE::SiteOverStatClient' }

#### Generic StatClient Functions
#
# GetTotal    (HASHREF ClientSiteRequestParamsHashRef)
# GetTable    (ARRAYREF of INT SiteIDs, HASHREF ClientSiteRequestParamsHashRef)
# GetGeo      (ARRAYREF of INT GeoIDs, HASHREF ClientSiteRequestParamsHashRef)
# GetMonthDay (HASHREF ClientSiteRequestParamsHashRef)
# GetWeekDay  (HASHREF ClientSiteRequestParamsHashRef)
# GetDayHour  (HASHREF ClientSiteRequestParamsHashRef)
# GetUniStat  (HASHREF ClientSiteRequestParamsHashRef)
# GetGeoDays  (HASHREF ClientSiteRequestParamsHashRef)
#
#### Functions
#
## Get toppages of site.
#
# GetToppages(HASHREF ClientSiteRequestParamsHashRef)
#
## Get toppages of slice (site have to be specified).
#
# GetSliceToppages(HASHREF ClientSiteRequestParamsHashRef)
#
## Get detail table for site stat (total stat, by sz/pz/bt/bs/bn).
## src_type:
## STAT_SITE_OFFSET         = 2048;
## STAT_SITEZONE_OBJ_TYPE   = 1 + STAT_SITE_OFFSET;
## STAT_PAGEZONE_OBJ_TYPE   = 2 + STAT_SITE_OFFSET;
## STAT_BANNERTYPE_OBJ_TYPE = 3 + STAT_SITE_OFFSET;
## STAT_BANNERSPEC_OBJ_TYPE = 4 + STAT_SITE_OFFSET;
## STAT_BANNERNUM_OBJ_TYPE  = 5 + STAT_SITE_OFFSET
## Second params unknown.
#
# GetDetailTable(INT src_type, ARRAYREF of INT IDs, ClientSiteRequestParamsHashRef)
#
## UNKNOWN. LATER.
#
# GetFatTop(HASHREF ClientSiteRequestParamsHashRef)
# GetURLs(HASHREF ClientSiteRequestParamsHashRef)
# GetTestRegex(HASHREF ClientSiteRequestParamsHashRef)
#
#### Input Data Info
#
# HASHREF ClientSiteRequestParamsHashRef =>
# {
#     'siteID'         => INTs
#     'flags'          => INT     # Common flags for all stat clients
#
#     'userID'         => INT
#
#     'order'          => INT     #   TopRequests()
#     'urlsCnt'        => INT     #   TopRequests()
#     'startNum'       => INT     #   TopRequests()
#     'sliceID'        => INT     #   TopRequests()
#
#     'regex_str'      => STRING  #   Regex requests
#     'replace_str'    => STRING  #   Regex requests
#
#
#     'bannerNumber'   => INT
#
#     'siteZoneID'     => INT
#     'pageZoneID'     => INT
#     'bannerType'     => INT
#     'bannerSpec'     => INT
#
#     'geoID'          => INT
#     'geoIDstart'     => INT
#     'geoIDend'       => INT
#
#     'startDate'      => INT
#     'endDate'        => INT
#
#     'opcode'         => INT     # Operation code OP_NONE = 0 OP_SUM = 1 OP_ILLEGAL = 2
#
#     'grid'           => INT     # 1 record per day/hour HOUR = 24 DAY = 1
#
#     # DO NOT SET/MODIFY!
#     'what'           => INT     # Used by specify request type in multirequests
#     'noCache'        => BOOL    # If true, request response shouldn't be cached
#     'juuEventType'   => INT
#     'juuCatID'       => INT
#     'juuNetworkType' => INT
# }
#
## Flags
#
# MONTH_FIXED_LENGTH   0x2  // Using for BasePlotStat result. Result will have a fixed length size.
# GET_SUB_EVENT        0x4  // Set this bit to have subevents in result.
# GET_SITE_CATS        0x8  // Not used.
# DEFPROF_SUPPORT_FLAG 0x10 // Set this bit to get default stat data in all ad requsts (internal using).
# GET_UU_RANGE         0x20 // Set this bit to get UU in GetMonthDay reqests.
#
####

sub GetToppages
{
    validate_pos(@_, { type => OBJECT }, { type => HASHREF });
    my ($self, @args) = @_;

    my $result;
    eval { $result = $self->{client}->GetToppages(@args); };
    if (my $e = Adriver::DBI::Exceptions::DBError->caught())
    {
        Adriver::DBI::Exceptions::Clients->throw(
            error  => Adriver::ErrorMessage::error_message($e),
            code   => $e->{code},
            method => 'GetToppages',
            args   => \@args
        );
    }

    return $result;
}

sub GetSliceToppages
{
    validate_pos(@_, { type => OBJECT }, { type => HASHREF });
    my ($self, @args) = @_;

    my $result;
    eval { $result = $self->{client}->GetSliceToppages(@args); };
    if (my $e = Adriver::DBI::Exceptions::DBError->caught())
    {
        Adriver::DBI::Exceptions::Clients->throw(
            error  => Adriver::ErrorMessage::error_message($e),
            code   => $e->{code},
            method => 'GetSliceToppages',
            args   => \@args
        );
    }

    return $result;
}

sub GetDetailTable
{
    validate_pos(@_, { type => OBJECT }, { type => SCALAR }, { type => ARRAYREF }, { type => HASHREF });
    my ($self, @args) = @_;

    my $result;
    eval { $result = $self->{client}->GetDetailTable(@args); };
    if (my $e = Adriver::DBI::Exceptions::DBError->caught())
    {
        Adriver::DBI::Exceptions::Clients->throw(
            error  => Adriver::ErrorMessage::error_message($e),
            code   => $e->{code},
            method => 'GetDetailTable',
            args   => \@args
        );
    }

    return $result;
}

sub GetFatTop
{
    validate_pos(@_, { type => OBJECT }, { type => HASHREF });
    my ($self, @args) = @_;

    my $result;
    eval { $result = $self->{client}->GetFatTop(@args); };
    if (my $e = Adriver::DBI::Exceptions::DBError->caught())
    {
        Adriver::DBI::Exceptions::Clients->throw(
            error  => Adriver::ErrorMessage::error_message($e),
            code   => $e->{code},
            method => 'GetFatTop',
            args   => \@args
        );
    }

    return $result;
}

sub GetURLs
{
    validate_pos(@_, { type => OBJECT }, { type => HASHREF });
    my ($self, @args) = @_;

    my $result;
    eval { $result = $self->{client}->GetURLs(@args); };
    if (my $e = Adriver::DBI::Exceptions::DBError->caught())
    {
        Adriver::DBI::Exceptions::Clients->throw(
            error  => Adriver::ErrorMessage::error_message($e),
            code   => $e->{code},
            method => 'GetURLs',
            args   => \@args
        );
    }

    return $result;
}

sub GetTestRegex
{
    validate_pos(@_, { type => OBJECT }, { type => HASHREF });
    my ($self, @args) = @_;

    my $result;
    eval { $result = $self->{client}->GetTestRegex(@args); };
    if (my $e = Adriver::DBI::Exceptions::DBError->caught())
    {
        Adriver::DBI::Exceptions::Clients->throw(
            error  => Adriver::ErrorMessage::error_message($e),
            code   => $e->{code},
            method => 'GetTestRegex',
            args   => \@args
        );
    }

    return $result;
}

1;


__END__


=head1 NAME

    Adriver::DBI::Clients::SiteOverStatClient - this module provides methods to get
    statistics by sites.


=head1 DESCRIPTION

    This module is inherited from Adriver::DBI::Clients::BaseStatClient class.


=head1 SYNOPSIS

    use Adriver::DBI::Stat;
    use Adriver::DatabaseConnect::Stat;
    use Adriver::Exceptions;
    use Data::Dumper;

    my $config_file = '../stat4perl.conf';

    eval
    {
        my $dbh = Adriver::DBI::Stat->new(
            Adriver::DatabaseConnect::Stat->new(config_file => $config_file)
        );

        my $site_id = 98291;
        my $site_stat = $dbh->Site->GetTotal({ 'siteID' => $site_id });
        print Dumper($site_stat);

        my $site_stat = $dbh->Site->GetToppages({ 'siteID' => $site_id });
        print Dumper($site_stat);
    };

    if (my $e = Exception::Class->caught('Adriver::Exceptions'))
    {
        die "Caught Adriver::Exceptions: '", $e->error, "'\n", $e->trace->as_string, "\n";
    }
    elsif ($e = Exception::Class->caught('Exception::Class::Base'))
    {
        die "Caught unknown exception: '", $e->error, "'\n", $e->trace->as_string, "\n";
    }
    elsif ($e = Exception::Class->caught)
    {
        die "$e";
    }


=head1 INHERITED OBJECT INTERFACE

=head2 GetTotal($ClientSiteRequestParamsHashRef)

    Get total stat for the site.

B<ClientSiteRequestParamsHashRef>

    This is a hash reference with next structure:

    ClientSiteRequestParamsHashRef =>
    {
        'siteID'         => INTs
        'flags'          => INT     # Common flags for all stat clients

        'userID'         => INT

        'order'          => INT     #   TopRequests()
        'urlsCnt'        => INT     #   TopRequests()
        'startNum'       => INT     #   TopRequests()
        'sliceID'        => INT     #   TopRequests()

        'regex_str'      => STRING  #   Regex requests
        'replace_str'    => STRING  #   Regex requests


        'bannerNumber'   => INT

        'siteZoneID'     => INT
        'pageZoneID'     => INT
        'bannerType'     => INT
        'bannerSpec'     => INT

        'geoID'          => INT
        'geoIDstart'     => INT
        'geoIDend'       => INT

        'startDate'      => INT
        'endDate'        => INT

        'opcode'         => INT     # Operation code OP_NONE = 0 OP_SUM = 1 OP_ILLEGAL = 2

        'grid'           => INT     # 1 record per day/hour HOUR = 24 DAY = 1

        # DO NOT SET/MODIFY!
        'what'           => INT     # Used by specify request type in multirequests
        'noCache'        => BOOL    # If true, request response shouldn't be cached
        'juuEventType'   => INT
        'juuCatID'       => INT
        'juuNetworkType' => INT
    }


B<Flags>

    MONTH_FIXED_LENGTH   0x2  // Using for BasePlotStat result. Result will have a fixed length size.
    GET_SUB_EVENT        0x4  // Set this bit to have subevents in result.
    GET_SITE_CATS        0x8  // Not used.
    DEFPROF_SUPPORT_FLAG 0x10 // Set this bit to get default stat data in all ad requsts (internal using).
    GET_UU_RANGE         0x20 // Set this bit to get UU in GetMonthDay reqests.

B<Exceptions>

    Adriver::DBI::Exceptions::ParamsValidation
    Adriver::DBI::Exceptions::Clients

=head2 GetTable($SiteIDs, $ClientSiteRequestParamsHashRef)

    Get total stats for list of sites with specified identifiers.

B<SiteIDs>

    ARRAYREF of INT sites identifiers.

B<ClientSiteRequestParamsHashRef>

    This is the same hash reference as described in GetTotal() method.

B<Exceptions>

    Adriver::DBI::Exceptions::ParamsValidation
    Adriver::DBI::Exceptions::Clients

=head2 GetGeo($GeoIDs, $ClientSiteRequestParamsHashRef)

    Get geo stat for site.
    If GeoIDs specified only for this GeoIDs.
    If GeoIDs empty for all GeoIDs.

B<GeoIDs>

    ARRAYREF of INT GeoIDs.

B<ClientSiteRequestParamsHashRef>

    This is the same hash reference as described in GetTotal() method.

B<Exceptions>

    Adriver::DBI::Exceptions::ParamsValidation
    Adriver::DBI::Exceptions::Clients

=head2 GetMonthDay($ClientSiteRequestParamsHashRef)

    Get statistics for site by days.

B<ClientSiteRequestParamsHashRef>

    This is the same hash reference as described in GetTotal() method.

B<Exceptions>

    Adriver::DBI::Exceptions::ParamsValidation
    Adriver::DBI::Exceptions::Clients

=head2 GetWeekDay($ClientSiteRequestParamsHashRef)

    Get average statistics for site by weekday.

B<ClientSiteRequestParamsHashRef>

    This is the same hash reference as described in GetTotal() method.

B<Exceptions>

    Adriver::DBI::Exceptions::ParamsValidation
    Adriver::DBI::Exceptions::Clients

=head2 GetDayHour($ClientSiteRequestParamsHashRef)

    Get average statistics for site by dayhour.

B<ClientSiteRequestParamsHashRef>

    This is the same hash reference as described in GetTotal() method.

B<Exceptions>

    Adriver::DBI::Exceptions::ParamsValidation
    Adriver::DBI::Exceptions::Clients

=head2 GetUniStat($ClientSiteRequestParamsHashRef)

    Universal stat request.

B<ClientSiteRequestParamsHashRef>

    This is the same hash reference as described in GetTotal() method.

B<Exceptions>

    Adriver::DBI::Exceptions::ParamsValidation
    Adriver::DBI::Exceptions::Clients

=head2 GetGeoDays($ClientSiteRequestParamsHashRef)

    Geo stat by days.

B<ClientSiteRequestParamsHashRef>

    This is the same hash reference as described in GetTotal() method.

B<Exceptions>

    Adriver::DBI::Exceptions::ParamsValidation
    Adriver::DBI::Exceptions::Clients

=head2 GetDaysCount($ClientSiteRequestParamsHashRef)

    Get begindate, enddate and diff (in weeks).

B<ClientSiteRequestParamsHashRef>

    This is the same hash reference as described in GetTotal() method.

B<Exceptions>

    Adriver::DBI::Exceptions::ParamsValidation
    Adriver::DBI::Exceptions::Clients


=head1 OBJECT INTERFACE

=head2 GetToppages($ClientSiteRequestParamsHashRef)

    Get toppages of site.

B<ClientSiteRequestParamsHashRef>

    This is the same hash reference as described in GetTotal() method.

B<Exceptions>

    Adriver::DBI::Exceptions::ParamsValidation
    Adriver::DBI::Exceptions::Clients

=head2 GetSliceToppages($ClientSiteRequestParamsHashRef)

    Get toppages of slice (site have to be specified).

B<ClientSiteRequestParamsHashRef>

    This is the same hash reference as described in GetTotal() method.

B<Exceptions>

    Adriver::DBI::Exceptions::ParamsValidation
    Adriver::DBI::Exceptions::Clients

=head2 GetDetailTable($src_type, $IDs, $ClientSiteRequestParamsHashRef)

    Get detail table for site stat (total stat, by sz/pz/bt/bs/bn).

B<src_type>

    Integer. Types:

    STAT_SITE_OFFSET         = 2048;
    STAT_SITEZONE_OBJ_TYPE   = 1 + STAT_SITE_OFFSET;
    STAT_PAGEZONE_OBJ_TYPE   = 2 + STAT_SITE_OFFSET;
    STAT_BANNERTYPE_OBJ_TYPE = 3 + STAT_SITE_OFFSET;
    STAT_BANNERSPEC_OBJ_TYPE = 4 + STAT_SITE_OFFSET;
    STAT_BANNERNUM_OBJ_TYPE  = 5 + STAT_SITE_OFFSET

B<IDs>

    ARRAYREF of Integer. Unknown parameter.

B<ClientSiteRequestParamsHashRef>

    This is the same hash reference as described in GetTotal() method.

B<Exceptions>

    Adriver::DBI::Exceptions::ParamsValidation
    Adriver::DBI::Exceptions::Clients

=head2 GetFatTop($ClientSiteRequestParamsHashRef)

B<ClientSiteRequestParamsHashRef>

    This is the same hash reference as described in GetTotal() method.

B<Exceptions>

    Adriver::DBI::Exceptions::ParamsValidation
    Adriver::DBI::Exceptions::Clients

=head2 GetURLs($ClientSiteRequestParamsHashRef)

B<ClientSiteRequestParamsHashRef>

    This is the same hash reference as described in GetTotal() method.

B<Exceptions>

    Adriver::DBI::Exceptions::ParamsValidation
    Adriver::DBI::Exceptions::Clients

=head2 GetTestRegex($ClientSiteRequestParamsHashRef)

B<ClientSiteRequestParamsHashRef>

    This is the same hash reference as described in GetTotal() method.

B<Exceptions>

    Adriver::DBI::Exceptions::ParamsValidation
    Adriver::DBI::Exceptions::Clients


=head1 SEE ALSO

    Adriver::DBI::Clients::BaseStatClient
    Adriver::DBI::Exceptions

