package Adriver::DBI::Clients::RLENetworkADClient;

use strict;
our $VERSION = '0.0300';
use Carp;
use Params::Validate qw(:all);
use base qw ( Adriver::DBI::Clients::BaseID );

validation_options(on_fail => sub { Adriver::DBI::Exceptions::ParamsValidation->throw( error => $_[0]); } );

sub package { 'RLE::RLENetwork::RLENetworkADClient' }

#### Generic BaseID Functions
#
# get(INT RLENetADID)
# getids()
# getlist(ARRAYREF of INT RLENetADIDs)
# set(HASHREF RLENetworkADHashRef)
# add(HASHREF RLENetworkADHashRef)
# remove(INT RLENetADID)
#
#### Other Functions
#
## Set or add Amount credits for rlenetworkad with RLENetADID
## Amount type is float (double in c-source)
#
# (INT NewAmount) add_credit(INT RLENetADID, FLOAT Amount)
# (INT NewAmount) set_credit(INT RLENetADID, FLOAT Amount)
#
## Reset daily balance counter in RLENetAD
#
# (INT 1) reset_balance(INT RLENetADID)
#
## Increment exposures or click in rlenetworkad with RLENetADID
## DONOT USE THIS METHODS IN IFACES! SPECIAL SYSTEM CALLS!
#
# (INT 1) exposure(INT RLENetADID)
# (INT 1) click(INT RLENetADID)
# (INT 1) rep_exposure(INT RLENetADID)
# (INT 1) rep_click(INT RLENetADID)
#
## Sets exposures or click counter in rlenetworkad with RLENetADID
#
# (INT 1) set_exposures_counter(INT RLENetADID, HASHREF HourlyCounterHashRef)
# (INT 1) set_clicks_counter(INT RLENetADID, HASHREF HourlyCounterHashRef)
# (INT 1) set_rep_exposures_counter(INT RLENetADID, HASHREF HourlyCounterHashRef)
# (INT 1) set_rep_clicks_counter(INT RLENetADID, HASHREF HourlyCounterHashRef)
#
## Get top-list for counter, specified in HourlyCounterHashRefMask ("counter" => 1)
## Its highly recommended to set to 1 only one counter
## (if you set many, func will use only one)
## Input params:
## Number - number of elements in output
## From - from what element we get Number of ADs
## SortOrder - sort order  FORWARD = 0 (ASC), REVERSE = 1 (DESC) ?
## If list of the ADIDs is not empty, func get toplist from this list,
## otherwise from all network.
## Flags - Arrayref of the flags (see Input Data Info for details) for ReqTempl
## ReqTemplHashRef - HashRef with options for query
#
# (ARRAYREF of HASHREF RLENetworkHashRefs) get_top_exposures(INT RLENetID, ARRAYREF of INT RLENetADIDs, HASHREF HourlyCounterHashRefMask, HASHREF ReqTemplHashRef, ARRAYREF of INT Flags, INT Number, INT From, BOOL SortOrder)
# (ARRAYREF of HASHREF RLENetworkHashRefs) get_top_clicks(INT RLENetID, ARRAYREF of INT RLENetADIDs, HASHREF HourlyCounterHashRefMask, HASHREF ReqTemplHashRef, ARRAYREF of INT Flags, INT Number, INT From, BOOL SortOrder)
# (ARRAYREF of HASHREF RLENetworkHashRefs) get_top_rep_exposures(INT RLENetID, ARRAYREF of INT RLENetADIDs, HASHREF HourlyCounterHashRefMask, HASHREF ReqTemplHashRef, ARRAYREF of INT Flags, INT Number, INT From, BOOL SortOrder)
# (ARRAYREF of HASHREF RLENetworkHashRefs) get_top_rep_clicks(INT RLENetID, ARRAYREF of INT RLENetADIDs, HASHREF HourlyCounterHashRefMask, HASHREF ReqTemplHashRef, ARRAYREF of INT Flags, INT Number, INT From, BOOL SortOrder)
#
## Get top-list
## Input params:
## Number - number of elements in output
## From - from what element we get Number of ADs
## SortOrder - sort order  FORWARD = 0 (ASC), REVERSE = 1 (DESC) ?
## If list of the ADIDs is not empty, func get toplist from this list,
## otherwise from all network.
## SortBy - param for sort (0 - by credit, 1 - by balance)
#
# (ARRAYREF of HASHREF RLENetworkHashRefs) get_top_params(INT RLENetID, ARRAYREF of INT RLENetADIDs, INT SortBy, INT Number, INT From, BOOL SortOrder)
#
## Get RLENetADs for mask RLENetADHashRefMask
## Elements in mask is substrs for search in base
## If list of the ADIDs is specified, func get ADs from this list
#
# (ARRAYREF of HASHREF RLENetworkHashRefs) get_ex(INT RLENetID, ARRAYREF of INT RLENetADIDs, HASHREF RLENetADHashRefMask)
#
## Rotate counter in all rlenetworks
## DONOT USE THIS METHODS IN IFACES! SPECIAL SYSTEM CALLS!
#
# (void) rotate_hourly()
# (void) rotate_daily()
# (void) rotate_weekly()
#
#### Input Data Info
#
# ReqTemplHashRef =>
# {
#     'networkID'       => INT
#     'priority'        => INT
#     'end_priority'    => INT
#     'nice'            => INT
#     'enable_indexing' => BOOL
#     'enable'          => BOOL
# }
#
## Priority: 0 - common, 1 - gold, 100-200 commerce, 200-300 hosters
## Nice: -1 low, 0 normal, +1 high
## Enable_indexing: if off ad is not in pretendent queue
#
# Flags ARRAYREF (5) BOOL
#
## FlagListL:
## ENABLE          0
## ENABLE_INDEXING 1
## PRIORITY        2
## NICE            3
## NETWORKID       4
#
# RLENetADHashRefMask =>
# {
#     'networkID'   => INT
#     'adName'      => STRING
#     'email'       => STRING
#     'supportName' => STRING
#     'shortName'   => STRING
# }
#
# HourlyCounterHashRef =>
# {
#     'today'     => INT
#     'yesterday' => INT
#     'week'      => INT
#     'last_week' => INT
#     'total'     => INT
#     'last_hour' => INT
# }
#
# RLENetworkHashRef =>
# {
#     'adID'                  => INT
#     'networkID'             => INT
#     'adName'                => STRING
#     'shortName'             => STRING
#     'supportName'           => STRING
#     'email'                 => STRING
#     'credit'                => INT
#     'priority'              => INT
#     'enable'                => BOOL
#     'enables'               => ARRAYREF(128) BOOL
#     'debt'                  => INT
#     'enable_indexing'       => BOOL
#     'creationTime'          => INT
#     'balance'               => INT
#     'price'                 => INT (??? FLOAT)
#     'nice'                  => INT
#     'priorityTargeting'     => ARRAYREF(2) INT
#     'targeting_cost'        => ARRAYREF(17) INT
#     'maxSaleExposures'      => INT
#     'salePriceTomorrow'     => INT
#     'salePriceToday'        => INT
#     'dayMinExposures'       => INT
#     'dayMaxExposures'       => INT
#     'dayMinClicks'          => INT
#     'dayMaxClicks'          => INT
#     'uniqueUserMaxShows'    => ARRAYREF(3) INT
#     'uniqueUserMaxClicks'   => INT
#     'uniqueUserMinInterval' => INT
#     'retargetingInfo'       => HASHREF {'objectID'=>INT,'objectType'=>INT,'options'=>ARRAYREF(32) BOOL(?INT)}
#     'rep_exposures'         => HourlyCounterHashRef
#     'rep_clicks'            => HourlyCounterHashRef
#     'exposures'             => HourlyCounterHashRef
#     'clicks'                => HourlyCounterHashRef
# }
#
####

sub add_credit
{
    validate_pos(@_, { type => OBJECT },
        { type => SCALAR, regex => qr/^\d+$/ }, # INT RLENetADID
        { type => SCALAR },                     # FLOAT Amount
    );
    my ($self, @args) = @_;

    my $result;
    eval { $result = $self->{client}->add_credit(@args); };
    if (my $e = Adriver::DBI::Exceptions::DBError->caught())
    {
        Adriver::DBI::Exceptions::Clients->throw(
            error  => Adriver::ErrorMessage::error_message($e),
            code   => $e->{code},
            method => 'add_credit',
            args   => \@args
        );
    }

    return $result;
}

sub set_credit
{
    validate_pos(@_, { type => OBJECT },
        { type => SCALAR, regex => qr/^\d+$/ }, # INT RLENetADID
        { type => SCALAR },                     # FLOAT Amount
    );
    my ($self, @args) = @_;

    my $result;
    eval { $result = $self->{client}->set_credit(@args); };
    if (my $e = Adriver::DBI::Exceptions::DBError->caught())
    {
        Adriver::DBI::Exceptions::Clients->throw(
            error  => Adriver::ErrorMessage::error_message($e),
            code   => $e->{code},
            method => 'set_credit',
            args   => \@args
        );
    }

    return $result;
}

sub reset_balance
{
    validate_pos(@_, { type => OBJECT },
        { type => SCALAR, regex => qr/^\d+$/ }, # INT RLENetADID
    );
    my ($self, @args) = @_;

    my $result;
    eval { $result = $self->{client}->reset_balance(@args); };
    if (my $e = Adriver::DBI::Exceptions::DBError->caught())
    {
        Adriver::DBI::Exceptions::Clients->throw(
            error  => Adriver::ErrorMessage::error_message($e),
            code   => $e->{code},
            method => 'reset_balance',
            args   => \@args
        );
    }

    return $result;
}

sub exposure
{
    validate_pos(@_, { type => OBJECT },
        { type => SCALAR, regex => qr/^\d+$/ }, # INT RLENetADID
    );
    my ($self, @args) = @_;

    my $result;
    eval { $result = $self->{client}->exposure(@args); };
    if (my $e = Adriver::DBI::Exceptions::DBError->caught())
    {
        Adriver::DBI::Exceptions::Clients->throw(
            error  => Adriver::ErrorMessage::error_message($e),
            code   => $e->{code},
            method => 'exposure',
            args   => \@args
        );
    }

    return $result;
}

sub click
{
    validate_pos(@_, { type => OBJECT },
        { type => SCALAR, regex => qr/^\d+$/ }, # INT RLENetADID
    );
    my ($self, @args) = @_;

    my $result;
    eval { $result = $self->{client}->click(@args); };
    if (my $e = Adriver::DBI::Exceptions::DBError->caught())
    {
        Adriver::DBI::Exceptions::Clients->throw(
            error  => Adriver::ErrorMessage::error_message($e),
            code   => $e->{code},
            method => 'click',
            args   => \@args
        );
    }

    return $result;
}

sub rep_exposure
{
    validate_pos(@_, { type => OBJECT },
        { type => SCALAR, regex => qr/^\d+$/ }, # INT RLENetADID
    );
    my ($self, @args) = @_;

    my $result;
    eval { $result = $self->{client}->rep_exposure(@args); };
    if (my $e = Adriver::DBI::Exceptions::DBError->caught())
    {
        Adriver::DBI::Exceptions::Clients->throw(
            error  => Adriver::ErrorMessage::error_message($e),
            code   => $e->{code},
            method => 'rep_exposure',
            args   => \@args
        );
    }

    return $result;
}

sub rep_click
{
    validate_pos(@_, { type => OBJECT },
        { type => SCALAR, regex => qr/^\d+$/ }, # INT RLENetADID
    );
    my ($self, @args) = @_;

    my $result;
    eval { $result = $self->{client}->rep_click(@args); };
    if (my $e = Adriver::DBI::Exceptions::DBError->caught())
    {
        Adriver::DBI::Exceptions::Clients->throw(
            error  => Adriver::ErrorMessage::error_message($e),
            code   => $e->{code},
            method => 'rep_click',
            args   => \@args
        );
    }

    return $result;
}

sub set_reach_counter
{
    # set_reach_counter($Id, {period => 2, limit => 100, total => 100})
    validate_pos(@_, { type => OBJECT },
        { type => SCALAR, regex => qr/^\d+$/ }, # INT ADID
        { type => HASHREF },                    # HASHREF ReachCounterHashRef
                                                # {period => , limit => , total => }
    );
    my ($self, @args) = @_;

    my $result;
    eval { $result = $self->{client}->set_reach_counter(@args); };
    if (my $e = Adriver::DBI::Exceptions::DBError->caught())
    {
        Adriver::DBI::Exceptions::Clients->throw(
            error  => Adriver::ErrorMessage::error_message($e),
            code   => $e->{code},
            method => 'set_reach_counter',
            args   => \@args
        );
    }

    return $result;
}

sub set_exposures_counter
{
    validate_pos(@_, { type => OBJECT },
        { type => SCALAR, regex => qr/^\d+$/ }, # INT RLENetADID
        { type => HASHREF },                    # HASHREF HourlyCounterHashRef
    );
    my ($self, @args) = @_;

    my $result;
    eval { $result = $self->{client}->set_exposures_counter(@args); };
    if (my $e = Adriver::DBI::Exceptions::DBError->caught())
    {
        Adriver::DBI::Exceptions::Clients->throw(
            error  => Adriver::ErrorMessage::error_message($e),
            code   => $e->{code},
            method => 'set_exposures_counter',
            args   => \@args
        );
    }

    return $result;
}

sub set_clicks_counter
{
    validate_pos(@_, { type => OBJECT },
        { type => SCALAR, regex => qr/^\d+$/ }, # INT RLENetADID
        { type => HASHREF },                    # HASHREF HourlyCounterHashRef
    );
    my ($self, @args) = @_;

    my $result;
    eval { $result = $self->{client}->set_clicks_counter(@args); };
    if (my $e = Adriver::DBI::Exceptions::DBError->caught())
    {
        Adriver::DBI::Exceptions::Clients->throw(
            error  => Adriver::ErrorMessage::error_message($e),
            code   => $e->{code},
            method => 'set_clicks_counter',
            args   => \@args
        );
    }

    return $result;
}

sub set_rep_exposures_counter
{
    validate_pos(@_, { type => OBJECT },
        { type => SCALAR, regex => qr/^\d+$/ }, # INT RLENetADID
        { type => HASHREF },                    # HASHREF HourlyCounterHashRef
    );
    my ($self, @args) = @_;

    my $result;
    eval { $result = $self->{client}->set_rep_exposures_counter(@args); };
    if (my $e = Adriver::DBI::Exceptions::DBError->caught())
    {
        Adriver::DBI::Exceptions::Clients->throw(
            error  => Adriver::ErrorMessage::error_message($e),
            code   => $e->{code},
            method => 'set_rep_exposures_counter',
            args   => \@args
        );
    }

    return $result;
}

sub set_rep_clicks_counter
{
    validate_pos(@_, { type => OBJECT },
        { type => SCALAR, regex => qr/^\d+$/ }, # INT RLENetADID
        { type => HASHREF },                    # HASHREF HourlyCounterHashRef
    );
    my ($self, @args) = @_;

    my $result;
    eval { $result = $self->{client}->set_rep_clicks_counter(@args); };
    if (my $e = Adriver::DBI::Exceptions::DBError->caught())
    {
        Adriver::DBI::Exceptions::Clients->throw(
            error  => Adriver::ErrorMessage::error_message($e),
            code   => $e->{code},
            method => 'set_rep_clicks_counter',
            args   => \@args
        );
    }

    return $result;
}

sub get_top_exposures
{
    validate_pos(@_, { type => OBJECT },
        { type => SCALAR | UNDEF },             # INT RLENetID
        { type => ARRAYREF },                   # ARRAYREF of INT RLENetADIDs
        { type => HASHREF },                    # HASHREF HourlyCounterHashRefMask
        { type => HASHREF },                    # HASHREF ReqTemplHashRef
        { type => ARRAYREF },                   # ARRAYREF of INT Flags
        { type => SCALAR, regex => qr/^\d+$/ }, # INT Number
        { type => SCALAR, regex => qr/^\d+$/ }, # INT From
        { type => SCALAR, regex => qr/^\d+$/ }, # BOOL SortOrder
    );
    my ($self, @args) = @_;

    my $result;
    eval { $result = $self->{client}->get_top_exposures(@args); };
    if (my $e = Adriver::DBI::Exceptions::DBError->caught())
    {
        Adriver::DBI::Exceptions::Clients->throw(
            error  => Adriver::ErrorMessage::error_message($e),
            code   => $e->{code},
            method => 'get_top_exposures',
            args   => \@args
        );
    }

    return $result;
}

sub get_top_clicks
{
    validate_pos(@_, { type => OBJECT },
        { type => SCALAR | UNDEF },             # INT RLENetID
        { type => ARRAYREF },                   # ARRAYREF of INT RLENetADIDs
        { type => HASHREF },                    # HASHREF HourlyCounterHashRefMask
        { type => HASHREF },                    # HASHREF ReqTemplHashRef
        { type => ARRAYREF },                   # ARRAYREF of INT Flags
        { type => SCALAR, regex => qr/^\d+$/ }, # INT Number
        { type => SCALAR, regex => qr/^\d+$/ }, # INT From
        { type => SCALAR, regex => qr/^\d+$/ }, # BOOL SortOrder
    );
    my ($self, @args) = @_;

    my $result;
    eval { $result = $self->{client}->get_top_clicks(@args); };
    if (my $e = Adriver::DBI::Exceptions::DBError->caught())
    {
        Adriver::DBI::Exceptions::Clients->throw(
            error  => Adriver::ErrorMessage::error_message($e),
            code   => $e->{code},
            method => 'get_top_clicks',
            args   => \@args
        );
    }

    return $result;
}

sub get_top_rep_exposures
{
    validate_pos(@_, { type => OBJECT },
        { type => SCALAR | UNDEF },             # INT RLENetID
        { type => ARRAYREF },                   # ARRAYREF of INT RLENetADIDs
        { type => HASHREF },                    # HASHREF HourlyCounterHashRefMask
        { type => HASHREF },                    # HASHREF ReqTemplHashRef
        { type => ARRAYREF },                   # ARRAYREF of INT Flags
        { type => SCALAR, regex => qr/^\d+$/ }, # INT Number
        { type => SCALAR, regex => qr/^\d+$/ }, # INT From
        { type => SCALAR, regex => qr/^\d+$/ }, # BOOL SortOrder
    );
    my ($self, @args) = @_;

    my $result;
    eval { $result = $self->{client}->get_top_rep_exposures(@args); };
    if (my $e = Adriver::DBI::Exceptions::DBError->caught())
    {
        Adriver::DBI::Exceptions::Clients->throw(
            error  => Adriver::ErrorMessage::error_message($e),
            code   => $e->{code},
            method => 'get_top_rep_exposures',
            args   => \@args
        );
    }

    return $result;
}

sub get_top_rep_clicks
{
    validate_pos(@_, { type => OBJECT },
        { type => SCALAR | UNDEF },             # INT RLENetID
        { type => ARRAYREF },                   # ARRAYREF of INT RLENetADIDs
        { type => HASHREF },                    # HASHREF HourlyCounterHashRefMask
        { type => HASHREF },                    # HASHREF ReqTemplHashRef
        { type => ARRAYREF },                   # ARRAYREF of INT Flags
        { type => SCALAR, regex => qr/^\d+$/ }, # INT Number
        { type => SCALAR, regex => qr/^\d+$/ }, # INT From
        { type => SCALAR, regex => qr/^\d+$/ }, # BOOL SortOrder
    );
    my ($self, @args) = @_;

    my $result;
    eval { $result = $self->{client}->get_top_rep_clicks(@args); };
    if (my $e = Adriver::DBI::Exceptions::DBError->caught())
    {
        Adriver::DBI::Exceptions::Clients->throw(
            error  => Adriver::ErrorMessage::error_message($e),
            code   => $e->{code},
            method => 'get_top_rep_clicks',
            args   => \@args
        );
    }

    return $result;
}

sub get_top_params
{
    validate_pos(@_, { type => OBJECT },
        { type => SCALAR | UNDEF },             # INT RLENetID
        { type => ARRAYREF },                   # ARRAYREF of INT RLENetADIDs
        { type => SCALAR, regex => qr/^\d+$/ }, # INT SortBy
        { type => SCALAR, regex => qr/^\d+$/ }, # INT Number
        { type => SCALAR, regex => qr/^\d+$/ }, # INT From
        { type => SCALAR, regex => qr/^\d+$/ }, # BOOL SortOrder
    );
    my ($self, @args) = @_;

    my $result;
    eval { $result = $self->{client}->get_top_params(@args); };
    if (my $e = Adriver::DBI::Exceptions::DBError->caught())
    {
        Adriver::DBI::Exceptions::Clients->throw(
            error  => Adriver::ErrorMessage::error_message($e),
            code   => $e->{code},
            method => 'get_top_params',
            args   => \@args
        );
    }

    return $result;
}

sub get_ex
{
    validate_pos(@_, { type => OBJECT },
        { type => SCALAR, regex => qr/^\d+$/ }, # INT RLENetID
        { type => ARRAYREF },                   # ARRAYREF of INT RLENetADIDs
        { type => HASHREF },                    # HASHREF RLENetADHashRefMask
    );
    my ($self, @args) = @_;

    my $result;
    eval { $result = $self->{client}->get_ex(@args); };
    if (my $e = Adriver::DBI::Exceptions::DBError->caught())
    {
        Adriver::DBI::Exceptions::Clients->throw(
            error  => Adriver::ErrorMessage::error_message($e),
            code   => $e->{code},
            method => 'get_ex',
            args   => \@args
        );
    }

    return $result;
}

sub rotate_hourly
{
    validate_pos(@_, { type => OBJECT });
    my ($self, @args) = @_;

    my $result;
    eval { $result = $self->{client}->rotate_hourly(@args); };
    if (my $e = Adriver::DBI::Exceptions::DBError->caught())
    {
        Adriver::DBI::Exceptions::Clients->throw(
            error  => Adriver::ErrorMessage::error_message($e),
            code   => $e->{code},
            method => 'rotate_hourly',
            args   => \@args
        );
    }

    return $result;
}

sub rotate_daily
{
    validate_pos(@_, { type => OBJECT });
    my ($self, @args) = @_;

    my $result;
    eval { $result = $self->{client}->rotate_daily(@args); };
    if (my $e = Adriver::DBI::Exceptions::DBError->caught())
    {
        Adriver::DBI::Exceptions::Clients->throw(
            error  => Adriver::ErrorMessage::error_message($e),
            code   => $e->{code},
            method => 'rotate_daily',
            args   => \@args
        );
    }

    return $result;
}

sub rotate_weekly
{
    validate_pos(@_, { type => OBJECT });
    my ($self, @args) = @_;

    my $result;
    eval { $result = $self->{client}->rotate_weekly(@args); };
    if (my $e = Adriver::DBI::Exceptions::DBError->caught())
    {
        Adriver::DBI::Exceptions::Clients->throw(
            error  => Adriver::ErrorMessage::error_message($e),
            code   => $e->{code},
            method => 'rotate_weekly',
            args   => \@args
        );
    }

    return $result;
}

1;


__END__


=head1 NAME

    Adriver::DBI::Clients::RLENetworkADClient - this module provides methods to work with
    RLE network advertizing companies database.


=head1 DESCRIPTION

    This module is inherited from Adriver::DBI::Clients::BaseID class.


=head1 SYNOPSIS

    use Adriver::DBI;
    use Adriver::DatabaseConnect::Adriver;
    use Adriver::Exceptions;

    my $host = 'f2.x';
    my $port = 16000;

    eval
    {
        my $dbh = Adriver::DBI->new( Adriver::DatabaseConnect::Adriver->new({host => $host, port => $port}) );

        my $RLENetworkADID = 147433;
        my $RLENetworkAD = $dbh->RLENetworkAD->get($RLENetworkADID);
        print Dumper($RLENetworkAD);

        my $db_info = $dbh->RLENetworkAD->GetCaps();
        print Dumper($db_info);

        my $ids = $dbh->RLENetworkAD->getids();
        print Dumper($ids);
    };

    if (my $e = Exception::Class->caught('Adriver::Exceptions'))
    {
        die "Caught Adriver::Exceptions: '", $e->error, "'\n", $e->trace->as_string, "\n";
    }
    elsif ($e = Exception::Class->caught('Exception::Class::Base'))
    {
        die "Caught unknown exception: '", $e->error, "'\n", $e->trace->as_string, "\n";
    }
    elsif ($e = Exception::Class->caught)
    {
        die "$e";
    }


=head1 INHERITED OBJECT INTERFACE

=head2 get($RLENetADID) : $RLENetworkADHashRef

    Get certain RLE network advertizing company from database by it's identifier.

B<RLENetworkADID>

    This is the identifier of advertizing company.

B<RLENetworkADHashRef>

    This is a hash reference with next structure:

    RLENetworkHashRef =>
    {
        'adID'                  => INT
        'networkID'             => INT
        'adName'                => STRING
        'shortName'             => STRING
        'supportName'           => STRING
        'email'                 => STRING
        'credit'                => INT
        'priority'              => INT
        'enable'                => BOOL
        'enables'               => ARRAYREF(128) BOOL
        'debt'                  => INT
        'enable_indexing'       => BOOL
        'creationTime'          => INT
        'balance'               => INT
        'price'                 => INT (??? FLOAT)
        'nice'                  => INT
        'priorityTargeting'     => ARRAYREF(2) INT
        'targeting_cost'        => ARRAYREF(17) INT
        'maxSaleExposures'      => INT
        'salePriceTomorrow'     => INT
        'salePriceToday'        => INT
        'dayMinExposures'       => INT
        'dayMaxExposures'       => INT
        'dayMinClicks'          => INT
        'dayMaxClicks'          => INT
        'uniqueUserMaxShows'    => ARRAYREF(3) INT
        'uniqueUserMaxClicks'   => INT
        'uniqueUserMinInterval' => INT
        'retargetingInfo'       => HASHREF {'objectID'=>INT,'objectType'=>INT,'options'=>ARRAYREF(32) BOOL(?INT)}
        'rep_exposures'         => HourlyCounterHashRef
        'rep_clicks'            => HourlyCounterHashRef
        'exposures'             => HourlyCounterHashRef
        'clicks'                => HourlyCounterHashRef
    }

    where

    HourlyCounterHashRef =>
    {
        'today'     => INT
        'yesterday' => INT
        'week'      => INT
        'last_week' => INT
        'total'     => INT
        'last_hour' => INT
    }

B<Exceptions>

    Adriver::DBI::Exceptions::ParamsValidation
    Adriver::DBI::Exceptions::Clients

=head2 getids() : $RLENetADIDs

    This method returns a list of all advertizing companies identifiers from database.

B<RLENetADIDs>

    This is the array reference with obtained advertizing companies identifiers.

B<Exceptions>

    Adriver::DBI::Exceptions::ParamsValidation
    Adriver::DBI::Exceptions::Clients

=head2 getlist($RLENetADIDs) : ARRAYREF of $RLENetworkADHashRef

    This method returns a list of advertizing companies with specified identifiers.

B<RLENetADIDs>

    This is the array reference with advertizing companies identifiers you want to get.

B<RLENetworkADHashRef>

    This is the same hash reference as described in get() method.

B<Exceptions>

    Adriver::DBI::Exceptions::ParamsValidation
    Adriver::DBI::Exceptions::Clients

=head2 set($RLENetworkADHashRef) : undef

    This method updates given advertizing company in database.

B<RLENetworkADHashRef>

    This is the same hash reference as described in get() method.

B<Exceptions>

    Adriver::DBI::Exceptions::ParamsValidation
    Adriver::DBI::Exceptions::Clients

=head2 add($RLENetworkADHashRef) : $RLENetADID

    This method adds the new advertizing company in database and returns it's identifier.

B<RLENetworkHashRef>

    This is the same hash reference as described in get() method.

B<RLENetADID>

    This is the integer identifier of added company.

B<Exceptions>

    Adriver::DBI::Exceptions::ParamsValidation
    Adriver::DBI::Exceptions::Clients

=head2 remove($RLENetADID) : undef

    This method removes advertizing company from database by it's identifier.

B<RLENetADID>

    This is the company identifier you want to remove.

B<Exceptions>

    Adriver::DBI::Exceptions::ParamsValidation
    Adriver::DBI::Exceptions::Clients


=head1 OBJECT INTERFACE

=head2 add_credit($RLENetADID, $amount) : $new_amount

    This method adds specified amount of credits to the company.

B<RLENetADID>

    This is the company's identifier which amount of credits you want to increase.

B<amount>

    This is the amount of credits you want to add to the company.

B<new_amount>

    This is the new amount of credits of the company.

B<Exceptions>

    Adriver::DBI::Exceptions::ParamsValidation
    Adriver::DBI::Exceptions::Clients

=head2 set_credit($RLENetADID, $new_amount) : $new_amount

    This method sets the new amount of credits to the company.

B<RLENetADID>

    This is the company's identifier which amount of credits you want to set.

B<new_amount>

    This is the new amount of credits of the company.

B<Exceptions>

    Adriver::DBI::Exceptions::ParamsValidation
    Adriver::DBI::Exceptions::Clients

=head2 reset_balance($RLENetADID) : 1

    This method resets daily balance counter in specified company.

B<RLENetADID>

    This is the company's identifier which balance you want to reset.

B<Exceptions>

    Adriver::DBI::Exceptions::ParamsValidation
    Adriver::DBI::Exceptions::Clients

=head2 exposure($RLENetADID) : 1

    This method icrements the number of banner exposures for certain advertizing company.
    DONOT USE THIS METHODS IN IFACES! SPECIAL SYSTEM CALLS!

B<RLENetADID>

    This is the identifier of company which banner exposures counter you want to increase.

B<Exceptions>

    Adriver::DBI::Exceptions::ParamsValidation
    Adriver::DBI::Exceptions::Clients

=head2 click($RLENetADID) : 1

    This method icrements the number of banner clicks for certain advertizing company.
    DONOT USE THIS METHODS IN IFACES! SPECIAL SYSTEM CALLS!

B<RLENetADID>

    This is the identifier of company which banner clicks counter you want to increase.

B<Exceptions>

    Adriver::DBI::Exceptions::ParamsValidation
    Adriver::DBI::Exceptions::Clients

=head2 rep_exposure($RLENetADID) : 1

    This method icrements the number of banner rep_exposures for certain advertizing company.
    DONOT USE THIS METHODS IN IFACES! SPECIAL SYSTEM CALLS!

B<RLENetADID>

    This is the identifier of company which banner rep_exposures counter you want to increase.

B<Exceptions>

    Adriver::DBI::Exceptions::ParamsValidation
    Adriver::DBI::Exceptions::Clients

=head2 rep_click($RLENetADID) : 1

    This method icrements the number of banner rep_clicks for certain advertizing company.
    DONOT USE THIS METHODS IN IFACES! SPECIAL SYSTEM CALLS!

B<RLENetADID>

    This is the identifier of company which banner rep_clicks counter you want to increase.

B<Exceptions>

    Adriver::DBI::Exceptions::ParamsValidation
    Adriver::DBI::Exceptions::Clients

=head2 set_exposures_counter($RLENetADID, $HourlyCounterHashRef) : 1

    This method sets the counter of banner exposures for certain advertizing company.

B<RLENetADID>

    This is the company identifier which banner exposures counter you want to set.

B<HourlyCounterHashRef>

    This is the same hash reference as described in get() method.

B<Exceptions>

    Adriver::DBI::Exceptions::ParamsValidation
    Adriver::DBI::Exceptions::Clients

=head2 set_clicks_counter($RLENetADID, $HourlyCounterHashRef) : 1

    This method sets the counter of banner clicks for certain advertizing company.

B<RLENetADID>

    This is the company identifier which banner clicks counter you want to set.

B<HourlyCounterHashRef>

    This is the same hash reference as described in get() method.

B<Exceptions>

    Adriver::DBI::Exceptions::ParamsValidation
    Adriver::DBI::Exceptions::Clients

=head2 set_rep_exposures_counter($RLENetADID, $HourlyCounterHashRef) : 1

    This method sets the counter of banner rep_exposures for certain advertizing company.

B<RLENetADID>

    This is the company identifier which banner rep_exposures counter you want to set.

B<HourlyCounterHashRef>

    This is the same hash reference as described in get() method.

B<Exceptions>

    Adriver::DBI::Exceptions::ParamsValidation
    Adriver::DBI::Exceptions::Clients

=head2 set_rep_clicks_counter($RLENetADID, $HourlyCounterHashRef) : 1

    This method sets the counter of banner rep_clicks for certain advertizing company.

B<RLENetADID>

    This is the company identifier which banner rep_clicks counter you want to set.

B<HourlyCounterHashRef>

    This is the same hash reference as described in get() method.

B<Exceptions>

    Adriver::DBI::Exceptions::ParamsValidation
    Adriver::DBI::Exceptions::Clients

=head2 get_top_exposures($RLENetID, $RLENetADIDs, $HourlyCounterHashRefMask, $ReqTemplHashRef, $Flags, $Number, $From, $SortOrderFlag) : ARRAYREF of $RLENetworkADHashRef

    Get top-list for counter, specified in HourlyCounterHashRefMask ("counter" => 1)
    Its highly recommended to set to 1 only one counter, if you set many, func will use only one.
    If list of the ADIDs is not empty, func get toplist from this list, otherwise from all network.

B<RLENetID>

    This is the RLE network identifier.

B<RLENetADIDs>

    This is a list of companies in which function will make a search.

B<HourlyCounterHashRefMask>

    This is the hash reference with next structure:

    HourlyCounterHashRefMask =>
    {
        'today'     => BOOL
        'yesterday' => BOOL
        'week'      => BOOL
        'last_week' => BOOL
        'total'     => BOOL
        'last_hour' => BOOL
    }

B<ReqTemplHashRef>

    This is a hash reference with options for query. It has next structure:

    ReqTemplHashRef =>
    {
        'networkID'       => INT
        'priority'        => INT
        'end_priority'    => INT
        'nice'            => INT
        'enable_indexing' => BOOL
        'enable'          => BOOL
    }

    Priority: 0 - common, 1 - gold, 100-200 commerce, 200-300 hosters
    Nice: -1 low, 0 normal, +1 high
    Enable_indexing: if off ad is not in pretendent queue

B<Flags>

    This is the array reference of integer flags.

     Flags ARRAYREF (5) BOOL

     FlagListL:
     ENABLE          0
     ENABLE_INDEXING 1
     PRIORITY        2
     NICE            3
     NETWORKID       4

B<Number>

    This is the number of elements in output.

B<From>

    From what element we get Number of RLENetworkADs.

B<SortOrderFlag>

    Sort order: FORWARD = 0 (ASC), REVERSE = 1 (DESC) ?

B<RLENetworkADHashRef>

    This is the same hash reference as described in get() method.

B<Exceptions>

    Adriver::DBI::Exceptions::ParamsValidation
    Adriver::DBI::Exceptions::Clients

=head2 get_top_clicks($RLENetID, $RLENetADIDs, $HourlyCounterHashRefMask, $ReqTemplHashRef, $Flags, $Number, $From, $SortOrderFlag) : ARRAYREF of $RLENetworkADHashRef

    Get top-list for counter, specified in HourlyCounterHashRefMask ("counter" => 1)
    Its highly recommended to set to 1 only one counter, if you set many, func will use only one.
    If list of the ADIDs is not empty, func get toplist from this list, otherwise from all network.

B<RLENetID>

    This is the RLE network identifier.

B<RLENetADIDs>

    This is a list of companies in which function will make a search.

B<HourlyCounterHashRefMask>

    This is the same hash reference as described in get_top_exposures() method.

B<ReqTemplHashRef>

    This is the same hash reference as described in get_top_exposures() method.

B<Flags>

    This is the array reference of integer flags as in get_top_exposures() method.

B<Number>

    This is the number of elements in output.

B<From>

    From what element we get Number of RLENetworkADs.

B<SortOrderFlag>

    Sort order: FORWARD = 0 (ASC), REVERSE = 1 (DESC) ?

B<RLENetworkADHashRef>

    This is the same hash reference as described in get() method.

B<Exceptions>

    Adriver::DBI::Exceptions::ParamsValidation
    Adriver::DBI::Exceptions::Clients

=head2 get_top_rep_exposures($RLENetID, $RLENetADIDs, $HourlyCounterHashRefMask, $ReqTemplHashRef, $Flags, $Number, $From, $SortOrderFlag) : ARRAYREF of $RLENetworkADHashRef

    Get top-list for counter, specified in HourlyCounterHashRefMask ("counter" => 1)
    Its highly recommended to set to 1 only one counter, if you set many, func will use only one.
    If list of the ADIDs is not empty, func get toplist from this list, otherwise from all network.

B<RLENetID>

    This is the RLE network identifier.

B<RLENetADIDs>

    This is a list of companies in which function will make a search.

B<HourlyCounterHashRefMask>

    This is the same hash reference as described in get_top_exposures() method.

B<ReqTemplHashRef>

    This is the same hash reference as described in get_top_exposures() method.

B<Flags>

    This is the array reference of integer flags as in get_top_exposures() method.

B<Number>

    This is the number of elements in output.

B<From>

    From what element we get Number of RLENetworkADs.

B<SortOrderFlag>

    Sort order: FORWARD = 0 (ASC), REVERSE = 1 (DESC) ?

B<RLENetworkADHashRef>

    This is the same hash reference as described in get() method.

B<Exceptions>

    Adriver::DBI::Exceptions::ParamsValidation
    Adriver::DBI::Exceptions::Clients

=head2 get_rep_top_clicks($RLENetID, $RLENetADIDs, $HourlyCounterHashRefMask, $ReqTemplHashRef, $Flags, $Number, $From, $SortOrderFlag) : ARRAYREF of $RLENetworkADHashRef

    Get top-list for counter, specified in HourlyCounterHashRefMask ("counter" => 1)
    Its highly recommended to set to 1 only one counter, if you set many, func will use only one.
    If list of the ADIDs is not empty, func get toplist from this list, otherwise from all network.

B<RLENetID>

    This is the RLE network identifier.

B<RLENetADIDs>

    This is a list of companies in which function will make a search.

B<HourlyCounterHashRefMask>

    This is the same hash reference as described in get_top_exposures() method.

B<ReqTemplHashRef>

    This is the same hash reference as described in get_top_exposures() method.

B<Flags>

    This is the array reference of integer flags as in get_top_exposures() method.

B<Number>

    This is the number of elements in output.

B<From>

    From what element we get Number of RLENetworkADs.

B<SortOrderFlag>

    Sort order: FORWARD = 0 (ASC), REVERSE = 1 (DESC) ?

B<RLENetworkADHashRef>

    This is the same hash reference as described in get() method.

B<Exceptions>

    Adriver::DBI::Exceptions::ParamsValidation
    Adriver::DBI::Exceptions::Clients

=head2 get_top_params($RLENetID, $RLENetADIDs, $SortBy, $Number, $From, $SortOrderFlag) : ARRAYREF of $RLENetworkADHashRef

    Get top-list by some parameter.
    If list of the ADIDs is not empty, func get toplist from this list,
    otherwise from all network.

B<RLENetID>

    This is the RLE network identifier.

B<RLENetADIDs>

    This is a list of companies in which function will make a search.

B<SortBy>

    Parameter for sort (0 - by credit, 1 - by balance)

B<Number>

    This is the number of elements in output.

B<From>

    From what element we get Number of RLENetworkADs.

B<SortOrderFlag>

    Sort order: FORWARD = 0 (ASC), REVERSE = 1 (DESC) ?

B<RLENetworkADHashRef>

    This is the same hash reference as described in get() method.

B<Exceptions>

    Adriver::DBI::Exceptions::ParamsValidation
    Adriver::DBI::Exceptions::Clients

=head2 get_ex($RLENetID, $RLENetADIDs, $RLENetADHashRefMask) : ARRAYREF of RLENetworkADHashRef

    This method gets advertizing companies appropriate to mask RLENetADHashRefMask.
    If list of the ADIDs is specified, function searchs companies from this list.

B<RLENetID>

    This is the RLE network identifier.

B<RLENetADIDs>

    This is a list of companies in which function will make a search.

B<RLENetADHashRefMask>

    This is a hash reference. Elements in mask is substrs for search in base.
    The structure specified below:

    RLENetADHashRefMask =>
    {
        'networkID'   => INT
        'adName'      => STRING
        'email'       => STRING
        'supportName' => STRING
        'shortName'   => STRING
    }

B<RLENetworkADHashRef>

    This is the same hash reference as described in get() method.

B<Exceptions>

    Adriver::DBI::Exceptions::ParamsValidation
    Adriver::DBI::Exceptions::Clients

=head2 rotate_hourly() : undef

    This procedure rotates hourly counters in all companies.
    DONOT USE THIS METHODS IN IFACES! SPECIAL SYSTEM CALLS!

B<Exceptions>

    Adriver::DBI::Exceptions::ParamsValidation
    Adriver::DBI::Exceptions::Clients

=head2 rotate_daily() : undef

    This procedure rotates daily counters in all companies.
    DONOT USE THIS METHODS IN IFACES! SPECIAL SYSTEM CALLS!

B<Exceptions>

    Adriver::DBI::Exceptions::ParamsValidation
    Adriver::DBI::Exceptions::Clients

=head2 rotate_weekly() : undef

    This procedure rotates weekly counters in all companies.
    DONOT USE THIS METHODS IN IFACES! SPECIAL SYSTEM CALLS!

B<Exceptions>

    Adriver::DBI::Exceptions::ParamsValidation
    Adriver::DBI::Exceptions::Clients


=head1 SEE ALSO

    Adriver::DBI::Clients::BaseID
    Adriver::DBI::Exceptions

