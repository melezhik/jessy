package Adriver::DBI::Clients::BannerOverStatClient;

use strict;
our $VERSION = '0.0300';
use Carp;
use Params::Validate qw(:all);
use base qw ( Adriver::DBI::Clients::BaseStatClient );

validation_options(on_fail => sub { Adriver::DBI::Exceptions::ParamsValidation->throw( error => $_[0]); } );

sub package { 'RLE::BannerOverStatClient' }

#### Generic StatClient Functions
#
# GetTotal    (HASHREF ClientBannerRequestParamsHashRef)
# GetTable    (ARRAYREF of INT BannerIDs, HASHREF ClientBannerRequestParamsHashRef)
# GetGeo      (ARRAYREF of INT GeoIDs, HASHREF ClientBannerRequestParamsHashRef)
# GetMonthDay (HASHREF ClientBannerRequestParamsHashRef)
# GetWeekDay  (HASHREF ClientBannerRequestParamsHashRef)
# GetDayHour  (HASHREF ClientBannerRequestParamsHashRef)
# GetUniStat  (HASHREF ClientBannerRequestParamsHashRef)
# GetGeoDays  (HASHREF ClientBannerRequestParamsHashRef)
#
#### Functions
#
## Get stat for banners in profile
#
# GetProfileBanners(HASHREF ClientBannerRequestParamsHashRef)
#
## Get stat for default banners in AD
#
# GetDefProfileBanners(HASHREF ClientBannerRequestParamsHashRef)
#
## Get stat by network categories for banners from RLENetworkAD
#
# GetSiteCatTable(ARRAYREF of INT BannerIDs, HASHREF ClientBannerRequestParamsHashRef)
#
## Get stat for AD or profile banners
## ?: ARRAYREF of INT ?IDs
#
# GetDetail(ARRAYREF of INT IDs, HASHREF ClientBannerRequestParamsHashRef)
#
#### Input Data Info
#
# HASHREF ClientBannerRequestParamsHashRef =>
# {
#     'bannerID'       => INT
#     'flags'          => INT     # Common flags for all stat clients
#
#     'adID'           => INT     # GetDefProfileBanners()
#     'networkADType'  => INT     # GetDefProfileBanners()
#
#     'profileID'      => INT     # GetProfileBanners()
#
#     'geoID'          => INT
#     'geoIDstart'     => INT
#     'geoIDend'       => INT
#
#     'startDate'      => INT
#     'endDate'        => INT
#
#     'opcode'         => INT     # Operation code OP_NONE = 0 OP_SUM = 1 OP_ILLEGAL = 2
#
#     'grid'           => INT     # 1 record per day/hour HOUR = 24 DAY = 1
#
#     'detailSrcType'  => INT     # GetDetail()
#     'detailDstType'  => INT     # GetDetail()
#
#     # DO NOT SET/MODIFY!
#     'what'           => INT
#     'noCache'        => BOOL
#     'juuEventType'   => INT
#     'juuCatID'       => INT
#     'juuNetworkType' => INT
# }
#
## Flags
#
# MONTH_FIXED_LENGTH   0x2  // Using for BasePlotStat result. Result will have a fixed length size.
# GET_SUB_EVENT        0x4  // Set this bit to have subevents in result.
# GET_SITE_CATS        0x8  // Not used.
# DEFPROF_SUPPORT_FLAG 0x10 // Set this bit to get default stat data in all ad requsts (internal using).
# GET_UU_RANGE         0x20 // Set this bit to get UU in GetMonthDay reqests.
#
####

sub GetProfileBanners
{
    validate_pos(@_, { type => OBJECT }, { type => HASHREF });
    my ($self, @args) = @_;

    my $result;
    eval { $result = $self->{client}->GetProfileBanners(@args); };
    if (my $e = Adriver::DBI::Exceptions::DBError->caught())
    {
        Adriver::DBI::Exceptions::Clients->throw(
            error  => Adriver::ErrorMessage::error_message($e),
            code   => $e->{code},
            method => 'GetProfileBanners',
            args   => \@args
        );
    }

    return $result;
}

sub GetDefProfileBanners
{
    validate_pos(@_, { type => OBJECT }, { type => HASHREF });
    my ($self, @args) = @_;

    my $result;
    eval { $result = $self->{client}->GetDefProfileBanners(@args); };
    if (my $e = Adriver::DBI::Exceptions::DBError->caught())
    {
        Adriver::DBI::Exceptions::Clients->throw(
            error  => Adriver::ErrorMessage::error_message($e),
            code   => $e->{code},
            method => 'GetDefProfileBanners',
            args   => \@args
        );
    }

    return $result;
}

sub GetSiteCatTable
{
    validate_pos(@_, { type => OBJECT }, { type => ARRAYREF }, { type => HASHREF });
    my ($self, @args) = @_;

    my $result;
    eval { $result = $self->{client}->GetSiteCatTable(@args); };
    if (my $e = Adriver::DBI::Exceptions::DBError->caught())
    {
        Adriver::DBI::Exceptions::Clients->throw(
            error  => Adriver::ErrorMessage::error_message($e),
            code   => $e->{code},
            method => 'GetSiteCatTable',
            args   => \@args
        );
    }

    return $result;
}

sub GetDetail
{
    validate_pos(@_, { type => OBJECT }, { type => ARRAYREF }, { type => HASHREF });
    my ($self, @args) = @_;

    my $result;
    eval { $result = $self->{client}->GetDetail(@args); };
    if (my $e = Adriver::DBI::Exceptions::DBError->caught())
    {
        Adriver::DBI::Exceptions::Clients->throw(
            error  => Adriver::ErrorMessage::error_message($e),
            code   => $e->{code},
            method => 'GetDetail',
            args   => \@args
        );
    }

    return $result;
}

1;


__END__


=head1 NAME

    Adriver::DBI::Clients::BannerOverStatClient - this module provides methods to get
    statistics by banners.


=head1 DESCRIPTION

    This module is inherited from Adriver::DBI::Clients::BaseStatClient class.


=head1 SYNOPSIS

    use Adriver::DBI::Stat;
    use Adriver::DatabaseConnect::Stat;
    use Adriver::Exceptions;
    use Data::Dumper;

    my $config_file = '../stat4perl.conf';

    eval
    {
        my $dbh = Adriver::DBI::Stat->new(
            Adriver::DatabaseConnect::Stat->new(config_file => $config_file)
        );

        my $banner_id = 413634;
        my $banner_stat = $dbh->Banner->GetTotal({ 'bannerID' => $banner_id });
        print Dumper($banner_stat);

        my $profile_id = 241790;
        my $banner_stat = $dbh->Banner->GetProfileBanners({ 'profileID' => $profile_id });
        print Dumper($banner_stat);
    };

    if (my $e = Exception::Class->caught('Adriver::Exceptions'))
    {
        die "Caught Adriver::Exceptions: '", $e->error, "'\n", $e->trace->as_string, "\n";
    }
    elsif ($e = Exception::Class->caught('Exception::Class::Base'))
    {
        die "Caught unknown exception: '", $e->error, "'\n", $e->trace->as_string, "\n";
    }
    elsif ($e = Exception::Class->caught)
    {
        die "$e";
    }


=head1 INHERITED OBJECT INTERFACE

=head2 GetTotal($ClientBannerRequestParamsHashRef)

    Get total stat for banner.

B<ClientBannerRequestParamsHashRef>

    This is a hash reference with next structure:

    ClientBannerRequestParamsHashRef =>
    {
        'bannerID'       => INT
        'flags'          => INT     # Common flags for all stat clients

        'adID'           => INT     # GetDefProfileBanners()
        'networkADType'  => INT     # GetDefProfileBanners()

        'profileID'      => INT     # GetProfileBanners()

        'geoID'          => INT
        'geoIDstart'     => INT
        'geoIDend'       => INT

        'startDate'      => INT
        'endDate'        => INT

        'opcode'         => INT     # Operation code OP_NONE = 0 OP_SUM = 1 OP_ILLEGAL = 2

        'grid'           => INT     # 1 record per day/hour HOUR = 24 DAY = 1

        'detailSrcType'  => INT     # GetDetail()
        'detailDstType'  => INT     # GetDetail()

        # DO NOT SET/MODIFY!
        'what'           => INT
        'noCache'        => BOOL
        'juuEventType'   => INT
        'juuCatID'       => INT
        'juuNetworkType' => INT
    }

B<Flags>

    MONTH_FIXED_LENGTH   0x2  // Using for BasePlotStat result. Result will have a fixed length size.
    GET_SUB_EVENT        0x4  // Set this bit to have subevents in result.
    GET_SITE_CATS        0x8  // Not used.
    DEFPROF_SUPPORT_FLAG 0x10 // Set this bit to get default stat data in all ad requsts (internal using).
    GET_UU_RANGE         0x20 // Set this bit to get UU in GetMonthDay reqests.

B<Exceptions>

    Adriver::DBI::Exceptions::ParamsValidation
    Adriver::DBI::Exceptions::Clients

=head2 GetTable($BannerIDs, $ClientBannerRequestParamsHashRef)

    Get total stats for list of banners with specified identifiers.

B<BannerIDs>

    ARRAYREF of INT banners identifiers.

B<ClientBannerRequestParamsHashRef>

    This is the same hash reference as described in GetTotal() method.

B<Exceptions>

    Adriver::DBI::Exceptions::ParamsValidation
    Adriver::DBI::Exceptions::Clients

=head2 GetGeo($GeoIDs, $ClientBannerRequestParamsHashRef)

    Get geo stat for banner.
    If GeoIDs specified only for this GeoIDs.
    If GeoIDs empty for all GeoIDs.

B<GeoIDs>

    ARRAYREF of INT GeoIDs.

B<ClientBannerRequestParamsHashRef>

    This is the same hash reference as described in GetTotal() method.

B<Exceptions>

    Adriver::DBI::Exceptions::ParamsValidation
    Adriver::DBI::Exceptions::Clients

=head2 GetMonthDay($ClientBannerRequestParamsHashRef)

    Get statistics for banner by days.

B<ClientBannerRequestParamsHashRef>

    This is the same hash reference as described in GetTotal() method.

B<Exceptions>

    Adriver::DBI::Exceptions::ParamsValidation
    Adriver::DBI::Exceptions::Clients

=head2 GetWeekDay($ClientBannerRequestParamsHashRef)

    Get average statistics for banner by weekday.

B<ClientBannerRequestParamsHashRef>

    This is the same hash reference as described in GetTotal() method.

B<Exceptions>

    Adriver::DBI::Exceptions::ParamsValidation
    Adriver::DBI::Exceptions::Clients

=head2 GetDayHour($ClientBannerRequestParamsHashRef)

    Get average statistics for banner by dayhour.

B<ClientBannerRequestParamsHashRef>

    This is the same hash reference as described in GetTotal() method.

B<Exceptions>

    Adriver::DBI::Exceptions::ParamsValidation
    Adriver::DBI::Exceptions::Clients

=head2 GetUniStat($ClientBannerRequestParamsHashRef)

    Universal stat request.

B<ClientBannerRequestParamsHashRef>

    This is the same hash reference as described in GetTotal() method.

B<Exceptions>

    Adriver::DBI::Exceptions::ParamsValidation
    Adriver::DBI::Exceptions::Clients

=head2 GetGeoDays($ClientBannerRequestParamsHashRef)

    Geo stat by days.

B<ClientBannerRequestParamsHashRef>

    This is the same hash reference as described in GetTotal() method.

B<Exceptions>

    Adriver::DBI::Exceptions::ParamsValidation
    Adriver::DBI::Exceptions::Clients

=head2 GetDaysCount($ClientBannerRequestParamsHashRef)

    Get begindate, enddate and diff (in weeks).

B<ClientBannerRequestParamsHashRef>

    This is the same hash reference as described in GetTotal() method.

B<Exceptions>

    Adriver::DBI::Exceptions::ParamsValidation
    Adriver::DBI::Exceptions::Clients


=head1 OBJECT INTERFACE

=head2 GetProfileBanners($ClientBannerRequestParamsHashRef)

    Get stat for banner in profile.

B<ClientBannerRequestParamsHashRef>

    This is the same hash reference as described in GetTotal() method.

B<Exceptions>

    Adriver::DBI::Exceptions::ParamsValidation
    Adriver::DBI::Exceptions::Clients

=head2 GetDefProfileBanners($ClientBannerRequestParamsHashRef)

    Get stat for default banners in AD.

B<ClientBannerRequestParamsHashRef>

    This is the same hash reference as described in GetTotal() method.

B<Exceptions>

    Adriver::DBI::Exceptions::ParamsValidation
    Adriver::DBI::Exceptions::Clients

=head2 GetSiteCatTable($BannerIDs, $ClientBannerRequestParamsHashRef)

    Get stat by network categories for banners from RLENetworkAD.

B<BannerIDs>

    ARRAYREF of INT banners identifiers.

B<ClientBannerRequestParamsHashRef>

    This is the same hash reference as described in GetTotal() method.

B<Exceptions>

    Adriver::DBI::Exceptions::ParamsValidation
    Adriver::DBI::Exceptions::Clients

=head2 GetDetail($IDs, $ClientBannerRequestParamsHashRef)

    Get stat for AD or profile banners.

B<IDs>

    ? ARRAYREF of INT ?IDs

B<ClientBannerRequestParamsHashRef>

    This is the same hash reference as described in GetTotal() method.

B<Exceptions>

    Adriver::DBI::Exceptions::ParamsValidation
    Adriver::DBI::Exceptions::Clients


=head1 SEE ALSO

    Adriver::DBI::Clients::BaseStatClient
    Adriver::DBI::Exceptions

