package Adriver::DBI::Clients::GeoClient;

use strict;
our $VERSION = '0.0300';
use Carp;
use Params::Validate qw(:all);
use base qw ( Adriver::DBI::Clients::Base );

validation_options(on_fail => sub { Adriver::DBI::Exceptions::ParamsValidation->throw( error => $_[0]); } );

sub package { 'RLE::GeoClient' }

#### Functions
#
## Get, set, add, remove Geo
#
# (HASHREF GeoHashRef) get(INT IP)
# (INT 0) set(HASHREF GeoHashRef)
# (INT 0) add(HASHREF GeoHashRef)
# (INT 0) remove(HASHREF GeoHashRef)
#
## Get list of Geo by GeoHashRefMask
#
# (ARRAYREF of HASHREF GeoHashRefs) get_list(HASHREF GeoHashRefMask)
#
#### Input Data Info
#
## I'm not sure. Maybe we can use all fields in mask, but in SuperAdmin
## Adriver Face used only this ones. And when I tried to use other fields, 
## this was VERY slow (i didn't get any result, but maybe it possible). 
## Maybe there is no indexing for other fields.
#
# GeoHashRefMask =>
# {
#     'start_IP'         => INT
#     'stop_IP'          => INT
#     'geoZone'          => INT
#     'Country_ID'       => INT
#     'City_ID'          => INT
#     'ConnectionType'   => INT
#     'organizationType' => INT
# }
#
# GeoHashRef =>
# {
#     'start_IP'         => INT
#     'stop_IP'          => INT
#     'geoZone'          => INT
#     'timeZone'         => INT
#     'Region_ID'        => INT
#     'Country_ID'       => INT
#     'City_ID'          => INT
#     'zipCode'          => INT
#     'ISP'              => INT
#     'ConnectionType'   => INT
#     'organizationType' => INT
#     'telPrefix'        => INT
#     'telPrefixDigNum'  => INT
# }
#
####

sub get
{
    validate_pos(@_, { type => OBJECT },
        { type => SCALAR }, # INT IP
    );
    my ($self, @args) = @_;

    my $result;
    eval { $result = $self->{client}->get(@args); };

    if (my $e = Adriver::DBI::Exceptions::DBError->caught())
    {
        Adriver::DBI::Exceptions::Clients->throw(
            error  => Adriver::ErrorMessage::error_message($e),
            code   => $e->{code},
            method => 'get',
            args   => \@args
        );
    }

    return $result;
}

sub get_list
{
    validate_pos(@_, { type => OBJECT },
        { type => HASHREF }, # HASHREF GeoHashRefMask
    );
    my ($self, @args) = @_;

    my $result;
    eval { $result = $self->{client}->get_list(@args); };

    if (my $e = Adriver::DBI::Exceptions::DBError->caught())
    {
        Adriver::DBI::Exceptions::Clients->throw(
            error  => Adriver::ErrorMessage::error_message($e),
            code   => $e->{code},
            method => 'get_list',
            args   => \@args
        );
    }

    return $result;
}

sub set
{
    validate_pos(@_, { type => OBJECT },
        { type => HASHREF }, # HASHREF GeoHashRef
    );
    my ($self, @args) = @_;

    my $result;
    eval { $result = $self->{client}->set(@args); };
    if (my $e = Adriver::DBI::Exceptions::DBError->caught())
    {
        Adriver::DBI::Exceptions::Clients->throw(
            error  => Adriver::ErrorMessage::error_message($e),
            code   => $e->{code},
            method => 'set',
            args   => \@args
        );
    }

    return $result;
}

sub add
{
    validate_pos(@_, { type => OBJECT },
        { type => HASHREF }, # HASHREF GeoHashRef
    );
    my ($self, @args) = @_;

    my $result;
    eval { $result = $self->{client}->add(@args); };
    if (my $e = Adriver::DBI::Exceptions::DBError->caught())
    {
        Adriver::DBI::Exceptions::Clients->throw(
            error  => Adriver::ErrorMessage::error_message($e),
            code   => $e->{code},
            method => 'add',
            args   => \@args
        );
    }

    return $result;
}

sub remove
{
    validate_pos(@_, { type => OBJECT },
        { type => HASHREF }, # HASHREF GeoHashRef
    );
    my ($self, @args) = @_;

    my $result;
    eval { $result = $self->{client}->remove(@args); };
    if (my $e = Adriver::DBI::Exceptions::DBError->caught())
    {
        Adriver::DBI::Exceptions::Clients->throw(
            error  => Adriver::ErrorMessage::error_message($e),
            code   => $e->{code},
            method => 'remove',
            args   => \@args
        );
    }

    return $result;
}

1;


__END__


=head1 NAME

    Adriver::DBI::Clients::GeoClient - this module provides methods to work with
    Geo database.


=head1 DESCRIPTION

    This module is inherited from Adriver::DBI::Clients::Base class.


=head1 SYNOPSIS

    use Adriver::DBI::Geo;
    use Adriver::DatabaseConnect::Geo;
    use Adriver::Exceptions;

    sub get_ip_int
    {
        my $ip = shift;

        my @ip_cut = split /\./, $ip;
        $ip = 16777216*$ip_cut[0] + 65536*$ip_cut[1] + 256*$ip_cut[2] + $ip_cut[3];

        return $ip;
    }

    my @db_servers;
    push @db_servers, {host => 'f2.x', port => 16000, 'start_IP'=> 0, 'stop_IP' => 4294967295};

    eval
    {
        my $dbh = Adriver::DBI::Geo->new(
            Adriver::DatabaseConnect::Geo->new(config => \@db_servers)
        );

        my $geo = $dbh->Geo->get(get_ip_int("217.170.90.1"));
        print Dumper($geo);

        my $db_info = $dbh->Geo->GetCaps();
        print Dumper($db_info);
    };

    if (my $e = Exception::Class->caught('Adriver::Exceptions'))
    {
        die "Caught Adriver::Exceptions: '", $e->error, "'\n", $e->trace->as_string, "\n";
    }
    elsif ($e = Exception::Class->caught('Exception::Class::Base'))
    {
        die "Caught unknown exception: '", $e->error, "'\n", $e->trace->as_string, "\n";
    }
    elsif ($e = Exception::Class->caught)
    {
        die "$e";
    }


=head1 OBJECT INTERFACE

=head2 get($int_ip) : $GeoHashRef

    Get certain Geo from database.

B<int_ip>

    This is the integer representation of ip address.
    INT IP = 16777216*IP[0] + 65536*IP[1] + 256*IP[2] + IP[3]

B<GeoHashRef>

    This is a hash reference with next structure:

    GeoHashRef =>
    {
        'start_IP'         => INT
        'stop_IP'          => INT
        'geoZone'          => INT
        'timeZone'         => INT
        'Region_ID'        => INT
        'Country_ID'       => INT
        'City_ID'          => INT
        'zipCode'          => INT
        'ISP'              => INT
        'ConnectionType'   => INT
        'organizationType' => INT
        'telPrefix'        => INT
        'telPrefixDigNum'  => INT
    }

B<Exceptions>

    Adriver::DBI::Exceptions::ParamsValidation
    Adriver::DBI::Exceptions::Clients

=head2 set($GeoHashRef) : 0

    This method updates given Geo in database.

B<GeoHashRef>

    This is the same hash reference as described in get() method.

B<Exceptions>

    Adriver::DBI::Exceptions::ParamsValidation
    Adriver::DBI::Exceptions::Clients

=head2 add($GeoHashRef) : 0

    This method adds the new Geo in database.

B<GeoHashRef>

    This is the same hash reference as described in get() method.

B<Exceptions>

    Adriver::DBI::Exceptions::ParamsValidation
    Adriver::DBI::Exceptions::Clients

=head2 remove($GeoHashRef) : 0

    This method removes given Geo from database.

B<GeoHashRef>

    This is the same hash reference as described in get() method.

B<Exceptions>

    Adriver::DBI::Exceptions::ParamsValidation
    Adriver::DBI::Exceptions::Clients

=head2 get_list($GeoHashRefMask) : ARRAYREF of GeoHashRef

    Get list of Geo by GeoHashRefMask.

B<GeoHashRefMask>

    This is the hash reference with next structure:

    GeoHashRefMask =>
    {
        'start_IP'         => INT
        'stop_IP'          => INT
        'geoZone'          => INT
        'Country_ID'       => INT
        'City_ID'          => INT
        'ConnectionType'   => INT
        'organizationType' => INT
    }

B<GeoHashRef>

    This is the same hash reference as described in get() method.

B<Exceptions>

    Adriver::DBI::Exceptions::ParamsValidation
    Adriver::DBI::Exceptions::Clients


=head1 SEE ALSO

    Adriver::DBI::Clients::Base
    Adriver::DBI::Exceptions

