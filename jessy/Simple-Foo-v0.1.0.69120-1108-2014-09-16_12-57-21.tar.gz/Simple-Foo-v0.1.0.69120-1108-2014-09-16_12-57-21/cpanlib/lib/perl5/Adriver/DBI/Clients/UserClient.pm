package Adriver::DBI::Clients::UserClient;

use strict;
our $VERSION = '0.0300';
use Carp;
use Params::Validate qw(:all);
use base qw ( Adriver::DBI::Clients::BaseID );

validation_options(on_fail => sub { Adriver::DBI::Exceptions::ParamsValidation->throw( error => $_[0]); } );

sub package { 'RLE::UserClient' }

#### Generic BaseID Functions
#
# get(INT UserID)
# getids()
# getlist(ARRAYREF of INT UserIDs)
# set(HASHREF UserHashRef)
# add(HASHREF UserHashRef)
# remove(INT UserID)
#
#### Other Functions
#
## Set or add Amount credits for User
#
# (INT NewAmount) add_credit(INT UserID, INT Amount)
# (INT NewAmount) set_credit(INT UserID, INT Amount)
#
## Get User by Login
#
# (HASHREF User) get_bylogin(STRING Login)
#
## Get Users for mask UserHashRefMask
## Elements in mask is substrs for search in base if type is STRING
## If type is INT, elements is compare, if elem == 0, not checked
#
# (ARRAYREF of HASHREF Users) get_list(HASHREF UserHashRefMask)
#
#### Input Data Info
#
# UserHashRefMask =>
# {
#     'userType'   => INT (0 - Admin, 1 - AA, 2 - SimpleAdmin, 4 - PB, 8 - Guest)
#     'personName' => STRING
#     'password'   => STRING
#     'email'      => STRING
#     'login'      => STRING
#     'comment'    => STRING
#     'shortName'  => STRING
# }
#
# UserHashRef =>
# {
#     'userID'        => INT
#     'userType'      => INT
#     'login'         => STRING
#     'password'      => STRING
#     'email'         => STRING
#     'shortName'     => STRING
#     'personName'    => STRING
#     'phone'         => ARRAYREF(3) INT
#     'policy'        => INT
#     'lang'          => INT
#     'locale'        => STRING
#     'comment'       => STRING
#     'interfacePath' => STRING
#     'defaultADID'   => INT
#     'credit'        => INT
#     'enables'       => ARRAYREF(64) INT
#     'creationTime'  => INT
#     'userList'      => ARRAYREF(64) INT
# }
#
####

sub add_credit
{
    validate_pos(@_, { type => OBJECT },
        { type => SCALAR, regex => qr/^\d+$/ }, # INT UserID
        { type => SCALAR, regex => qr/^\d+$/ }, # INT Amount
    );
    my ($self, @args) = @_;

    my $result;
    eval { $result = $self->{client}->add_credit(@args); };
    if (my $e = Adriver::DBI::Exceptions::DBError->caught())
    {
        Adriver::DBI::Exceptions::Clients->throw(
            error  => Adriver::ErrorMessage::error_message($e),
            code   => $e->{code},
            method => 'add_credit',
            args   => \@args
        );
    }

    return $result;
}

sub set_credit
{
    validate_pos(@_, { type => OBJECT },
        { type => SCALAR, regex => qr/^\d+$/ }, # INT UserID
        { type => SCALAR, regex => qr/^\d+$/ }, # INT Amount
    );
    my ($self, @args) = @_;

    my $result;
    eval { $result = $self->{client}->set_credit(@args); };
    if (my $e = Adriver::DBI::Exceptions::DBError->caught())
    {
        Adriver::DBI::Exceptions::Clients->throw(
            error  => Adriver::ErrorMessage::error_message($e),
            code   => $e->{code},
            method => 'set_credit',
            args   => \@args
        );
    }

    return $result;
}


sub get_bylogin
{
    validate_pos(@_, { type => OBJECT },
        { type => SCALAR }, # STRING Login
    );
    my ($self, @args) = @_;

    my $result;
    eval { $result = $self->{client}->get_bylogin(@args); };
    if (my $e = Adriver::DBI::Exceptions::DBError->caught())
    {
        Adriver::DBI::Exceptions::Clients->throw(
            error  => Adriver::ErrorMessage::error_message($e),
            code   => $e->{code},
            method => 'get_bylogin',
            args   => \@args
        );
    }

    return $result;
}

sub get_list
{
    validate_pos(@_, { type => OBJECT },
        { type => HASHREF }, # HASHREF UserHashRefMask
    );
    my ($self, @args) = @_;

    my $result;
    eval { $result = $self->{client}->get_list(@args); };
    if (my $e = Adriver::DBI::Exceptions::DBError->caught())
    {
        Adriver::DBI::Exceptions::Clients->throw(
            error  => Adriver::ErrorMessage::error_message($e),
            code   => $e->{code},
            method => 'get_list',
            args   => \@args
        );
    }

    return $result;
}

1;


__END__


=head1 NAME

    Adriver::DBI::Clients::UserClient - this module provides methods to work with Adriver users database.


=head1 DESCRIPTION

    This module is inherited from Adriver::DBI::Clients::BaseID class.


=head1 SYNOPSIS

    use Adriver::DBI;
    use Adriver::DatabaseConnect::Adriver;
    use Adriver::Exceptions;

    my $host = 'f2.x';
    my $port = 16000;

    my $user_id = 1;
    my $credit = 1000;
    my $login = 'root';

    eval
    {
        my $dbh = Adriver::DBI->new( Adriver::DatabaseConnect::Adriver->new({host => $host, port => $port}) );

        my $user = $dbh->User->get($user_id);
        print Dumper($user);

        $user = $dbh->User->get_bylogin($login);
        print Dumper($user);

        my $users = $dbh->User->get_list({login => $login});
        print Dumper($users);

        $dbh->User->add_credit($user_id, $credit);
        $dbh->User->set_credit($user_id, $credit);

        $dbh->User->set($user);
    };

    if (my $e = Exception::Class->caught('Adriver::Exceptions'))
    {
        die "Caught Adriver::Exceptions: '", $e->error, "\n", $e->trace->as_string, "\n";
    }
    elsif ($e = Exception::Class->caught('Exception::Class::Base'))
    {
        die "Caught unknown exception: '", $e->error, "\n", $e->trace->as_string, "\n";
    }
    elsif ($e = Exception::Class->caught)
    {
        die "$e";
    }


=head1 INHERITED OBJECT INTERFACE

=head2 get($user_id) : $UserHashRef

    Get certain user from database by it's identifier.

B<user_id>

    This is the integer identifier of the user.

B<UserHashRef>

    This is a hash reference with next structure:

    UserHashRef =>
    {
        'userID'        => INT
        'userType'      => INT
        'login'         => STRING
        'password'      => STRING
        'email'         => STRING
        'shortName'     => STRING
        'personName'    => STRING
        'phone'         => ARRAYREF(3) INT
        'policy'        => INT
        'lang'          => INT
        'locale'        => STRING
        'comment'       => STRING
        'interfacePath' => STRING
        'defaultADID'   => INT
        'credit'        => INT
        'enables'       => ARRAYREF(64) INT
        'creationTime'  => INT
        'userList'      => ARRAYREF(64) INT
    }

B<Exceptions>

    Adriver::DBI::Exceptions::ParamsValidation
    Adriver::DBI::Exceptions::Clients

=head2 getids() : $user_ids

    This method returns a list of all users identifiers from database.

B<user_ids>

    This is the array reference with obtained users identifiers.

B<Exceptions>

    Adriver::DBI::Exceptions::ParamsValidation
    Adriver::DBI::Exceptions::Clients

=head2 getlist(\@user_ids) : ARRAYREF of $UserHashRef

    This method returns a list of users from database by their identifiers.

B<user_ids>

    This is the array reference with users identifiers you want to get.

B<UserHashRef>

    This is the same hash reference as described in get() method.

B<Exceptions>

    Adriver::DBI::Exceptions::ParamsValidation
    Adriver::DBI::Exceptions::Clients


=head2 set($UserHashRef) : undef

    This method updates given user in database.

B<UserHashRef>

    This is the same hash reference as described in get() method.

B<Exceptions>

    Adriver::DBI::Exceptions::ParamsValidation
    Adriver::DBI::Exceptions::Clients

=head2 add($UserHashRef) : $user_id

    This method adds the new user in database and returns it's identifier.

B<UserHashRef>

    This is the same hash reference as described in get() method.

B<user_id>

    This is the integer identifier of added user.

B<Exceptions>

    Adriver::DBI::Exceptions::ParamsValidation
    Adriver::DBI::Exceptions::Clients

=head2 remove($user_id) : undef

    This method removes user from database by it's identifier.

B<user_id>

    This is the user identifier you want to remove.

B<Exceptions>

    Adriver::DBI::Exceptions::ParamsValidation
    Adriver::DBI::Exceptions::Clients


=head1 OBJECT INTERFACE

=head2 get_bylogin($login) : $UserHashRef

    Get certain user from database by it's login.

B<login>

    User login.

B<UserHashRef>

    This is the same hash reference as described in get() method.

B<Exceptions>

    Adriver::DBI::Exceptions::ParamsValidation
    Adriver::DBI::Exceptions::Clients

=head2 getlist($UserHashRefMask) : ARRAYREF of $UserHashRef

    This method returns a list of users from database appropriate to specified user mask.

B<UserHashRefMask>

    This is a hash reference with some specified user properties. Structure of this hash specified below.
    Elements in mask is substrs for search in base if type is STRING. If type is INT, elements is compare,
    if elem == 0, not checked. You cat set only a few of this properties.

    UserHashRefMask =>
    {
        'userType'   => INT (0 - Admin, 1 - AA, 2 - SimpleAdmin, 4 - PB, 8 - Guest)
        'personName' => STRING
        'password'   => STRING
        'email'      => STRING
        'login'      => STRING
        'comment'    => STRING
        'shortName'  => STRING
    }

B<UserHashRef>

    This is the same hash reference as described in get() method.

B<Exceptions>

    Adriver::DBI::Exceptions::ParamsValidation
    Adriver::DBI::Exceptions::Clients

=head2 add_credit($user_id, $credit_amount) : undef

    This method adds amount credits to the user with appropriate user identifier.

B<user_id>

    Integer user identifier.

B<credit_amount>

    Integer credit amount.

B<Exceptions>

    Adriver::DBI::Exceptions::ParamsValidation
    Adriver::DBI::Exceptions::Clients

=head2 set_credit($user_id, $credit_amount) : undef

    This method sets amount credits to the user with appropriate user identifier.

B<user_id>

    Integer user identifier.

B<credit_amount>

    Integer credit amount.

B<Exceptions>

    Adriver::DBI::Exceptions::ParamsValidation
    Adriver::DBI::Exceptions::Clients


=head1 SEE ALSO

    Adriver::DBI::Clients::BaseID
    Adriver::DBI
    Adriver::DatabaseConnect::Adriver
    Adriver::DBI::Exceptions

