package Adriver::DBI::Clients::SimpleNetworkADClient;

use strict;
our $VERSION = '0.0300';
use Carp;
use Params::Validate qw(:all);
use base qw ( Adriver::DBI::Clients::BaseID );

validation_options(on_fail => sub { Adriver::DBI::Exceptions::ParamsValidation->throw( error => $_[0]); } );

sub package { 'RLE::SimpleNetwork::SimpleNetworkADClient' }

#### Generic BaseID Functions
#
# get(INT SimpleNetworkADID)
# getids()
# getlist(ARRAYREF of INT SimpleNetworkADIDs)
# set(HASHREF SimpleNetworkADHashRef)
# add(HASHREF SimpleNetworkADHashRef)
# remove(INT SimpleNetworkADID)
#
#### Other Functions
#
## Set or add Amount credits for SimpleNetworkAD
#
# (INT NewAmount) add_credit(INT SimpleNetworkADID, INT Amount)
# (INT NewAmount) set_credit(INT SimpleNetworkADID, INT Amount)
#
## Increment exposures or click in SimpleNetworkAD
## DONOT USE THIS METHODS IN IFACES! SPECIAL SYSTEM CALLS!
#
# (INT 1) exposure(INT SimpleNetworkADID)
# (INT 1) click(INT SimpleNetworkADID)
#
## Sets exposures or click counter in SimpleNetworkAD
#
# (INT 1) set_exposures_counter(INT SimpleNetworkADID, HASHREF CounterHashRef)
# (INT 1) set_clicks_counter(INT SimpleNetworkADID, HASHREF CounterHashRef)
#
## Rotate counter in all ads
## DONOT USE THIS METHODS IN IFACES! SPECIAL SYSTEM CALLS!
#
# (void) rotate_daily()
# (void) rotate_weekly()
#
#### Input Data Info
#
# CounterHashRef =>
# {
#     'today'     => INT
#     'yesterday' => INT
#     'week'      => INT
#     'last_week' => INT
#     'total'     => INT
# }
#
# SimpleNetworkADHashRef =>
# {
#     'adID'                  => INT
#     'adName'                => STRING
#     'enable'                => BOOL
#     'enables'               => ARRAYREF(128) BOOL
#     'priority'              => INT
#     'credit'                => INT
#     'shortName'             => STRING
#     'supportName'           => STRING
#     'email'                 => STRING
#     'creationTime'          => INT
#     'dayMinExposures'       => INT
#     'dayMaxExposures'       => INT
#     'dayMinClicks'          => INT
#     'dayMaxClicks'          => INT
#     'uniqueUserMaxShows'    => ARRAYREF(3) INT
#     'uniqueUserMaxClicks'   => INT
#     'uniqueUserMinInterval' => INT
#     'exposures'             => CounterHashRef
#     'clicks'                => CounterHashRef
# }
#
####


sub add_credit
{
    validate_pos(@_, { type => OBJECT },
        { type => SCALAR, regex => qr/^\d+$/ }, # INT SimpleNetworkADID
        { type => SCALAR, regex => qr/^\d+$/ }, # INT Amount
    );
    my ($self, @args) = @_;

    my $result;
    eval { $result = $self->{client}->add_credit(@args); };
    if (my $e = Adriver::DBI::Exceptions::DBError->caught())
    {
        Adriver::DBI::Exceptions::Clients->throw(
            error  => Adriver::ErrorMessage::error_message($e),
            code   => $e->{code},
            method => 'add_credit',
            args   => \@args
        );
    }

    return $result;
}

sub set_credit
{
    validate_pos(@_, { type => OBJECT },
        { type => SCALAR, regex => qr/^\d+$/ }, # INT SimpleNetworkADID
        { type => SCALAR, regex => qr/^\d+$/ }, # INT Amount
    );
    my ($self, @args) = @_;

    my $result;
    eval { $result = $self->{client}->set_credit(@args); };
    if (my $e = Adriver::DBI::Exceptions::DBError->caught())
    {
        Adriver::DBI::Exceptions::Clients->throw(
            error  => Adriver::ErrorMessage::error_message($e),
            code   => $e->{code},
            method => 'set_credit',
            args   => \@args
        );
    }

    return $result;
}

sub exposure
{
    validate_pos(@_, { type => OBJECT },
        { type => SCALAR, regex => qr/^\d+$/ }, # INT SimpleNetworkADID
    );
    my ($self, @args) = @_;

    my $result;
    eval { $result = $self->{client}->exposure(@args); };
    if (my $e = Adriver::DBI::Exceptions::DBError->caught())
    {
        Adriver::DBI::Exceptions::Clients->throw(
            error  => Adriver::ErrorMessage::error_message($e),
            code   => $e->{code},
            method => 'exposure',
            args   => \@args
        );
    }

    return $result;
}

sub click
{
    validate_pos(@_, { type => OBJECT },
        { type => SCALAR, regex => qr/^\d+$/ }, # INT SimpleNetworkADID
    );
    my ($self, @args) = @_;

    my $result;
    eval { $result = $self->{client}->click(@args); };
    if (my $e = Adriver::DBI::Exceptions::DBError->caught())
    {
        Adriver::DBI::Exceptions::Clients->throw(
            error  => Adriver::ErrorMessage::error_message($e),
            code   => $e->{code},
            method => 'click',
            args   => \@args
        );
    }

    return $result;
}

sub set_exposures_counter
{
    validate_pos(@_, { type => OBJECT },
        { type => SCALAR, regex => qr/^\d+$/ }, # INT SimpleNetworkADID
        { type => HASHREF },                    # HASHREF CounterHashRef
    );
    my ($self, @args) = @_;

    my $result;
    eval { $result = $self->{client}->set_exposures_counter(@args); };
    if (my $e = Adriver::DBI::Exceptions::DBError->caught())
    {
        Adriver::DBI::Exceptions::Clients->throw(
            error  => Adriver::ErrorMessage::error_message($e),
            code   => $e->{code},
            method => 'set_exposures_counter',
            args   => \@args
        );
    }

    return $result;
}

sub set_clicks_counter
{
    validate_pos(@_, { type => OBJECT },
        { type => SCALAR, regex => qr/^\d+$/ }, # INT SimpleNetworkADID
        { type => HASHREF },                    # HASHREF CounterHashRef
    );
    my ($self, @args) = @_;

    my $result;
    eval { $result = $self->{client}->set_clicks_counter(@args); };
    if (my $e = Adriver::DBI::Exceptions::DBError->caught())
    {
        Adriver::DBI::Exceptions::Clients->throw(
            error  => Adriver::ErrorMessage::error_message($e),
            code   => $e->{code},
            method => 'set_clicks_counter',
            args   => \@args
        );
    }

    return $result;
}

sub rotate_daily
{
    validate_pos(@_, { type => OBJECT });
    my ($self, @args) = @_;

    my $result;
    eval { $result = $self->{client}->rotate_daily(@args); };
    if (my $e = Adriver::DBI::Exceptions::DBError->caught())
    {
        Adriver::DBI::Exceptions::Clients->throw(
            error  => Adriver::ErrorMessage::error_message($e),
            code   => $e->{code},
            method => 'rotate_daily',
            args   => \@args
        );
    }

    return $result;
}

sub rotate_weekly
{
    validate_pos(@_, { type => OBJECT });
    my ($self, @args) = @_;

    my $result;
    eval { $result = $self->{client}->rotate_weekly(@args); };
    if (my $e = Adriver::DBI::Exceptions::DBError->caught())
    {
        Adriver::DBI::Exceptions::Clients->throw(
            error  => Adriver::ErrorMessage::error_message($e),
            code   => $e->{code},
            method => 'rotate_weekly',
            args   => \@args
        );
    }

    return $result;
}

1;
