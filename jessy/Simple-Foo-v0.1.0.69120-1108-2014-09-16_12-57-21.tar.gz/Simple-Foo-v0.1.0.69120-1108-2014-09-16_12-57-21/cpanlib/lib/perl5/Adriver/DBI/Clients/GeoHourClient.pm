package Adriver::DBI::Clients::GeoHourClient;

use strict;
our $VERSION = '0.0300';
use Carp;
use Params::Validate qw(:all);
use base qw ( Adriver::DBI::Clients::Base );

validation_options(on_fail => sub { Adriver::DBI::Exceptions::ParamsValidation->throw( error => $_[0]); } );

sub package { 'RLE::GeoHourClient' }

#### Functions
#
## Get or set GeoHour
#
# (HASHREF GeoHourHashRef) get()
# (INT 1) set(HASHREF GeoHourHashRef)
#
## Increment counter for Hour and Geo (Hour - [0..23], Geo - [0..31])
#
# (INT 1) increment(INT Hour, INT Geo)
#
## Rotate GeoHour
## DONOT USE THIS METHODS IN IFACES! SPECIAL SYSTEM CALLS!
#
# (void) rotate()
#
#### Input Data Info
#
# GeoHourHashRef =>
# {
#     'exp_today'         => ARRAYREF(32) of ARRAYREF(24) INT
#     'exp_yesterday'     => ARRAYREF(32) of ARRAYREF(24) INT
#     'exp_yesterday_sum' => ARRAYREF(32) INT
# }
#
####

sub get
{
    validate_pos(@_, { type => OBJECT });
    my ($self, @args) = @_;

    my $result;
    eval { $result = $self->{client}->get(@args); };

    if (my $e = Adriver::DBI::Exceptions::DBError->caught())
    {
        Adriver::DBI::Exceptions::Clients->throw(
            error  => Adriver::ErrorMessage::error_message($e),
            code   => $e->{code},
            method => 'get',
            args   => \@args
        );
    }

    return $result;
}

sub set
{
    validate_pos(@_, { type => OBJECT },
        { type => HASHREF }, # HASHREF GeoHourHashRef
    );
    my ($self, @args) = @_;

    my $result;
    eval { $result = $self->{client}->set(@args); };

    if (my $e = Adriver::DBI::Exceptions::DBError->caught())
    {
        Adriver::DBI::Exceptions::Clients->throw(
            error  => Adriver::ErrorMessage::error_message($e),
            code   => $e->{code},
            method => 'set',
            args   => \@args
        );
    }

    return $result;
}

sub increment
{
    validate_pos(@_, { type => OBJECT },
        { type => SCALAR, regex => qr/^\d+$/ }, # INT Hour
        { type => SCALAR, regex => qr/^\d+$/ }, # INT Geo
    );
    my ($self, @args) = @_;

    my $result;
    eval { $result = $self->{client}->increment(@args); };

    if (my $e = Adriver::DBI::Exceptions::DBError->caught())
    {
        Adriver::DBI::Exceptions::Clients->throw(
            error  => Adriver::ErrorMessage::error_message($e),
            code   => $e->{code},
            method => 'increment',
            args   => \@args
        );
    }

    return $result;
}

sub rotate
{
    validate_pos(@_, { type => OBJECT });
    my ($self, @args) = @_;

    my $result;
    eval { $result = $self->{client}->rotate(@args); };

    if (my $e = Adriver::DBI::Exceptions::DBError->caught())
    {
        Adriver::DBI::Exceptions::Clients->throw(
            error  => Adriver::ErrorMessage::error_message($e),
            code   => $e->{code},
            method => 'rotate',
            args   => \@args
        );
    }

    return $result;
}

1;


__END__



=head1 NAME

    Adriver::DBI::Clients::GeoHourClient - this module provides methods to work with GeoHour.


=head1 DESCRIPTION

    This module is inherited from Adriver::DBI::Clients::Base class.


=head1 SYNOPSIS

    use Adriver::DBI;
    use Adriver::DatabaseConnect::Adriver;
    use Adriver::Exceptions;

    my $host = 'f2.x';
    my $port = 16000;

    eval
    {
        my $dbh = Adriver::DBI->new( Adriver::DatabaseConnect::Adriver->new({host => $host, port => $port}) );

        my $geo_hour = $dbh->GeoHour->get();
        print Dumper($geo_hour);
    };

    if (my $e = Exception::Class->caught('Adriver::Exceptions'))
    {
        die "Caught Adriver::Exceptions: '", $e->error, "'\n", $e->trace->as_string, "\n";
    }
    elsif ($e = Exception::Class->caught('Exception::Class::Base'))
    {
        die "Caught unknown exception: '", $e->error, "'\n", $e->trace->as_string, "\n";
    }
    elsif ($e = Exception::Class->caught)
    {
        die "$e";
    }


=head1 OBJECT INTERFACE

=head2 get() : $GeoHourHashRef

    Get GeoHour.

B<GeoHourHashRef>

    This is a hash reference with next structure:

    GeoHourHashRef =>
    {
        'exp_today'         => ARRAYREF(32) of ARRAYREF(24) INT
        'exp_yesterday'     => ARRAYREF(32) of ARRAYREF(24) INT
        'exp_yesterday_sum' => ARRAYREF(32) INT
    }

B<Exceptions>

    Adriver::DBI::Exceptions::ParamsValidation
    Adriver::DBI::Exceptions::Clients

=head2 set($GeoHourHashRef) : 1

    Set GeoHour.

B<GeoHourHashRef>

    This is the same hash reference as described in get() method.

B<Exceptions>

    Adriver::DBI::Exceptions::ParamsValidation
    Adriver::DBI::Exceptions::Clients

=head2 increment($hour, $geo) : 1

    Increment counter for Hour and Geo.

B<hour>

    Integer: [0..23]

B<Geo>

    Integer: [0..31]

B<Exceptions>

    Adriver::DBI::Exceptions::ParamsValidation
    Adriver::DBI::Exceptions::Clients

=head2 rotate() : undef

    Rotate GeoHour.
    DONOT USE THIS METHODS IN IFACES! SPECIAL SYSTEM CALLS!

B<Exceptions>

    Adriver::DBI::Exceptions::ParamsValidation
    Adriver::DBI::Exceptions::Clients


=head1 SEE ALSO

    Adriver::DBI::Clients::Base
    Adriver::DBI::Exceptions


