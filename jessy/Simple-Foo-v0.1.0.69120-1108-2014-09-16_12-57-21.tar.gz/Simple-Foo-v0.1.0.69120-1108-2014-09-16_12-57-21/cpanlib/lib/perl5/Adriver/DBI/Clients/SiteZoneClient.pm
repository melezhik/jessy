package Adriver::DBI::Clients::SiteZoneClient;

use strict;
our $VERSION = '0.0300';
use Carp;
use Params::Validate qw(:all);
use base qw ( Adriver::DBI::Clients::Base );

validation_options(on_fail => sub { Adriver::DBI::Exceptions::ParamsValidation->throw( error => $_[0]); } );

sub package { 'RLE::SiteZoneClient' }

#### Functions
#
### Get sitezone by SiteID and SiteZoneID
#
# (HASHREF SiteZoneHashRef) getBySZoneID(INT SiteID, INT SiteZoneID)
#
## Set, add, remove sitezone
#
# (INT SiteZoneID) set(HASHREF SiteZoneHashRef)
# (INT SiteZoneID) add(HASHREF SiteZoneHashRef)
# (INT SiteZoneID) remove(HASHREF SiteZoneHashRef)
#
## Get sitezones for specified SiteID
#
# (ARRAYREF of HASHREF SiteZoneHashRefs) getBySiteID(INT SiteID)
#
## Get sitezone for specified SiteID and URL
#
# (HASHREF SiteZoneHashRef) getByURL(INT SiteID, STRING URL)
#
## Increment exposures or click in ad with ADID
## DONOT USE THIS METHODS IN IFACES! SPECIAL SYSTEM CALLS!
#
# (INT 1) exposure(INT SiteID, INT SiteZoneID, INT PageZone)
# (INT 1) click(INT SiteID, INT SiteZoneID, INT PageZone)
#
## Sets exposures or click counter in sitezone with specified SiteID, SiteZoneID, PageZone
#
# (INT 1) set_exposures_counter(INT SiteID, INT SiteZoneID, INT PageZone, HASHREF CounterHashRef)
# (INT 1) set_clicks_counter(INT SiteID, INT SiteZoneID, INT PageZone, HASHREF CounterHashRef)
#
## Rotate counter in all ads
## DONOT USE THIS METHODS IN IFACES! SPECIAL SYSTEM CALLS!
#
# (void) rotate_daily()
# (void) rotate_weekly()
#
#### Input Data Info
#
# CounterHashRef =>
# {
#     'today'     => INT
#     'yesterday' => INT
#     'week'      => INT
#     'last_week' => INT
#     'total'     => INT
# }
#
# SiteZoneHashRef =>
# {
#           'siteZoneID'        => INT
#           'siteID'            => INT
#           'zoneName'          => STRING
#           'alias'             => STRING
#           'priority'          => INT
#           'urls'              => ARRAYREF(10) {'str'=>STRING,'op'=>INT,'inverse'=>BOOL}
#           'pageZoneClicks'    => ARRAYREF(4) CounterHashRef
#           'pageZoneExposures' => ARRAYREF(4) CounterHashRef
# }
#
####

sub getBySiteID
{
    validate_pos(@_, { type => OBJECT },
        { type => SCALAR, regex => qr/^\d+$/ }, # INT SiteID
    );
    my ($self, @args) = @_;

    my $result;
    eval { $result = $self->{client}->getBySiteID(@args); };
    if (my $e = Adriver::DBI::Exceptions::DBError->caught())
    {
        Adriver::DBI::Exceptions::Clients->throw(
            error  => Adriver::ErrorMessage::error_message($e),
            code   => $e->{code},
            method => 'getBySiteID',
            args   => \@args
        );
    }

    return $result;
}

sub getByURL
{
    validate_pos(@_, { type => OBJECT },
        { type => SCALAR, regex => qr/^\d+$/ }, # INT SiteID
        { type => SCALAR },                     # STRING URL
    );
    my ($self, @args) = @_;

    my $result;
    eval { $result = $self->{client}->getByURL(@args); };
    if (my $e = Adriver::DBI::Exceptions::DBError->caught())
    {
        Adriver::DBI::Exceptions::Clients->throw(
            error  => Adriver::ErrorMessage::error_message($e),
            code   => $e->{code},
            method => 'getByURL',
            args   => \@args
        );
    }

    return $result;
}

sub getBySZoneID
{
    validate_pos(@_, { type => OBJECT },
        { type => SCALAR, regex => qr/^\d+$/ }, # INT SiteID
        { type => SCALAR, regex => qr/^\d+$/ }, # INT SiteZoneID
    );
    my ($self, @args) = @_;

    my $result;
    eval { $result = $self->{client}->getBySZoneID(@args); };
    if (my $e = Adriver::DBI::Exceptions::DBError->caught())
    {
        Adriver::DBI::Exceptions::Clients->throw(
            error  => Adriver::ErrorMessage::error_message($e),
            code   => $e->{code},
            method => 'getBySZoneID',
            args   => \@args
        );
    }

    return $result;
}

sub set
{
    validate_pos(@_, { type => OBJECT },
        { type => HASHREF }, # HASHREF SiteZoneHashRef
    );
    my ($self, @args) = @_;

    my $result;
    eval { $result = $self->{client}->set(@args); };
    if (my $e = Adriver::DBI::Exceptions::DBError->caught())
    {
        Adriver::DBI::Exceptions::Clients->throw(
            error  => Adriver::ErrorMessage::error_message($e),
            code   => $e->{code},
            method => 'set',
            args   => \@args
        );
    }

    return $result;
}

sub add
{
    validate_pos(@_, { type => OBJECT },
        { type => HASHREF }, # HASHREF SiteZoneHashRef
    );
    my ($self, @args) = @_;

    my $result;
    eval { $result = $self->{client}->add(@args); };
    if (my $e = Adriver::DBI::Exceptions::DBError->caught())
    {
        Adriver::DBI::Exceptions::Clients->throw(
            error  => Adriver::ErrorMessage::error_message($e),
            code   => $e->{code},
            method => 'add',
            args   => \@args
        );
    }

    return $result;
}

sub remove
{
    validate_pos(@_, { type => OBJECT },
        { type => HASHREF }, # HASHREF SiteZoneHashRef
    );
    my ($self, @args) = @_;

    my $result;
    eval { $result = $self->{client}->remove(@args); };
    if (my $e = Adriver::DBI::Exceptions::DBError->caught())
    {
        Adriver::DBI::Exceptions::Clients->throw(
            error  => Adriver::ErrorMessage::error_message($e),
            code   => $e->{code},
            method => 'remove',
            args   => \@args
        );
    }

    return $result;
}

sub rotate_daily
{
    validate_pos(@_, { type => OBJECT });
    my ($self, @args) = @_;

    my $result;
    eval { $result = $self->{client}->rotate_daily(@args); };
    if (my $e = Adriver::DBI::Exceptions::DBError->caught())
    {
        Adriver::DBI::Exceptions::Clients->throw(
            error  => Adriver::ErrorMessage::error_message($e),
            code   => $e->{code},
            method => 'rotate_daily',
            args   => \@args
        );
    }

    return $result;
}

sub rotate_weekly
{
    validate_pos(@_, { type => OBJECT });
    my ($self, @args) = @_;

    my $result;
    eval { $result = $self->{client}->rotate_weekly(@args); };
    if (my $e = Adriver::DBI::Exceptions::DBError->caught())
    {
        Adriver::DBI::Exceptions::Clients->throw(
            error  => Adriver::ErrorMessage::error_message($e),
            code   => $e->{code},
            method => 'rotate_weekly',
            args   => \@args
        );
    }

    return $result;
}

sub exposure
{
    validate_pos(@_, { type => OBJECT },
        { type => SCALAR, regex => qr/^\d+$/ }, # INT SiteID
        { type => SCALAR, regex => qr/^\d+$/ }, # INT SiteZoneID
        { type => SCALAR, regex => qr/^\d+$/ }, # INT PageZone
    );
    my ($self, @args) = @_;

    my $result;
    eval { $result = $self->{client}->exposure(@args); };
    if (my $e = Adriver::DBI::Exceptions::DBError->caught())
    {
        Adriver::DBI::Exceptions::Clients->throw(
            error  => Adriver::ErrorMessage::error_message($e),
            code   => $e->{code},
            method => 'exposure',
            args   => \@args
        );
    }

    return $result;
}

sub click
{
    validate_pos(@_, { type => OBJECT },
        { type => SCALAR, regex => qr/^\d+$/ }, # INT SiteID
        { type => SCALAR, regex => qr/^\d+$/ }, # INT SiteZoneID
        { type => SCALAR, regex => qr/^\d+$/ }, # INT PageZone
    );
    my ($self, @args) = @_;

    my $result;
    eval { $result = $self->{client}->click(@args); };
    if (my $e = Adriver::DBI::Exceptions::DBError->caught())
    {
        Adriver::DBI::Exceptions::Clients->throw(
            error  => Adriver::ErrorMessage::error_message($e),
            code   => $e->{code},
            method => 'click',
            args   => \@args
        );
    }

    return $result;
}

sub set_exposures_counter
{
    validate_pos(@_, { type => OBJECT },
        { type => SCALAR, regex => qr/^\d+$/ }, # INT SiteID
        { type => SCALAR, regex => qr/^\d+$/ }, # INT SiteZoneID
        { type => SCALAR, regex => qr/^\d+$/ }, # INT PageZone
        { type => HASHREF },                    # HASHREF CounterHashRef
    );
    my ($self, @args) = @_;

    my $result;
    eval { $result = $self->{client}->set_exposures_counter(@args); };
    if (my $e = Adriver::DBI::Exceptions::DBError->caught())
    {
        Adriver::DBI::Exceptions::Clients->throw(
            error  => Adriver::ErrorMessage::error_message($e),
            code   => $e->{code},
            method => 'set_exposures_counter',
            args   => \@args
        );
    }

    return $result;
}

sub set_clicks_counter
{
    validate_pos(@_, { type => OBJECT },
        { type => SCALAR, regex => qr/^\d+$/ }, # INT SiteID
        { type => SCALAR, regex => qr/^\d+$/ }, # INT SiteZoneID
        { type => SCALAR, regex => qr/^\d+$/ }, # INT PageZone
        { type => HASHREF },                    # HASHREF CounterHashRef
    );
    my ($self, @args) = @_;

    my $result;
    eval { $result = $self->{client}->set_clicks_counter(@args); };
    if (my $e = Adriver::DBI::Exceptions::DBError->caught())
    {
        Adriver::DBI::Exceptions::Clients->throw(
            error  => Adriver::ErrorMessage::error_message($e),
            code   => $e->{code},
            method => 'set_clicks_counter',
            args   => \@args
        );
    }

    return $result;
}

1;

__END__


=head1 NAME

    Adriver::DBI::Clients::SiteZoneClient - this module provides methods to work with
    Adriver site zones database.


=head1 DESCRIPTION

    This module is inherited from Adriver::DBI::Clients::Base class.


=head1 SYNOPSIS

    use Adriver::DBI;
    use Adriver::DatabaseConnect::Adriver;
    use Adriver::Exceptions;

    my $host = 'f2.x';
    my $port = 16000;

    eval
    {
        my $dbh = Adriver::DBI->new( Adriver::DatabaseConnect::Adriver->new({host => $host, port => $port}) );

        my $site_id = 98291;
        my $sitezones = $dbh->SiteZone->getBySiteID($site_id);
        print Dumper($sitezones);

        my $sitezone_id = 1;
        my $sitezone = $dbh->SiteZone->getBySZoneID($site_id, $sitezone_id);
        print Dumper($sitezone);

        my $url = 'showman';
        $sitezone = $dbh->SiteZone->getByURL($site_id, $url);
        print Dumper($sitezone);

        my $db_info = $dbh->SiteZone->GetCaps();
        print Dumper($db_info);

        $dbh->SiteZone->set($sitezone);
    };

    if (my $e = Exception::Class->caught('Adriver::Exceptions'))
    {
        die "Caught Adriver::Exceptions: '", $e->error, "'\n", $e->trace->as_string, "\n";
    }
    elsif ($e = Exception::Class->caught('Exception::Class::Base'))
    {
        die "Caught unknown exception: '", $e->error, "'\n", $e->trace->as_string, "\n";
    }
    elsif ($e = Exception::Class->caught)
    {
        die "$e";
    }


=head1 OBJECT INTERFACE

=head2 getBySiteID($site_id) : ARRAYREF of $SiteZoneHashRef

    Get all site zones of certain site determined by it's identifier.

B<site_id>

    This is the integer identifier of site.

B<SiteZoneHashRef>

    This is a hash reference with next structure:

    SiteZoneHashRef =>
    {
        'siteZoneID'        => INT
        'siteID'            => INT
        'zoneName'          => STRING
        'alias'             => STRING
        'priority'          => INT
        'urls'              => ARRAYREF(10) {'str'=>STRING,'op'=>INT,'inverse'=>BOOL}
        'pageZoneClicks'    => ARRAYREF(4) CounterHashRef
        'pageZoneExposures' => ARRAYREF(4) CounterHashRef
    }

    where

    CounterHashRef =>
    {
        'today'     => INT
        'yesterday' => INT
        'week'      => INT
        'last_week' => INT
        'total'     => INT
    }

B<Exceptions>

    Adriver::DBI::Exceptions::ParamsValidation
    Adriver::DBI::Exceptions::Clients

=head2 getByURL($site_id, $url) : $SiteZoneHashRef

    Get site zone of specified site and URL.

B<site_id>

    This is the integer identifier of site.

B<url>

    This is the URL string.

B<SiteZoneHashRef>

    This is the same hash reference as described in getBySiteID() method.

B<Exceptions>

    Adriver::DBI::Exceptions::ParamsValidation
    Adriver::DBI::Exceptions::Clients

=head2 getBySZoneID($site_id, $sitezone_id) : $SiteZoneHashRef

    Get site zone by site and site zone identifiers.

B<site_id>

    This is the integer identifier of site.

B<sitezone_id>

    This is the integer identifier of site zone.

B<SiteZoneHashRef>

    This is the same hash reference as described in getBySiteID() method.

B<Exceptions>

    Adriver::DBI::Exceptions::ParamsValidation
    Adriver::DBI::Exceptions::Clients

=head2 set($SiteZoneHashRef) : $sitezone_id

    This method updates given site zone in database.

B<SiteZoneHashRef>

    This is the same hash reference as described in getBySiteID() method.

B<sitezone_id>

    This is the integer identifier of site zone.

B<Exceptions>

    Adriver::DBI::Exceptions::ParamsValidation
    Adriver::DBI::Exceptions::Clients

=head2 add($SiteZoneHashRef) : $sitezone_id

    This method adds the new site zone in database and returns it's identifier.

B<SiteZoneHashRef>

    This is the same hash reference as described in getBySiteID() method.

B<sitezone_id>

    This is the integer identifier of added site zone.

B<Exceptions>

    Adriver::DBI::Exceptions::ParamsValidation
    Adriver::DBI::Exceptions::Clients

=head2 remove($SiteZoneHashRef) : $sitezone_id

    This method removes site zone from database.

B<SiteZoneHashRef>

    This is the same hash reference as described in getBySiteID() method.

B<sitezone_id>

    This is the site zone identifier.

B<Exceptions>

    Adriver::DBI::Exceptions::ParamsValidation
    Adriver::DBI::Exceptions::Clients

=head2 exposure($site_id, $sitezone_id, $pagezone) : 1

    This method icrements the number of exposures on site zone with specified page zone.
    DONOT USE THIS METHODS IN IFACES! SPECIAL SYSTEM CALLS!

B<site_id>

    This is the site identifier.

B<sitezone_id>

    This is the site zone identifier.

B<pagezone>

    This is the page zone (integer).

B<Exceptions>

    Adriver::DBI::Exceptions::ParamsValidation
    Adriver::DBI::Exceptions::Clients

=head2 click($site_id, $sitezone_id, $pagezone) : 1

    This method icrements the number of clicks on site zone with specified page zone.
    DONOT USE THIS METHODS IN IFACES! SPECIAL SYSTEM CALLS!

B<site_id>

    This is the site identifier.

B<sitezone_id>

    This is the site zone identifier.

B<pagezone>

    This is the page zone (integer).

B<Exceptions>

    Adriver::DBI::Exceptions::ParamsValidation
    Adriver::DBI::Exceptions::Clients

=head2 set_exposures_counter($site_id, $sitezone_id, $pagezone, $CounterHashRef) : 1

    This method sets the exposures counter of site zone with specified page zone.

B<site_id>

    This is the site identifier.

B<sitezone_id>

    This is the site zone identifier.

B<pagezone>

    This is the page zone (integer).

B<CounterHashRef>

    This is the same hash reference as described in getBySiteID() method.

B<Exceptions>

    Adriver::DBI::Exceptions::ParamsValidation
    Adriver::DBI::Exceptions::Clients

=head2 set_clicks_counter($site_id, $sitezone_id, $pagezone, $CounterHashRef) : 1

    This method sets the clicks counter of site zone with specified page zone.

B<site_id>

    This is the site identifier.

B<sitezone_id>

    This is the site zone identifier.

B<pagezone>

    This is the page zone (integer).

B<CounterHashRef>

    This is the same hash reference as described in get() method.

B<Exceptions>

    Adriver::DBI::Exceptions::ParamsValidation
    Adriver::DBI::Exceptions::Clients

=head2 rotate_daily() : undef

    This procedure rotates daily counters.
    DONOT USE THIS METHODS IN IFACES! SPECIAL SYSTEM CALLS!

B<Exceptions>

    Adriver::DBI::Exceptions::ParamsValidation
    Adriver::DBI::Exceptions::Clients

=head2 rotate_weekly() : undef

    This procedure rotates weekly counters.
    DONOT USE THIS METHODS IN IFACES! SPECIAL SYSTEM CALLS!

B<Exceptions>

    Adriver::DBI::Exceptions::ParamsValidation
    Adriver::DBI::Exceptions::Clients


=head1 SEE ALSO

    Adriver::DBI::Clients::Base
    Adriver::DBI::Exceptions

