package Adriver::DBI::Clients::LinksClient;

use strict;
our $VERSION = '0.0300';
use Carp;
use Params::Validate qw(:all);
use base qw ( Adriver::DBI::Clients::Base );

validation_options(on_fail => sub { Adriver::DBI::Exceptions::ParamsValidation->throw( error => $_[0]); } );

sub package { 'RLE::LinksClient' }

#### Functions
#
## Get Link from ObjectID (with ObjectType) to LinkToID (with LinkToType)
#
# (HASHREF LinkHashRef) get(INT LinkToID, INT LinkToType, INT ObjectID, INT ObjectType)
#
## Add or Remove Link
#
# (INT 1) add(HASHREF LinkHashRef)
# (INT 1) remove(HASHREF LinkHashRef)
#
## Get links from ObjectID (with ObjectType) with optional object type
## of the LinkTo element
#
# (ARRAYREF of HASHREF LinkHashRefs) get_links(INT ObjectID, INT ObjectType [,INT LinkToType])
#
## Get links to LinkToID (with LinkToType) with optional object type
## of the LinkFrom Element
#
# (ARRAYREF of HASHREF LinkHashRefs) get_objects(INT LinkToID, INT LinkToType [, INT ObjectType])
#
## Get list of object ids with ObjectType and with links to LinkToID
## or several LinkToIDs (with LinkToType and optional Link Attributes)
#
# (ARRAYREF of INTS ADIDs) get_ids(INT LinkToID | ARRAYREF of INT LinkToIDs, INT LinkToType, INT ObjectType [,ARRAYREF of INT LinkAttr])
#
## Get all Links
## DONOT USE THIS METHOD IN IFACES!
## YOU WILL BE DOOMED!
#
# getall()
#
#### Input Data Info
#
# LinkHashRef =>
# {
#     'linkToID'   => INT
#     'linkToType' => INT
#     'objectID'   => INT
#     'objectType' => INT
#     'attrs'      => ARRAYREF (2) INT
# }
#
####

sub get
{
    validate_pos(@_, { type => OBJECT },
        { type => SCALAR, regex => qr/^\d+$/ }, # INT LinkToID
        { type => SCALAR, regex => qr/^\d+$/ }, # INT LinkToType
        { type => SCALAR, regex => qr/^\d+$/ }, # INT ObjectID
        { type => SCALAR, regex => qr/^\d+$/ }, # INT ObjectType
    );
    my ($self, @args) = @_;

    my $result;
    eval { $result = $self->{client}->get(@args); };
    if (my $e = Adriver::DBI::Exceptions::DBError->caught())
    {
        Adriver::DBI::Exceptions::Clients->throw(
            error  => Adriver::ErrorMessage::error_message($e),
            code   => $e->{code},
            method => 'get',
            args   => \@args
        );
    }

    return $result;
}

sub add
{
    validate_pos(@_, { type => OBJECT },
        { type => HASHREF }, # HASHREF LinkHashRef
    );
    my ($self, @args) = @_;

    my $result;
    eval { $result = $self->{client}->add(@args); };
    if (my $e = Adriver::DBI::Exceptions::DBError->caught())
    {
        Adriver::DBI::Exceptions::Clients->throw(
            error  => Adriver::ErrorMessage::error_message($e),
            code   => $e->{code},
            method => 'add',
            args   => \@args
        );
    }

    return $result;
}

sub remove
{
    validate_pos(@_, { type => OBJECT },
        { type => HASHREF }, # HASHREF LinkHashRef
    );
    my ($self, @args) = @_;

    my $result;
    eval { $result = $self->{client}->remove(@args); };
    if (my $e = Adriver::DBI::Exceptions::DBError->caught())
    {
        Adriver::DBI::Exceptions::Clients->throw(
            error  => Adriver::ErrorMessage::error_message($e),
            code   => $e->{code},
            method => 'remove',
            args   => \@args
        );
    }

    return $result;
}

sub get_links
{
    validate_pos(@_, { type => OBJECT },
        { type => SCALAR, regex => qr/^\d+$/ },                # INT ObjectID
        { type => SCALAR, regex => qr/^\d+$/ },                # INT ObjectType
        { type => SCALAR, regex => qr/^\d+$/, optional => 1 }, # INT LinkToType
    );
    my ($self, @args) = @_;

    my $result;
    eval { $result = $self->{client}->get_links(@args); };
    if (my $e = Adriver::DBI::Exceptions::DBError->caught())
    {
        Adriver::DBI::Exceptions::Clients->throw(
            error  => Adriver::ErrorMessage::error_message($e),
            code   => $e->{code},
            method => 'get_links',
            args   => \@args
        );
    }

    return $result;
}

sub get_objects
{
    validate_pos(@_, { type => OBJECT },
        { type => SCALAR, regex => qr/^\d+$/ },               # INT LinkToID
        { type => SCALAR, regex => qr/^\d+$/ },               # INT LinkToType
        { type => SCALAR, regex => qr/^\d+$/, optional => 1 } # INT ObjectType
    );
    my ($self, @args) = @_;

    my $result;
    eval { $result = $self->{client}->get_objects(@args); };
    if (my $e = Adriver::DBI::Exceptions::DBError->caught())
    {
        Adriver::DBI::Exceptions::Clients->throw(
            error  => Adriver::ErrorMessage::error_message($e),
            code   => $e->{code},
            method => 'get_objects',
            args   => \@args
        );
    }

    return $result;
}

sub get_ids
{
    validate_pos(@_, { type => OBJECT },
        { type => SCALAR | ARRAYREF },          # INT LinkToID | ARRAYREF of INT LinkToIDs
        { type => SCALAR, regex => qr/^\d+$/ }, # INT LinkToType
        { type => SCALAR, regex => qr/^\d+$/ }, # INT ObjectType
        { type => ARRAYREF, optional => 1 },    # ARRAYREF of INT LinkAttr
    );
    my ($self, @args) = @_;

    my $result;
    eval { $result = $self->{client}->get_ids(@args); };
    if (my $e = Adriver::DBI::Exceptions::DBError->caught())
    {
        Adriver::DBI::Exceptions::Clients->throw(
            error  => Adriver::ErrorMessage::error_message($e),
            code   => $e->{code},
            method => 'get_ids',
            args   => \@args
        );
    }

    return $result;
}

sub getall
{
    validate_pos(@_, { type => OBJECT },
        { type => OBJECT, isa => 'Adriver::DBI::ForceGetall', optional => 1 }, # FORCE GETALL
    );
    my ($self, @args) = @_;

    unless (scalar @args == 1 and (pop @args)->access_granted)
    {
        Adriver::DBI::Exceptions->throw( error => 'Calling getall method' );
    }

    my $result;
    eval { $result = $self->{client}->getall(@args); };
    if (my $e = Adriver::DBI::Exceptions::DBError->caught())
    {
        Adriver::DBI::Exceptions::Clients->throw(
            error  => Adriver::ErrorMessage::error_message($e),
            code   => $e->{code},
            method => 'getall',
            args   => \@args
        );
    }

    return $result;
}

1;

__END__


=head1 NAME

    Adriver::DBI::Clients::LinksClient - this module provides methods to work with
    Adriver links between objects database.


=head1 DESCRIPTION

    Using this module each object can be linked with another object.
    This module is inherited from Adriver::DBI::Clients::Base class.


=head1 SYNOPSIS

    use Adriver::DBI;
    use Adriver::DatabaseConnect::Adriver;
    use Adriver::DBI::ForceGetall;
    use Adriver::Exceptions;

    my $host = 'f2.x';
    my $port = 16000;

    eval
    {
        my $dbh = Adriver::DBI->new( Adriver::DatabaseConnect::Adriver->new({host => $host, port => $port}) );

        my $object_id = 94009;
        my $object_type = 14;
        my $link_to_id = 15;
        my $link_to_type = 13;
        my $link = $dbh->Links->get($link_to_id, $link_to_type, $object_id, $object_type);
        print Dumper($link);

        $object_id = 15;
        $object_type = 13;
        my $links = $dbh->Links->get_links($object_id, $object_type);
        print Dumper($links);

        $object_type = 14;
        $links = $dbh->Links->get_objects($link_to_id, $link_to_type, $object_type);
        print Dumper($links);

        $links = $dbh->Links->get_ids($link_to_id, $link_to_type, $object_type);
        print Dumper($links);
    };

    if (my $e = Exception::Class->caught('Adriver::Exceptions'))
    {
        die "Caught Adriver::Exceptions: '", $e->error, "'\n", $e->trace->as_string, "\n";
    }
    elsif ($e = Exception::Class->caught('Exception::Class::Base'))
    {
        die "Caught unknown exception: '", $e->error, "'\n", $e->trace->as_string, "\n";
    }
    elsif ($e = Exception::Class->caught)
    {
        die "$e";
    }


=head1 OBJECT INTERFACE

=head2 get($link_to_id, $link_to_type, $object_id, $object_type) : $LinkHashRef

    Get certain link from database, from and to objects specified by their id and type.

B<link_to_id>

    This is the identifier of object link aims at.

B<link_to_type>

    This is the type of object link aims at.

B<object_id>

    This is the identifier of object which is a source of link.

B<object_type>

    This is the type of object which is a source of link.

B<LinkHashRef>

    This is a hash reference with next structure:

    LinkHashRef =>
    {
        'linkToID'   => INT
        'linkToType' => INT
        'objectID'   => INT
        'objectType' => INT
        'attrs'      => ARRAYREF (2) INT
    }

B<Exceptions>

    Adriver::DBI::Exceptions::ParamsValidation
    Adriver::DBI::Exceptions::Clients

=head2 add($LinkHashRef) : 1

    This method adds the new link between objects.

B<LinkHashRef>

    This is the same hash reference as described in get() method.

B<Exceptions>

    Adriver::DBI::Exceptions::ParamsValidation
    Adriver::DBI::Exceptions::Clients

=head2 remove($LinkHashRef) : 1

    This method removes the link between objects.

B<LinkHashRef>

    This is the same hash reference as in get() method.

B<Exceptions>

    Adriver::DBI::Exceptions::ParamsValidation
    Adriver::DBI::Exceptions::Clients

=head2 get_links($object_id, $object_type, $link_to_type) : ARRAYREF of $LinkHashRef

    This method returns a list of links which begin in the given object and aim at objects
    with specified type.

B<object_id>

    This is the identifier of object which is a source of link.

B<object_type>

    This is the type of object which is a source of link.

B<link_to_type>

    This is the type of object link aims at. Optional parameter.

B<LinkHashRef>

    This is the same hash reference as described in get() method.

B<Exceptions>

    Adriver::DBI::Exceptions::ParamsValidation
    Adriver::DBI::Exceptions::Clients

=head2 get_objects($link_to_id, $link_to_type, $object_type) : ARRAYREF of $LinkHashRef

    This method returns a list of links which aim at specified object and have a source in
    the object with specified type.

B<link_to_id>

    This is the identifier of object link aims at.

B<link_to_type>

    This is the type of object link aims at.

B<object_type>

    This is the type of object which is a source of link. Optional parameter.

B<LinkHashRef>

    This is the same hash reference as described in get() method.

B<Exceptions>

    Adriver::DBI::Exceptions::ParamsValidation
    Adriver::DBI::Exceptions::Clients

=head2 get_ids($link_to_id, $link_to_type, $object_type, $link_attr) : $ids

    This method returns a list of object identifiers with links aimed at specified object.

B<link_to_id>

    This is the identifier of object link aims at.

B<link_to_type>

    This is the type of object link aims at.

B<object_type>

    This is the type of object which is a source of link.

B<link_attr>

    This is the link attributes you can use them like a filter. Optional parameter.

B<ids>

    This is an array reference with object identifiers.

B<Exceptions>

    Adriver::DBI::Exceptions::ParamsValidation
    Adriver::DBI::Exceptions::Clients

=head2 getall($object) : ARRAYREF of $LinkHashRef

    This method can get all links between objects in database. Be careful the amount of data can be significant.

B<object>

    This is object of Adriver::DBI::ForceGetall class.

B<LinkHashRef>

    This is the same hash reference as described in get() method.

B<Exceptions>

    Adriver::DBI::Exceptions::ParamsValidation
    Adriver::DBI::Exceptions::Clients


=head1 SEE ALSO

    Adriver::DBI::Clients::Base
    Adriver::DBI::Exceptions
    Adriver::ObjectType
    Adriver::DBI::ForceGetall

