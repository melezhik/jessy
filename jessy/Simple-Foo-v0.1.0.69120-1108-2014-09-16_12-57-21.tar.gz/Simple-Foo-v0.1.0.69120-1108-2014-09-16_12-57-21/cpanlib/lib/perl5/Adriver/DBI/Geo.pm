package Adriver::DBI::Geo;

use strict;
our $VERSION = '0.0300';
use Carp;
use Params::Validate qw(:all);

use base qw( Adriver::DBI::Base );

validation_options(on_fail => sub { Adriver::DBI::Exceptions::ParamsValidation->throw(error => $_[0]); });

my $accessors = {
     Geo     => { class_name => 'Adriver::DBI::Clients::GeoClient', },
};

# Generate DB accessors methods
__PACKAGE__->ACCESSORS($accessors);

sub new
{
    validate_pos(@_, { type => SCALAR }, { type => OBJECT, isa => 'Adriver::DatabaseConnect::Geo'});
    my ($self, $connect) = @_;
    my $dbh = bless {}, $self;
    # we cant work without connection
    #     unless ($connect) {
    #         Adriver::DBI::Exceptions->throw(error => 'Connection is needed for Adriver::DBI::Geo::new(Adriver::DatabaseConnect::Geo()).');
    #     }
    # store connection
    $dbh->{'connect'} = $connect;
    return $dbh;
}

1;

__END__

=head1 NAME

    Adriver::DBI::Geo - this module provides an interface for communication with Geo database.


=head1 DESCRIPTION

    This module contains a list of Geo database clients which can get all needed information from it.
    What you need to know that is which client can get information you want to get. For each database client
    there is accessor method. When you call accessor you get control under the object of corresponded client
    class. This module is inherited from Adriver::DBI::Base class.


=head1 SYNOPSIS

    use Adriver::DBI::Geo;
    use Adriver::DatabaseConnect::Geo;
    use Adriver::Exceptions;

    sub get_ip_int
    {
        my $ip = shift;

        my @ip_cut = split /\./, $ip;
        $ip = 16777216*$ip_cut[0] + 65536*$ip_cut[1] + 256*$ip_cut[2] + $ip_cut[3];

        return $ip;
    }

    my @db_servers;
    push @db_servers, {host => 'f2.x', port => 16000, 'start_IP'=> 0, 'stop_IP' => 4294967295};

    eval
    {
        my $geo_connect = Adriver::DatabaseConnect::Geo->new(config => \@db_servers);
        $geo_connect->connect;
        my $dbh = Adriver::DBI::Geo->new($geo_connect);

        my $geo = $dbh->Geo->get(get_ip_int("217.170.90.1"));
        print Dumper($geo);
    };

    if (my $e = Exception::Class->caught('Adriver::Exceptions'))
    {
        die "Caught Adriver::Exceptions: '", $e->error, "\n", $e->trace->as_string, "\n";
    }
    elsif ($e = Exception::Class->caught('Exception::Class::Base'))
    {
        die "Caught unknown exception: '", $e->error, "\n", $e->trace->as_string, "\n";
    }
    elsif ($e = Exception::Class->caught)
    {
        die "$e";
    }


=head1 ACCESSORS AND CORRESPONDED CLIENTS

    Geo      =>  Adriver::DBI::Clients::GeoClient


=head1 CLASS INTERFACE

=head2 new($geo_connect) : Adriver::DBI::Geo object

    Create the new object of class.

B<geo_connect>

    This is Adriver::DatabaseConnect::Geo object or it's child.

B<Exceptions>

    Adriver::DBI::Exceptions::ParamsValidation


=head1 SEE ALSO

    Adriver::DatabaseConnect::Geo
    Adriver::DBI::Exceptions
    Adriver::DBI::Base
    Database clients classes

