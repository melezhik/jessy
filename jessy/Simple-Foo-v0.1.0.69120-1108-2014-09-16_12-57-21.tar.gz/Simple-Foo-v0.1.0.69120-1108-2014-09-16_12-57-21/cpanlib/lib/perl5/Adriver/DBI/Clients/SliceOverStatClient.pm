package Adriver::DBI::Clients::SliceOverStatClient;

use strict;
our $VERSION = '0.0300';
use Carp;
use Params::Validate qw(:all);
use base qw ( Adriver::DBI::Clients::BaseStatClient );

validation_options(on_fail => sub { Adriver::DBI::Exceptions::ParamsValidation->throw( error => $_[0]); } );

sub package { 'RLE::SliceOverStatClient' }

#### Generic StatClient Functions
#
# GetTotal    (HASHREF ClientSliceRequestParamsHashRef)
# GetTable    (ARRAYREF of INT SliceIDs, HASHREF ClientSliceRequestParamsHashRef)
# GetGeo      (ARRAYREF of INT GeoIDs, HASHREF ClientSliceRequestParamsHashRef)
# GetMonthDay (HASHREF ClientSliceRequestParamsHashRef)
# GetWeekDay  (HASHREF ClientSliceRequestParamsHashRef)
# GetDayHour  (HASHREF ClientSliceRequestParamsHashRef)
# GetUniStat  (HASHREF ClientSliceRequestParamsHashRef)
# GetGeoDays  (HASHREF ClientSliceRequestParamsHashRef)
#
#### Functions
#
## Get stat for slices in site
#
# GetSiteSlices(HASHREF ClientSliceRequestParamsHashRef)
#
#### Input Data Info
#
# HASHREF ClientSliceRequestParamsHashRef =>
# {
#     'siteID'         => INT
#     'flags'          => INT     # Common flags for all stat clients
#
#     'sliceID'        => INT
#
#     'geoID'          => INT
#     'geoIDstart'     => INT
#     'geoIDend'       => INT
#
#     'startDate'      => INT
#     'endDate'        => INT
#
#     'opcode'         => INT     # Operation code OP_NONE = 0 OP_SUM = 1 OP_ILLEGAL = 2
#
#     'grid'           => INT     # 1 record per day/hour HOUR = 24 DAY = 1
#
#     # DO NOT SET/MODIFY!
#     'what'           => INT     # Used by specify request type in multirequests
#     'noCache'        => BOOL    # If true, request response shouldn't be cached
#     'juuEventType'   => INT
#     'juuCatID'       => INT
#     'juuNetworkType' => INT
# }
#
## Flags
#
# MONTH_FIXED_LENGTH   0x2  // Using for BasePlotStat result. Result will have a fixed length size.
# GET_SUB_EVENT        0x4  // Set this bit to have subevents in result.
# GET_SITE_CATS        0x8  // Not used.
# DEFPROF_SUPPORT_FLAG 0x10 // Set this bit to get default stat data in all ad requsts (internal using).
# GET_UU_RANGE         0x20 // Set this bit to get UU in GetMonthDay reqests.
#
####

sub GetSiteSlices
{
    validate_pos(@_, { type => OBJECT }, { type => HASHREF });
    my ($self, @args) = @_;

    my $result;
    eval { $result = $self->{client}->GetSiteSlices(@args); };
    if (my $e = Adriver::DBI::Exceptions::DBError->caught())
    {
        Adriver::DBI::Exceptions::Clients->throw(
            error  => Adriver::ErrorMessage::error_message($e),
            code   => $e->{code},
            method => 'GetSiteSlices',
            args   => \@args
        );
    }

    return $result;
}

1;


__END__


=head1 NAME

    Adriver::DBI::Clients::SliceOverStatClient - this module provides methods to get
    statistics by slices.


=head1 DESCRIPTION

    This module is inherited from Adriver::DBI::Clients::BaseStatClient class.


=head1 SYNOPSIS

    use Adriver::DBI::Stat;
    use Adriver::DatabaseConnect::Stat;
    use Adriver::Exceptions;
    use Data::Dumper;

    my $config_file = '../stat4perl.conf';

    eval
    {
        my $dbh = Adriver::DBI::Stat->new(
            Adriver::DatabaseConnect::Stat->new(config_file => $config_file)
        );

        my $slice_id = 432016;
        my $slice_stat = $dbh->Slice->GetTotal({ 'sliceID' => $slice_id });
        print Dumper($slice_stat);

        my $site_id = 98291;
        my $slice_stat = $dbh->Slice->GetSiteSlices({ 'siteID' => $site_id });
        print Dumper($slice_stat);
    };

    if (my $e = Exception::Class->caught('Adriver::Exceptions'))
    {
        die "Caught Adriver::Exceptions: '", $e->error, "'\n", $e->trace->as_string, "\n";
    }
    elsif ($e = Exception::Class->caught('Exception::Class::Base'))
    {
        die "Caught unknown exception: '", $e->error, "'\n", $e->trace->as_string, "\n";
    }
    elsif ($e = Exception::Class->caught)
    {
        die "$e";
    }


=head1 INHERITED OBJECT INTERFACE

=head2 GetTotal($ClientSliceRequestParamsHashRef)

    Get total stat for the slice.

B<ClientSliceRequestParamsHashRef>

    This is a hash reference with next structure:

    ClientSliceRequestParamsHashRef =>
    {
        'siteID'         => INT
        'flags'          => INT     # Common flags for all stat clients

        'sliceID'        => INT

        'geoID'          => INT
        'geoIDstart'     => INT
        'geoIDend'       => INT

        'startDate'      => INT
        'endDate'        => INT

        'opcode'         => INT     # Operation code OP_NONE = 0 OP_SUM = 1 OP_ILLEGAL = 2

        'grid'           => INT     # 1 record per day/hour HOUR = 24 DAY = 1

        # DO NOT SET/MODIFY!
        'what'           => INT     # Used by specify request type in multirequests
        'noCache'        => BOOL    # If true, request response shouldn't be cached
        'juuEventType'   => INT
        'juuCatID'       => INT
        'juuNetworkType' => INT
    }

B<Flags>

    MONTH_FIXED_LENGTH   0x2  // Using for BasePlotStat result. Result will have a fixed length size.
    GET_SUB_EVENT        0x4  // Set this bit to have subevents in result.
    GET_SITE_CATS        0x8  // Not used.
    DEFPROF_SUPPORT_FLAG 0x10 // Set this bit to get default stat data in all ad requsts (internal using).
    GET_UU_RANGE         0x20 // Set this bit to get UU in GetMonthDay reqests.

B<Exceptions>

    Adriver::DBI::Exceptions::ParamsValidation
    Adriver::DBI::Exceptions::Clients

=head2 GetTable($SliceIDs, $ClientSliceRequestParamsHashRef)

    Get total stats for list of slices with specified identifiers.

B<SliceIDs>

    ARRAYREF of INT slices identifiers.

B<ClientSliceRequestParamsHashRef>

    This is the same hash reference as described in GetTotal() method.

B<Exceptions>

    Adriver::DBI::Exceptions::ParamsValidation
    Adriver::DBI::Exceptions::Clients

=head2 GetGeo($GeoIDs, $ClientSliceRequestParamsHashRef)

    Get geo stat for slice.
    If GeoIDs specified only for this GeoIDs.
    If GeoIDs empty for all GeoIDs.

B<GeoIDs>

    ARRAYREF of INT GeoIDs.

B<ClientSliceRequestParamsHashRef>

    This is the same hash reference as described in GetTotal() method.

B<Exceptions>

    Adriver::DBI::Exceptions::ParamsValidation
    Adriver::DBI::Exceptions::Clients

=head2 GetMonthDay($ClientSliceRequestParamsHashRef)

    Get statistics for slice by days.

B<ClientSliceRequestParamsHashRef>

    This is the same hash reference as described in GetTotal() method.

B<Exceptions>

    Adriver::DBI::Exceptions::ParamsValidation
    Adriver::DBI::Exceptions::Clients

=head2 GetWeekDay($ClientSliceRequestParamsHashRef)

    Get average statistics for slice by weekday.

B<ClientSliceRequestParamsHashRef>

    This is the same hash reference as described in GetTotal() method.

B<Exceptions>

    Adriver::DBI::Exceptions::ParamsValidation
    Adriver::DBI::Exceptions::Clients

=head2 GetDayHour($ClientSliceRequestParamsHashRef)

    Get average statistics for slice by dayhour.

B<ClientSliceRequestParamsHashRef>

    This is the same hash reference as described in GetTotal() method.

B<Exceptions>

    Adriver::DBI::Exceptions::ParamsValidation
    Adriver::DBI::Exceptions::Clients

=head2 GetUniStat($ClientSliceRequestParamsHashRef)

    Universal stat request.

B<ClientSliceRequestParamsHashRef>

    This is the same hash reference as described in GetTotal() method.

B<Exceptions>

    Adriver::DBI::Exceptions::ParamsValidation
    Adriver::DBI::Exceptions::Clients

=head2 GetGeoDays($ClientSliceRequestParamsHashRef)

    Geo stat by days.

B<ClientSliceRequestParamsHashRef>

    This is the same hash reference as described in GetTotal() method.

B<Exceptions>

    Adriver::DBI::Exceptions::ParamsValidation
    Adriver::DBI::Exceptions::Clients

=head2 GetDaysCount($ClientSliceRequestParamsHashRef)

    Get begindate, enddate and diff (in weeks).

B<ClientSliceRequestParamsHashRef>

    This is the same hash reference as described in GetTotal() method.

B<Exceptions>

    Adriver::DBI::Exceptions::ParamsValidation
    Adriver::DBI::Exceptions::Clients


=head1 OBJECT INTERFACE

=head2 GetSiteSlices($ClientSliceRequestParamsHashRef)

    Get stat for slices in site.

B<ClientSliceRequestParamsHashRef>

    This is the same hash reference as described in GetTotal() method.

B<Exceptions>

    Adriver::DBI::Exceptions::ParamsValidation
    Adriver::DBI::Exceptions::Clients


=head1 SEE ALSO

    Adriver::DBI::Clients::BaseStatClient
    Adriver::DBI::Exceptions

