package Adriver::DBI::Clients::CityClient;

use strict;
our $VERSION = '0.0300';
use Carp;
use Params::Validate qw(:all);
use base qw ( Adriver::DBI::Clients::BaseID );

validation_options(on_fail => sub { Adriver::DBI::Exceptions::ParamsValidation->throw( error => $_[0]); } );

sub package { 'RLE::CityClient' }

#### Generic BaseID Functions
#
# get(INT CityID)
# getids()
# getlist(ARRAYREF of INT CityIDs)
# set(HASHREF CityHashRef)
# add(HASHREF CityHashRef)
# remove(INT CityID)
#
#### Input Data Info
#
# CityHashRef =>
# {
#     'City_ID'    => INT
#     'City_Name'  => ARRAYREF(5) STRING
#     'geoZone'    => INT
#     'Country_ID' => INT
#     'Region_ID'  => INT
#     'CityCfg_ID' => INT
# }
#
####

1;

__END__


=head1 NAME

    Adriver::DBI::Clients::CityClient - this module provides methods to work with
    Adriver cities database.


=head1 DESCRIPTION

    Using this module you can work with database of cities.
    This module is inherited from Adriver::DBI::Clients::BaseID class.


=head1 SYNOPSIS

    use Adriver::DBI;
    use Adriver::DatabaseConnect::Adriver;
    use Adriver::Exceptions;

    my $host = 'f2.x';
    my $port = 16000;

    eval
    {
        my $dbh = Adriver::DBI->new( Adriver::DatabaseConnect::Adriver->new({host => $host, port => $port}) );

        my $city_id = 1477;
        my $city = $dbh->City->get($city_id);
        print Dumper($city);

        my $db_info = $dbh->City->GetCaps();
        print Dumper($db_info);

        my $ids = $dbh->City->getids();
        print Dumper($ids);

        my @ids = (1514, 1524, 1537);
        my $cities = $dbh->City->getlist(\@ids);
        print Dumper($cities);
    };

    if (my $e = Exception::Class->caught('Adriver::Exceptions'))
    {
        die "Caught Adriver::Exceptions: '", $e->error, "\n", $e->trace->as_string, "\n";
    }
    elsif ($e = Exception::Class->caught('Exception::Class::Base'))
    {
        die "Caught unknown exception: '", $e->error, "\n", $e->trace->as_string, "\n";
    }
    elsif ($e = Exception::Class->caught)
    {
        die "$e";
    }


=head1 INHERITED OBJECT INTERFACE

=head2 get($city_id) : $CityHashRef

    Get certain city from database by it's identifier.

B<city_id>

    Integer identifier of the city.

B<CityHashRef>

    This is a hash reference with next structure:

    CityHashRef =>
    {
        'City_ID'    => INT
        'City_Name'  => ARRAYREF(5) STRING
        'geoZone'    => INT
        'Country_ID' => INT
        'Region_ID'  => INT
        'CityCfg_ID' => INT
    }

B<Exceptions>

    Adriver::DBI::Exceptions::ParamsValidation
    Adriver::DBI::Exceptions::Clients

=head2 getids() : $ids

    This method returns all cities identifiers stored in database.

B<ids>

    This is a array reference with getted identifiers.

B<Exceptions>

    Adriver::DBI::Exceptions::ParamsValidation
    Adriver::DBI::Exceptions::Clients

=head2 getlist($ids) : ARRAYREF of $CityHashRef

    This method returns a list of cities from database by their identifiers.

B<ids>

    The array reference with cities identifiers you want to get.

B<CityHashRef>

    This is the same hash reference as described in get() method.

B<Exceptions>

    Adriver::DBI::Exceptions::ParamsValidation
    Adriver::DBI::Exceptions::Clients

=head2 set($CityHashRef) : undef

    This method updates given city in database.

B<CityHashRef>

    This is the same hash reference as described in get() method.

B<Exceptions>

    Adriver::DBI::Exceptions::ParamsValidation
    Adriver::DBI::Exceptions::Clients

=head2 add($CityHashRef) : $city_id

    This method adds the new city in database and returns it's identifier.

B<CityHashRef>

    This is the same hash reference as described in get() method.

B<city_id>

    This is the integer identifier of added city.

B<Exceptions>

    Adriver::DBI::Exceptions::ParamsValidation
    Adriver::DBI::Exceptions::Clients

=head2 remove($city_id) : undef

    This method removes city from database by it's identifier.

B<city_id>

    This is the city identifier you want to remove.

B<Exceptions>

    Adriver::DBI::Exceptions::ParamsValidation
    Adriver::DBI::Exceptions::Clients


=head1 SEE ALSO

    Adriver::DBI::Clients::BaseID
    Adriver::DBI::Exceptions

