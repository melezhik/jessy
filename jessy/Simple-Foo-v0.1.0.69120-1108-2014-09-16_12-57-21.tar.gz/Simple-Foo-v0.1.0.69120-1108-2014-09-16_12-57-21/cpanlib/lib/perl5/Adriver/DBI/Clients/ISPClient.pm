package Adriver::DBI::Clients::ISPClient;

use strict;
our $VERSION = '0.0300';
use Carp;
use Params::Validate qw(:all);
use base qw ( Adriver::DBI::Clients::BaseID );

validation_options(on_fail => sub { Adriver::DBI::Exceptions::ParamsValidation->throw( error => $_[0]); } );

sub package { 'RLE::ISPClient' }

#### Generic BaseID Functions
#
# get(INT ISPID)
# getids()
# getlist(ARRAYREF of INT ISPIDs)
# set(HASHREF ISPHashRef)
# add(HASHREF ISPHashRef)
# remove(INT ISPID)
#
#### Input Data Info
#
# ISPHashRef =>
# {
#           'ISP_ID'    => INT
#           'ISP_Name'  => ARRAYREF(5) STRING
#           'ISPCfg_ID' => INT
# }
#
####

1;

__END__


=head1 NAME

    Adriver::DBI::Clients::ISPClient - this module provides methods to work with
    Adriver Internet Service Providers (ISP) database.


=head1 DESCRIPTION

    Using this module you can work with database of Internet Service Providers (ISP).
    This module is inherited from Adriver::DBI::Clients::BaseID class.


=head1 SYNOPSIS

    use Adriver::DBI;
    use Adriver::DatabaseConnect::Adriver;
    use Adriver::Exceptions;

    my $host = 'f2.x';
    my $port = 16000;

    eval
    {
        my $dbh = Adriver::DBI->new( Adriver::DatabaseConnect::Adriver->new({host => $host, port => $port}) );

        my $isp_id = 15031;
        my $isp = $dbh->ISP->get($isp_id);
        print Dumper($isp);

        my $db_info = $dbh->ISP->GetCaps();
        print Dumper($db_info);

        my @ids = (15011, 15012, 15013);
        my $providers = $dbh->ISP->getlist(\@ids);
        print Dumper($providers);

        my $ids = $dbh->ISP->getids();
        print Dumper($ids);
    };

    if (my $e = Exception::Class->caught('Adriver::Exceptions'))
    {
        die "Caught Adriver::Exceptions: '", $e->error, "\n", $e->trace->as_string, "\n";
    }
    elsif ($e = Exception::Class->caught('Exception::Class::Base'))
    {
        die "Caught unknown exception: '", $e->error, "\n", $e->trace->as_string, "\n";
    }
    elsif ($e = Exception::Class->caught)
    {
        die "$e";
    }


=head1 INHERITED OBJECT INTERFACE

=head2 get($isp_id) : $ISPHashRef

    Get certain provider from database by it's identifier.

B<isp_id>

    Integer identifier of the provider.

B<ISPHashRef>

    This is a hash reference with next structure:

    ISPHashRef =>
    {
        'ISP_ID'    => INT
        'ISP_Name'  => ARRAYREF(5) STRING
        'ISPCfg_ID' => INT
    }

B<Exceptions>

    Adriver::DBI::Exceptions::ParamsValidation
    Adriver::DBI::Exceptions::Clients

=head2 getids() : $ids

    This method returns all providers identifiers stored in database.

B<ids>

    This is a array reference with getted identifiers.

B<Exceptions>

    Adriver::DBI::Exceptions::ParamsValidation
    Adriver::DBI::Exceptions::Clients

=head2 getlist($ids) : ARRAYREF of $ISPHashRef

    This method returns a list of providers from database by their identifiers.

B<ids>

    The array reference with providers identifiers you want to get.

B<ISPHashRef>

    This is the same hash reference as described in get() method.

B<Exceptions>

    Adriver::DBI::Exceptions::ParamsValidation
    Adriver::DBI::Exceptions::Clients

=head2 set($ISPHashRef) : undef

    This method updates given provider in database.

B<ISPHashRef>

    This is the same hash reference as described in get() method.

B<Exceptions>

    Adriver::DBI::Exceptions::ParamsValidation
    Adriver::DBI::Exceptions::Clients

=head2 add($ISPHashRef) : $isp_id

    This method adds the new provider in database and returns it's identifier.

B<ISPHashRef>

    This is the same hash reference as described in get() method.

B<isp_id>

    This is the integer identifier of added provider.

B<Exceptions>

    Adriver::DBI::Exceptions::ParamsValidation
    Adriver::DBI::Exceptions::Clients

=head2 remove($isp_id) : undef

    This method removes provider from database by it's identifier.

B<isp_id>

    This is the provider identifier you want to remove.

B<Exceptions>

    Adriver::DBI::Exceptions::ParamsValidation
    Adriver::DBI::Exceptions::Clients


=head1 SEE ALSO

    Adriver::DBI::Clients::BaseID
    Adriver::DBI::Exceptions

