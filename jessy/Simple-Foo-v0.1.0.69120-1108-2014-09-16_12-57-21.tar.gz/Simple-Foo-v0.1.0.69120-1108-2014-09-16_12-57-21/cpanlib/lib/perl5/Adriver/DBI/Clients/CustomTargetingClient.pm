package Adriver::DBI::Clients::CustomTargetingClient;

use strict;
our $VERSION = '0.0300';
use Carp;
use Params::Validate qw(:all);
use base qw ( Adriver::DBI::Clients::Base );

validation_options(on_fail => sub { Adriver::DBI::Exceptions::ParamsValidation->throw( error => $_[0]); } );

sub package { 'RLE::CustomTargetingClient' }
sub version { '0.01' }

#### Functions
#
## Get rules for ProfileID
#
# (ARRAYREF of HASHREF CustomTargetingHashRefs) get_rules(INT ProfileID)
#
## Get all sitetargetings
## DONOT USE THIS METHOD IN IFACES!
#
# getall()
#
## Set, add or remove CustomTargeting
#
# (INT 1) set(HASHREF CustomTargetingHashRef)
# (INT 1) add(HASHREF CustomTargetingHashRef)
# (INT 1) remove(HASHREF CustomTargetingHashRef)
#
#### Input Data Info
#
# CustomTargetingHashRef =>
# {
#     'profileID'      => INT  ( int32    )
#     'ruleID'         => INT  ( int32    )
#     'blockOperation' => INT  ( int      )
#     'operation'      => INT  ( int      )
#     'prohibited'     => BOOL ( bool     )
#     'ruleType'       => INT  ( int      )
#     'paramId'        => INT  ( uint16   )
#     'paramName'      => STR  ( char[16] )
#     'keyword'        => STR  ( char[16] )
#     'lowBound'       => INT  ( int32    )
#     'highBound'      => INT  ( int32    )
# }
#
####

sub get_rules
{
    validate_pos(@_, { type => OBJECT },
        { type => SCALAR, regex => qr/^\d+$/ }, # INT ProfileID
    );
    my ($self, @args) = @_;

    my $result;
    eval { $result = $self->{client}->get_rules(@args); };
    if (my $e = Adriver::DBI::Exceptions::DBError->caught())
    {
        Adriver::DBI::Exceptions::Clients->throw(
            error  => Adriver::ErrorMessage::error_message($e),
            code   => $e->{code},
            method => 'get_rules',
            args   => \@args
        );
    }

    return $result;
}

sub getall
{
    validate_pos(@_, { type => OBJECT },
        { type => OBJECT, isa => 'Adriver::DBI::ForceGetall', optional => 1 }, # FORCE GETALL
    );
    my ($self, @args) = @_;

    unless (scalar @args == 1 and (pop @args)->access_granted)
    {
        Adriver::DBI::Exceptions->throw( error => 'Calling getall method' );
    }

    my $result;
    eval { $result = $self->{client}->getall(@args); };
    if (my $e = Adriver::DBI::Exceptions::DBError->caught())
    {
        Adriver::DBI::Exceptions::Clients->throw(
            error  => Adriver::ErrorMessage::error_message($e),
            code   => $e->{code},
            method => 'getall',
            args   => \@args
        );
    }

    return $result;
}

sub set
{
    validate_pos(@_, { type => OBJECT },
        { type => HASHREF }, # HASHREF CustomTargetingHashRef
    );
    my ($self, @args) = @_;

    my $result;
    eval { $result = $self->{client}->set(@args); };
    if (my $e = Adriver::DBI::Exceptions::DBError->caught())
    {
        Adriver::DBI::Exceptions::Clients->throw(
            error  => Adriver::ErrorMessage::error_message($e),
            code   => $e->{code},
            method => 'set',
            args   => \@args
        );
    }

    return $result;
}

sub add
{
    validate_pos(@_, { type => OBJECT },
        { type => HASHREF }, # HASHREF CustomTargetingHashRef
    );
    my ($self, @args) = @_;

    my $result;
    eval { $result = $self->{client}->add(@args); };
    if (my $e = Adriver::DBI::Exceptions::DBError->caught())
    {
        Adriver::DBI::Exceptions::Clients->throw(
            error  => Adriver::ErrorMessage::error_message($e),
            code   => $e->{code},
            method => 'add',
            args   => \@args
        );
    }

    return $result;
}

sub remove
{
    validate_pos(@_, { type => OBJECT },
        { type => HASHREF }, # HASHREF CustomTargetingHashRef
    );
    my ($self, @args) = @_;

    my $result;
    eval { $result = $self->{client}->remove(@args); };
    if (my $e = Adriver::DBI::Exceptions::DBError->caught())
    {
        Adriver::DBI::Exceptions::Clients->throw(
            error  => Adriver::ErrorMessage::error_message($e),
            code   => $e->{code},
            method => 'remove',
            args   => \@args
        );
    }

    return $result;
}

1;


__END__


=head1 NAME

    Adriver::DBI::Clients::CustomTargetingClient - this module provides methods to work with
    Adriver custom targeting database.


=head1 DESCRIPTION

    Using this module you can tune custom targeting for profile.
    This module is inherited from Adriver::DBI::Clients::Base class.


=head1 SYNOPSIS

    use Adriver::DBI;
    use Adriver::DatabaseConnect::Adriver;
    use Adriver::Exceptions;

    my $host = 'f2.x';
    my $port = 16000;

    eval
    {
        my $dbh = Adriver::DBI->new( Adriver::DatabaseConnect::Adriver->new({host => $host, port => $port}) );

        my $profile_id = 161295;
        my $rules = $dbh->CustomTargeting->get_rules($profile_id);
        print Dumper($rules);

        my $db_info = $dbh->CustomTargeting->GetCaps();
        print Dumper($db_info);

        $rules = $dbh->CustomTargeting->getall(FORCE_GETALL);
        print Dumper($rules);
    };

    if (my $e = Exception::Class->caught('Adriver::Exceptions'))
    {
        die "Caught Adriver::Exceptions: '", $e->error, "'\n", $e->trace->as_string, "\n";
    }
    elsif ($e = Exception::Class->caught('Exception::Class::Base'))
    {
        die "Caught unknown exception: '", $e->error, "'\n", $e->trace->as_string, "\n";
    }
    elsif ($e = Exception::Class->caught)
    {
        die "$e";
    }


=head1 OBJECT INTERFACE

=head2 get_rules($profile_id) : ARRAYREF of $CustomTargetingHashRef

    This method returns a list of all customs targeting for specified profile.

B<profile_id>

    This is the identifier of profile.

B<CustomTargetingHashRef>

    This is a hash reference with next structure:

    CustomTargetingHashRef =>
    {
        'profileID'      => INT  ( int32    )
        'ruleID'         => INT  ( int32    )
        'blockOperation' => INT  ( int      )
        'operation'      => INT  ( int      )
        'prohibited'     => BOOL ( bool     )
        'ruleType'       => INT  ( int      )
        'paramId'        => INT  ( uint16   )
        'paramName'      => STR  ( char[16] )
        'keyword'        => STR  ( char[16] )
        'lowBound'       => INT  ( int32    )
        'highBound'      => INT  ( int32    )
    }

B<Exceptions>

    Adriver::DBI::Exceptions::ParamsValidation
    Adriver::DBI::Exceptions::Clients

=head2 getall($object) : ARRAYREF of $CustomTargetingHashRef

    This method can get all customs targeting. Be careful the amount of data can be significant.
    DONOT USE THIS METHOD IN IFACES!

B<object>

    This is object of Adriver::DBI::ForceGetall class.

B<CustomTargetingHashRef>

    This is the same hash reference as described in get_rules() method.

B<Exceptions>

    Adriver::DBI::Exceptions::ParamsValidation
    Adriver::DBI::Exceptions::Clients

=head2 set($CustomTargetingHashRef) : 1

    This method updates given custom targeting in database.

B<CustomTargetingHashRef>

    This is the same hash reference as described in get_rules() method.

B<Exceptions>

    Adriver::DBI::Exceptions::ParamsValidation
    Adriver::DBI::Exceptions::Clients

=head2 add($CustomTargetingHashRef) : 1

    This method adds the new custom targeting in database.

B<CustomTargetingHashRef>

    This is the same hash reference as described in get_rules() method.

B<Exceptions>

    Adriver::DBI::Exceptions::ParamsValidation
    Adriver::DBI::Exceptions::Clients

=head2 remove($CustomTargetingHashRef) : 1

    This method removes custom targeting from database.

B<CustomTargetingHashRef>

    This is the same hash reference as described in get_rules() method.

B<Exceptions>

    Adriver::DBI::Exceptions::ParamsValidation
    Adriver::DBI::Exceptions::Clients


=head1 SEE ALSO

    Adriver::DBI::Clients::Base
    Adriver::DBI::Exceptions
    Adriver::DBI::ForceGetall

