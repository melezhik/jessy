package Adriver::DBI::Clients::RegionClient;

use strict;
our $VERSION = '0.0300';
use Carp;
use Params::Validate qw(:all);
use base qw ( Adriver::DBI::Clients::BaseID );

validation_options(on_fail => sub { Adriver::DBI::Exceptions::ParamsValidation->throw( error => $_[0]); } );

sub package { 'RLE::RegionClient' }

#### Generic BaseID Functions
#
# get(INT RegionID)
# getids()
# getlist(ARRAYREF of INT RegionIDs)
# set(HASHREF RegionHashRef)
# add(HASHREF RegionHashRef)
# remove(INT RegionID)
#
#### Input Data Info
#
# RegionHashRef =>
# {
#     'Region_ID' => 222,
#     'Region_Name' => ARRAYREF(5) STRING
#     'RegionCfg_ID' => 0,
# }
#
####

1;

__END__


=head1 NAME

    Adriver::DBI::Clients::RegionClient - this module provides methods to work with
    Adriver regions database.


=head1 DESCRIPTION

    Using this module you can work with database of regions.
    This module is inherited from Adriver::DBI::Clients::BaseID class.


=head1 SYNOPSIS

    use Adriver::DBI;
    use Adriver::DatabaseConnect::Adriver;
    use Adriver::Exceptions;

    my $host = 'f2.x';
    my $port = 16000;

    eval
    {
        my $dbh = Adriver::DBI->new( Adriver::DatabaseConnect::Adriver->new({host => $host, port => $port}) );

        my $region_id = 15;
        my $region = $dbh->Region->get($region_id);
        print Dumper($region);

        my $db_info = $dbh->Region->GetCaps();
        print Dumper($db_info);

        my @ids = (11, 12, 13);
        my $regions = $dbh->Region->getlist(\@ids);
        print Dumper($regions);

        my $ids = $dbh->Region->getids();
        print Dumper($ids);
    };

    if (my $e = Exception::Class->caught('Adriver::Exceptions'))
    {
        die "Caught Adriver::Exceptions: '", $e->error, "\n", $e->trace->as_string, "\n";
    }
    elsif ($e = Exception::Class->caught('Exception::Class::Base'))
    {
        die "Caught unknown exception: '", $e->error, "\n", $e->trace->as_string, "\n";
    }
    elsif ($e = Exception::Class->caught)
    {
        die "$e";
    }


=head1 INHERITED OBJECT INTERFACE

=head2 get($region_id) : $RegionHashRef

    Get certain region from database by it's identifier.

B<region_id>

    Integer identifier of the region.

B<RegionHashRef>

    This is a hash reference with next structure:

    RegionHashRef =>
    {
        'Region_ID'    => INT,
        'Region_Name'  => ARRAYREF(5) STRING
        'RegionCfg_ID' => INT,
    }

B<Exceptions>

    Adriver::DBI::Exceptions::ParamsValidation
    Adriver::DBI::Exceptions::Clients

=head2 getids() : $ids

    This method returns all regions identifiers stored in database.

B<ids>

    This is a array reference with getted identifiers.

B<Exceptions>

    Adriver::DBI::Exceptions::ParamsValidation
    Adriver::DBI::Exceptions::Clients

=head2 getlist($ids) : ARRAYREF of $RegionHashRef

    This method returns a list of regions from database by their identifiers.

B<ids>

    The array reference with regions identifiers you want to get.

B<RegionHashRef>

    This is the same hash reference as described in get() method.

B<Exceptions>

    Adriver::DBI::Exceptions::ParamsValidation
    Adriver::DBI::Exceptions::Clients

=head2 set($RegionHashRef) : undef

    This method updates given region in database.

B<RegionHashRef>

    This is the same hash reference as described in get() method.

B<Exceptions>

    Adriver::DBI::Exceptions::ParamsValidation
    Adriver::DBI::Exceptions::Clients

=head2 add($RegionHashRef) : $region_id

    This method adds the new region in database and returns it's identifier.

B<RegionHashRef>

    This is the same hash reference as described in get() method.

B<region_id>

    This is the integer identifier of added region.

B<Exceptions>

    Adriver::DBI::Exceptions::ParamsValidation
    Adriver::DBI::Exceptions::Clients

=head2 remove($region_id) : undef

    This method removes region from database by it's identifier.

B<region_id>

    This is the region identifier you want to remove.

B<Exceptions>

    Adriver::DBI::Exceptions::ParamsValidation
    Adriver::DBI::Exceptions::Clients


=head1 SEE ALSO

    Adriver::DBI::Clients::BaseID
    Adriver::DBI::Exceptions

