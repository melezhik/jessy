package Adriver::DBI::Clients::BannerClient;

use strict;
our $VERSION = '0.0300';
use Carp;
use Params::Validate qw(:all);
use base qw ( Adriver::DBI::Clients::BaseID );

validation_options(on_fail => sub { Adriver::DBI::Exceptions::ParamsValidation->throw( error => $_[0]); } );

sub package { 'RLE::BannerClient' }

#### Generic BaseID Functions
#
# get(INT BannerID)
# getids()
# getlist(ARRAYREF of INT BannerIDs)
# set(HASHREF BannerHashRef)
# add(HASHREF BannerHashRef)
# remove(INT BannerID)
#
#### Other Functions
#
## Increment exposures, click or subevent in banner with BannerID
## DONOT USE THIS METHODS IN IFACES! SPECIAL SYSTEM CALLS!
#
# (INT BannerID) exposure(INT BannerID)
# (INT BannerID) click(INT BannerID)
# (INT BannerID) subevent(INT BannerID, INT SubeventType)
#
## Sets exposures, click or subevent counter in banner with BannerID
#
# (INT BannerID) set_exposures_counter(INT BannerID, HASHREF HourlyCounterHashRef)
# (INT BannerID) set_clicks_counter(INT BannerID, HASHREF HourlyCounterHashRef)
# (INT BannerID) set_subevents_counter(INT BannerID, INT SubeventType, HASHREF CounterHashRef)
#
#### Input Data Info
#
# CounterHashRef =>
# {
#     'today'     => INT
#     'yesterday' => INT
#     'week'      => INT
#     'last_week' => INT
#     'total'     => INT
# }
#
# HourlyCounterHashRef =>
# {
#     'today'     => INT
#     'yesterday' => INT
#     'week'      => INT
#     'last_week' => INT
#     'total'     => INT
#     'last_hour' => INT
# }
#
# BannerHashRef =>
# {
#     'bannerID'              => INT
#     'bannerType'            => INT
#     'bannerSpec'            => INT
#     'priority'              => INT
#     'burstMode'             => BOOL
#     'percent'               => INT
#     'percent_cnt'           => INT
#     'targetURL'             => STRING
#     'altField'              => STRING
#     'bannerLocation'        => STRING
#     'mirrorStatus'          => ARRAYREF(33) BOOL
#     'mirrorMask'            => ARRAYREF(32) BOOL
#     'enable'                => BOOL
#     'enables'               => ARRAYREF (32) BOOL
#     'componentsSubTypes'    => ARRAYREF(3) INT
#     'catID'                 => INT
#     'labelID'               => INT
#     'startTime'             => INT (?)
#     'stopTime'              => INT (?)
#     'exposures'             => HourlyCounterHashRef
#     'clicks'                => HourlyCounterHashRef
#     'subevents'             => ARRAYREF(10) CounterHashRef
#     'dayMaxShows'           => INT
#     'dayMaxClicks'          => INT
#     'dayMaxSubevents'       => ARRAYREF(10) INT
#     'totalMaxShows'         => INT
#     'totalMaxClicks'        => INT
#     'totalMaxSubevents'     => ARRAYREF(10) INT
#     'uniqueUserMaxShows'    => ARRAYREF(3) INT
#     'uniqueUserMaxClicks'   => INT
#     'uniqueUserMinInterval' => INT
#     'subeventIntervals'     => ARRAYREF(10) INT
#     'quickForward'          =>
#     {
#         'enable'     => BOOL
#         'siteZoneID' => INT
#         'siteID'     => INT
#     },
# }
#
####

sub exposure
{
    validate_pos(@_, { type => OBJECT },
        { type => SCALAR, regex => qr/^\d+$/ }, # INT BannerID
    );
    my ($self, @args) = @_;

    my $result;
    eval { $result = $self->{client}->exposure(@args); };
    if (my $e = Adriver::DBI::Exceptions::DBError->caught())
    {
        Adriver::DBI::Exceptions::Clients->throw(
            error  => Adriver::ErrorMessage::error_message($e),
            code   => $e->{code},
            method => 'exposure',
            args   => \@args
        );
    }

    return $result;
}

sub click
{
    validate_pos(@_, { type => OBJECT },
        { type => SCALAR, regex => qr/^\d+$/ }, # INT BannerID
    );
    my ($self, @args) = @_;

    my $result;
    eval { $result = $self->{client}->click(@args); };
    if (my $e = Adriver::DBI::Exceptions::DBError->caught())
    {
        Adriver::DBI::Exceptions::Clients->throw(
            error  => Adriver::ErrorMessage::error_message($e),
            code   => $e->{code},
            method => 'click',
            args   => \@args
        );
    }

    return $result;
}

sub subevent
{
    validate_pos(@_, { type => OBJECT },
        { type => SCALAR, regex => qr/^\d+$/ }, # INT BannerID
        { type => SCALAR, regex => qr/^\d+$/ }, # INT SubeventType
    );
    my ($self, @args) = @_;

    my $result;
    eval { $result = $self->{client}->subevent(@args); };
    if (my $e = Adriver::DBI::Exceptions::DBError->caught())
    {
        Adriver::DBI::Exceptions::Clients->throw(
            error  => Adriver::ErrorMessage::error_message($e),
            code   => $e->{code},
            method => 'subevent',
            args   => \@args
        );
    }

    return $result;
}

sub set_reach_counter
{
    # set_reach_counter($Id, {period => 2, limit => 100, total => 100})
    validate_pos(@_, { type => OBJECT },
        { type => SCALAR, regex => qr/^\d+$/ }, # INT ADID
        { type => HASHREF },                    # HASHREF ReachCounterHashRef
                                                # {period => , limit => , total => }
    );
    my ($self, @args) = @_;

    my $result;
    eval { $result = $self->{client}->set_reach_counter(@args); };
    if (my $e = Adriver::DBI::Exceptions::DBError->caught())
    {
        Adriver::DBI::Exceptions::Clients->throw(
            error  => Adriver::ErrorMessage::error_message($e),
            code   => $e->{code},
            method => 'set_reach_counter',
            args   => \@args
        );
    }

    return $result;
}

sub set_exposures_counter
{
    validate_pos(@_, { type => OBJECT },
        { type => SCALAR, regex => qr/^\d+$/ }, # INT BannerID
        { type => HASHREF },                    # HASHREF HourlyCounterHashRef
    );
    my ($self, @args) = @_;

    my $result;
    eval { $result = $self->{client}->set_exposures_counter(@args); };
    if (my $e = Adriver::DBI::Exceptions::DBError->caught())
    {
        Adriver::DBI::Exceptions::Clients->throw(
            error  => Adriver::ErrorMessage::error_message($e),
            code   => $e->{code},
            method => 'set_exposures_counter',
            args   => \@args
        );
    }

    return $result;
}

sub set_clicks_counter
{
    validate_pos(@_, { type => OBJECT },
        { type => SCALAR, regex => qr/^\d+$/ }, # INT BannerID
        { type => HASHREF },                    # HASHREF HourlyCounterHashRef
    );
    my ($self, @args) = @_;

    my $result;
    eval { $result = $self->{client}->set_clicks_counter(@args); };
    if (my $e = Adriver::DBI::Exceptions::DBError->caught())
    {
        Adriver::DBI::Exceptions::Clients->throw(
            error  => Adriver::ErrorMessage::error_message($e),
            code   => $e->{code},
            method => 'set_clicks_counter',
            args   => \@args
        );
    }

    return $result;
}

sub set_subevents_counter
{
    validate_pos(@_, { type => OBJECT },
        { type => SCALAR, regex => qr/^\d+$/ }, # INT BannerID
        { type => SCALAR, regex => qr/^\d+$/ }, # INT SubeventType
        { type => HASHREF },                    # HASHREF CounterHashRef
    );
    my ($self, @args) = @_;

    my $result;
    eval { $result = $self->{client}->set_subevents_counter(@args); };
    if (my $e = Adriver::DBI::Exceptions::DBError->caught())
    {
        Adriver::DBI::Exceptions::Clients->throw(
            error  => Adriver::ErrorMessage::error_message($e),
            code   => $e->{code},
            method => 'set_subevents_counter',
            args   => \@args
        );
    }

    return $result;
}

1;

__END__


=head1 NAME

    Adriver::DBI::Clients::BannerClient - this module provides methods to work with
    Adriver banners database.


=head1 DESCRIPTION

    Using this module you can modify banners and their properties.
    This module is inherited from Adriver::DBI::Clients::BaseID class.


=head1 SYNOPSIS

    use Adriver::DBI;
    use Adriver::DatabaseConnect::Adriver;
    use Adriver::Exceptions;

    my $host = 'f2.x';
    my $port = 16000;

    eval
    {
        my $dbh = Adriver::DBI->new( Adriver::DatabaseConnect::Adriver->new({host => $host, port => $port}) );

        my $banner = $dbh->Banner->get($banner_id);
        print Dumper($banner);

        my $db_info = $dbh->Banner->GetCaps();
        print Dumper($db_info);

        my $ids = $dbh->Banner->getids();
        print Dumper($ids);

        $dbh->Banner->set($banner);
    };

    if (my $e = Exception::Class->caught('Adriver::Exceptions'))
    {
        die "Caught Adriver::Exceptions: '", $e->error, "'\n", $e->trace->as_string, "\n";
    }
    elsif ($e = Exception::Class->caught('Exception::Class::Base'))
    {
        die "Caught unknown exception: '", $e->error, "'\n", $e->trace->as_string, "\n";
    }
    elsif ($e = Exception::Class->caught)
    {
        die "$e";
    }


=head1 INHERITED OBJECT INTERFACE

=head2 get($banner_id) : $BannerHashRef

    Get certain banner from database by it's identifier.

B<banner_id>

    This is the integer identifier of banner.

B<BannerHashRef>

    This is a hash reference with next structure:

    BannerHashRef =>
    {
        'bannerID'              => INT
        'bannerType'            => INT
        'bannerSpec'            => INT
        'priority'              => INT
        'burstMode'             => BOOL
        'percent'               => INT
        'percent_cnt'           => INT
        'targetURL'             => STRING
        'altField'              => STRING
        'bannerLocation'        => STRING
        'mirrorStatus'          => ARRAYREF(33) BOOL
        'mirrorMask'            => ARRAYREF(32) BOOL
        'enable'                => BOOL
        'enables'               => ARRAYREF (32) BOOL
        'componentsSubTypes'    => ARRAYREF(3) INT
        'catID'                 => INT
        'labelID'               => INT
        'startTime'             => INT (?)
        'stopTime'              => INT (?)
        'exposures'             => HourlyCounterHashRef
        'clicks'                => HourlyCounterHashRef
        'subevents'             => ARRAYREF(10) CounterHashRef
        'dayMaxShows'           => INT
        'dayMaxClicks'          => INT
        'dayMaxSubevents'       => ARRAYREF(10) INT
        'totalMaxShows'         => INT
        'totalMaxClicks'        => INT
        'totalMaxSubevents'     => ARRAYREF(10) INT
        'uniqueUserMaxShows'    => ARRAYREF(3) INT
        'uniqueUserMaxClicks'   => INT
        'uniqueUserMinInterval' => INT
        'subeventIntervals'     => ARRAYREF(10) INT
        'quickForward'          =>
        {
            'enable'     => BOOL
            'siteZoneID' => INT
            'siteID'     => INT
        },
    }

    where

    CounterHashRef =>
    {
        'today'     => INT
        'yesterday' => INT
        'week'      => INT
        'last_week' => INT
        'total'     => INT
    }

    and

    HourlyCounterHashRef =>
    {
        'today'     => INT
        'yesterday' => INT
        'week'      => INT
        'last_week' => INT
        'total'     => INT
        'last_hour' => INT
    }

B<Exceptions>

    Adriver::DBI::Exceptions::ParamsValidation
    Adriver::DBI::Exceptions::Clients

=head2 getids() : $banner_ids

    This method returns a list of all banners identifiers from database.

B<banner_ids>

    This is the array reference with obtained banners identifiers.

B<Exceptions>

    Adriver::DBI::Exceptions::ParamsValidation
    Adriver::DBI::Exceptions::Clients

=head2 getlist(\@banner_ids) : ARRAYREF of $BannerHashRef

    This method returns a list of banners from database by their identifiers.

B<banner_ids>

    This is the array reference with banners identifiers you want to get.

B<BannerHashRef>

    This is the same hash reference as described in get() method.

B<Exceptions>

    Adriver::DBI::Exceptions::ParamsValidation
    Adriver::DBI::Exceptions::Clients

=head2 set($BannerHashRef) : undef

    This method updates given banner in database.

B<BannerHashRef>

    This is the same hash reference as described in get() method.

B<Exceptions>

    Adriver::DBI::Exceptions::ParamsValidation
    Adriver::DBI::Exceptions::Clients

=head2 add($BannerHashRef) : $banner_id

    This method adds the new banner in database and returns it's identifier.

B<BannerHashRef>

    This is the same hash reference as described in get() method.

B<banner_id>

    This is the integer identifier of added banner.

B<Exceptions>

    Adriver::DBI::Exceptions::ParamsValidation
    Adriver::DBI::Exceptions::Clients

=head2 remove($banner_id) : undef

    This method removes banner from database by it's identifier.

B<banner_id>

    This is the banner identifier you want to remove.

B<Exceptions>

    Adriver::DBI::Exceptions::ParamsValidation
    Adriver::DBI::Exceptions::Clients


=head1 OBJECT INTERFACE

=head2 exposure($banner_id) : $banner_id

    This method icrements the number of banner exposures.
    DONOT USE THIS METHODS IN IFACES! SPECIAL SYSTEM CALLS!

B<banner_id>

    This is the banner identifier which exposures counter you want to increase.

B<Exceptions>

    Adriver::DBI::Exceptions::ParamsValidation
    Adriver::DBI::Exceptions::Clients

=head2 click($banner_id) : $banner_id

    This method icrements the number of banner clicks.
    DONOT USE THIS METHODS IN IFACES! SPECIAL SYSTEM CALLS!

B<banner_id>

    This is the banner identifier which clicks counter you want to increase.

B<Exceptions>

    Adriver::DBI::Exceptions::ParamsValidation
    Adriver::DBI::Exceptions::Clients

=head2 subevent($banner_id, $subevent_type) : $banner_id

    This method icrements the number of banner subevents.
    DONOT USE THIS METHODS IN IFACES! SPECIAL SYSTEM CALLS!

B<banner_id>

    This is the banner identifier which subevents counter you want to increase.

B<subevent_type>

    This is the subevent type.

B<Exceptions>

    Adriver::DBI::Exceptions::ParamsValidation
    Adriver::DBI::Exceptions::Clients

=head2 set_reach_counter($banner_id, $ReachCounterHashRef) : $banner_id

    This method sets the reach counter.

B<banner_id>

    This is the banner identifier which reach counter you want to set.

B<ReachCounterHashRef>

    This is the hash reference with next structure:

    ReachCounterHashRef =>
    {
        'period' => INT,
        'limit'  => INT,
        'total'  => INT
    }

B<Exceptions>

    Adriver::DBI::Exceptions::ParamsValidation
    Adriver::DBI::Exceptions::Clients

=head2 set_exposures_counter($banner_id, $HourlyCounterHashRef) : $banner_id

    This method sets the counter of banner exposures.

B<banner_id>

    This is the banner identifier which exposures counter you want to set.

B<HourlyCounterHashRef>

    This is the same hash reference as described in get() method.

B<Exceptions>

    Adriver::DBI::Exceptions::ParamsValidation
    Adriver::DBI::Exceptions::Clients

=head2 set_clicks_counter($banner_id, $HourlyCounterHashRef) : $banner_id

    This method sets the counter of banner clicks.

B<banner_id>

    This is the banner identifier which clicks counter you want to set.

B<HourlyCounterHashRef>

    This is the same hash reference as described in get() method.

B<Exceptions>

    Adriver::DBI::Exceptions::ParamsValidation
    Adriver::DBI::Exceptions::Clients

=head2 set_subevents_counter($banner_id, $subevent_type, $CounterHashRef) : $banner_id

    This method sets the subevent counter of banner. Subevent specified by it's type.

B<banner_id>

    This is the banner identifier which subevent counter you want to set.

B<subevent_type>

    This is the subevent type.

B<CounterHashRef>

    This is the same hash reference as described in get() method.

B<Exceptions>

    Adriver::DBI::Exceptions::ParamsValidation
    Adriver::DBI::Exceptions::Clients


=head1 SEE ALSO

    Adriver::DBI::Clients::BaseID
    Adriver::DBI::Exceptions

