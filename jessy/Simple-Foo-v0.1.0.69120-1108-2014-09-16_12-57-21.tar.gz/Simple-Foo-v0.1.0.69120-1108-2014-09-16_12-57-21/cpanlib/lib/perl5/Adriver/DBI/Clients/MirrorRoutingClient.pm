package Adriver::DBI::Clients::MirrorRoutingClient;

use strict;
our $VERSION = '0.0300';
use Carp;
use Params::Validate qw(:all);
use base qw ( Adriver::DBI::Clients::Base );

validation_options(on_fail => sub { Adriver::DBI::Exceptions::ParamsValidation->throw( error => $_[0]); } );

sub package { 'RLE::MirrorRoutingClient' }

#### Functions
#
## INT IP = 16777216*IP[0] + 65536*IP[1] + 256*IP[2] + IP[3]
## IP[0,1,2,3] - ip octets
#
## Get, set, add, remove MirrorRouting.
#
# (HASHREF MirrorRoutingHashRef) get(INT MirrorID, INT IP)
# (INT 1) set(HASHREF MirrorRoutingHashRef)
# (INT 1) add(HASHREF MirrorRoutingHashRef)
# (INT 1) remove(HASHREF MirrorRoutingHashRef)
#
## Get list of MirrorRoutings by MirrorID
#
# (ARRAYREF of HASHREF MirrorRoutingHashRefs) getlist(INT MirrorID)
#
## Get mask of MirrorRoutings by IP
#
# (ARRAYREF(32) BOOL) get_mask(INT IP)
#
#### Input Data Info
#
# MirrorRoutingHashRef =>
# {
#     'mirrorID' => INT
#     'enable'   => INT
#     'start_IP' => INT
#     'stop_IP'  => INT
# }
#
####

sub get
{
    validate_pos(@_, { type => OBJECT },
        { type => SCALAR, regex => qr/^\d+$/ }, # INT MirrorID
        { type => SCALAR, regex => qr/^\d+$/ }, # INT IP
    );
    my ($self, @args) = @_;

    my $result;
    eval { $result = $self->{client}->get(@args); };
    if (my $e = Adriver::DBI::Exceptions::DBError->caught())
    {
        Adriver::DBI::Exceptions::Clients->throw(
            error  => Adriver::ErrorMessage::error_message($e),
            code   => $e->{code},
            method => 'get',
            args   => \@args
        );
    }

    return $result;
}

sub set
{
    validate_pos(@_, { type => OBJECT },
        { type => HASHREF }, # HASHREF MirrorRoutingHashRef
    );
    my ($self, @args) = @_;

    my $result;
    eval { $result = $self->{client}->set(@args); };
    if (my $e = Adriver::DBI::Exceptions::DBError->caught())
    {
        Adriver::DBI::Exceptions::Clients->throw(
            error  => Adriver::ErrorMessage::error_message($e),
            code   => $e->{code},
            method => 'set',
            args   => \@args
        );
    }

    return $result;
}

sub add
{
    validate_pos(@_, { type => OBJECT },
        { type => HASHREF }, # HASHREF MirrorRoutingHashRef
    );
    my ($self, @args) = @_;

    my $result;
    eval { $result = $self->{client}->add(@args); };
    if (my $e = Adriver::DBI::Exceptions::DBError->caught())
    {
        Adriver::DBI::Exceptions::Clients->throw(
            error  => Adriver::ErrorMessage::error_message($e),
            code   => $e->{code},
            method => 'add',
            args   => \@args
        );
    }

    return $result;
}

sub remove
{
    validate_pos(@_, { type => OBJECT },
        { type => HASHREF }, # HASHREF MirrorRoutingHashRef
    );
    my ($self, @args) = @_;

    my $result;
    eval { $result = $self->{client}->remove(@args); };
    if (my $e = Adriver::DBI::Exceptions::DBError->caught())
    {
        Adriver::DBI::Exceptions::Clients->throw(
            error  => Adriver::ErrorMessage::error_message($e),
            code   => $e->{code},
            method => 'remove',
            args   => \@args
        );
    }

    return $result;
}

sub getlist
{
    validate_pos(@_, { type => OBJECT },
        { type => SCALAR, regex => qr/^\d+$/ }, # INT MirrorID
    );
    my ($self, @args) = @_;

    my $result;
    eval { $result = $self->{client}->getlist(@args); };
    if (my $e = Adriver::DBI::Exceptions::DBError->caught())
    {
        Adriver::DBI::Exceptions::Clients->throw(
            error  => Adriver::ErrorMessage::error_message($e),
            code   => $e->{code},
            method => 'getlist',
            args   => \@args
        );
    }

    return $result;
}

sub get_mask
{
    validate_pos(@_, { type => OBJECT },
        { type => SCALAR, regex => qr/^\d+$/ }, # INT IP
    );
    my ($self, @args) = @_;

    my $result;
    eval { $result = $self->{client}->get_mask(@args); };
    if (my $e = Adriver::DBI::Exceptions::DBError->caught())
    {
        Adriver::DBI::Exceptions::Clients->throw(
            error  => Adriver::ErrorMessage::error_message($e),
            code   => $e->{code},
            method => 'get_mask',
            args   => \@args
        );
    }

    return $result;
}

1;


__END__


=head1 NAME

    Adriver::DBI::Clients::SiteClient - this module provides methods to work with
    Adriver mirrors database.


=head1 DESCRIPTION

    This module is inherited from Adriver::DBI::Clients::Base class.


=head1 SYNOPSIS

    use Adriver::DBI;
    use Adriver::DatabaseConnect::Adriver;
    use Adriver::Exceptions;

    sub get_ip_int
    {
        my $ip = shift;

        my @ip_cut = split /\./, $ip;
        $ip = 16777216*$ip_cut[0] + 65536*$ip_cut[1] + 256*$ip_cut[2] + $ip_cut[3];

        return $ip;
    }

    my $host = 'f2.x';
    my $port = 16000;

    eval
    {
        my $dbh = Adriver::DBI->new( Adriver::DatabaseConnect::Adriver->new({host => $host, port => $port}) );

        my $mirror_id = 1;
        my $ip_address = '217.117.80.1';
        my $mrouting = $dbh->MirrorRouting->get($mirror_id, get_ip_int($ip_address));
        print Dumper($mrouting);

        my $mroutings = $dbh->MirrorRouting->getlist($mirror_id);
        print Dumper($mroutings);
    };

    if (my $e = Exception::Class->caught('Adriver::Exceptions'))
    {
        die "Caught Adriver::Exceptions: '", $e->error, "'\n", $e->trace->as_string, "\n";
    }
    elsif ($e = Exception::Class->caught('Exception::Class::Base'))
    {
        die "Caught unknown exception: '", $e->error, "'\n", $e->trace->as_string, "\n";
    }
    elsif ($e = Exception::Class->caught)
    {
        die "$e";
    }


=head1 OBJECT INTERFACE

=head2 get(mirror_id, $int_ip) : $MirrorRoutingHashRef

    Get certain mirror routing record by mirror identifier and given integer representation of IP address.

B<mirror_id>

    This is the integer identifier of mirror.

B<int_ip>

    This is the integer representation of IP address.
    It's calculating with formula:

    INT IP = 16777216*IP[0] + 65536*IP[1] + 256*IP[2] + IP[3] 

B<MirrorRoutingHashRef>

    This is a hash reference with next structure:

    MirrorRoutingHashRef =>
    {
        'mirrorID' => INT
        'enable'   => INT
        'start_IP' => INT
        'stop_IP'  => INT
    }

B<Exceptions>

    Adriver::DBI::Exceptions::ParamsValidation
    Adriver::DBI::Exceptions::Clients

=head2 getlist($mirror_id) : ARRAYREF of $MirrorRoutingHashRef

    This method returns a list of routing records for certain mirror.

B<mirror_id>

    This is the integer identifier of mirror.

B<MirrorRoutingHashRef>

    This is the same hash reference as described in get() method.

B<Exceptions>

    Adriver::DBI::Exceptions::ParamsValidation
    Adriver::DBI::Exceptions::Clients

=head2 get_mask($int_ip) : ARRAYREF(32) BOOL

    This method returns the mask of MirrorRoutings by IP.

B<int_ip>

    This is the integer representation of IP address. See description on get() method to
    find out how to calculate it.

B<Exceptions>

    Adriver::DBI::Exceptions::ParamsValidation
    Adriver::DBI::Exceptions::Clients

=head2 set($MirrorRoutingHashRef) : 1

    This method updates given mirror routing record in database.

B<MirrorRoutingHashRef>

    This is the same hash reference as described in get() method.

B<Exceptions>

    Adriver::DBI::Exceptions::ParamsValidation
    Adriver::DBI::Exceptions::Clients

=head2 add($MirrorRoutingHashRef) : 1

    This method adds the new mirror routing record.

B<MirrorRoutingHashRef>

    This is the same hash reference as described in get() method.

B<Exceptions>

    Adriver::DBI::Exceptions::ParamsValidation
    Adriver::DBI::Exceptions::Clients

=head2 remove($MirrorRoutingHashRef) : 1

    This method removes the mirror routing record.

B<MirrorRoutingHashRef>

    This is the same hash reference as described in get() method.

B<Exceptions>

    Adriver::DBI::Exceptions::ParamsValidation
    Adriver::DBI::Exceptions::Clients


=head1 SEE ALSO

    Adriver::DBI::Clients::Base
    Adriver::DBI::Exceptions

