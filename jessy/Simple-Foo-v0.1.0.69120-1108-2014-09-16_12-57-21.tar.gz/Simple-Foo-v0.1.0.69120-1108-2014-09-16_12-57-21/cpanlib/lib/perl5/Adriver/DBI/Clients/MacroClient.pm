package Adriver::DBI::Clients::MacroClient;

use strict;
our $VERSION = '0.0300';
use Carp;
use Params::Validate qw(:all);
use base qw ( Adriver::DBI::Clients::Base );

validation_options(on_fail => sub { Adriver::DBI::Exceptions::ParamsValidation->throw( error => $_[0]); } );

sub package { 'RLE::MacroClient' }

#### Functions
#
# (INT 1) set_link_attrs(HASHREF LinkHashRef)
# (INT 1) set_banner(HASHREF BannerHashRef)
# (INT 1) set_profile(HASHREF ProfileHashRef)
# (INT 1) set_ad(HASHREF ADHashRef)
# (INT 1) set_simple_ad(HASHREF SimpleNetworkADHashRef)
# (INT 1) set_rle_ad(HASHREF RLENetworkADHashRef)
#
#### Input Data Info
#
## You can see all hashrefs in corresponding modules
#
####

sub set_link_attrs
{
    validate_pos(@_, { type => OBJECT },
        { type => HASHREF }, # HASHREF LinkHashRef
    );
    my ($self, @args) = @_;

    my $result;
    eval { $result = $self->{client}->set_link_attrs(@args); };
    if (my $e = Adriver::DBI::Exceptions::DBError->caught())
    {
        Adriver::DBI::Exceptions::Clients->throw(
            error  => Adriver::ErrorMessage::error_message($e),
            code   => $e->{code},
            method => 'set_link_attrs',
            args   => \@args
        );
    }

    return $result;
}

sub set_banner
{
    validate_pos(@_, { type => OBJECT },
        { type => HASHREF }, # HASHREF BannerHashRef
    );
    my ($self, @args) = @_;

    my $result;
    eval { $result = $self->{client}->set_banner(@args); };
    if (my $e = Adriver::DBI::Exceptions::DBError->caught())
    {
        Adriver::DBI::Exceptions::Clients->throw(
            error  => Adriver::ErrorMessage::error_message($e),
            code   => $e->{code},
            method => 'set_banner',
            args   => \@args
        );
    }

    return $result;
}

sub set_profile
{
    validate_pos(@_, { type => OBJECT },
        { type => HASHREF }, # HASHREF ProfileHashRef
    );
    my ($self, @args) = @_;

    my $result;
    eval { $result = $self->{client}->set_profile(@args); };
    if (my $e = Adriver::DBI::Exceptions::DBError->caught())
    {
        Adriver::DBI::Exceptions::Clients->throw(
            error  => Adriver::ErrorMessage::error_message($e),
            code   => $e->{code},
            method => 'set_profile',
            args   => \@args
        );
    }

    return $result;
}

sub set_ad
{
    validate_pos(@_, { type => OBJECT },
        { type => HASHREF }, # HASHREF ADHashRef
    );
    my ($self, @args) = @_;

    my $result;
    eval { $result = $self->{client}->set_ad(@args); };
    if (my $e = Adriver::DBI::Exceptions::DBError->caught())
    {
        Adriver::DBI::Exceptions::Clients->throw(
            error  => Adriver::ErrorMessage::error_message($e),
            code   => $e->{code},
            method => 'set_ad',
            args   => \@args
        );
    }

    return $result;
}

sub set_simple_ad
{
    validate_pos(@_, { type => OBJECT },
        { type => HASHREF }, # HASHREF SimpleNetworkADHashRef
    );
    my ($self, @args) = @_;

    my $result;
    eval { $result = $self->{client}->set_simple_ad(@args); };
    if (my $e = Adriver::DBI::Exceptions::DBError->caught())
    {
        Adriver::DBI::Exceptions::Clients->throw(
            error  => Adriver::ErrorMessage::error_message($e),
            code   => $e->{code},
            method => 'set_simple_ad',
            args   => \@args
        );
    }

    return $result;
}

sub set_rle_ad
{
    validate_pos(@_, { type => OBJECT },
        { type => HASHREF }, # HASHREF RLENetworkADHashRef
    );
    my ($self, @args) = @_;

    my $result;
    eval { $result = $self->{client}->set_rle_ad(@args); };
    if (my $e = Adriver::DBI::Exceptions::DBError->caught())
    {
        Adriver::DBI::Exceptions::Clients->throw(
            error  => Adriver::ErrorMessage::error_message($e),
            code   => $e->{code},
            method => 'set_rle_ad',
            args   => \@args
        );
    }

    return $result;
}

1;


__END__


=head1 NAME

    Adriver::DBI::Clients::MacroClient - this module provides methods to work with
    Adriver databases as a macro database.


=head1 DESCRIPTION

    This module is inherited from Adriver::DBI::Clients::Base class.


=head1 SYNOPSIS

    use Adriver::DBI;
    use Adriver::DatabaseConnect::Adriver;
    use Adriver::Exceptions;

    my $host = 'f2.x';
    my $port = 16000;

    eval
    {
        my $dbh = Adriver::DBI->new( Adriver::DatabaseConnect::Adriver->new({host => $host, port => $port}) );

        my $result = $dbh->Macro->set_link_attrs($LinkHashRef);
        my $result = $dbh->Macro->set_banner($BannerHashRef);
        my $result = $dbh->Macro->set_profile($ProfileHashRef);
        my $result = $dbh->Macro->set_ad($ADHashRef);
        my $result = $dbh->Macro->set_simple_ad($SimpleNetworkADHashRef);
        my $result = $dbh->Macro->set_rle_ad($RLENetworkADHashRef);
    };

    if (my $e = Exception::Class->caught('Adriver::Exceptions'))
    {
        die "Caught Adriver::Exceptions: '", $e->error, "'\n", $e->trace->as_string, "\n";
    }
    elsif ($e = Exception::Class->caught('Exception::Class::Base'))
    {
        die "Caught unknown exception: '", $e->error, "'\n", $e->trace->as_string, "\n";
    }
    elsif ($e = Exception::Class->caught)
    {
        die "$e";
    }


=head1 OBJECT INTERFACE

=head2 set_link_attrs($LinkHashRef) : 1

    Set link attributes.

B<LinkHashRef>

    This is hash reference with next structure:

    LinkHashRef =>
    {
        'linkToID'   => INT
        'linkToType' => INT
        'objectID'   => INT
        'objectType' => INT
        'attrs'      => ARRAYREF (2) INT
    }

B<Exceptions>

    Adriver::DBI::Exceptions::ParamsValidation
    Adriver::DBI::Exceptions::Clients

=head2 set_banner($BannerHashRef) : 1

    Set banner.

B<BannerHashRef>

    This is hash reference with next structure:

    BannerHashRef =>
    {
        'bannerID'              => INT
        'bannerType'            => INT
        'bannerSpec'            => INT
        'priority'              => INT
        'burstMode'             => BOOL
        'percent'               => INT
        'percent_cnt'           => INT
        'targetURL'             => STRING
        'altField'              => STRING
        'bannerLocation'        => STRING
        'mirrorStatus'          => ARRAYREF(33) BOOL
        'mirrorMask'            => ARRAYREF(32) BOOL
        'enable'                => BOOL
        'enables'               => ARRAYREF (32) BOOL
        'componentsSubTypes'    => ARRAYREF(3) INT
        'catID'                 => INT
        'labelID'               => INT
        'startTime'             => INT (?)
        'stopTime'              => INT (?)
        'exposures'             => HourlyCounterHashRef
        'clicks'                => HourlyCounterHashRef
        'subevents'             => ARRAYREF(10) CounterHashRef
        'dayMaxShows'           => INT
        'dayMaxClicks'          => INT
        'dayMaxSubevents'       => ARRAYREF(10) INT
        'totalMaxShows'         => INT
        'totalMaxClicks'        => INT
        'totalMaxSubevents'     => ARRAYREF(10) INT
        'uniqueUserMaxShows'    => ARRAYREF(3) INT
        'uniqueUserMaxClicks'   => INT
        'uniqueUserMinInterval' => INT
        'subeventIntervals'     => ARRAYREF(10) INT
        'quickForward'          =>
        {
            'enable'     => BOOL
            'siteZoneID' => INT
            'siteID'     => INT
        },
    }

    where

    CounterHashRef =>
    {
        'today'     => INT
        'yesterday' => INT
        'week'      => INT
        'last_week' => INT
        'total'     => INT
    }

    and

    HourlyCounterHashRef =>
    {
        'today'     => INT
        'yesterday' => INT
        'week'      => INT
        'last_week' => INT
        'total'     => INT
        'last_hour' => INT
    }

B<Exceptions>

    Adriver::DBI::Exceptions::ParamsValidation
    Adriver::DBI::Exceptions::Clients

=head2 set_profile($ProfileHashRef) : 1

    Set profile.

B<ProfileHashRef>

    This is hash reference with next structure:

    ProfileHashRef =>
    {
        'profileID'             => INT
        'profileName'           => STRING
        'burstMode'             => INT
        'enable'                => BOOL
        'enables'               => ARRAYREF(32) BOOL
        'dayHour'               => ARRAYREF(24x7) BOOL
        'dayMonth'              => ARRAYREF(31) BOOL
        'geoZoneMask'           => ARRAYREF(1024) BOOL
        'orgMask'               => ARRAYREF(256) BOOL
        'connectionTypeMask'    => (2)
        'catMask'               => ARRAYREF(256) BOOL
        'browserMask'           => ARRAYREF(32) BOOL
        'osMask'                => ARRAYREF(32) BOOL
        'targetingSwitch'       => {}
        'TZConversion'          => BOOL
        'exposures'             => HourlyCounter
        'clicks'                => HourlyCounter
        'subevents'             => ARRAYREF(10) HourlyCounter
        'totalMaxShows'         => INT
        'totalMaxClicks'        => INT
        'totalMaxSubevents'     => ARRAYREF(10) INT
        'dayMaxShows'           => INT
        'dayMaxClicks'          => INT
        'dayMaxSubevents'       => ARRAYREF(10) INT
        'uniqueUserMaxShows'    => INT
        'uniqueUserMaxClicks'   => INT
        'uniqueUserMinInterval' => INT
    }

    where

    HourlyCounterHashRef =>
    {
        'today'     => INT
        'yesterday' => INT
        'week'      => INT
        'last_week' => INT
        'total'     => INT
        'last_hour' => INT
    }


B<Exceptions>

    Adriver::DBI::Exceptions::ParamsValidation
    Adriver::DBI::Exceptions::Clients

=head2 set_ad($ADHashRef) : 1

    Set advertizing company.

B<ADHashRef>

    This is hash reference with next structure:

    ADHashRef =>
    {
        'adID'                  => INT
        'adName'                => STRING
        'shortName'             => STRING
        'supportName'           => STRING
        'email'                 => STRING
        'credit'                => INT
        'can_borrow'            => BOOL
        'uniqueUserMinInterval' => INT
        'creationTime'          => INT (?)
        'enable'                => BOOL
        'enables'               => ARRAYREF(128) BOOL
        'exposures'             => CounterHashRef
        'clicks'                => CounterHashRef
        'uniqueUserMaxShows'    => ARRAYREF(3) INT
        'uniqueUserMaxClicks'   => INT
        'retargetingInfo'       =>
        {
            'objectID'   => INT,
            'options'    => ARRAYREF(32) INT (?BOOL)
            'objectType' => INT
        },
        'reach' =>
        {
            'period' => INT,
            'limit'  => INT,
            'total'  => INT
        },
    }

    where

    CounterHashRef =>
    {
        'today'     => INT
        'yesterday' => INT
        'week'      => INT
        'last_week' => INT
        'total'     => INT
    }

B<Exceptions>

    Adriver::DBI::Exceptions::ParamsValidation
    Adriver::DBI::Exceptions::Clients

=head2 set_simple_ad($SimpleNetworkADHashRef) : 1

    Set simple advertizing company.

B<SimpleNetworkADHashRef>

    This is hash reference with next structure:

    SimpleNetworkADHashRef =>
    {
        'adID'                  => INT
        'adName'                => STRING
        'enable'                => BOOL
        'enables'               => ARRAYREF(128) BOOL
        'priority'              => INT
        'credit'                => INT
        'shortName'             => STRING
        'supportName'           => STRING
        'email'                 => STRING
        'creationTime'          => INT
        'dayMinExposures'       => INT
        'dayMaxExposures'       => INT
        'dayMinClicks'          => INT
        'dayMaxClicks'          => INT
        'uniqueUserMaxShows'    => ARRAYREF(3) INT
        'uniqueUserMaxClicks'   => INT
        'uniqueUserMinInterval' => INT
        'exposures'             => CounterHashRef
        'clicks'                => CounterHashRef
    }

    where

    CounterHashRef =>
    {
        'today'     => INT
        'yesterday' => INT
        'week'      => INT
        'last_week' => INT
        'total'     => INT
    }

B<Exceptions>

    Adriver::DBI::Exceptions::ParamsValidation
    Adriver::DBI::Exceptions::Clients

=head2 set_rle_ad($RLENetworkADHashRef) : 1

    Set RLE network advertizing company.

B<RLENetworkADHashRef>

    This is hash reference with next structure:

    RLENetworkHashRef =>
    {
        'adID'                  => INT
        'networkID'             => INT
        'adName'                => STRING
        'shortName'             => STRING
        'supportName'           => STRING
        'email'                 => STRING
        'credit'                => INT
        'priority'              => INT
        'enable'                => BOOL
        'enables'               => ARRAYREF(128) BOOL
        'debt'                  => INT
        'enable_indexing'       => BOOL
        'creationTime'          => INT
        'balance'               => INT
        'price'                 => INT (??? FLOAT)
        'nice'                  => INT
        'priorityTargeting'     => ARRAYREF(2) INT
        'targeting_cost'        => ARRAYREF(17) INT
        'maxSaleExposures'      => INT
        'salePriceTomorrow'     => INT
        'salePriceToday'        => INT
        'dayMinExposures'       => INT
        'dayMaxExposures'       => INT
        'dayMinClicks'          => INT
        'dayMaxClicks'          => INT
        'uniqueUserMaxShows'    => ARRAYREF(3) INT
        'uniqueUserMaxClicks'   => INT
        'uniqueUserMinInterval' => INT
        'retargetingInfo'       => HASHREF {'objectID'=>INT,'objectType'=>INT,'options'=>ARRAYREF(32) BOOL(?INT)}
        'rep_exposures'         => HourlyCounterHashRef
        'rep_clicks'            => HourlyCounterHashRef
        'exposures'             => HourlyCounterHashRef
        'clicks'                => HourlyCounterHashRef
    }

    where

    HourlyCounterHashRef =>
    {
        'today'     => INT
        'yesterday' => INT
        'week'      => INT
        'last_week' => INT
        'total'     => INT
        'last_hour' => INT
    }

B<Exceptions>

    Adriver::DBI::Exceptions::ParamsValidation
    Adriver::DBI::Exceptions::Clients


=head1 SEE ALSO

    Adriver::DBI::Clients::Base
    Adriver::DBI::Exceptions
    Adriver::DBI::Clients::LinksClient
    Adriver::DBI::Clients::BannerClient
    Adriver::DBI::Clients::ProfileClient
    Adriver::DBI::Clients::ADClient
    Adriver::DBI::Clients::SimpleNetworkADClient
    Adriver::DBI::Clients::RLENetworkADClient

