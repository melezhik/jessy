package Adriver::DBI::Clients::BaseID;

use strict;
our $VERSION = '0.0300';
use Carp;
use Params::Validate qw(:all);
use base qw ( Adriver::DBI::Clients::Base );

validation_options(on_fail => sub { Adriver::DBI::Exceptions::ParamsValidation->throw( error => $_[0]); } );

#### List of common methods for IDClients
#
# $ELEMENT get($ID)
# \@IDs getids()
# \@ELEMENTs getlist(\@IDs)
# void set($ELEMENT)
# ID add($ELEMENT)
# void remove($ID)
#
## ELEMENT - Hash Ref, object
## ID      - Int, object id
#
#### List of IDClients
#
# ADClient
# BannerClient
# CityClient
# CountryClient
# ISPClient
# OrgClient
# PoolClient
# ProfileClient
# RegionClient
# SiteClient
# SliceClient
# UserClient
# RLENetworkADClient
# RLENetworkClient
# SimpleNetworkADClient
# SimpleNetworkClient
#
####

#### NonID Clients List. Temporary here, devel propose only.
#
# BadIPClient
# CommentClient
# DelegatedObjectsClient
# ExposuresClient -
# KeywordTargetingClient
# LinksClient
# MacroClient
# MirrorRoutingClient
# ObjectOwnersClient
# RLENetworkSiteClient
# SiteTargetingClient
# SiteZoneClient
# StatOptionClient
# UniqueUsersClient -
#
# ADOverStatClient ?
# BannerOverStatClient ?
# ProfileOverStatClient ?
# SiteOverStatClient ?
# SliceOverStatClient ?
#
# GeoClient ? (get_list - hashref)
# GeoHourClient
# GeoStatClient
#
####


sub get
{
    validate_pos(@_, { type => OBJECT },
        { type => SCALAR, regex => qr/^\d+$/ }, # INT ELEMENT_ID
    );
    my ($self, @args) = @_;

    my $result;
    eval { $result = $self->{client}->get(@args); };
    if (my $e = Adriver::DBI::Exceptions::DBError->caught())
    {
        Adriver::DBI::Exceptions::Clients->throw(
            error  => Adriver::ErrorMessage::error_message($e),
            code   => $e->{code},
            method => 'get',
            args   => \@args
        );
    }

    return $result;
}

sub getids
{
    validate_pos(@_, { type => OBJECT });
    my ($self, @args) = @_;

    my $result;
    eval { $result = $self->{client}->getids(); };
    if (my $e = Adriver::DBI::Exceptions::DBError->caught())
    {
        Adriver::DBI::Exceptions::Clients->throw(
            error  => Adriver::ErrorMessage::error_message($e),
            code   => $e->{code},
            method => 'getids',
            args   => \@args
        );
    }

    return $result;
}

sub getlist
{
    validate_pos(@_, { type => OBJECT },
        { type => ARRAYREF }, # ARRAYREF of ELEMENT_IDs
    );
    my ($self, @args) = @_;

    my $result;
    eval { $result = $self->{client}->getlist(@args); };
    if (my $e = Adriver::DBI::Exceptions::DBError->caught())
    {
        Adriver::DBI::Exceptions::Clients->throw(
            error  => Adriver::ErrorMessage::error_message($e),
            code   => $e->{code},
            method => 'getlist',
            args   => \@args
        );
    }

    return $result;
}

sub set
{
    validate_pos(@_, { type => OBJECT },
        { type => HASHREF }, # HASHREF ELEMENT
    );
    my ($self, @args) = @_;

    my $result;
    eval { $result = $self->{client}->set(@args); };
    if (my $e = Adriver::DBI::Exceptions::DBError->caught())
    {
        Adriver::DBI::Exceptions::Clients->throw(
            error  => Adriver::ErrorMessage::error_message($e),
            code   => $e->{code},
            method => 'set',
            args   => \@args
        );
    }

    return $result;
}

sub add
{
    validate_pos(@_, { type => OBJECT },
        { type => HASHREF }, # HASHREF ELEMENT
    );
    my ($self, @args) = @_;

    my $result;
    eval { $result = $self->{client}->add(@args); };
    if (my $e = Adriver::DBI::Exceptions::DBError->caught())
    {
        Adriver::DBI::Exceptions::Clients->throw(
            error  => Adriver::ErrorMessage::error_message($e),
            code   => $e->{code},
            method => 'add',
            args   => \@args
        );
    }

    return $result;
}

sub remove
{
    validate_pos(@_, { type => OBJECT },
        { type => SCALAR, regex => qr/^\d+$/ }, # INT ELEMENT_ID
    );
    my ($self, @args) = @_;

    my $result;
    eval { $result = $self->{client}->remove(@args); };
    if (my $e = Adriver::DBI::Exceptions::DBError->caught())
    {
        Adriver::DBI::Exceptions::Clients->throw(
            error  => Adriver::ErrorMessage::error_message($e),
            code   => $e->{code},
            method => 'remove',
            args   => \@args
        );
    }

    return $result;
}

1;

__END__


=head1 NAME

    Adriver::DBI::Clients::BaseID - this module contains several common methods for some
    Adriver::DBI::Clients modules which are working with databases using elements identifiers.


=head1 DESCRIPTION

    You should not use this module directly. It's used like as a basic class for some Adriver::DBI::Clients modules
    and implemets several common methods for them. This module is inherited from Adriver::DBI::Clients::Base class.


=head1 OBJECT INTERFACE

=head2 get($element_id) : $element

    Get certain element from database by it's identifier.

B<element_id>

    Integer.

B<element>

    Getted element.

B<Exceptions>

    Adriver::DBI::Exceptions::ParamsValidation
    Adriver::DBI::Exceptions::Clients

=head2 getids() : $ids

    This method returns all elements identifiers stored in database.

B<ids>

    This is a array reference with getted identifiers.

B<Exceptions>

    Adriver::DBI::Exceptions::ParamsValidation
    Adriver::DBI::Exceptions::Clients

=head2 getlist($ids) : $ElementsArrayRef

    This method returns a list of elements from database by their identifiers.

B<ids>

    The array reference with elements identifiers you want to get.

B<ElementsArrayRef>

    Returned list of elements.

B<Exceptions>

    Adriver::DBI::Exceptions::ParamsValidation
    Adriver::DBI::Exceptions::Clients

=head2 set($element) : undef

    This method updates given element in database.

B<element>

    Element from database.

B<Exceptions>

    Adriver::DBI::Exceptions::ParamsValidation
    Adriver::DBI::Exceptions::Clients

=head2 add($element) : $id

    This method adds the new element in database and returns it's identifier.

B<element>

    This is a hash reference representes the new element of database.

B<id>

    This is the integer identifier of added element.

B<Exceptions>

    Adriver::DBI::Exceptions::ParamsValidation
    Adriver::DBI::Exceptions::Clients

=head2 remove($element_id) : undef

    This method removes element from database by it's identifier.

B<element_id>

    This is element identifier you want to remove.

B<Exceptions>

    Adriver::DBI::Exceptions::ParamsValidation
    Adriver::DBI::Exceptions::Clients


=head1 SEE ALSO

    Adriver::DBI::Clients::Base
    Adriver::DBI::Exceptions

