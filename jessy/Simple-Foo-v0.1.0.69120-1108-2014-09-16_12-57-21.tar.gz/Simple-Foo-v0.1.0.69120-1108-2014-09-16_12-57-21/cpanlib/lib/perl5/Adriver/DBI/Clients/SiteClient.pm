package Adriver::DBI::Clients::SiteClient;

use strict;
our $VERSION = '0.0300';
use Carp;
use Params::Validate qw(:all);
use base qw ( Adriver::DBI::Clients::BaseID );

validation_options(on_fail => sub { Adriver::DBI::Exceptions::ParamsValidation->throw( error => $_[0]); } );

sub package { 'RLE::SiteClient' }

#### Generic BaseID Functions
#
# get(INT SiteID)
# getids()
# getlist(ARRAYREF of INT SiteIDs)
# set(HASHREF SiteHashRef)
# add(HASHREF SiteHashRef)
# remove(INT SiteID)
#
#### Other Functions
#
## Increment exposures or click in site with SiteID
## DONOT USE THIS METHODS IN IFACES! SPECIAL SYSTEM CALLS!
#
# (INT SiteID) exposure(INT SiteID)
# (INT SiteID) click(INT SiteID)
#
## Sets exposures or click counter in site with SiteID
#
# (INT SiteID) set_exposures_counter(INT SiteID, HASHREF CounterHashRef)
# (INT SiteID) set_clicks_counter(INT SiteID, HASHREF CounterHashRef)
#
## Get top-list for counter, specified in CounterHashRefMask ("counter" => 1)
## Input param Number is the number of elements in the top-list
## Its highly recommended to set to 1 only one counter
## (if you set many, func will use only one)
## If list of the SiteIDs is specified, func get toplist from this list
#
# (ARRAYREF of HASHREF Sites) get_top_exposures(HASHREF CounterHashRefMask, INT Number[, ARRAYREF of INT SiteIDs])
# (ARRAYREF of HASHREF Sites) get_top_clicks(HASHREF CounterHashRefMask, INT Number[, ARRAYREF of INT SiteIDs])
#
## Get Sites for mask SiteHashRefMask
## Elements in mask is substrs for search in base
## If list of the SiteIDs is specified, func get Sites from this list
## (Url compare with all urls of site, if one is eq ==> ok)
#
# (ARRAYREF of HASHREF Sites) get_ex(HASHREF SiteHashRefMask[, ARRAYREF of INT SiteIDs])
#
## Rotate counter in all sites
## DONOT USE THIS METHODS IN IFACES! SPECIAL SYSTEM CALLS!
#
# (void) rotate_daily()
# (void) rotate_weekly()
#
#### Input Data Info
#
# CounterHashRef =>
# {
#     'today'     => INT
#     'yesterday' => INT
#     'week'      => INT
#     'last_week' => INT
#     'total'     => INT
# }
#
# CounterHashRefMask =>
# {
#     'today'     => BOOL
#     'yesterday' => BOOL
#     'week'      => BOOL
#     'last_week' => BOOL
#     'total'     => BOOL
# }
#
# SiteHashRefMask =>
# {
#     'siteURLs'    => STRING
#     'siteName'    => STRING
#     'email'       => STRING
#     'supportName' => STRING
#     'shortName'   => STRING
# }
#
# SiteHashRef =>
# {
#     'siteID'              => INT
#     'siteName'            => STRING
#     'shortName'           => STRING
#     'siteURLs'            => ARRAYREF(16) STRING
#     'supportName'         => STRING
#     'email'               => STRING
#     'checkSiteURL'        => BOOL
#     'enable'              => BOOL
#     'enables'             => ARRAYREF(32) BOOL
#     'creationTime'        => INT
#     'maxSiteZoneID'       => INT
#     'defaultBannerType'   => INT
#     'bannerSpecParamsNum' => INT
#     'bannerSpecParams'    => ARRAYREF(32) {'action'=>INT, 'bannerSpec'=>INT, 'exposureInterval'=>INT}
#     'exposures'           => CounterHashRef
#     'clicks'              => CounterHashRef
# }
#
####

sub exposure
{
    validate_pos(@_, { type => OBJECT },
        { type => SCALAR, regex => qr/^\d+$/ }, # INT SiteID
    );
    my ($self, @args) = @_;

    my $result;
    eval { $result = $self->{client}->exposure(@args); };
    if (my $e = Adriver::DBI::Exceptions::DBError->caught())
    {
        Adriver::DBI::Exceptions::Clients->throw(
            error  => Adriver::ErrorMessage::error_message($e),
            code   => $e->{code},
            method => 'exposure',
            args   => \@args
        );
    }

    return $result;
}

sub click
{
    validate_pos(@_, { type => OBJECT },
        { type => SCALAR, regex => qr/^\d+$/ }, # INT SiteID
    );
    my ($self, @args) = @_;

    my $result;
    eval { $result = $self->{client}->click(@args); };
    if (my $e = Adriver::DBI::Exceptions::DBError->caught())
    {
        Adriver::DBI::Exceptions::Clients->throw(
            error  => Adriver::ErrorMessage::error_message($e),
            code   => $e->{code},
            method => 'click',
            args   => \@args
        );
    }

    return $result;
}

sub set_exposures_counter
{
    validate_pos(@_, { type => OBJECT },
        { type => SCALAR, regex => qr/^\d+$/ }, # INT SiteID
        { type => HASHREF },                    # HASHREF CounterHashRef
    );
    my ($self, @args) = @_;

    my $result;
    eval { $result = $self->{client}->set_exposures_counter(@args); };
    if (my $e = Adriver::DBI::Exceptions::DBError->caught())
    {
        Adriver::DBI::Exceptions::Clients->throw(
            error  => Adriver::ErrorMessage::error_message($e),
            code   => $e->{code},
            method => 'set_exposures_counter',
            args   => \@args
        );
    }

    return $result;
}

sub set_clicks_counter
{
    validate_pos(@_, { type => OBJECT },
        { type => SCALAR, regex => qr/^\d+$/ }, # INT SiteID
        { type => HASHREF },                    # HASHREF CounterHashRef
    );
    my ($self, @args) = @_;

    my $result;
    eval { $result = $self->{client}->set_clicks_counter(@args); };
    if (my $e = Adriver::DBI::Exceptions::DBError->caught())
    {
        Adriver::DBI::Exceptions::Clients->throw(
            error  => Adriver::ErrorMessage::error_message($e),
            code   => $e->{code},
            method => 'set_clicks_counter',
            args   => \@args
        );
    }

    return $result;
}

sub get_top_exposures
{
    validate_pos(@_, { type => OBJECT },
        { type => HASHREF },                    # HASHREF CounterHashRefMask
        { type => SCALAR, regex => qr/^\d+$/ }, # INT Number
        { type => ARRAYREF, optional => 1 },    # ARRAYREF of INT SiteIDs
    );
    my ($self, @args) = @_;

    my $result;
    eval { $result = $self->{client}->get_top_exposures(@args); };
    if (my $e = Adriver::DBI::Exceptions::DBError->caught())
    {
        Adriver::DBI::Exceptions::Clients->throw(
            error  => Adriver::ErrorMessage::error_message($e),
            code   => $e->{code},
            method => 'get_top_exposures',
            args   => \@args
        );
    }

    return $result;
}

sub get_top_clicks
{
    validate_pos(@_, { type => OBJECT },
        { type => HASHREF },                    # HASHREF CounterHashRefMask
        { type => SCALAR, regex => qr/^\d+$/ }, # INT Number
        { type => ARRAYREF, optional => 1 },    # ARRAYREF of INT SiteIDs
    );
    my ($self, @args) = @_;

    my $result;
    eval { $result = $self->{client}->get_top_clicks(@args); };
    if (my $e = Adriver::DBI::Exceptions::DBError->caught())
    {
        Adriver::DBI::Exceptions::Clients->throw(
            error  => Adriver::ErrorMessage::error_message($e),
            code   => $e->{code},
            method => 'get_top_clicks',
            args   => \@args
        );
    }

    return $result;
}

sub get_ex
{
    validate_pos(@_, { type => OBJECT },
        { type => HASHREF },                 # HASHREF SiteHashRefMask
        { type => ARRAYREF, optional => 1 }, # ARRAYREF of INT SiteIDs
    );
    my ($self, @args) = @_;

    my $result;
    eval { $result = $self->{client}->get_ex(@args); };
    if (my $e = Adriver::DBI::Exceptions::DBError->caught())
    {
        Adriver::DBI::Exceptions::Clients->throw(
            error  => Adriver::ErrorMessage::error_message($e),
            code   => $e->{code},
            method => 'get_ex',
            args   => \@args
        );
    }

    return $result;
}

sub rotate_daily
{
    validate_pos(@_, { type => OBJECT });
    my ($self, @args) = @_;

    my $result;
    eval { $result = $self->{client}->rotate_daily(@args); };
    if (my $e = Adriver::DBI::Exceptions::DBError->caught())
    {
        Adriver::DBI::Exceptions::Clients->throw(
            error  => Adriver::ErrorMessage::error_message($e),
            code   => $e->{code},
            method => 'rotate_daily',
            args   => \@args
        );
    }

    return $result;
}

sub rotate_weekly
{
    validate_pos(@_, { type => OBJECT });
    my ($self, @args) = @_;

    my $result;
    eval { $result = $self->{client}->rotate_weekly(@args); };
    if (my $e = Adriver::DBI::Exceptions::DBError->caught())
    {
        Adriver::DBI::Exceptions::Clients->throw(
            error  => Adriver::ErrorMessage::error_message($e),
            code   => $e->{code},
            method => 'rotate_weekly',
            args   => \@args
        );
    }

    return $result;
}

1;


__END__


=head1 NAME

    Adriver::DBI::Clients::SiteClient - this module provides methods to work with
    Adriver sites database.


=head1 DESCRIPTION

    This module is inherited from Adriver::DBI::Clients::BaseID class.


=head1 SYNOPSIS

    use Adriver::DBI;
    use Adriver::DatabaseConnect::Adriver;
    use Adriver::Exceptions;

    my $host = 'f2.x';
    my $port = 16000;

    eval
    {
        my $dbh = Adriver::DBI->new( Adriver::DatabaseConnect::Adriver->new({host => $host, port => $port}) );

        my $site_id = 98291;
        my $site = $dbh->Site->get($site_id);
        print Dumper($site);

        my $db_info = $dbh->Site->GetCaps();
        print Dumper($db_info);

        my $ids = $dbh->Site->getids();
        print Dumper($ids);

        my @ids = (72115, 23007, 72192);
        my $sites = $dbh->Site->getlist(\@ids);
        print Dumper($sites);

        $dbh->Site->set($site);
    };

    if (my $e = Exception::Class->caught('Adriver::Exceptions'))
    {
        die "Caught Adriver::Exceptions: '", $e->error, "'\n", $e->trace->as_string, "\n";
    }
    elsif ($e = Exception::Class->caught('Exception::Class::Base'))
    {
        die "Caught unknown exception: '", $e->error, "'\n", $e->trace->as_string, "\n";
    }
    elsif ($e = Exception::Class->caught)
    {
        die "$e";
    }


=head1 INHERITED OBJECT INTERFACE

=head2 get($site_id) : $SiteHashRef

    Get certain site from database by it's identifier.

B<site_id>

    This is the integer identifier of site.

B<SiteHashRef>

    This is a hash reference with next structure:

    SiteHashRef =>
    {
        'siteID'              => INT
        'siteName'            => STRING
        'shortName'           => STRING
        'siteURLs'            => ARRAYREF(16) STRING
        'supportName'         => STRING
        'email'               => STRING
        'checkSiteURL'        => BOOL
        'enable'              => BOOL
        'enables'             => ARRAYREF(32) BOOL
        'creationTime'        => INT
        'maxSiteZoneID'       => INT
        'defaultBannerType'   => INT
        'bannerSpecParamsNum' => INT
        'bannerSpecParams'    => ARRAYREF(32) {'action'=>INT, 'bannerSpec'=>INT, 'exposureInterval'=>INT}
        'exposures'           => CounterHashRef
        'clicks'              => CounterHashRef
    }

    where

    CounterHashRef =>
    {
        'today'     => INT
        'yesterday' => INT
        'week'      => INT
        'last_week' => INT
        'total'     => INT
    }

B<Exceptions>

    Adriver::DBI::Exceptions::ParamsValidation
    Adriver::DBI::Exceptions::Clients

=head2 getids() : $site_ids

    This method returns a list of all sites identifiers from database.

B<sites_ids>

    This is the array reference with obtained sites identifiers.

B<Exceptions>

    Adriver::DBI::Exceptions::ParamsValidation
    Adriver::DBI::Exceptions::Clients

=head2 getlist(\@site_ids) : ARRAYREF of $SiteHashRef

    This method returns a list of sites from database by their identifiers.

B<site_ids>

    This is the array reference with sites identifiers you want to get.

B<SiteHashRef>

    This is the same hash reference as described in get() method.

B<Exceptions>

    Adriver::DBI::Exceptions::ParamsValidation
    Adriver::DBI::Exceptions::Clients

=head2 set($SiteHashRef) : undef

    This method updates given site in database.

B<SiteHashRef>

    This is the same hash reference as described in get() method.

B<Exceptions>

    Adriver::DBI::Exceptions::ParamsValidation
    Adriver::DBI::Exceptions::Clients

=head2 add($SiteHashRef) : $site_id

    This method adds the new site in database and returns it's identifier.

B<SiteHashRef>

    This is the same hash reference as described in get() method.

B<site_id>

    This is the integer identifier of added site.

B<Exceptions>

    Adriver::DBI::Exceptions::ParamsValidation
    Adriver::DBI::Exceptions::Clients

=head2 remove($site_id) : undef

    This method removes site from database by it's identifier.

B<site_id>

    This is the site identifier you want to remove.

B<Exceptions>

    Adriver::DBI::Exceptions::ParamsValidation
    Adriver::DBI::Exceptions::Clients


=head1 OBJECT INTERFACE

=head2 exposure($site_id) : $site_id

    This method icrements the number of site exposures.
    DONOT USE THIS METHODS IN IFACES! SPECIAL SYSTEM CALLS!

B<site_id>

    This is the site identifier which exposures counter you want to increase.

B<Exceptions>

    Adriver::DBI::Exceptions::ParamsValidation
    Adriver::DBI::Exceptions::Clients

=head2 click($site_id) : $site_id

    This method icrements the number of site clicks.
    DONOT USE THIS METHODS IN IFACES! SPECIAL SYSTEM CALLS!

B<site_id>

    This is the site identifier which clicks counter you want to increase.

B<Exceptions>

    Adriver::DBI::Exceptions::ParamsValidation
    Adriver::DBI::Exceptions::Clients

=head2 set_exposures_counter($site_id, $CounterHashRef) : $site_id

    This method sets the counter of site exposures.

B<site_id>

    This is the site identifier which exposures counter you want to set.

B<CounterHashRef>

    This is the same hash reference as described in get() method.

B<Exceptions>

    Adriver::DBI::Exceptions::ParamsValidation
    Adriver::DBI::Exceptions::Clients

=head2 set_clicks_counter($site_id, $CounterHashRef) : $site_id

    This method sets the counter of site clicks.

B<site_id>

    This is the site identifier which clicks counter you want to set.

B<CounterHashRef>

    This is the same hash reference as described in get() method.

B<Exceptions>

    Adriver::DBI::Exceptions::ParamsValidation
    Adriver::DBI::Exceptions::Clients

=head2 get_top_exposures($CounterHashRefMask, $number[, ARRAYREF of INT SiteIDs]) : ARRAYREF of $SiteHashRef

    This method returns the top-list of sites sorted by exposures counter.
    If list of the sites identifiers is specified, procedure gets top-list from them.

B<CounterHashRefMask>

    This is a hash reference. Procedure gets top-list for counter, specified in CounterHashRefMask ("counter" => 1).
    Its highly recommended to set to 1 only one counter, if you set many, procedure will use only one anyway.
    The structure of CounterHashRefMask specified below:

    CounterHashRefMask =>
    {
        'today'     => BOOL
        'yesterday' => BOOL
        'week'      => BOOL
        'last_week' => BOOL
        'total'     => BOOL
    }

B<number>

    This is the number of elements in the top-list.

B<SiteHashRef>

    This is the same hash reference as described in get() method.

B<Exceptions>

    Adriver::DBI::Exceptions::ParamsValidation
    Adriver::DBI::Exceptions::Clients

=head2 get_top_clicks($CounterHashRefMask, $number[, ARRAYREF of INT SiteIDs]) : ARRAYREF of $SiteHashRef

    This method returns the top-list of sites sorted by clicks counter.
    If list of the sites identifiers is specified, procedure gets top-list from this list.

B<CounterHashRefMask>

    This is a hash reference. Procedure gets top-list for counter, specified in CounterHashRefMask ("counter" => 1).
    Its highly recommended to set to 1 only one counter, if you set many, procedure will use only one anyway.
    The structure of CounterHashRefMask specified below:

    CounterHashRefMask =>
    {
        'today'     => BOOL
        'yesterday' => BOOL
        'week'      => BOOL
        'last_week' => BOOL
        'total'     => BOOL
    }

B<number>

    This is the number of elements in the top-list.

B<SiteHashRef>

    This is the same hash reference as described in get() method.

B<Exceptions>

    Adriver::DBI::Exceptions::ParamsValidation
    Adriver::DBI::Exceptions::Clients

=head2 get_ex($SiteHashRefMask[, ARRAYREF of INT SiteIDs]) : ARRAYREF of SiteHashRef

    This method gets sites appropriate to mask SiteHashRefMask.
    If the list of site identifiers is specified, procedure searchs sites from them.

B<SiteHashRefMask>

    This is a hash reference. Elements in mask is substrs for search in base.
    The structure of SiteHashRefMask specified below:

    SiteHashRefMask =>
    {
        'siteURLs'    => STRING
        'siteName'    => STRING
        'email'       => STRING
        'supportName' => STRING
        'shortName'   => STRING
    }


B<SiteHashRef>

    This is the same hash reference as described in get() method.

B<Exceptions>

    Adriver::DBI::Exceptions::ParamsValidation
    Adriver::DBI::Exceptions::Clients

=head2 rotate_daily() : undef

    This procedure rotates daily counters in all sites.
    DONOT USE THIS METHODS IN IFACES! SPECIAL SYSTEM CALLS!

B<Exceptions>

    Adriver::DBI::Exceptions::ParamsValidation
    Adriver::DBI::Exceptions::Clients

=head2 rotate_weekly() : undef

    This procedure rotates weekly counters in all sites.
    DONOT USE THIS METHODS IN IFACES! SPECIAL SYSTEM CALLS!

B<Exceptions>

    Adriver::DBI::Exceptions::ParamsValidation
    Adriver::DBI::Exceptions::Clients


=head1 SEE ALSO

    Adriver::DBI::Clients::BaseID
    Adriver::DBI::Exceptions

