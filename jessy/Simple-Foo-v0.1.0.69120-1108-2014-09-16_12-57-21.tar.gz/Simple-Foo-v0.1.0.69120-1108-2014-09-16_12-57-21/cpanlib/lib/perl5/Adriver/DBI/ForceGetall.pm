package Adriver::DBI::ForceGetall;

use strict;
our $VERSION = '0.0300';
use Carp;
use base qw(Exporter);
use Adriver::DBI::Exceptions;

our @EXPORT = qw(FORCE_GETALL);

sub new
{
    unless ((caller(1))[3] eq 'Adriver::DBI::ForceGetall::FORCE_GETALL')
    {
        Adriver::DBI::Exceptions->throw( error => 'This object can be created only by special method' );
    }
    my $self = {};
    my $that = shift;
    my $class = ref($that)||$that;
    bless($self, $class);
    return $self;
}

sub access_granted
{
    my $self = shift;
    return 42;
}

sub FORCE_GETALL
{
    return new Adriver::DBI::ForceGetall;
}

1;


__END__


=head1 NAME

    Adriver::DBI::ForceGetall - this module is used as confirmation when you are
    going to execute some danger operations.


=head1 DESCRIPTION

    Using this module you can approve that you realy want to carry out this function.


=head1 SYNOPSIS

    use Adriver::DBI;
    use Adriver::DatabaseConnect::Adriver;
    use Adriver::DBI::ForceGetall;
    use Adriver::Exceptions;

    my $host = 'f2.x';
    my $port = 16000;

    eval
    {
        my $dbh = Adriver::DBI->new( Adriver::DatabaseConnect::Adriver->new({host => $host, port => $port}) );

        my $links = $dbh->Links->getall(FORCE_GETALL);
        print Dumper($links);

    };

    if (my $e = Exception::Class->caught('Adriver::Exceptions'))
    {
        die "Caught Adriver::Exceptions: '", $e->error, "'\n", $e->trace->as_string, "\n";
    }
    elsif ($e = Exception::Class->caught('Exception::Class::Base'))
    {
        die "Caught unknown exception: '", $e->error, "'\n", $e->trace->as_string, "\n";
    }
    elsif ($e = Exception::Class->caught)
    {
        die "$e";
    }


=head1 INTERFACE

=head2 FORCE_GETALL() : Adriver::DBI::ForceGetall $object

    This function creates the new object of class and returns it.

B<object>

    The new object of class.

B<Exceptions>

    Adriver::DBI::Exceptions


=head1 SEE ALSO

    Adriver::DBI::Exceptions

