package Adriver::DBI::Clients::SliceClient;

use strict;
our $VERSION = '0.0300';
use Carp;
use Params::Validate qw(:all);
use base qw ( Adriver::DBI::Clients::BaseID );

validation_options(on_fail => sub { Adriver::DBI::Exceptions::ParamsValidation->throw( error => $_[0]); } );

sub package { 'RLE::SliceClient' }

#### Generic BaseID Functions
#
# get(INT SliceID)
# getids()
# getlist(ARRAYREF of INT SliceIDs)
# set(HASHREF SliceHashRef)
# add(HASHREF SliceHashRef)
# remove(INT SliceID)
#
###
#
## Increment exposures, click or subevent in slice with SliceID
## DONOT USE THIS METHODS IN IFACES! SPECIAL SYSTEM CALLS!
#
# (INT 1) exposure(INT SliceID)
# (INT 1) click(INT SliceID)
# (INT 1) subevent(INT SliceID, INT SubeventType)
#
## Sets exposures, click or subevent counter in slice with SliceID
#
# (INT 1) set_exposures_counter(INT SliceID, HASHREF HourlyCounterHashRef)
# (INT 1) set_clicks_counter(INT SliceID, HASHREF HourlyCounterHashRef)
# (INT 1) set_subevents_counter(INT SliceID, INT SubeventType, HASHREF CounterHashRef)
#
## Return list of slices or sliceids for SiteID
#
# (ARRAYREF of HASHREF Slices) get_site_slices(INT SiteID)
# (ARRAYREF of INT SliceIDs) get_site_ids(INT SiteID)
#
## Return list of slices or sliceids for PublisherID
#
# (ARRAYREF of HASHREF Slices) get_publisher_slices(INT PublisherID)
# (ARRAYREF of INT SliceIDs) get_publisher_ids(INT PublisherID)
#
## Return list of slices or sliceids for AAID
#
# (ARRAYREF of HASHREF Slices) get_aa_slices(INT AAID)
# (ARRAYREF of INT SliceIDs) get_aa_ids(INT AAID)
#
## Return list of slices or sliceids for ADID
#
# (ARRAYREF of HASHREF Slices) get_ad_slices(INT ADID)
# (ARRAYREF of INT SliceIDs) get_ad_ids(INT ADID)
#
## Return list of slices or sliceids for PoolID
#
# (ARRAYREF of HASHREF Slices) get_pool_slices(INT PoolID)
# (ARRAYREF of INT SliceIDs) get_pool_ids(INT PoolID)
#
## Return list of slices or sliceids for NetworkID with NetworkType
#
# (ARRAYREF of HASHREF Slices) get_network_slices(INT NetworkID, INT NetworkType)
# (ARRAYREF of INT SliceIDs) get_network_ids(INT NetworkID, INT NetworkType)
#
## Return list of slices or sliceids for Rep_ADID with NetworkType
#
# (ARRAYREF of HASHREF Slices) get_rep_ad_slices(INT Rep_ADID, INT NetworkType)
# (ARRAYREF of INT SliceIDs) get_rep_ad_ids(INT Rep_ADID, INT NetworkType)
#
## Get top-list for counter, specified in HourlyCounterHashRefMask ("counter" => 1)
## Input param Number is the number of elements in the top-list
## Its highly recommended to set to 1 only one counter
## (if you set many, func will use only one)
## If list of the SliceIDs is specified, func get toplist from this list
#
# (ARRAYREF of HASHREF Slices) get_top_exposures(HASHREF HourlyCounterHashRefMask, INT Number[, ARRAYREF of INT SliceIDs])
# (ARRAYREF of HASHREF Slices) get_top_clicks(HASHREF HourlyCounterHashRefMask, INT Number[, ARRAYREF of INT SliceIDs])
#
## Get Slices for mask SliceHashRefMask, but only for fields, checked in flags
## (and if field in mask == 0 and checked in flags, it compared but not skipped)
## If list of the SliceIDs is specified, func get Slices from this list
#
# (ARRAYREF of HASHREF Slices) get_ex(ARRAYREF of BOOL Flags, HASHREF SliceHashRefMask[, ARRAYREF of INT SliceIDs])
#
## Rotate counter in all slices
## DONOT USE THIS METHODS IN IFACES! SPECIAL SYSTEM CALLS!
#
# (void) rotate_hourly()
# (void) rotate_daily()
# (void) rotate_weekly()
#
#### Input Data Info
#
# CounterHashRef =>
# {
#     'today'     => INT
#     'yesterday' => INT
#     'week'      => INT
#     'last_week' => INT
#     'total'     => INT
# }
#
# HourlyCounterHashRef =>
# {
#     'today'     => INT
#     'yesterday' => INT
#     'week'      => INT
#     'last_week' => INT
#     'total'     => INT
#     'last_hour' => INT
# }
#
# HourlyCounterHashRefMask =>
# {
#     'today'     => BOOL
#     'yesterday' => BOOL
#     'week'      => BOOL
#     'last_week' => BOOL
#     'total'     => BOOL
#     'last_hour' => BOOL
# }
#
# SliceHashRefMask =>
# {
#     'siteID'       => INT
#     'siteZoneID'   => INT
#     'pageZone'     => INT
#     'sliceType'    => INT
#     'startDate'    => INT
#     'finishDate'   => INT
#     'bannerType'   => INT
#     'pubID'        => INT
#     'aaID'         => INT
#     'adID'         => INT
#     'percent'      => INT
#     'priority'     => INT
#     'maxshows'     => INT
#     'day_maxshows' => INT
#     'assign'       => INT
#     'enable'       => BOOL
#     'networkType'  => INT
#     'networkID'    => INT
#     'rep_adID'     => INT
#     'poolID'       => INT
# }
#
## Its very strange logic for date comparsion :)
## If only one date is cpecified, its ok - dates is compared.
## But in case, when both dates is specified, strange logic is appeared.
## Pair of start- and stop- dates matching if this interval equal or
## intersect with interval of the slice, but not included or including.
## So, be careful!
## It's part of the code from c-sources:
##
## // Date Analysis
## // 1. SLICE_OPT_STARTDATE is specified
## (
##   !(flags[SLICE_OPT_STARTDATE] && (flags[SLICE_OPT_STARTDATE] && !(flags[SLICE_OPT_FINISHDATE] && flags[SLICE_OPT_STARTDATE])))
##   ||
##   (
##     (flags[SLICE_OPT_STARTDATE] && (flags[SLICE_OPT_STARTDATE] && !(flags[SLICE_OPT_FINISHDATE] && flags[SLICE_OPT_STARTDATE])))
##     &&
##     req.startDate == slice.startDate
##   )
## ) &&
## // 2. SLICE_OPT_FINISHDATE is specified
## (
##   !(flags[SLICE_OPT_FINISHDATE] && (flags[SLICE_OPT_FINISHDATE] && !(flags[SLICE_OPT_FINISHDATE] && flags[SLICE_OPT_STARTDATE])))
##   ||
##   (
##     (flags[SLICE_OPT_FINISHDATE] && (flags[SLICE_OPT_FINISHDATE] && !(flags[SLICE_OPT_FINISHDATE] && flags[SLICE_OPT_STARTDATE])))
##     &&
##     req.startDate == slice.startDate
##   )
## ) &&
## // 3. both OPT_STARTDATE & SLICE_OPT_FINISHDATE are specified
## (
##   !(flags[SLICE_OPT_STARTDATE] && flags[SLICE_OPT_FINISHDATE])
##   ||
##   (
##     (flags[SLICE_OPT_STARTDATE] && flags[SLICE_OPT_FINISHDATE])
##     &&
##     (
##       (slice.startDate <= req.startDate && req.startDate <= slice.finishDate && slice.finishDate <= req.finishDate)
##       ||
##       (req.startDate <= slice.startDate && slice.startDate <= req.finishDate && req.finishDate <= slice.finishDate)
##     )
##   )
## ) &&
#
# Flags => ARRAYREF (21) BOOL
#
## FlagList:
## SITEID          0  | SITEZONEID      1  | PAGEZONE        2
## SLICETYPE       3  | STARTDATE       4  | FINISHDATE      5
## BANNERTYPE      6  | PUBID           7  | AAID            8
## ADID            9  | PERCENT         10 | PRIORITY        11
## MAXSHOWS        12 | DAYMAXSHOWS     13 | ASSIGN          14
## ENABLE          15 | NETWORK_TYPE    16 | NETWORKID       17
## REP_ADID        18 | POOLID          19 | NUM             20
#
# SliceHashRef =>
# {
#     'sliceID'          => INT
#     'siteID'           => INT
#     'adID'             => INT
#     'rep_adID'         => INT
#     'pubID'            => INT
#     'aaID'             => INT
#     'poolID'           => INT
#     'siteZoneID'       => INT
#     'networkID'        => INT
#     'networkType'      => INT
#     'sliceType'        => INT
#     'burstMode'        => BOOL
#     'enable'           => BOOL
#     'enables'          => ARRAYREF(32) BOOL
#     'priority'         => INT
#     'percent'          => INT
#     'bannerNumber'     => INT
#     'bannerType'       => INT
#     'pageZone'         => INT
#     'startDate'        => INT
#     'finishDate'       => INT
#     'maxshows'         => INT
#     'maxclicks'        => INT
#     'maxsubevents'     => ARRAYREF(10) INT
#     'day_maxshows'     => INT
#     'day_maxclicks'    => INT
#     'day_maxsubevents' => ARRAYREF(10) INT
#     'exposures'        => HourlyCounterHashRef
#     'clicks'           => HourlyCounterHashRef
#     'subevents'        => ARRAYREF(10) CounterHashRef
#     'dayHour'          => ARRAYREF(7) of ARRAYREF(24) BOOL
#     'dayMonth'         => ARRAYREF (31) BOOL
#     'geoMask'          => ARRAYREF(1024) BOOL
#     'balanceSwitch'    => ARRAYREF(32) BOOL (?INT)
#     'balanceCounters'  => ARRAYREF(32) BOOL (?INT)
#     'TZConversion'     => INT (?BOOL)
#     'assign'           => INT (?BOOL)
#     'rejects'          => CounterHashRef
# }
#
####

sub exposure
{
    validate_pos(@_, { type => OBJECT },
        { type => SCALAR, regex => qr/^\d+$/ }, # INT SliceID
    );
    my ($self, @args) = @_;

    my $result;
    eval { $result = $self->{client}->exposure(@args); };
    if (my $e = Adriver::DBI::Exceptions::DBError->caught())
    {
        Adriver::DBI::Exceptions::Clients->throw(
            error  => Adriver::ErrorMessage::error_message($e),
            code   => $e->{code},
            method => 'exposure',
            args   => \@args
        );
    }

    return $result;
}

sub click
{
    validate_pos(@_, { type => OBJECT },
        { type => SCALAR, regex => qr/^\d+$/ }, # INT SliceID
    );
    my ($self, @args) = @_;

    my $result;
    eval { $result = $self->{client}->click(@args); };
    if (my $e = Adriver::DBI::Exceptions::DBError->caught())
    {
        Adriver::DBI::Exceptions::Clients->throw(
            error  => Adriver::ErrorMessage::error_message($e),
            code   => $e->{code},
            method => 'click',
            args   => \@args
        );
    }

    return $result;
}

sub subevent
{
    validate_pos(@_, { type => OBJECT },
        { type => SCALAR, regex => qr/^\d+$/ }, # INT SliceID
        { type => SCALAR, regex => qr/^\d+$/ }, # INT SubeventType
    );
    my ($self, @args) = @_;

    my $result;
    eval { $result = $self->{client}->subevent(@args); };
    if (my $e = Adriver::DBI::Exceptions::DBError->caught())
    {
        Adriver::DBI::Exceptions::Clients->throw(
            error  => Adriver::ErrorMessage::error_message($e),
            code   => $e->{code},
            method => 'subevent',
            args   => \@args
        );
    }

    return $result;
}

sub set_exposures_counter
{
    validate_pos(@_, { type => OBJECT },
        { type => SCALAR, regex => qr/^\d+$/ }, # INT SliceID
        { type => HASHREF },                    # HASHREF CounterHashRef
    );
    my ($self, @args) = @_;

    my $result;
    eval { $result = $self->{client}->set_exposures_counter(@args); };
    if (my $e = Adriver::DBI::Exceptions::DBError->caught())
    {
        Adriver::DBI::Exceptions::Clients->throw(
            error  => Adriver::ErrorMessage::error_message($e),
            code   => $e->{code},
            method => 'set_exposures_counter',
            args   => \@args
        );
    }

    return $result;
}

sub set_clicks_counter
{
    validate_pos(@_, { type => OBJECT },
        { type => SCALAR, regex => qr/^\d+$/ }, # INT SliceID
        { type => HASHREF },                    # HASHREF CounterHashRef
    );
    my ($self, @args) = @_;

    my $result;
    eval { $result = $self->{client}->set_clicks_counter(@args); };
    if (my $e = Adriver::DBI::Exceptions::DBError->caught())
    {
        Adriver::DBI::Exceptions::Clients->throw(
            error  => Adriver::ErrorMessage::error_message($e),
            code   => $e->{code},
            method => 'set_clicks_counter',
            args   => \@args
        );
    }

    return $result;
}

sub set_subevents_counter
{
    validate_pos(@_, { type => OBJECT },
        { type => SCALAR, regex => qr/^\d+$/ }, # INT SliceID
        { type => SCALAR, regex => qr/^\d+$/ }, # INT SubeventType
        { type => HASHREF },                    # HASHREF CounterHashRef
    );
    my ($self, @args) = @_;

    my $result;
    eval { $result = $self->{client}->set_subevents_counter(@args); };
    if (my $e = Adriver::DBI::Exceptions::DBError->caught())
    {
        Adriver::DBI::Exceptions::Clients->throw(
            error  => Adriver::ErrorMessage::error_message($e),
            code   => $e->{code},
            method => 'set_subevents_counter',
            args   => \@args
        );
    }

    return $result;
}

sub get_site_slices
{
    validate_pos(@_, { type => OBJECT },
        { type => SCALAR, regex => qr/^\d+$/ }, # INT SiteID
    );
    my ($self, @args) = @_;

    my $result;
    eval { $result = $self->{client}->get_site_slices(@args); };
    if (my $e = Adriver::DBI::Exceptions::DBError->caught())
    {
        Adriver::DBI::Exceptions::Clients->throw(
            error  => Adriver::ErrorMessage::error_message($e),
            code   => $e->{code},
            method => 'get_site_slices',
            args   => \@args
        );
    }

    return $result;
}

sub get_site_ids
{
    validate_pos(@_, { type => OBJECT },
        { type => SCALAR, regex => qr/^\d+$/ }, # INT SiteID
    );
    my ($self, @args) = @_;

    my $result;
    eval { $result = $self->{client}->get_site_ids(@args); };
    if (my $e = Adriver::DBI::Exceptions::DBError->caught())
    {
        Adriver::DBI::Exceptions::Clients->throw(
            error  => Adriver::ErrorMessage::error_message($e),
            code   => $e->{code},
            method => 'get_site_ids',
            args   => \@args
        );
    }

    return $result;
}

sub get_publisher_slices
{
    validate_pos(@_, { type => OBJECT },
        { type => SCALAR, regex => qr/^\d+$/ }, # INT PublisherID
    );
    my ($self, @args) = @_;

    my $result;
    eval { $result = $self->{client}->get_publisher_slices(@args); };
    if (my $e = Adriver::DBI::Exceptions::DBError->caught())
    {
        Adriver::DBI::Exceptions::Clients->throw(
            error  => Adriver::ErrorMessage::error_message($e),
            code   => $e->{code},
            method => 'get_publisher_slices',
            args   => \@args
        );
    }

    return $result;
}

sub get_publisher_ids
{
    validate_pos(@_, { type => OBJECT },
        { type => SCALAR, regex => qr/^\d+$/ }, # INT PublisherID
    );
    my ($self, @args) = @_;

    my $result;
    eval { $result = $self->{client}->get_publisher_ids(@args); };
    if (my $e = Adriver::DBI::Exceptions::DBError->caught())
    {
        Adriver::DBI::Exceptions::Clients->throw(
            error  => Adriver::ErrorMessage::error_message($e),
            code   => $e->{code},
            method => 'get_publisher_ids',
            args   => \@args
        );
    }

    return $result;
}

sub get_aa_slices
{
    validate_pos(@_, { type => OBJECT },
        { type => SCALAR, regex => qr/^\d+$/ }, # INT AAID
    );
    my ($self, @args) = @_;

    my $result;
    eval { $result = $self->{client}->get_aa_slices(@args); };
    if (my $e = Adriver::DBI::Exceptions::DBError->caught())
    {
        Adriver::DBI::Exceptions::Clients->throw(
            error  => Adriver::ErrorMessage::error_message($e),
            code   => $e->{code},
            method => 'get_aa_slices',
            args   => \@args
        );
    }

    return $result;
}

sub get_aa_ids
{
    validate_pos(@_, { type => OBJECT },
        { type => SCALAR, regex => qr/^\d+$/ }, # INT AAID
    );
    my ($self, @args) = @_;

    my $result;
    eval { $result = $self->{client}->get_aa_ids(@args); };
    if (my $e = Adriver::DBI::Exceptions::DBError->caught())
    {
        Adriver::DBI::Exceptions::Clients->throw(
            error  => Adriver::ErrorMessage::error_message($e),
            code   => $e->{code},
            method => 'get_aa_ids',
            args   => \@args
        );
    }

    return $result;
}

sub get_ad_slices
{
    validate_pos(@_, { type => OBJECT },
        { type => SCALAR, regex => qr/^\d+$/ }, # INT ADID
    );
    my ($self, @args) = @_;

    my $result;
    eval { $result = $self->{client}->get_ad_slices(@args); };
    if (my $e = Adriver::DBI::Exceptions::DBError->caught())
    {
        Adriver::DBI::Exceptions::Clients->throw(
            error  => Adriver::ErrorMessage::error_message($e),
            code   => $e->{code},
            method => 'get_ad_slices',
            args   => \@args
        );
    }

    return $result;
}

sub get_ad_ids
{
    validate_pos(@_, { type => OBJECT },
        { type => SCALAR, regex => qr/^\d+$/ }, # INT ADID
    );
    my ($self, @args) = @_;

    my $result;
    eval { $result = $self->{client}->get_ad_ids(@args); };
    if (my $e = Adriver::DBI::Exceptions::DBError->caught())
    {
        Adriver::DBI::Exceptions::Clients->throw(
            error  => Adriver::ErrorMessage::error_message($e),
            code   => $e->{code},
            method => 'get_ad_ids',
            args   => \@args
        );
    }

    return $result;
}

sub get_pool_slices
{
    validate_pos(@_, { type => OBJECT },
        { type => SCALAR, regex => qr/^\d+$/ }, # INT PoolID
    );
    my ($self, @args) = @_;

    my $result;
    eval { $result = $self->{client}->get_pool_slices(@args); };
    if (my $e = Adriver::DBI::Exceptions::DBError->caught())
    {
        Adriver::DBI::Exceptions::Clients->throw(
            error  => Adriver::ErrorMessage::error_message($e),
            code   => $e->{code},
            method => 'get_pool_slices',
            args   => \@args
        );
    }

    return $result;
}

sub get_pool_ids
{
    validate_pos(@_, { type => OBJECT },
        { type => SCALAR, regex => qr/^\d+$/ }, # INT PoolID
    );
    my ($self, @args) = @_;

    my $result;
    eval { $result = $self->{client}->get_pool_ids(@args); };
    if (my $e = Adriver::DBI::Exceptions::DBError->caught())
    {
        Adriver::DBI::Exceptions::Clients->throw(
            error  => Adriver::ErrorMessage::error_message($e),
            code   => $e->{code},
            method => 'get_pool_ids',
            args   => \@args
        );
    }

    return $result;
}

sub get_network_slices
{
    validate_pos(@_, { type => OBJECT },
        { type => SCALAR, regex => qr/^\d+$/ }, # INT NetworkID
        { type => SCALAR, regex => qr/^\d+$/ }, # INT NetworkType
    );
    my ($self, @args) = @_;

    my $result;
    eval { $result = $self->{client}->get_network_slices(@args); };
    if (my $e = Adriver::DBI::Exceptions::DBError->caught())
    {
        Adriver::DBI::Exceptions::Clients->throw(
            error  => Adriver::ErrorMessage::error_message($e),
            code   => $e->{code},
            method => 'get_network_slices',
            args   => \@args
        );
    }

    return $result;
}

sub get_network_ids
{
    validate_pos(@_, { type => OBJECT },
        { type => SCALAR, regex => qr/^\d+$/ }, # INT NetworkID
        { type => SCALAR, regex => qr/^\d+$/ }, # INT NetworkType
    );
    my ($self, @args) = @_;

    my $result;
    eval { $result = $self->{client}->get_network_ids(@args); };
    if (my $e = Adriver::DBI::Exceptions::DBError->caught())
    {
        Adriver::DBI::Exceptions::Clients->throw(
            error  => Adriver::ErrorMessage::error_message($e),
            code   => $e->{code},
            method => 'get_network_ids',
            args   => \@args
        );
    }

    return $result;
}

sub get_rep_ad_slices
{
    validate_pos(@_, { type => OBJECT },
        { type => SCALAR, regex => qr/^\d+$/ }, # INT Rep_ADID
        { type => SCALAR, regex => qr/^\d+$/ }, # INT NetworkType
    );
    my ($self, @args) = @_;

    my $result;
    eval { $result = $self->{client}->get_rep_ad_slices(@args); };
    if (my $e = Adriver::DBI::Exceptions::DBError->caught())
    {
        Adriver::DBI::Exceptions::Clients->throw(
            error  => Adriver::ErrorMessage::error_message($e),
            code   => $e->{code},
            method => 'get_rep_ad_slices',
            args   => \@args
        );
    }

    return $result;
}

sub get_rep_ad_ids
{
    validate_pos(@_, { type => OBJECT },
        { type => SCALAR, regex => qr/^\d+$/ }, # INT Rep_ADID
        { type => SCALAR, regex => qr/^\d+$/ }, # INT NetworkType
    );
    my ($self, @args) = @_;

    my $result;
    eval { $result = $self->{client}->get_rep_ad_ids(@args); };
    if (my $e = Adriver::DBI::Exceptions::DBError->caught())
    {
        Adriver::DBI::Exceptions::Clients->throw(
            error  => Adriver::ErrorMessage::error_message($e),
            code   => $e->{code},
            method => 'get_rep_ad_ids',
            args   => \@args
        );
    }

    return $result;
}

sub get_top_exposures
{
    validate_pos(@_, { type => OBJECT },
        { type => HASHREF },                    # HASHREF HourlyCounterHashRefMask
        { type => SCALAR, regex => qr/^\d+$/ }, # INT Number
        { type => ARRAYREF, optional => 1 },    # ARRAYREF of INT SliceIDs
    );
    my ($self, @args) = @_;

    my $result;
    eval { $result = $self->{client}->get_top_exposures(@args); };
    if (my $e = Adriver::DBI::Exceptions::DBError->caught())
    {
        Adriver::DBI::Exceptions::Clients->throw(
            error  => Adriver::ErrorMessage::error_message($e),
            code   => $e->{code},
            method => 'get_top_exposures',
            args   => \@args
        );
    }

    return $result;
}

sub get_top_clicks
{
    validate_pos(@_, { type => OBJECT },
        { type => HASHREF },                    # HASHREF HourlyCounterHashRefMask
        { type => SCALAR, regex => qr/^\d+$/ }, # INT Number
        { type => ARRAYREF, optional => 1 },    # ARRAYREF of INT SliceIDs
    );
    my ($self, @args) = @_;

    my $result;
    eval { $result = $self->{client}->get_top_clicks(@args); };
    if (my $e = Adriver::DBI::Exceptions::DBError->caught())
    {
        Adriver::DBI::Exceptions::Clients->throw(
            error  => Adriver::ErrorMessage::error_message($e),
            code   => $e->{code},
            method => 'get_top_clicks',
            args   => \@args
        );
    }

    return $result;
}

sub get_ex
{
    validate_pos(@_, { type => OBJECT },
        { type => ARRAYREF, optional => 1 }, # ARRAYREF of BOOL Flags
        { type => HASHREF },                 # HASHREF SliceHashRefMask
        { type => ARRAYREF, optional => 1 }, # ARRAYREF of INT SliceIDs
    );
    my ($self, @args) = @_;

    my $result;
    eval { $result = $self->{client}->get_ex(@args); };
    if (my $e = Adriver::DBI::Exceptions::DBError->caught())
    {
        Adriver::DBI::Exceptions::Clients->throw(
            error  => Adriver::ErrorMessage::error_message($e),
            code   => $e->{code},
            method => 'get_ex',
            args   => \@args
        );
    }

    return $result;
}

sub rotate_hourly
{
    validate_pos(@_, { type => OBJECT });
    my ($self, @args) = @_;

    my $result;
    eval { $result = $self->{client}->rotate_hourly(@args); };
    if (my $e = Adriver::DBI::Exceptions::DBError->caught())
    {
        Adriver::DBI::Exceptions::Clients->throw(
            error  => Adriver::ErrorMessage::error_message($e),
            code   => $e->{code},
            method => 'rotate_hourly',
            args   => \@args
        );
    }

    return $result;
}

sub rotate_daily
{
    validate_pos(@_, { type => OBJECT });
    my ($self, @args) = @_;

    my $result;
    eval { $result = $self->{client}->rotate_daily(@args); };
    if (my $e = Adriver::DBI::Exceptions::DBError->caught())
    {
        Adriver::DBI::Exceptions::Clients->throw(
            error  => Adriver::ErrorMessage::error_message($e),
            code   => $e->{code},
            method => 'rotate_daily',
            args   => \@args
        );
    }

    return $result;
}

sub rotate_weekly
{
    validate_pos(@_, { type => OBJECT });
    my ($self, @args) = @_;

    my $result;
    eval { $result = $self->{client}->rotate_weekly(@args); };
    if (my $e = Adriver::DBI::Exceptions::DBError->caught())
    {
        Adriver::DBI::Exceptions::Clients->throw(
            error  => Adriver::ErrorMessage::error_message($e),
            code   => $e->{code},
            method => 'rotate_weekly',
            args   => \@args
        );
    }

    return $result;
}

1;


__END__


=head1 NAME

    Adriver::DBI::Clients::SliceClient - this module provides methods to work with
    Adriver slices database.


=head1 DESCRIPTION

    This module is inherited from Adriver::DBI::Clients::BaseID class.


=head1 SYNOPSIS

    use Adriver::DBI;
    use Adriver::DatabaseConnect::Adriver;
    use Adriver::Exceptions;

    my $host = 'f2.x';
    my $port = 16000;

    eval
    {
        my $dbh = Adriver::DBI->new( Adriver::DatabaseConnect::Adriver->new({host => $host, port => $port}) );

        my $slice_id = 432016;
        my $slice = $dbh->Slice->get($slice_id);
        print Dumper($slice);

        my $db_info = $dbh->Slice->GetCaps();
        print Dumper($db_info);

        my $ids = $dbh->Slice->getids();
        print Dumper($ids);

        my @ids = (423146, 423151, 423159);
        my $slices = $dbh->Slice->getlist(\@ids);
        print Dumper($slices);

        $dbh->Slice->set($slice);

        my $site_id = 106437;
        my $slices = $dbh->Slice->get_site_slices($site_id);

        my $slice_ids = $dbh->Slice->get_site_ids($site_id);

        my $publisher_id = 103853;
        my $slices = $dbh->Slice->get_publisher_slices($publisher_id);
    };

    if (my $e = Exception::Class->caught('Adriver::Exceptions'))
    {
        die "Caught Adriver::Exceptions: '", $e->error, "'\n", $e->trace->as_string, "\n";
    }
    elsif ($e = Exception::Class->caught('Exception::Class::Base'))
    {
        die "Caught unknown exception: '", $e->error, "'\n", $e->trace->as_string, "\n";
    }
    elsif ($e = Exception::Class->caught)
    {
        die "$e";
    }


=head1 INHERITED OBJECT INTERFACE

=head2 get($slice_id) : $SliceHashRef

    Get certain slice from database by it's identifier.

B<slice_id>

    This is the integer identifier of slice.

B<SliceHashRef>

    This is a hash reference with next structure:

    SliceHashRef =>
    {
        'sliceID'          => INT
        'siteID'           => INT
        'adID'             => INT
        'rep_adID'         => INT
        'pubID'            => INT
        'aaID'             => INT
        'poolID'           => INT
        'siteZoneID'       => INT
        'networkID'        => INT
        'networkType'      => INT
        'sliceType'        => INT
        'burstMode'        => BOOL
        'enable'           => BOOL
        'enables'          => ARRAYREF(32) BOOL
        'priority'         => INT
        'percent'          => INT
        'bannerNumber'     => INT
        'bannerType'       => INT
        'pageZone'         => INT
        'startDate'        => INT
        'finishDate'       => INT
        'maxshows'         => INT
        'maxclicks'        => INT
        'maxsubevents'     => ARRAYREF(10) INT
        'day_maxshows'     => INT
        'day_maxclicks'    => INT
        'day_maxsubevents' => ARRAYREF(10) INT
        'exposures'        => HourlyCounterHashRef
        'clicks'           => HourlyCounterHashRef
        'subevents'        => ARRAYREF(10) CounterHashRef
        'dayHour'          => ARRAYREF(7) of ARRAYREF(24) BOOL
        'dayMonth'         => ARRAYREF (31) BOOL
        'geoMask'          => ARRAYREF(1024) BOOL
        'balanceSwitch'    => ARRAYREF(32) BOOL (?INT)
        'balanceCounters'  => ARRAYREF(32) BOOL (?INT)
        'TZConversion'     => INT (?BOOL)
        'assign'           => INT (?BOOL)
        'rejects'          => CounterHashRef
    }

    where

    HourlyCounterHashRef =>
    {
        'today'     => INT
        'yesterday' => INT
        'week'      => INT
        'last_week' => INT
        'total'     => INT
        'last_hour' => INT
    }

    and

    CounterHashRef =>
    {
        'today'     => INT
        'yesterday' => INT
        'week'      => INT
        'last_week' => INT
        'total'     => INT
    }

B<Exceptions>

    Adriver::DBI::Exceptions::ParamsValidation
    Adriver::DBI::Exceptions::Clients

=head2 getids() : $slice_ids

    This method returns a list of all slice identifiers from database.

B<slice_ids>

    This is the array reference with obtained slice identifiers.

B<Exceptions>

    Adriver::DBI::Exceptions::ParamsValidation
    Adriver::DBI::Exceptions::Clients

=head2 getlist(\@slice_ids) : ARRAYREF of $SliceHashRef

    This method returns a list of slices from database by their identifiers.

B<slice_ids>

    This is the array reference with slice identifiers you want to get.

B<SliceHashRef>

    This is the same hash reference as described in get() method.

B<Exceptions>

    Adriver::DBI::Exceptions::ParamsValidation
    Adriver::DBI::Exceptions::Clients

=head2 set($SliceHashRef) : undef

    This method updates given slice in database.

B<SliceHashRef>

    This is the same hash reference as described in get() method.

B<Exceptions>

    Adriver::DBI::Exceptions::ParamsValidation
    Adriver::DBI::Exceptions::Clients

=head2 add($SliceHashRef) : $slice_id

    This method adds the new slice in database and returns it's identifier.

B<SliceHashRef>

    This is the same hash reference as described in get() method.

B<slice_id>

    This is the integer identifier of added slice.

B<Exceptions>

    Adriver::DBI::Exceptions::ParamsValidation
    Adriver::DBI::Exceptions::Clients

=head2 remove($slice_id) : undef

    This method removes slice from database by it's identifier.

B<slice_id>

    This is the slice identifier you want to remove.

B<Exceptions>

    Adriver::DBI::Exceptions::ParamsValidation
    Adriver::DBI::Exceptions::Clients


=head1 OBJECT INTERFACE

=head2 exposure($slice_id) : 1

    This method icrements the number of slice exposures.
    DONOT USE THIS METHODS IN IFACES! SPECIAL SYSTEM CALLS!

B<slice_id>

    This is the slice identifier which exposures counter you want to increase.

B<Exceptions>

    Adriver::DBI::Exceptions::ParamsValidation
    Adriver::DBI::Exceptions::Clients

=head2 click($slice_id) : 1

    This method icrements the number of slice clicks.
    DONOT USE THIS METHODS IN IFACES! SPECIAL SYSTEM CALLS!

B<slice_id>

    This is the slice identifier which clicks counter you want to increase.

B<Exceptions>

    Adriver::DBI::Exceptions::ParamsValidation
    Adriver::DBI::Exceptions::Clients

=head2 subevent($slice_id, $subevent_type) : 1

    This method icrements the number of slice subevents.
    DONOT USE THIS METHODS IN IFACES! SPECIAL SYSTEM CALLS!

B<slice_id>

    This is the slice identifier which clicks counter you want to increase.

B<subevent_type>

    This is the subevent type.

B<Exceptions>

    Adriver::DBI::Exceptions::ParamsValidation
    Adriver::DBI::Exceptions::Clients

=head2 set_exposures_counter($slice_id, $HourlyCounterHashRef) : 1

    This method sets the counter of slice exposures.

B<slice_id>

    This is the slice identifier which exposures counter you want to set.

B<HourlyCounterHashRef>

    This is the same hash reference as described in get() method.

B<Exceptions>

    Adriver::DBI::Exceptions::ParamsValidation
    Adriver::DBI::Exceptions::Clients

=head2 set_clicks_counter($slice_id, $HourlyCounterHashRef) : 1

    This method sets the counter of slice clicks.

B<slice_id>

    This is the slice identifier which clicks counter you want to set.

B<HourlyCounterHashRef>

    This is the same hash reference as described in get() method.

B<Exceptions>

    Adriver::DBI::Exceptions::ParamsValidation
    Adriver::DBI::Exceptions::Clients

=head2 set_subevents_counter($slice_id, $subevent_type, $CounterHashRef) : 1

    This method sets the subevent counter of slice. Subevent specified by it's type.

B<slice_id>

    This is the slice identifier which subevent counter you want to set.

B<subevent_type>

    This is the subevent type.

B<CounterHashRef>

    This is the same hash reference as described in get() method.

B<Exceptions>

    Adriver::DBI::Exceptions::ParamsValidation
    Adriver::DBI::Exceptions::Clients

=head2 get_site_slices($site_id) : ARRAYREF of $SliceHashRef

    This method returns a list of slices for certain site.

B<site_id>

    This is the site identifier which slices you want to get.

B<SliceHashRef>

    This is the same hash reference as described in get() method.

B<Exceptions>

    Adriver::DBI::Exceptions::ParamsValidation
    Adriver::DBI::Exceptions::Clients

=head2 get_site_ids($site_id) : ARRAYREF of $slice_id

    This method returns a list of slice identifiers for certain site.

B<site_id>

    This is the site identifier which slice identifiers you want to get.

B<slice_id>

    This is the slice identifier.

B<Exceptions>

    Adriver::DBI::Exceptions::ParamsValidation
    Adriver::DBI::Exceptions::Clients

=head2 get_publisher_slices($publisher_id) : ARRAYREF of $SliceHashRef

    This method returns a list of slices for certain publisher.

B<publisher_id>

    This is the publisher identifier which slices you want to get.

B<SliceHashRef>

    This is the same hash reference as described in get() method.

B<Exceptions>

    Adriver::DBI::Exceptions::ParamsValidation
    Adriver::DBI::Exceptions::Clients

=head2 get_publisher_ids($publisher_id) : ARRAYREF of $slice_id

    This method returns a list of slice identifiers for certain publisher.

B<publisher_id>

    This is the publisher identifier which slice identifiers you want to get.

B<slice_id>

    This is the slice identifier.

B<Exceptions>

    Adriver::DBI::Exceptions::ParamsValidation
    Adriver::DBI::Exceptions::Clients

=head2 get_aa_slices($aa_id) : ARRAYREF of $SliceHashRef

    This method returns a list of slices for certain advertizing agency.

B<aa_id>

    This is the agency identifier which slices you want to get.

B<SliceHashRef>

    This is the same hash reference as described in get() method.

B<Exceptions>

    Adriver::DBI::Exceptions::ParamsValidation
    Adriver::DBI::Exceptions::Clients

=head2 get_aa_ids($aa_id) : ARRAYREF of $slice_id

    This method returns a list of slice identifiers for certain advertizing agency.

B<aa_id>

    This is the agency identifier which slice identifiers you want to get.

B<slice_id>

    This is the slice identifier.

B<Exceptions>

    Adriver::DBI::Exceptions::ParamsValidation
    Adriver::DBI::Exceptions::Clients

=head2 get_ad_slices($ad_id) : ARRAYREF of $SliceHashRef

    This method returns a list of slices for certain advertizing company.

B<ad_id>

    This is the company identifier which slices you want to get.

B<SliceHashRef>

    This is the same hash reference as described in get() method.

B<Exceptions>

    Adriver::DBI::Exceptions::ParamsValidation
    Adriver::DBI::Exceptions::Clients

=head2 get_ad_ids($ad_id) : ARRAYREF of $slice_id

    This method returns a list of slice identifiers for certain advertizing company.

B<ad_id>

    This is the company identifier which slice identifiers you want to get.

B<slice_id>

    This is the slice identifier.

B<Exceptions>

    Adriver::DBI::Exceptions::ParamsValidation
    Adriver::DBI::Exceptions::Clients

=head2 get_pool_slices($pool_id) : ARRAYREF of $SliceHashRef

    This method returns a list of slices for certain pool.

B<pool_id>

    This is the pool identifier which slices you want to get.

B<SliceHashRef>

    This is the same hash reference as described in get() method.

B<Exceptions>

    Adriver::DBI::Exceptions::ParamsValidation
    Adriver::DBI::Exceptions::Clients

=head2 get_pool_ids($pool_id) : ARRAYREF of $slice_id

    This method returns a list of slice identifiers for certain pool.

B<pool_id>

    This is the pool identifier which slice identifiers you want to get.

B<slice_id>

    This is the slice identifier.

B<Exceptions>

    Adriver::DBI::Exceptions::ParamsValidation
    Adriver::DBI::Exceptions::Clients

=head2 get_network_slices($network_id, $network_type) : ARRAYREF of $SliceHashRef

    This method returns a list of slices for certain network and network type.

B<network_id>

    This is the network identifier which slices you want to get.

B<network_type>

    This is the network type.

B<SliceHashRef>

    This is the same hash reference as described in get() method.

B<Exceptions>

    Adriver::DBI::Exceptions::ParamsValidation
    Adriver::DBI::Exceptions::Clients

=head2 get_network_ids($network_id, $network_type) : ARRAYREF of $slice_id

    This method returns a list of slice identifiers for certain network and network type.

B<network_id>

    This is the network identifier which slice identifiers you want to get.

B<network_type>

    This is the network type.

B<slice_id>

    This is the slice identifier.

B<Exceptions>

    Adriver::DBI::Exceptions::ParamsValidation
    Adriver::DBI::Exceptions::Clients

=head2 get_rep_ad_slices($rep_ad_id, $network_type) : ARRAYREF of $SliceHashRef

    This method returns a list of slices for certain $rep_ad_id with $network_type.

B<network_type>

    This is the network type.

B<SliceHashRef>

    This is the same hash reference as described in get() method.

B<Exceptions>

    Adriver::DBI::Exceptions::ParamsValidation
    Adriver::DBI::Exceptions::Clients

=head2 get_rep_ad_ids($rep_ad_id, $network_type) : ARRAYREF of $slice_id

    This method returns a list of slice identifiers for certain $rep_ad_id with $network_type.

B<network_type>

    This is the network type.

B<slice_id>

    This is the slice identifier.

B<Exceptions>

    Adriver::DBI::Exceptions::ParamsValidation
    Adriver::DBI::Exceptions::Clients

=head2 get_top_exposures($HourlyCounterHashRefMask, $number[, ARRAYREF of INT SliceIDs]) : ARRAYREF of $SliceHashRef

    This method returns the top-list of slices sorted by exposures counter.
    If the list of slice identifiers is specified, procedure gets top-list from them.

B<HourlyCounterHashRefMask>

    This is a hash reference. Procedure gets top-list for counter, specified in HourlyCounterHashRefMask
    ("counter" => 1). Its highly recommended to set to 1 only one counter, if you set many, procedure
    will use only one anyway. The structure of HourlyCounterHashRefMask specified below:

    HourlyCounterHashRefMask =>
    {
        'today'     => BOOL
        'yesterday' => BOOL
        'week'      => BOOL
        'last_week' => BOOL
        'total'     => BOOL
        'last_hour' => BOOL
    }

B<number>

    This is the number of elements in the top-list.

B<SliceHashRef>

    This is the same hash reference as described in get() method.

B<Exceptions>

    Adriver::DBI::Exceptions::ParamsValidation
    Adriver::DBI::Exceptions::Clients

=head2 get_top_clicks($HourlyCounterHashRefMask, $number[, ARRAYREF of INT SliceIDs]) : ARRAYREF of $SliceHashRef

    This method returns the top-list of slices sorted by clicks counter.
    If list of the sclice identifiers is specified, procedure gets top-list from this list.

B<HourlyCounterHashRefMask>

    This is a hash reference. Procedure gets top-list for counter, specified in HourlyCounterHashRefMask
    ("counter" => 1). Its highly recommended to set to 1 only one counter, if you set many, procedure will
    use only one anyway. The structure of HourlyCounterHashRefMask specified below:

    HourlyCounterHashRefMask =>
    {
        'today'     => BOOL
        'yesterday' => BOOL
        'week'      => BOOL
        'last_week' => BOOL
        'total'     => BOOL
    }

B<number>

    This is the number of elements in the top-list.

B<SliceHashRef>

    This is the same hash reference as described in get() method.

B<Exceptions>

    Adriver::DBI::Exceptions::ParamsValidation
    Adriver::DBI::Exceptions::Clients

=head2 get_ex(ARRAYREF of BOOL Flags, $SliceHashRefMask[, ARRAYREF of INT SliceIDs]) : ARRAYREF of SliceHashRef

    This method gets slices appropriate to mask SliceHashRefMask, but only for fields, checked
    in flags. (and if field in mask == 0 and checked in flags, it compared but not skipped).
    If the list of slice identifiers is specified, procedure makes search in it.

B<SliceHashRefMask>

    The structure of SiteHashRefMask specified below:

    SliceHashRefMask =>
    {
        'siteID'       => INT
        'siteZoneID'   => INT
        'pageZone'     => INT
        'sliceType'    => INT
        'startDate'    => INT
        'finishDate'   => INT
        'bannerType'   => INT
        'pubID'        => INT
        'aaID'         => INT
        'adID'         => INT
        'percent'      => INT
        'priority'     => INT
        'maxshows'     => INT
        'day_maxshows' => INT
        'assign'       => INT
        'enable'       => BOOL
        'networkType'  => INT
        'networkID'    => INT
        'rep_adID'     => INT
        'poolID'       => INT
    }

B<SliceHashRef>

    This is the same hash reference as described in get() method.

B<Exceptions>

    Adriver::DBI::Exceptions::ParamsValidation
    Adriver::DBI::Exceptions::Clients

=head2 rotate_hourly() : undef

    This procedure rotates hourly counters.
    DONOT USE THIS METHODS IN IFACES! SPECIAL SYSTEM CALLS!

B<Exceptions>

    Adriver::DBI::Exceptions::ParamsValidation
    Adriver::DBI::Exceptions::Clients

=head2 rotate_daily() : undef

    This procedure rotates daily counters.
    DONOT USE THIS METHODS IN IFACES! SPECIAL SYSTEM CALLS!

B<Exceptions>

    Adriver::DBI::Exceptions::ParamsValidation
    Adriver::DBI::Exceptions::Clients

=head2 rotate_weekly() : undef

    This procedure rotates weekly counters.
    DONOT USE THIS METHODS IN IFACES! SPECIAL SYSTEM CALLS!

B<Exceptions>

    Adriver::DBI::Exceptions::ParamsValidation
    Adriver::DBI::Exceptions::Clients


=head1 SEE ALSO

    Adriver::DBI::Clients::BaseID
    Adriver::DBI::Exceptions

