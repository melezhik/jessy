package Adriver::DBI::Clients::GeoStatClient;

use strict;
our $VERSION = '0.0300';
use Carp;
use Params::Validate qw(:all);
use base qw ( Adriver::DBI::Clients::Base );

validation_options(on_fail => sub { Adriver::DBI::Exceptions::ParamsValidation->throw( error => $_[0]); } );

sub package { 'RLE::GeoStatClient' }

#### Functions
#
## Get, set, add or remove GeoStat
#
# (HASHREF GeoStatHashRef) get(INT SiteID)
# (INT 1) set(HASHREF GeoStatHashRef)
# (INT 1) add(INT SiteID)
# (INT 1) remove(INT SiteID)
#
## Increment counter for SiteID and Geo (Geo - [0..31])
#
# (INT 1) increment(INT SiteID, INT Geo)
#
## Rotate GeoStat
## DONOT USE THIS METHODS IN IFACES! SPECIAL SYSTEM CALLS!
#
# (void) rotate()
#
#### Input Data Info
#
# GeoStatHashRef =>
# {
#     'sid'           => INT
#     'exp_yesterday' => ARRAYREF(32) INT
#     'exp_today'     => ARRAYREF(32) INT
# }
#
####

sub get
{
    validate_pos(@_, { type => OBJECT },
        { type => SCALAR, regex => qr/^\d+$/ }, # INT SiteID
    );
    my ($self, @args) = @_;

    my $result;
    eval { $result = $self->{client}->get(@args); };

    if (my $e = Adriver::DBI::Exceptions::DBError->caught())
    {
        Adriver::DBI::Exceptions::Clients->throw(
            error  => Adriver::ErrorMessage::error_message($e),
            code   => $e->{code},
            method => 'get',
            args   => \@args
        );
    }

    return $result;
}

sub set
{
    validate_pos(@_, { type => OBJECT },
        { type => HASHREF }, # HASHREF GeoStatHashRef
    );
    my ($self, @args) = @_;

    my $result;
    eval { $result = $self->{client}->set(@args); };

    if (my $e = Adriver::DBI::Exceptions::DBError->caught())
    {
        Adriver::DBI::Exceptions::Clients->throw(
            error  => Adriver::ErrorMessage::error_message($e),
            code   => $e->{code},
            method => 'set',
            args   => \@args
        );
    }

    return $result;
}

sub add
{
    validate_pos(@_, { type => OBJECT },
        { type => SCALAR, regex => qr/^\d+$/ }, # INT SiteID
    );
    my ($self, @args) = @_;

    my $result;
    eval { $result = $self->{client}->add(@args); };

    if (my $e = Adriver::DBI::Exceptions::DBError->caught())
    {
        Adriver::DBI::Exceptions::Clients->throw(
            error  => Adriver::ErrorMessage::error_message($e),
            code   => $e->{code},
            method => 'add',
            args   => \@args
        );
    }

    return $result;
}

sub remove
{
    validate_pos(@_, { type => OBJECT },
        { type => SCALAR, regex => qr/^\d+$/ }, # INT SiteID
    );
    my ($self, @args) = @_;

    my $result;
    eval { $result = $self->{client}->remove(@args); };

    if (my $e = Adriver::DBI::Exceptions::DBError->caught())
    {
        Adriver::DBI::Exceptions::Clients->throw(
            error  => Adriver::ErrorMessage::error_message($e),
            code   => $e->{code},
            method => 'remove',
            args   => \@args
        );
    }

    return $result;
}

sub increment
{
    validate_pos(@_, { type => OBJECT },
        { type => SCALAR, regex => qr/^\d+$/ }, # INT SiteID
        { type => SCALAR, regex => qr/^\d+$/ }, # INT Geo
    );
    my ($self, @args) = @_;

    my $result;
    eval { $result = $self->{client}->increment(@args); };

    if (my $e = Adriver::DBI::Exceptions::DBError->caught())
    {
        Adriver::DBI::Exceptions::Clients->throw(
            error  => Adriver::ErrorMessage::error_message($e),
            code   => $e->{code},
            method => 'increment',
            args   => \@args
        );
    }

    return $result;
}

sub rotate
{
    validate_pos(@_, { type => OBJECT });
    my ($self, @args) = @_;

    my $result;
    eval { $result = $self->{client}->rotate(@args); };

    if (my $e = Adriver::DBI::Exceptions::DBError->caught())
    {
        Adriver::DBI::Exceptions::Clients->throw(
            error  => Adriver::ErrorMessage::error_message($e),
            code   => $e->{code},
            method => 'rotate',
            args   => \@args
        );
    }

    return $result;
}

1;


__END__


=head1 NAME

    Adriver::DBI::Clients::GeoStatClient - this module provides methods to work with
    Adriver GeoStat database.


=head1 DESCRIPTION

    Using this module you can work with database of geographical statistics.
    This module is inherited from Adriver::DBI::Clients::Base class.


=head1 SYNOPSIS

    use Adriver::DBI;
    use Adriver::DatabaseConnect::Adriver;
    use Adriver::Exceptions;

    my $host = 'f2.x';
    my $port = 16000;

    eval
    {
        my $dbh = Adriver::DBI->new( Adriver::DatabaseConnect::Adriver->new({host => $host, port => $port}) );

        my $site_id = 15031;
        my $geo_stat = $dbh->GeoStat->get($site_id);
        print Dumper($geo_stat);

        my $db_info = $dbh->GeoStat->GetCaps();
        print Dumper($db_info);
    };

    if (my $e = Exception::Class->caught('Adriver::Exceptions'))
    {
        die "Caught Adriver::Exceptions: '", $e->error, "\n", $e->trace->as_string, "\n";
    }
    elsif ($e = Exception::Class->caught('Exception::Class::Base'))
    {
        die "Caught unknown exception: '", $e->error, "\n", $e->trace->as_string, "\n";
    }
    elsif ($e = Exception::Class->caught)
    {
        die "$e";
    }


=head1 OBJECT INTERFACE

=head2 get($site_id) : $GeoStatHashRef

    Get statistics for certain site by it's identifier.

B<site_id>

    Integer identifier of the site.

B<GeoStatHashRef>

    This is a hash reference with next structure:

    GeoStatHashRef =>
    {
        'sid'           => INT
        'exp_yesterday' => ARRAYREF(32) INT
        'exp_today'     => ARRAYREF(32) INT
    }

B<Exceptions>

    Adriver::DBI::Exceptions::ParamsValidation
    Adriver::DBI::Exceptions::Clients

=head2 set($GeoStatHashRef) : 1

    This method updates given GeoStat object in database.

B<GeoStatHashRef>

    This is the same hash reference as described in get() method.

B<Exceptions>

    Adriver::DBI::Exceptions::ParamsValidation
    Adriver::DBI::Exceptions::Clients

=head2 add($site_id) : 1

    This method adds the new GeoStat object for specified site.

B<site_id>

    This is the integer identifier of site.

B<Exceptions>

    Adriver::DBI::Exceptions::ParamsValidation
    Adriver::DBI::Exceptions::Clients

=head2 remove($site_id) : 1

    This method removes GeoStat object for site from database.

B<site_id>

    This is the site identifier witch geographical statistics you want to remove.

B<Exceptions>

    Adriver::DBI::Exceptions::ParamsValidation
    Adriver::DBI::Exceptions::Clients

=head2 increment($site_id, $geo_id) : 1

    This method increments counter for specified site and geo.

B<site_id>

    Site identifier.

B<geo_id>

    Geo identifier from the range [0..31].

B<Exceptions>

    Adriver::DBI::Exceptions::ParamsValidation
    Adriver::DBI::Exceptions::Clients

=head2 rotate() : undef

    This method rotates all geographical statistics.
    DONOT USE THIS METHODS IN IFACES! SPECIAL SYSTEM CALLS!

B<Exceptions>

    Adriver::DBI::Exceptions::ParamsValidation
    Adriver::DBI::Exceptions::Clients


=head1 SEE ALSO

    Adriver::DBI::Clients::Base
    Adriver::DBI::Exceptions

