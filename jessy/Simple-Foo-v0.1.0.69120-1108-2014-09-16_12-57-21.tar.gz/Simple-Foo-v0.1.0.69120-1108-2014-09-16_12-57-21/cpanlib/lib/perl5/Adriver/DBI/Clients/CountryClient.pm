package Adriver::DBI::Clients::CountryClient;

use strict;
our $VERSION = '0.0300';
use Carp;
use Params::Validate qw(:all);
use base qw ( Adriver::DBI::Clients::BaseID );

validation_options(on_fail => sub { Adriver::DBI::Exceptions::ParamsValidation->throw( error => $_[0]); } );

sub package { 'RLE::CountryClient' }

#### Generic BaseID Functions
#
# get(INT CountryID)
# getids()
# getlist(ARRAYREF of INT CountryIDs)
# set(HASHREF CountryHashRef)
# add(HASHREF CountryHashRef)
# remove(INT CountryID)
#
#### Other Functions
#
## Get Countries for mask CountryHashRefMask
## If element in mask == 0, this fileld not checked (always true)
#
# (ARRAYREF of CountryHashRef) get_list(HASHREF CountryHashRefMask)
#
#### Input Data Info
#
# CountryHashRefMask =>
# {
#     "CountryCfg_ID" => INT
#     "geoZone"       => INT
#     "Region_ID"     => INT
# }
#
# CountryHashRef =>
# {
#     'Country_ID'    => INT
#     'Country_Name'  => ARRAYREF(5) STRING
#     'Region_ID'     => INT
#     'geoZone'       => INT
#     'CountryCfg_ID' => INT
#     'CityCount'     => INT
# }
#
####

sub get_list
{
    validate_pos(@_, { type => OBJECT },
        { type => HASHREF }, # HASHREF CountryHashRefMask
    );
    my ($self, @args) = @_;

    my $result;
    eval { $result = $self->{client}->get_list(@args); };
    if (my $e = Adriver::DBI::Exceptions::DBError->caught())
    {
        Adriver::DBI::Exceptions::Clients->throw(
            error  => Adriver::ErrorMessage::error_message($e),
            code   => $e->{code},
            method => 'get_list',
            args   => \@args
        );
    }

    return $result;
}

1;

__END__


=head1 NAME

    Adriver::DBI::Clients::CountryClient - this module provides methods to work with
    Adriver countries database.


=head1 DESCRIPTION

    Using this module you can work with database of countries.
    This module is inherited from Adriver::DBI::Clients::BaseID class.


=head1 SYNOPSIS

    use Adriver::DBI;
    use Adriver::DatabaseConnect::Adriver;
    use Adriver::Exceptions;

    my $host = 'f2.x';
    my $port = 16000;

    eval
    {
        my $dbh = Adriver::DBI->new( Adriver::DatabaseConnect::Adriver->new({host => $host, port => $port}) );

        my $country_id = 3;
        my $country = $dbh->Country->get($country_id);
        print Dumper($country);

        my $db_info = $dbh->Country->GetCaps();
        print Dumper($db_info);

        my $ids = $dbh->Country->getids();
        print Dumper($ids);

        my @ids = (1, 2, 3);
        my $countries = $dbh->Country->getlist(\@ids);
        print Dumper($countries);
    };

    if (my $e = Exception::Class->caught('Adriver::Exceptions'))
    {
        die "Caught Adriver::Exceptions: '", $e->error, "\n", $e->trace->as_string, "\n";
    }
    elsif ($e = Exception::Class->caught('Exception::Class::Base'))
    {
        die "Caught unknown exception: '", $e->error, "\n", $e->trace->as_string, "\n";
    }
    elsif ($e = Exception::Class->caught)
    {
        die "$e";
    }


=head1 INHERITED OBJECT INTERFACE

=head2 get($county_id) : $CountryHashRef

    Get certain country from database by it's identifier.

B<country_id>

    Integer identifier of the country.

B<CountryHashRef>

    This is a hash reference with next structure:

    CountryHashRef =>
    {
        'Country_ID'    => INT
        'Country_Name'  => ARRAYREF(5) STRING
        'Region_ID'     => INT
        'geoZone'       => INT
        'CountryCfg_ID' => INT
        'CityCount'     => INT
    }

B<Exceptions>

    Adriver::DBI::Exceptions::ParamsValidation
    Adriver::DBI::Exceptions::Clients

=head2 getids() : $ids

    This method returns all countries identifiers stored in database.

B<ids>

    This is a array reference with getted identifiers.

B<Exceptions>

    Adriver::DBI::Exceptions::ParamsValidation
    Adriver::DBI::Exceptions::Clients

=head2 getlist($ids) : ARRAYREF of $CountryHashRef

    This method returns a list of countries from database by their identifiers.

B<ids>

    The array reference with countries identifiers you want to get.

B<CountryHashRef>

    This is the same hash reference as described in get() method.

B<Exceptions>

    Adriver::DBI::Exceptions::ParamsValidation
    Adriver::DBI::Exceptions::Clients

=head2 set($CountryHashRef) : undef

    This method updates given country in database.

B<CountryHashRef>

    This is the same hash reference as described in get() method.

B<Exceptions>

    Adriver::DBI::Exceptions::ParamsValidation
    Adriver::DBI::Exceptions::Clients

=head2 add($CountryHashRef) : $country_id

    This method adds the new country in database and returns it's identifier.

B<CounterHashRef>

    This is the same hash reference as described in get() method.

B<country_id>

    This is the integer identifier of added country.

B<Exceptions>

    Adriver::DBI::Exceptions::ParamsValidation
    Adriver::DBI::Exceptions::Clients

=head2 remove($country_id) : undef

    This method removes country from database by it's identifier.

B<country_id>

    This is the country identifier you want to remove.

B<Exceptions>

    Adriver::DBI::Exceptions::ParamsValidation
    Adriver::DBI::Exceptions::Clients


=head1 OBJECT INTERFACE

=head2 get_list($CountryHashRefMask) : ARRAYREF of CountryHashRef

    This method returns a list of countries appropriated to mask CountryHashRefMask.

B<CountryHashRefMask>

    This is a hash reference with next structure:

    CountryHashRefMask =>
    {
        "CountryCfg_ID" => INT
        "geoZone"       => INT
        "Region_ID"     => INT
    }

B<CountryHashRef>

    This is the same hash reference as described in get() method.

B<Exceptions>

    Adriver::DBI::Exceptions::ParamsValidation
    Adriver::DBI::Exceptions::Clients


=head1 SEE ALSO

    Adriver::DBI::Clients::BaseID
    Adriver::DBI::Exceptions

