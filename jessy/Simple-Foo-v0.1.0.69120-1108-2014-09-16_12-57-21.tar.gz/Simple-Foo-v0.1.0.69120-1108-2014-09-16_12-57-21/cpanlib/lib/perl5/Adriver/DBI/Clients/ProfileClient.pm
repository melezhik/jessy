package Adriver::DBI::Clients::ProfileClient;

use strict;
our $VERSION = '0.0300';
use Carp;
use Params::Validate qw(:all);
use base qw ( Adriver::DBI::Clients::BaseID );

validation_options(on_fail => sub { Adriver::DBI::Exceptions::ParamsValidation->throw( error => $_[0]); } );

sub package { 'RLE::ProfileClient' }

#### Generic BaseID Functions
#
# get(INT ProfileID)
# getids()
# getlist(ARRAYREF of INT ProfileIDs)
# set(HASHREF ProfileHashRef)
# add(HASHREF ProfileHashRef)
# remove(INT ProfileID)
#
#### Other Functions
#
## Increment exposures, click or subevent in profile with ProfileID
## DONOT USE THIS METHODS IN IFACES! SPECIAL SYSTEM CALLS!
#
# (INT ProfileID) exposure(INT ProfileID)
# (INT ProfileID) click(INT ProfileID)
# (INT ProfileID) subevent(INT ProfileID, INT SubeventType)
#
## Sets exposures, click or subevent counter in profile with ProfileID
#
# (INT ProfileID) set_exposures_counter(INT ProfileID, HASHREF HourlyCounterHashRef)
# (INT ProfileID) set_clicks_counter(INT ProfileID, HASHREF HourlyCounterHashRef)
# (INT ProfileID) set_subevents_counter(INT ProfileID, INT SubeventType, HASHREF CounterHashRef)
#
## Rotate counter in all profiles
## DONOT USE THIS METHODS IN IFACES! SPECIAL SYSTEM CALLS!
#
# (void) rotate_hourly()
# (void) rotate_daily()
# (void) rotate_weekly()
#
#### Input Data Info
#
# CounterHashRef =>
# {
#     'today'     => INT
#     'yesterday' => INT
#     'week'      => INT
#     'last_week' => INT
#     'total'     => INT
# }
#
# HourlyCounterHashRef =>
# {
#     'today'     => INT
#     'yesterday' => INT
#     'week'      => INT
#     'last_week' => INT
#     'total'     => INT
#     'last_hour' => INT
# }
#
# ProfileHashRef =>
# {
#   'profileID'             => INT
#   'profileName'           => STRING
#   'burstMode'             => INT
#   'enable'                => BOOL
#   'enables'               => ARRAYREF(32) BOOL
#   'dayHour'               => ARRAYREF(24x7) BOOL
#   'dayMonth'              => ARRAYREF(31) BOOL
#   'geoZoneMask'           => ARRAYREF(1024) BOOL
#   'orgMask'               => ARRAYREF(256) BOOL
#   'connectionTypeMask'    => (2)
#   'catMask'               => ARRAYREF(256) BOOL
#   'browserMask'           => ARRAYREF(32) BOOL
#   'osMask'                => ARRAYREF(32) BOOL
#   'targetingSwitch'       => {}
#   'TZConversion'          => BOOL
#   'exposures'             => HourlyCounter
#   'clicks'                => HourlyCounter
#   'subevents'             => ARRAYREF(10) HourlyCounter
#   'totalMaxShows'         => INT
#   'totalMaxClicks'        => INT
#   'totalMaxSubevents'     => ARRAYREF(10) INT
#   'dayMaxShows'           => INT
#   'dayMaxClicks'          => INT
#   'dayMaxSubevents'       => ARRAYREF(10) INT
#   'uniqueUserMaxShows'    => ARRAYREF(3) INT
#   'uniqueUserMaxClicks'   => INT
#   'uniqueUserMinInterval' => INT
#   'exposurePrice'         => INT
# }
#
####
#define ORG_NUM                      256
#define MAX_DIRECT_TARGETING_NUM     32
#define PROFILE_NAME_LEN             50
#define SLICE_NUM                    32
#define BROWSER_NUM                  32
#define OS_NUM                       32
#define CAT_NUM                      256

#define CONN_TYPE_UNDEFINED          0
#define CONN_TYPE_LEASED             1
#define CONN_TYPE_DIALUP             2
#define CONN_TYPE_NUM                3

#define TARG_DAY_HOUR                0
#define TARG_DAY_MONTH               1
#define TARG_GEO                     2
#define TARG_DATES                   3
#define TARG_ORG                     4
#define TARG_CONN_TYPE               5
#define TARG_CAT                     6
#define TARG_DIRECT                  7
#define TARG_SUBNET                  8
#define TARG_SLICE                   9
#define TARG_BROWSER                 10
#define TARG_OS                      11
#define TARG_IP                      12
#define TARG_KEYWORD                 13
#define TARG_TRAIT                   14
#define TARG_CONTEXT                 15
#define TARG_NUM                     16
#define TARG_NUM_RESERVE             1

#define PROFILE_ENABLES_SIZE         32
#define PROFILE_ENABLE_UU_REPORTING  0

sub exposure
{
    validate_pos(@_, { type => OBJECT },
        { type => SCALAR, regex => qr/^\d+$/ }, # INT ProfileID
    );
    my ($self, @args) = @_;

    my $result;
    eval { $result = $self->{client}->exposure(@args); };
    if (my $e = Adriver::DBI::Exceptions::DBError->caught())
    {
        Adriver::DBI::Exceptions::Clients->throw(
            error  => Adriver::ErrorMessage::error_message($e),
            code   => $e->{code},
            method => 'exposure',
            args   => \@args
        );
    }

    return $result;
}

sub click
{
    validate_pos(@_, { type => OBJECT },
        { type => SCALAR, regex => qr/^\d+$/ }, # INT ProfileID
    );
    my ($self, @args) = @_;

    my $result;
    eval { $result = $self->{client}->click(@args); };
    if (my $e = Adriver::DBI::Exceptions::DBError->caught())
    {
        Adriver::DBI::Exceptions::Clients->throw(
            error  => Adriver::ErrorMessage::error_message($e),
            code   => $e->{code},
            method => 'click',
            args   => \@args
        );
    }

    return $result;
}

sub subevent
{
    validate_pos(@_, { type => OBJECT },
        { type => SCALAR, regex => qr/^\d+$/ }, # INT ProfileID
        { type => SCALAR, regex => qr/^\d+$/ }, # INT SubeventType
    );
    my ($self, @args) = @_;

    my $result;
    eval { $result = $self->{client}->subevent(@args); };
    if (my $e = Adriver::DBI::Exceptions::DBError->caught())
    {
        Adriver::DBI::Exceptions::Clients->throw(
            error  => Adriver::ErrorMessage::error_message($e),
            code   => $e->{code},
            method => 'subevent',
            args   => \@args
        );
    }

    return $result;
}

sub set_reach_counter
{
    # set_reach_counter($Id, {period => 2, limit => 100, total => 100})
    validate_pos(@_, { type => OBJECT },
        { type => SCALAR, regex => qr/^\d+$/ }, # INT ADID
        { type => HASHREF },                    # HASHREF ReachCounterHashRef
                                                # {period => , limit => , total => }
    );
    my ($self, @args) = @_;

    my $result;
    eval { $result = $self->{client}->set_reach_counter(@args); };
    if (my $e = Adriver::DBI::Exceptions::DBError->caught())
    {
        Adriver::DBI::Exceptions::Clients->throw(
            error  => Adriver::ErrorMessage::error_message($e),
            code   => $e->{code},
            method => 'set_reach_counter',
            args   => \@args
        );
    }

    return $result;
}

sub set_exposures_counter
{
    validate_pos(@_, { type => OBJECT },
        { type => SCALAR, regex => qr/^\d+$/ }, # INT ProfileID
        { type => HASHREF },                    # HASHREF CounterHashRef
    );
    my ($self, @args) = @_;

    my $result;
    eval { $result = $self->{client}->set_exposures_counter(@args); };
    if (my $e = Adriver::DBI::Exceptions::DBError->caught())
    {
        Adriver::DBI::Exceptions::Clients->throw(
            error  => Adriver::ErrorMessage::error_message($e),
            code   => $e->{code},
            method => 'set_exposures_counter',
            args   => \@args
        );
    }

    return $result;
}

sub set_clicks_counter
{
    validate_pos(@_, { type => OBJECT },
        { type => SCALAR, regex => qr/^\d+$/ }, # INT ProfileID
        { type => HASHREF },                    # HASHREF CounterHashRef
    );
    my ($self, @args) = @_;

    my $result;
    eval { $result = $self->{client}->set_clicks_counter(@args); };
    if (my $e = Adriver::DBI::Exceptions::DBError->caught())
    {
        Adriver::DBI::Exceptions::Clients->throw(
            error  => Adriver::ErrorMessage::error_message($e),
            code   => $e->{code},
            method => 'set_clicks_counter',
            args   => \@args
        );
    }

    return $result;
}

sub set_subevents_counter
{
    validate_pos(@_, { type => OBJECT },
        { type => SCALAR, regex => qr/^\d+$/ }, # INT ProfileID
        { type => SCALAR, regex => qr/^\d+$/ }, # INT SubeventType
        { type => HASHREF },                    # HASHREF CounterHashRef
    );
    my ($self, @args) = @_;

    my $result;
    eval { $result = $self->{client}->set_subevents_counter(@args); };
    if (my $e = Adriver::DBI::Exceptions::DBError->caught())
    {
        Adriver::DBI::Exceptions::Clients->throw(
            error  => Adriver::ErrorMessage::error_message($e),
            code   => $e->{code},
            method => 'set_subevents_counter',
            args   => \@args
        );
    }

    return $result;
}

sub rotate_hourly
{
    validate_pos(@_, { type => OBJECT });
    my ($self, @args) = @_;

    my $result;
    eval { $result = $self->{client}->rotate_hourly(@args); };
    if (my $e = Adriver::DBI::Exceptions::DBError->caught())
    {
        Adriver::DBI::Exceptions::Clients->throw(
            error  => Adriver::ErrorMessage::error_message($e),
            code   => $e->{code},
            method => 'rotate_hourly',
            args   => \@args
        );
    }

    return $result;
}

sub rotate_daily
{
    validate_pos(@_, { type => OBJECT });
    my ($self, @args) = @_;

    my $result;
    eval { $result = $self->{client}->rotate_daily(@args); };
    if (my $e = Adriver::DBI::Exceptions::DBError->caught())
    {
        Adriver::DBI::Exceptions::Clients->throw(
            error  => Adriver::ErrorMessage::error_message($e),
            code   => $e->{code},
            method => 'rotate_daily',
            args   => \@args
        );
    }

    return $result;
}

sub rotate_weekly
{
    validate_pos(@_, { type => OBJECT });
    my ($self, @args) = @_;

    my $result;
    eval { $result = $self->{client}->rotate_weekly(@args); };
    if (my $e = Adriver::DBI::Exceptions::DBError->caught())
    {
        Adriver::DBI::Exceptions::Clients->throw(
            error  => Adriver::ErrorMessage::error_message($e),
            code   => $e->{code},
            method => 'rotate_weekly',
            args   => \@args
        );
    }

    return $result;
}

1;

__END__


=head1 NAME

    Adriver::DBI::Clients::ProfileClient - this module provides methods to work with
    Adriver profiles database.


=head1 DESCRIPTION

    This module is inherited from Adriver::DBI::Clients::BaseID class.


=head1 SYNOPSIS

    use Adriver::DBI;
    use Adriver::DatabaseConnect::Adriver;
    use Adriver::Exceptions;

    my $host = 'f2.x';
    my $port = 16000;

    eval
    {
        my $dbh = Adriver::DBI->new( Adriver::DatabaseConnect::Adriver->new({host => $host, port => $port}) );

        my $profile_id = 241790;
        my $profile = $dbh->Profile->get($profile_id);
        print Dumper($profile);

        my $db_info = $dbh->Profile->GetCaps();
        print Dumper($db_info);

        my $ids = $dbh->Profile->getids();
        print Dumper($ids);

        my @ids = (224480, 224488, 27880);
        my $profiles = $dbh->Profile->getlist(\@ids);
        print Dumper($profiles);

        $dbh->Profile->set($profile);
    };

    if (my $e = Exception::Class->caught('Adriver::Exceptions'))
    {
        die "Caught Adriver::Exceptions: '", $e->error, "\n", $e->trace->as_string, "\n";
    }
    elsif ($e = Exception::Class->caught('Exception::Class::Base'))
    {
        die "Caught unknown exception: '", $e->error, "\n", $e->trace->as_string, "\n";
    }
    elsif ($e = Exception::Class->caught)
    {
        die "$e";
    }


=head1 INHERITED OBJECT INTERFACE

=head2 get($profile_id) : $ProfileHashRef

    Get certain profile from database by it's identifier.

B<profile_id>

    This is the integer identifier of profile.

B<ProfileHashRef>

    This is a hash reference with next structure:

    ProfileHashRef =>
    {
        'profileID'             => INT
        'profileName'           => STRING
        'burstMode'             => INT
        'enable'                => BOOL
        'enables'               => ARRAYREF(32) BOOL
        'dayHour'               => ARRAYREF(24x7) BOOL
        'dayMonth'              => ARRAYREF(31) BOOL
        'geoZoneMask'           => ARRAYREF(1024) BOOL
        'orgMask'               => ARRAYREF(256) BOOL
        'connectionTypeMask'    => (2)
        'catMask'               => ARRAYREF(256) BOOL
        'browserMask'           => ARRAYREF(32) BOOL
        'osMask'                => ARRAYREF(32) BOOL
        'targetingSwitch'       => {}
        'TZConversion'          => BOOL
        'exposures'             => HourlyCounter
        'clicks'                => HourlyCounter
        'subevents'             => ARRAYREF(10) HourlyCounter
        'totalMaxShows'         => INT
        'totalMaxClicks'        => INT
        'totalMaxSubevents'     => ARRAYREF(10) INT
        'dayMaxShows'           => INT
        'dayMaxClicks'          => INT
        'dayMaxSubevents'       => ARRAYREF(10) INT
        'uniqueUserMaxShows'    => INT
        'uniqueUserMaxClicks'   => INT
        'uniqueUserMinInterval' => INT
    }

    where

    HourlyCounterHashRef =>
    {
        'today'     => INT
        'yesterday' => INT
        'week'      => INT
        'last_week' => INT
        'total'     => INT
        'last_hour' => INT
    }

B<Exceptions>

    Adriver::DBI::Exceptions::ParamsValidation
    Adriver::DBI::Exceptions::Clients

=head2 getids() : $profile_ids

    This method returns a list of all profiles identifiers from database.

B<profile_ids>

    This is the array reference with obtained profiles identifiers.

B<Exceptions>

    Adriver::DBI::Exceptions::ParamsValidation
    Adriver::DBI::Exceptions::Clients

=head2 getlist(\@profile_ids) : ARRAYREF of $ProfileHashRef

    This method returns a list of profiles from database by their identifiers.

B<profile_ids>

    This is the array reference with profiles identifiers you want to get.

B<ProfileHashRef>

    This is the same hash reference as described in get() method.

B<Exceptions>

    Adriver::DBI::Exceptions::ParamsValidation
    Adriver::DBI::Exceptions::Clients


=head2 set($ProfileHashRef) : undef

    This method updates given profile in database.

B<ProfileHashRef>

    This is the same hash reference as described in get() method.

B<Exceptions>

    Adriver::DBI::Exceptions::ParamsValidation
    Adriver::DBI::Exceptions::Clients

=head2 add($ProfileHashRef) : $profile_id

    This method adds the new profile in database and returns it's identifier.

B<ProfileHashRef>

    This is the same hash reference as described in get() method.

B<profile_id>

    This is the integer identifier of added profile.

B<Exceptions>

    Adriver::DBI::Exceptions::ParamsValidation
    Adriver::DBI::Exceptions::Clients

=head2 remove($profile_id) : undef

    This method removes profile from database by it's identifier.

B<profile_id>

    This is the profile identifier you want to remove.

B<Exceptions>

    Adriver::DBI::Exceptions::ParamsValidation
    Adriver::DBI::Exceptions::Clients


=head1 OBJECT INTERFACE

=head2 exposure($profile_id) : $profile_id

    This method icrements the number of profile exposures.
    DONOT USE THIS METHODS IN IFACES! SPECIAL SYSTEM CALLS!

B<profile_id>

    This is the profile identifier which exposures counter you want to increase.

B<Exceptions>

    Adriver::DBI::Exceptions::ParamsValidation
    Adriver::DBI::Exceptions::Clients

=head2 click($profile_id) : $profile_id

    This method icrements the number of profile clicks.
    DONOT USE THIS METHODS IN IFACES! SPECIAL SYSTEM CALLS!

B<profile_id>

    This is the profile identifier which clicks counter you want to increase.

B<Exceptions>

    Adriver::DBI::Exceptions::ParamsValidation
    Adriver::DBI::Exceptions::Clients

=head2 subevent($profile_id, $subevent_type) : $profile_id

    This method icrements the number of profile subevents.
    DONOT USE THIS METHODS IN IFACES! SPECIAL SYSTEM CALLS!

B<profile_id>

    This is the profile identifier which subevents counter you want to increase.

B<subevent_type>

    This is the subevent type.

B<Exceptions>

    Adriver::DBI::Exceptions::ParamsValidation
    Adriver::DBI::Exceptions::Clients

=head2 set_exposures_counter($profile_id, $HourlyCounterHashRef) : $profile_id

    This method sets the counter of profile exposures.

B<profile_id>

    This is the profile identifier which exposures counter you want to set.

B<HourlyCounterHashRef>

    This is the same hash reference as described in get() method.

B<Exceptions>

    Adriver::DBI::Exceptions::ParamsValidation
    Adriver::DBI::Exceptions::Clients

=head2 set_clicks_counter($profile_id, $HourlyCounterHashRef) : $profile_id

    This method sets the counter of profile clicks.

B<profile_id>

    This is the profile identifier which clicks counter you want to set.

B<HourlyCounterHashRef>

    This is the same hash reference as described in get() method.

B<Exceptions>

    Adriver::DBI::Exceptions::ParamsValidation
    Adriver::DBI::Exceptions::Clients

=head2 set_subevents_counter($profile_id, $subevent_type, $CounterHashRef) : $profile_id

    This method sets the subevent counter of profile. Subevent specified by it's type.

B<profile_id>

    This is the profile identifier which subevent counter you want to set.

B<subevent_type>

    This is the subevent type.

B<CounterHashRef>

    This is the hash reference with next structure:

    CounterHashRef =>
    {
        'today'     => INT
        'yesterday' => INT
        'week'      => INT
        'last_week' => INT
        'total'     => INT
    }

B<Exceptions>

    Adriver::DBI::Exceptions::ParamsValidation
    Adriver::DBI::Exceptions::Clients

=head2 rotate_hourly() : undef

    This procedure rotates hourly counters in all profiles.
    DONOT USE THIS METHODS IN IFACES! SPECIAL SYSTEM CALLS!

B<Exceptions>

    Adriver::DBI::Exceptions::ParamsValidation
    Adriver::DBI::Exceptions::Clients

=head2 rotate_daily() : undef

    This procedure rotates daily counters in all profiles.
    DONOT USE THIS METHODS IN IFACES! SPECIAL SYSTEM CALLS!

B<Exceptions>

    Adriver::DBI::Exceptions::ParamsValidation
    Adriver::DBI::Exceptions::Clients

=head2 rotate_weekly() : undef

    This procedure rotates weekly counters in all profiles.
    DONOT USE THIS METHODS IN IFACES! SPECIAL SYSTEM CALLS!

B<Exceptions>

    Adriver::DBI::Exceptions::ParamsValidation
    Adriver::DBI::Exceptions::Clients


=head1 SEE ALSO

    Adriver::DBI::Clients::BaseID
    Adriver::DBI::Exceptions

