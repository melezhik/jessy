package Adriver::DBI::Clients::BaseNoSocket;

use strict;
our $VERSION = '0.0300';
use Carp;
use Adriver::ErrorMessage;
use Adriver::DBI::Exceptions;

sub new
{
    my $self = {};
    my $that = shift;
    my $class = ref($that) || $that;
    bless($self, $class);

    $self->{'client'} = shift;

    return $self;
}

sub GetCaps
{
    my $self = shift;

    my $db_info;
    eval {
        $db_info =  $self->{'client'}->GetCaps();
    };

    return $db_info;
}

1;


__END__


=head1 NAME

    Adriver::DBI::Clients::BaseNoSocket - this is a base class for some clients classes without
    socket connection to the database.


=head1 DESCRIPTION

    You should not use this module directly.


=head1 CLASS AND OBJECT INTERFACE

=head2 new() : some Adriver::DBI::Clients object

    Create the new object of some Adriver::DBI::Clients class.

=head2 GetCaps() : $InfoHashRef

    This method returns information about server database and client.

B<InfoHashRef>

    This is a hash reference with getted information.


=head1 SEE ALSO

    Adriver::DBI::Exceptions

