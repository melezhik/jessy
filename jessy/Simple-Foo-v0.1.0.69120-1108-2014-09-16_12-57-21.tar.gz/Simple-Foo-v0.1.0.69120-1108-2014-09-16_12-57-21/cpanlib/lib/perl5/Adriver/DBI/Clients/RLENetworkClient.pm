package Adriver::DBI::Clients::RLENetworkClient;

use strict;
our $VERSION = '0.0300';
use Carp;
use Params::Validate qw(:all);
use base qw ( Adriver::DBI::Clients::BaseID );

validation_options(on_fail => sub { Adriver::DBI::Exceptions::ParamsValidation->throw( error => $_[0]); } );

sub package { 'RLE::RLENetwork::RLENetworkClient' }

#### Generic BaseID Functions
#
# get(INT RLENetID)
# getids()
# getlist(ARRAYREF of INT RLENetIDs)
# set(HASHREF RLENetworkHashRef)
# add(HASHREF RLENetworkHashRef)
# remove(INT RLENetID)
#
#### Other Functions
#
## Set or add Amount credits for rlenetwork with RLENetID
## Amount type is float (double in c-source)
#
# (INT NewAmount) add_credit(INT RLENetID, FLOAT Amount)
# (INT NewAmount) set_credit(INT RLENetID, FLOAT Amount)
# (INT NewAmount) add_hoster_credit(INT RLENetID, FLOAT Amount)
# (INT NewAmount) set_hoster_credit(INT RLENetID, FLOAT Amount)
#
## Increment exposures or click in rlenetwork with
## RLENetID, CatID, ExpType (hoster - 1/general - 0)
## DONOT USE THIS METHODS IN IFACES! SPECIAL SYSTEM CALLS!
#
# (INT 1) exposure(INT RLENetID, INT CatID, BOOL ExpType)
# (INT 1) click(INT RLENetID, INT CatID, BOOL ExpType)
#
## Sets exposures or click counter in rlenetwork with RLENetID
#
# (INT 1) set_exposures_counter(INT RLENetID, HASHREF HourlyCounterHashRef)
# (INT 1) set_clicks_counter(INT RLENetID, HASHREF HourlyCounterHashRef)
# (INT 1) set_hoster_exposures_counter(INT RLENetID, HASHREF HourlyCounterHashRef)
# (INT 1) set_hoster_clicks_counter(INT RLENetID, HASHREF HourlyCounterHashRef)
# (INT 1) set_cat_exposures_counter(INT RLENetID, INT CatID, HASHREF HourlyCounterHashRef)
# (INT 1) set_cat_clicks_counter(INT RLENetID, INT CatID, HASHREF HourlyCounterHashRef)
#
## Rotate counter in all rlenetworks
## DONOT USE THIS METHODS IN IFACES! SPECIAL SYSTEM CALLS!
#
# (void) rotate_hourly()
# (void) rotate_daily()
# (void) rotate_weekly()
#
#### Input Data Info
#
# HourlyCounterHashRef =>
# {
#     'today'     => INT
#     'yesterday' => INT
#     'week'      => INT
#     'last_week' => INT
#     'total'     => INT
#     'last_hour' => INT
# }
#
# RLENetworkHashRef =>
# {
#      'RLENetworkID'     => INT
#      'RLENetworkName'   => STRING
#      'shortName'        => INT
#      'enables'          => ARRAYREF(128) BOOL
#      'defaultAD'        => INT
#      'bannerType'       => INT
#      'bannerSpecMask'   => ARRAYREF(2048) BOOL
#      'hoster_pay_rate'  => INT,
#      'pay_rate_table'   => ARRAYREF(32) of HASHREF {'bounds1'=>INT,'bounds2'=>INT,'pay_rate'=>INT}
#      'credit'           => INT
#      'hoster_credit'    => '0',
#      'default_pay_rate' => ARRAYREF(2) INT
#      'creationTime'     => INT
#      'default_price'    => ARRAYREF(2) INT
#      'gold_threshold'   => INT (? BOOL)
#      'targeting_cost'   => ARRAYREF(2) of ARRAYREF(17) BOOL (? INT)
#      'chooser_table'    => ARRAYREF(2) of ARRAYREF(12) of ARRAYREF(2) INT
#      'exposures'        => HourlyCounterHashRef
#      'clicks'           => HourlyCounterHashRef
#      'hoster_exposures' => HourlyCounterHashRef
#      'hoster_clicks'    => HourlyCounterHashRef
#      'hoster_limits1'   => INT
#      'hoster_limits2'   => INT
#      'categories'       => ARRAYREF(256) of HASHREF {'name'=>STRING,'enable'=>BOOL,'exposures'=>HourlyCounterHashRef,'clicks'=>HourlyCounterHashRef}
# }
#
####

sub add_credit
{
    validate_pos(@_, { type => OBJECT },
        { type => SCALAR, regex => qr/^\d+$/ }, # INT RLENetID
        { type => SCALAR },                     # FLOAT Amount
    );
    my ($self, @args) = @_;

    my $result;
    eval { $result = $self->{client}->add_credit(@args); };
    if (my $e = Adriver::DBI::Exceptions::DBError->caught())
    {
        Adriver::DBI::Exceptions::Clients->throw(
            error  => Adriver::ErrorMessage::error_message($e),
            code   => $e->{code},
            method => 'add_credit',
            args   => \@args
        );
    }

    return $result;
}

sub set_credit
{
    validate_pos(@_, { type => OBJECT },
        { type => SCALAR, regex => qr/^\d+$/ }, # INT RLENetID
        { type => SCALAR },                     # FLOAT Amount
    );
    my ($self, @args) = @_;

    my $result;
    eval { $result = $self->{client}->set_credit(@args); };
    if (my $e = Adriver::DBI::Exceptions::DBError->caught())
    {
        Adriver::DBI::Exceptions::Clients->throw(
            error  => Adriver::ErrorMessage::error_message($e),
            code   => $e->{code},
            method => 'set_credit',
            args   => \@args
        );
    }

    return $result;
}

sub add_hoster_credit
{
    validate_pos(@_, { type => OBJECT },
        { type => SCALAR, regex => qr/^\d+$/ }, # INT RLENetID
        { type => SCALAR },                     # FLOAT Amount
    );
    my ($self, @args) = @_;

    my $result;
    eval { $result = $self->{client}->add_hoster_credit(@args); };
    if (my $e = Adriver::DBI::Exceptions::DBError->caught())
    {
        Adriver::DBI::Exceptions::Clients->throw(
            error  => Adriver::ErrorMessage::error_message($e),
            code   => $e->{code},
            method => 'add_hoster_credit',
            args   => \@args
        );
    }

    return $result;
}

sub set_hoster_credit
{
    validate_pos(@_, { type => OBJECT },
        { type => SCALAR, regex => qr/^\d+$/ }, # INT RLENetID
        { type => SCALAR },                     # FLOAT Amount
    );
    my ($self, @args) = @_;

    my $result;
    eval { $result = $self->{client}->set_hoster_credit(@args); };
    if (my $e = Adriver::DBI::Exceptions::DBError->caught())
    {
        Adriver::DBI::Exceptions::Clients->throw(
            error  => Adriver::ErrorMessage::error_message($e),
            code   => $e->{code},
            method => 'set_hoster_credit',
            args   => \@args
        );
    }

    return $result;
}

sub exposure
{
    validate_pos(@_, { type => OBJECT },
        { type => SCALAR, regex => qr/^\d+$/ }, # INT RLENetID
        { type => SCALAR, regex => qr/^\d+$/ }, # INT CatID
        { type => SCALAR },                     # BOOL ExpType
    );
    my ($self, @args) = @_;

    my $result;
    eval { $result = $self->{client}->exposure(@args); };
    if (my $e = Adriver::DBI::Exceptions::DBError->caught())
    {
        Adriver::DBI::Exceptions::Clients->throw(
            error  => Adriver::ErrorMessage::error_message($e),
            code   => $e->{code},
            method => 'exposure',
            args   => \@args
        );
    }

    return $result;
}

sub click
{
    validate_pos(@_, { type => OBJECT },
        { type => SCALAR, regex => qr/^\d+$/ }, # INT RLENetID
        { type => SCALAR, regex => qr/^\d+$/ }, # INT CatID
        { type => SCALAR },                     # BOOL ExpType
    );
    my ($self, @args) = @_;

    my $result;
    eval { $result = $self->{client}->click(@args); };
    if (my $e = Adriver::DBI::Exceptions::DBError->caught())
    {
        Adriver::DBI::Exceptions::Clients->throw(
            error  => Adriver::ErrorMessage::error_message($e),
            code   => $e->{code},
            method => 'click',
            args   => \@args
        );
    }

    return $result;
}

sub set_exposures_counter
{
    validate_pos(@_, { type => OBJECT },
        { type => SCALAR, regex => qr/^\d+$/ }, # INT RLENetID
        { type => HASHREF },                    # HASHREF HourlyCounterHashRef
    );
    my ($self, @args) = @_;

    my $result;
    eval { $result = $self->{client}->set_exposures_counter(@args); };
    if (my $e = Adriver::DBI::Exceptions::DBError->caught())
    {
        Adriver::DBI::Exceptions::Clients->throw(
            error  => Adriver::ErrorMessage::error_message($e),
            code   => $e->{code},
            method => 'set_exposures_counter',
            args   => \@args
        );
    }

    return $result;
}

sub set_clicks_counter
{
    validate_pos(@_, { type => OBJECT },
        { type => SCALAR, regex => qr/^\d+$/ }, # INT RLENetID
        { type => HASHREF },                    # HASHREF HourlyCounterHashRef
    );
    my ($self, @args) = @_;

    my $result;
    eval { $result = $self->{client}->set_clicks_counter(@args); };
    if (my $e = Adriver::DBI::Exceptions::DBError->caught())
    {
        Adriver::DBI::Exceptions::Clients->throw(
            error  => Adriver::ErrorMessage::error_message($e),
            code   => $e->{code},
            method => 'set_clicks_counter',
            args   => \@args
        );
    }

    return $result;
}

sub set_hoster_exposures_counter
{
    validate_pos(@_, { type => OBJECT },
        { type => SCALAR, regex => qr/^\d+$/ }, # INT RLENetID
        { type => HASHREF },                    # HASHREF HourlyCounterHashRef
    );
    my ($self, @args) = @_;

    my $result;
    eval { $result = $self->{client}->set_hoster_exposures_counter(@args); };
    if (my $e = Adriver::DBI::Exceptions::DBError->caught())
    {
        Adriver::DBI::Exceptions::Clients->throw(
            error  => Adriver::ErrorMessage::error_message($e),
            code   => $e->{code},
            method => 'set_hoster_exposures_counter',
            args   => \@args
        );
    }

    return $result;
}

sub set_hoster_clicks_counter
{
    validate_pos(@_, { type => OBJECT },
        { type => SCALAR, regex => qr/^\d+$/ }, # INT RLENetID
        { type => HASHREF },                    # HASHREF HourlyCounterHashRef
    );
    my ($self, @args) = @_;

    my $result;
    eval { $result = $self->{client}->set_hoster_clicks_counter(@args); };
    if (my $e = Adriver::DBI::Exceptions::DBError->caught())
    {
        Adriver::DBI::Exceptions::Clients->throw(
            error  => Adriver::ErrorMessage::error_message($e),
            code   => $e->{code},
            method => 'set_hoster_clicks_counter',
            args   => \@args
        );
    }

    return $result;
}

sub set_cat_exposures_counter
{
    validate_pos(@_, { type => OBJECT },
        { type => SCALAR, regex => qr/^\d+$/ }, # INT RLENetID
        { type => SCALAR, regex => qr/^\d+$/ }, # INT CatID
        { type => HASHREF },                    # HASHREF HourlyCounterHashRef
    );
    my ($self, @args) = @_;

    my $result;
    eval { $result = $self->{client}->set_cat_exposures_counter(@args); };
    if (my $e = Adriver::DBI::Exceptions::DBError->caught())
    {
        Adriver::DBI::Exceptions::Clients->throw(
            error  => Adriver::ErrorMessage::error_message($e),
            code   => $e->{code},
            method => 'set_cat_exposures_counter',
            args   => \@args
        );
    }

    return $result;
}

sub set_cat_clicks_counter
{
    validate_pos(@_, { type => OBJECT },
        { type => SCALAR, regex => qr/^\d+$/ }, # INT RLENetID
        { type => SCALAR, regex => qr/^\d+$/ }, # INT CatID
        { type => HASHREF },                    # HASHREF HourlyCounterHashRef
    );
    my ($self, @args) = @_;

    my $result;
    eval { $result = $self->{client}->set_cat_clicks_counter(@args); };
    if (my $e = Adriver::DBI::Exceptions::DBError->caught())
    {
        Adriver::DBI::Exceptions::Clients->throw(
            error  => Adriver::ErrorMessage::error_message($e),
            code   => $e->{code},
            method => 'set_cat_clicks_counter',
            args   => \@args
        );
    }

    return $result;
}

sub rotate_hourly
{
    validate_pos(@_, { type => OBJECT });
    my ($self, @args) = @_;

    my $result;
    eval { $result = $self->{client}->rotate_hourly(@args); };
    if (my $e = Adriver::DBI::Exceptions::DBError->caught())
    {
        Adriver::DBI::Exceptions::Clients->throw(
            error  => Adriver::ErrorMessage::error_message($e),
            code   => $e->{code},
            method => 'rotate_hourly',
            args   => \@args
        );
    }

    return $result;
}

sub rotate_daily
{
    validate_pos(@_, { type => OBJECT });
    my ($self, @args) = @_;

    my $result;
    eval { $result = $self->{client}->rotate_daily(@args); };
    if (my $e = Adriver::DBI::Exceptions::DBError->caught())
    {
        Adriver::DBI::Exceptions::Clients->throw(
            error  => Adriver::ErrorMessage::error_message($e),
            code   => $e->{code},
            method => 'rotate_daily',
            args   => \@args
        );
    }

    return $result;
}

sub rotate_weekly
{
    validate_pos(@_, { type => OBJECT });
    my ($self, @args) = @_;

    my $result;
    eval { $result = $self->{client}->rotate_weekly(@args); };
    if (my $e = Adriver::DBI::Exceptions::DBError->caught())
    {
        Adriver::DBI::Exceptions::Clients->throw(
            error  => Adriver::ErrorMessage::error_message($e),
            code   => $e->{code},
            method => 'rotate_weekly',
            args   => \@args
        );
    }

    return $result;
}

1;


__END__


=head1 NAME

    Adriver::DBI::Clients::RLENetworkClient - this module provides methods to work with
    RLE networks database.


=head1 DESCRIPTION

    This module is inherited from Adriver::DBI::Clients::BaseID class.


=head1 SYNOPSIS

    use Adriver::DBI;
    use Adriver::DatabaseConnect::Adriver;
    use Adriver::Exceptions;

    my $host = 'f2.x';
    my $port = 16000;

    eval
    {
        my $dbh = Adriver::DBI->new( Adriver::DatabaseConnect::Adriver->new({host => $host, port => $port}) );

        my $RLENetworkID = 33;
        my $RLENetwork = $dbh->RLENetwork->get($RLENetworkID);
        print Dumper($RLENetwork);

        my $db_info = $dbh->RLENetwork->GetCaps();
        print Dumper($db_info);

        my $ids = $dbh->RLENetwork->getids();
        print Dumper($ids);
    };

    if (my $e = Exception::Class->caught('Adriver::Exceptions'))
    {
        die "Caught Adriver::Exceptions: '", $e->error, "'\n", $e->trace->as_string, "\n";
    }
    elsif ($e = Exception::Class->caught('Exception::Class::Base'))
    {
        die "Caught unknown exception: '", $e->error, "'\n", $e->trace->as_string, "\n";
    }
    elsif ($e = Exception::Class->caught)
    {
        die "$e";
    }


=head1 INHERITED OBJECT INTERFACE

=head2 get($RLENetID) : $RLENetworkHashRef

    Get certain RLE network from database by it's identifier.

B<RLENetID>

    This is the identifier of RLE network.

B<RLENetworkHashRef>

    This is a hash reference with next structure:

    RLENetworkHashRef =>
    {
        'RLENetworkID'     => INT
        'RLENetworkName'   => STRING
        'shortName'        => INT
        'enables'          => ARRAYREF(128) BOOL
        'defaultAD'        => INT
        'bannerType'       => INT
        'bannerSpecMask'   => ARRAYREF(2048) BOOL
        'hoster_pay_rate'  => INT,
        'pay_rate_table'   => ARRAYREF(32) of HASHREF {'bounds1'=>INT,'bounds2'=>INT,'pay_rate'=>INT}
        'credit'           => INT
        'hoster_credit'    => '0',
        'default_pay_rate' => ARRAYREF(2) INT
        'creationTime'     => INT
        'default_price'    => ARRAYREF(2) INT
        'gold_threshold'   => INT (? BOOL)
        'targeting_cost'   => ARRAYREF(2) of ARRAYREF(17) BOOL (? INT)
        'chooser_table'    => ARRAYREF(2) of ARRAYREF(12) of ARRAYREF(2) INT
        'exposures'        => HourlyCounterHashRef
        'clicks'           => HourlyCounterHashRef
        'hoster_exposures' => HourlyCounterHashRef
        'hoster_clicks'    => HourlyCounterHashRef
        'hoster_limits1'   => INT
        'hoster_limits2'   => INT
        'categories'       => ARRAYREF(256) of HASHREF {'name'=>STRING,'enable'=>BOOL,'exposures'=>HourlyCounterHashRef,'clicks'=>HourlyCounterHashRef}
    }

    where

    HourlyCounterHashRef =>
    {
        'today'     => INT
        'yesterday' => INT
        'week'      => INT
        'last_week' => INT
        'total'     => INT
        'last_hour' => INT
    }

B<Exceptions>

    Adriver::DBI::Exceptions::ParamsValidation
    Adriver::DBI::Exceptions::Clients

=head2 getids() : $RLENetIDs

    This method returns a list of all networks identifiers from database.

B<RLENetIDs>

    This is the array reference with obtained networks identifiers.

B<Exceptions>

    Adriver::DBI::Exceptions::ParamsValidation
    Adriver::DBI::Exceptions::Clients

=head2 getlist($RLENetIDs) : ARRAYREF of $RLENetworkHashRef

    This method returns a list of RLE networks with specified identifiers.

B<RLENetIDs>

    This is the array reference with networks identifiers you want to get.

B<RLENetworkHashRef>

    This is the same hash reference as described in get() method.

B<Exceptions>

    Adriver::DBI::Exceptions::ParamsValidation
    Adriver::DBI::Exceptions::Clients

=head2 set($RLENetworkHashRef) : undef

    This method updates given network in database.

B<RLENetworkHashRef>

    This is the same hash reference as described in get() method.

B<Exceptions>

    Adriver::DBI::Exceptions::ParamsValidation
    Adriver::DBI::Exceptions::Clients

=head2 add($RLENetworkHashRef) : $RLENetID

    This method adds the new network in database and returns it's identifier.

B<RLENetworkHashRef>

    This is the same hash reference as described in get() method.

B<RLENetID>

    This is the integer identifier of added network.

B<Exceptions>

    Adriver::DBI::Exceptions::ParamsValidation
    Adriver::DBI::Exceptions::Clients

=head2 remove($RLENetID) : undef

    This method removes network from database by it's identifier.

B<RLENetID>

    This is the network identifier you want to remove.

B<Exceptions>

    Adriver::DBI::Exceptions::ParamsValidation
    Adriver::DBI::Exceptions::Clients


=head1 OBJECT INTERFACE

=head2 add_credit($RLENetID, $amount) : $new_amount

    This method adds specified amount of credits to the network.

B<RLENetID>

    This is the network's identifier which amount of credits you want to increase.

B<amount>

    This is the amount of credits you want to add to the network.

B<new_amount>

    This is the new amount of credits of the network.

B<Exceptions>

    Adriver::DBI::Exceptions::ParamsValidation
    Adriver::DBI::Exceptions::Clients

=head2 set_credit($RLENetID, $new_amount) : $new_amount

    This method sets the new amount of credits to the network.

B<RLENetID>

    This is the network's identifier which amount of credits you want to set.

B<new_amount>

    This is the new amount of credits of the network.

B<Exceptions>

    Adriver::DBI::Exceptions::ParamsValidation
    Adriver::DBI::Exceptions::Clients

=head2 add_hoster_credit($RLENetID, $amount) : $new_amount

    This method adds specified amount of hoster credits to the network.

B<RLENetID>

    This is the network's identifier which amount of hoster credits you want to increase.

B<amount>

    This is the amount of hoster credits you want to add to the network.

B<new_amount>

    This is the new amount of hoster credits of the network.

B<Exceptions>

    Adriver::DBI::Exceptions::ParamsValidation
    Adriver::DBI::Exceptions::Clients

=head2 set_hoster_credit($RLENetID, $new_amount) : $new_amount

    This method sets the new amount of hoster credits to the network.

B<RLENetID>

    This is the network's identifier which amount of hoster credits you want to set.

B<new_amount>

    This is the new amount of hoster credits of the network.

B<Exceptions>

    Adriver::DBI::Exceptions::ParamsValidation
    Adriver::DBI::Exceptions::Clients

=head2 exposure($RLENetID, $CatID, $ExpType) : 1

    This method icrements the number of banner exposures for certain RLE network.
    DONOT USE THIS METHODS IN IFACES! SPECIAL SYSTEM CALLS!

B<RLENetID>

    This is the identifier of network which banner exposures counter you want to increase.

B<CatID>

    Integer.

B<ExpType>

    hoster - 1/general - 0

B<Exceptions>

    Adriver::DBI::Exceptions::ParamsValidation
    Adriver::DBI::Exceptions::Clients

=head2 click($RLENetID, $CatID, $ExpType) : 1

    This method icrements the number of banner clicks for certain RLE network.
    DONOT USE THIS METHODS IN IFACES! SPECIAL SYSTEM CALLS!

B<RLENetID>

    This is the identifier of network which banner clicks counter you want to increase.

B<CatID>

    Integer.

B<ExpType>

    hoster - 1/general - 0

B<Exceptions>

    Adriver::DBI::Exceptions::ParamsValidation
    Adriver::DBI::Exceptions::Clients

=head2 set_exposures_counter($RLENetID, $HourlyCounterHashRef) : 1

    This method sets the counter of banner exposures for certain RLE network.

B<RLENetID>

    This is the network identifier which banner exposures counter you want to set.

B<HourlyCounterHashRef>

    This is the same hash reference as described in get() method.

B<Exceptions>

    Adriver::DBI::Exceptions::ParamsValidation
    Adriver::DBI::Exceptions::Clients

=head2 set_clicks_counter($RLENetID, $HourlyCounterHashRef) : 1

    This method sets the counter of banner clicks for certain RLE network.

B<RLENetID>

    This is the identifier of network which banner clicks counter you want to set.

B<HourlyCounterHashRef>

    This is the same hash reference as described in get() method.

B<Exceptions>

    Adriver::DBI::Exceptions::ParamsValidation
    Adriver::DBI::Exceptions::Clients

=head2 set_hoster_exposures_counter($RLENetID, $HourlyCounterHashRef) : 1

    This method sets the counter of hoster exposures for certain RLE network.

B<RLENetID>

    This is the network identifier which hoster exposures counter you want to set.

B<HourlyCounterHashRef>

    This is the same hash reference as described in get() method.

B<Exceptions>

    Adriver::DBI::Exceptions::ParamsValidation
    Adriver::DBI::Exceptions::Clients

=head2 set_hoster_clicks_counter($RLENetID, $HourlyCounterHashRef) : 1

    This method sets the counter of hoster clicks for certain RLE network.

B<RLENetID>

    This is the network identifier which hoster clicks counter you want to set.

B<HourlyCounterHashRef>

    This is the same hash reference as described in get() method.

B<Exceptions>

    Adriver::DBI::Exceptions::ParamsValidation
    Adriver::DBI::Exceptions::Clients

=head2 set_cat_exposures_counter($RLENetID, $CatID, $HourlyCounterHashRef) : 1

    This method sets the counter of cat exposures for certain RLE network.

B<RLENetID>

    This is the network identifier which cat exposures counter you want to set.

B<CatID>

    Integer.

B<HourlyCounterHashRef>

    This is the same hash reference as described in get() method.

B<Exceptions>

    Adriver::DBI::Exceptions::ParamsValidation
    Adriver::DBI::Exceptions::Clients

=head2 set_cat_clicks_counter($RLENetID, $CatID, $HourlyCounterHashRef) : 1

    This method sets the counter of cat clicks for certain RLE network.

B<RLENetID>

    This is the network identifier which cat clicks counter you want to set.

B<CatID>

    Integer.

B<HourlyCounterHashRef>

    This is the same hash reference as described in get() method.

B<Exceptions>

    Adriver::DBI::Exceptions::ParamsValidation
    Adriver::DBI::Exceptions::Clients

=head2 rotate_hourly() : undef

    This procedure rotates hourly counters in all RLE networks.
    DONOT USE THIS METHODS IN IFACES! SPECIAL SYSTEM CALLS!

B<Exceptions>

    Adriver::DBI::Exceptions::ParamsValidation
    Adriver::DBI::Exceptions::Clients

=head2 rotate_daily() : undef

    This procedure rotates daily counters in all RLE networks.
    DONOT USE THIS METHODS IN IFACES! SPECIAL SYSTEM CALLS!

B<Exceptions>

    Adriver::DBI::Exceptions::ParamsValidation
    Adriver::DBI::Exceptions::Clients

=head2 rotate_weekly() : undef

    This procedure rotates weekly counters in all RLE networks.
    DONOT USE THIS METHODS IN IFACES! SPECIAL SYSTEM CALLS!

B<Exceptions>

    Adriver::DBI::Exceptions::ParamsValidation
    Adriver::DBI::Exceptions::Clients


=head1 SEE ALSO

    Adriver::DBI::Clients::BaseID
    Adriver::DBI::Exceptions

