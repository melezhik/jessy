package Adriver::DBI::Clients::OrgClient;

use strict;
our $VERSION = '0.0300';
use Carp;
use Params::Validate qw(:all);
use base qw ( Adriver::DBI::Clients::BaseID );

validation_options(on_fail => sub { Adriver::DBI::Exceptions::ParamsValidation->throw( error => $_[0]); } );

sub package { 'RLE::OrgClient' }

#### Generic BaseID Functions
#
# get(INT OrgID)
# getids()
# getlist(ARRAYREF of INT OrgIDs)
# set(HASHREF OrgHashRef)
# add(HASHREF OrgHashRef)
# remove(INT OrgID)
#
#### Input Data Info
#
# OrgHashRef =>
# {
#     'Org_ID'    => INT
#     'Org_Name'  => ARRAYREF(5) STRING
#     'OrgCfg_ID' => INT
# }
#
####

1;
