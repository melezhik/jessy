package Adriver::DBI::Clients::ADOverStatClient;

use strict;
our $VERSION = '0.0300';
use Carp;
use Params::Validate qw(:all);
use base qw ( Adriver::DBI::Clients::BaseStatClient );

validation_options(on_fail => sub { Adriver::DBI::Exceptions::ParamsValidation->throw( error => $_[0]); } );

sub package { 'RLE::ADOverStatClient' }

#### Generic StatClient Functions
#
# GetTotal    (HASHREF ClientADRequestParamsHashRef)
# GetTable    (ARRAYREF of INT ADIDs, HASHREF ClientADRequestParamsHashRef)
# GetGeo      (ARRAYREF of INT GeoIDs, HASHREF ClientADRequestParamsHashRef)
# GetMonthDay (HASHREF ClientADRequestParamsHashRef)
# GetWeekDay  (HASHREF ClientADRequestParamsHashRef)
# GetDayHour  (HASHREF ClientADRequestParamsHashRef)
# GetUniStat  (HASHREF ClientADRequestParamsHashRef)
# GetGeoDays  (HASHREF ClientADRequestParamsHashRef)
#
#### Functions
#
## Get stat for all ADs of the user
#
# GetUserADs(HASHREF ClientADRequestParamsHashRef)
#
## Get stat for all ADs of the network
#
# GetNetworkADs(HASHREF ClientADRequestParamsHashRef)
#
## By sites
#
# GetSites(HASHREF ClientADRequestParamsHashRef)
#
## By categories (for network ads)
#
# GetSiteCat(ARRAYREF of INT ADIDs, HASHREF ClientADRequestParamsHashRef)
#
## By days adn categories
#
# GetSiteCatMonthDay(HASHREF ClientADRequestParamsHashRef)
#
## Get total for all default banners of the ad
#
# GetDefProfileTotal(HASHREF ClientADRequestParamsHashRef)
#
## Get geo for all default banners of the ad
#
# GetDefProfileGeo(ARRAYREF of INT GeoIDs, HASHREF ClientADRequestParamsHashRef)
#
## By days for all default banners of the ad
#
# GetDefProfileMonthDay(HASHREF ClientADRequestParamsHashRef)
#
## Average by weekday for all default banners of the ad
#
# GetDefProfileWeekDay(HASHREF ClientADRequestParamsHashRef)
#
## Average by dayhour for all default banners of the ad
#
# GetDefProfileDayHour(HASHREF ClientADRequestParamsHashRef)
#
#### Input Data Info
#
# HASHREF ClientADRequestParamsHashRef =>
# {
#     'adID'            => INT
#     'networkADType    => INT
#     'flags'           => INT    # Common flags for all stat clients
#
#     'startDate'       => INT    # For daily stats
#     'endDate'         => INT    # For daily stats
#
#     'userID'          => INT    # For GetSites()
#     'networkID'       => INT    # For GetSites()
#     'from'            => INT    # For GetSites()
#     'num'             => INT    # For GetSites()
#                                 # (// enum Sort{EXP = 1, CLICK = 2, CTR = 3} sort;)
#     'level'           => ARRAYREF(3) {'n'=>(?),'type'=>(?),'sort'=>INT,'sameUnder'=>(?)}
#
#     'ids'             => ARRAYREF(x) of ARRAYREF(3) INT
#
#     'siteID'          => INT
#     'siteZoneID'      => INT
#     'bannerSpec'      => INT
#     'siteCatIds'      => ARRAYREF(x) INT
#
#     'opcode'          => (?)    # Operation code OP_NONE = 0 OP_SUM = 1 OP_ILLEGAL = 2
#
#     # DO NOT SET/MODIFY!
#     'juuEventType'    => INT
#     'juuCatID'        => INT
#     'juuNetworkType'  => INT
#     'required_entity' => INT        # Set in C++ code ....
# }
#
## Flags
#
# MONTH_FIXED_LENGTH   0x2  // Using for BasePlotStat result. Result will have a fixed length size.
# GET_SUB_EVENT        0x4  // Set this bit to have subevents in result.
# GET_SITE_CATS        0x8  // Not used.
# DEFPROF_SUPPORT_FLAG 0x10 // Set this bit to get default stat data in all ad requsts (internal using).
# GET_UU_RANGE         0x20 // Set this bit to get UU in GetMonthDay reqests.
#
####

sub GetUserADs
{
    validate_pos(@_, { type => OBJECT }, { type => HASHREF });
    my ($self, @args) = @_;

    my $result;
    eval { $result = $self->{client}->GetUserADs(@args); };
    if (my $e = Adriver::DBI::Exceptions::DBError->caught())
    {
        Adriver::DBI::Exceptions::Clients->throw(
            error  => Adriver::ErrorMessage::error_message($e),
            code   => $e->{code},
            method => 'GetUserADs',
            args   => \@args
        );
    }

    return $result;
}

sub GetNetworkADs
{
    validate_pos(@_, { type => OBJECT }, { type => HASHREF });
    my ($self, @args) = @_;

    my $result;
    eval { $result = $self->{client}->GetNetworkADs(@args); };
    if (my $e = Adriver::DBI::Exceptions::DBError->caught())
    {
        Adriver::DBI::Exceptions::Clients->throw(
            error  => Adriver::ErrorMessage::error_message($e),
            code   => $e->{code},
            method => 'GetNetworkADs',
            args   => \@args
        );
    }

    return $result;
}

sub GetSites
{
    validate_pos(@_, { type => OBJECT }, { type => HASHREF });
    my ($self, @args) = @_;

    my $result;
    eval { $result = $self->{client}->GetSites(@args); };
    if (my $e = Adriver::DBI::Exceptions::DBError->caught())
    {
        Adriver::DBI::Exceptions::Clients->throw(
            error  => Adriver::ErrorMessage::error_message($e),
            code   => $e->{code},
            method => 'GetSites',
            args   => \@args
        );
    }

    return $result;
}

sub GetSiteCat
{
    validate_pos(@_, { type => OBJECT }, { type => ARRAYREF }, { type => HASHREF });
    my ($self, @args) = @_;

    my $result;
    eval { $result = $self->{client}->GetSiteCat(@args); };
    if (my $e = Adriver::DBI::Exceptions::DBError->caught())
    {
        Adriver::DBI::Exceptions::Clients->throw(
            error  => Adriver::ErrorMessage::error_message($e),
            code   => $e->{code},
            method => 'GetSiteCat',
            args   => \@args
        );
    }

    return $result;
}

sub GetSiteCatMonthDay
{
    validate_pos(@_, { type => OBJECT }, { type => HASHREF });
    my ($self, @args) = @_;

    my $result;
    eval { $result = $self->{client}->GetSiteCatMonthDay(@args); };
    if (my $e = Adriver::DBI::Exceptions::DBError->caught())
    {
        Adriver::DBI::Exceptions::Clients->throw(
            error  => Adriver::ErrorMessage::error_message($e),
            code   => $e->{code},
            method => 'GetSiteCatMonthDay',
            args   => \@args
        );
    }

    return $result;
}

sub GetDefProfileTotal
{
    validate_pos(@_, { type => OBJECT }, { type => HASHREF });
    my ($self, @args) = @_;

    my $result;
    eval { $result = $self->{client}->GetDefProfileTotal(@args); };
    if (my $e = Adriver::DBI::Exceptions::DBError->caught())
    {
        Adriver::DBI::Exceptions::Clients->throw(
            error  => Adriver::ErrorMessage::error_message($e),
            code   => $e->{code},
            method => 'GetDefProfileTotal',
            args   => \@args
        );
    }

    return $result;
}

sub GetDefProfileGeo
{
    validate_pos(@_, { type => OBJECT }, { type => ARRAYREF }, { type => HASHREF });
    my ($self, @args) = @_;

    my $result;
    eval { $result = $self->{client}->GetDefProfileGeo(@args); };
    if (my $e = Adriver::DBI::Exceptions::DBError->caught())
    {
        Adriver::DBI::Exceptions::Clients->throw(
            error  => Adriver::ErrorMessage::error_message($e),
            code   => $e->{code},
            method => 'GetDefProfileGeo',
            args   => \@args
        );
    }

    return $result;
}

sub GetDefProfileMonthDay
{
    validate_pos(@_, { type => OBJECT }, { type => HASHREF });
    my ($self, @args) = @_;

    my $result;
    eval { $result = $self->{client}->GetDefProfileMonthDay(@args); };
    if (my $e = Adriver::DBI::Exceptions::DBError->caught())
    {
        Adriver::DBI::Exceptions::Clients->throw(
            error  => Adriver::ErrorMessage::error_message($e),
            code   => $e->{code},
            method => 'GetDefProfileMonthDay',
            args   => \@args
        );
    }

    return $result;
}

sub GetDefProfileWeekDay
{
    validate_pos(@_, { type => OBJECT }, { type => HASHREF });
    my ($self, @args) = @_;

    my $result;
    eval { $result = $self->{client}->GetDefProfileWeekDay(@args); };
    if (my $e = Adriver::DBI::Exceptions::DBError->caught())
    {
        Adriver::DBI::Exceptions::Clients->throw(
            error  => Adriver::ErrorMessage::error_message($e),
            code   => $e->{code},
            method => 'GetDefProfileWeekDay',
            args   => \@args
        );
    }

    return $result;
}

sub GetDefProfileDayHour
{
    validate_pos(@_, { type => OBJECT }, { type => HASHREF });
    my ($self, @args) = @_;

    my $result;
    eval { $result = $self->{client}->GetDefProfileDayHour(@args); };
    if (my $e = Adriver::DBI::Exceptions::DBError->caught())
    {
        Adriver::DBI::Exceptions::Clients->throw(
            error  => Adriver::ErrorMessage::error_message($e),
            code   => $e->{code},
            method => 'GetDefProfileDayHour',
            args   => \@args
        );
    }

    return $result;
}

1;


__END__


=head1 NAME

    Adriver::DBI::Clients::ADOverStatClient - this module provides methods to get
    statistics by advertizing companies.


=head1 DESCRIPTION

    This module is inherited from Adriver::DBI::Clients::BaseStatClient class.


=head1 SYNOPSIS

    use Adriver::DBI::Stat;
    use Adriver::DatabaseConnect::Stat;
    use Adriver::Exceptions;
    use Data::Dumper;

    my $config_file = '../stat4perl.conf';

    eval
    {
        my $dbh = Adriver::DBI::Stat->new(
            Adriver::DatabaseConnect::Stat->new(config_file => $config_file)
        );

        my $banner_id = 413634;
        my $ad_info = $dbh->AD->GetTotal({ 'bannerID' => $banner_id });
        print Dumper($ad_info);

        my $user_id = 98291;
        my $ad_info = $dbh->AD->GetUserADs({ 'userID' => $user_id });
        print Dumper($ad_info);

        my $site_id = 98291;
        my $ad_info = $dbh->AD->GetUserADs({ 'siteID' => $site_id });
        print Dumper($ad_info);
    };

    if (my $e = Exception::Class->caught('Adriver::Exceptions'))
    {
        die "Caught Adriver::Exceptions: '", $e->error, "'\n", $e->trace->as_string, "\n";
    }
    elsif ($e = Exception::Class->caught('Exception::Class::Base'))
    {
        die "Caught unknown exception: '", $e->error, "'\n", $e->trace->as_string, "\n";
    }
    elsif ($e = Exception::Class->caught)
    {
        die "$e";
    }


=head1 INHERITED OBJECT INTERFACE

=head2 GetTotal($ClientADRequestParamsHashRef)

    Get total stat for advertizing company.

B<ClientADRequestParamsHashRef>

    This is a hash reference with next structure:

    ClientADRequestParamsHashRef =>
    {
        'adID'            => INT
        'networkADType    => INT
        'flags'           => INT    # Common flags for all stat clients

        'startDate'       => INT    # For daily stats
        'endDate'         => INT    # For daily stats

        'userID'          => INT    # For GetSites()
        'networkID'       => INT    # For GetSites()
        'from'            => INT    # For GetSites()
        'num'             => INT    # For GetSites()
                                 # (// enum Sort{EXP = 1, CLICK = 2, CTR = 3} sort;)
        'level'           => ARRAYREF(3) {'n'=>(?),'type'=>(?),'sort'=>INT,'sameUnder'=>(?)}

        'ids'             => ARRAYREF(x) of ARRAYREF(3) INT

        'siteID'          => INT
        'siteZoneID'      => INT
        'bannerSpec'      => INT
        'siteCatIds'      => ARRAYREF(x) INT

        'opcode'          => (?)    # Operation code OP_NONE = 0 OP_SUM = 1 OP_ILLEGAL = 2

        # DO NOT SET/MODIFY!
        'juuEventType'    => INT
        'juuCatID'        => INT
        'juuNetworkType'  => INT
        'required_entity' => INT        # Set in C++ code ....
    }

B<Flags>

    MONTH_FIXED_LENGTH   0x2  // Using for BasePlotStat result. Result will have a fixed length size.
    GET_SUB_EVENT        0x4  // Set this bit to have subevents in result.
    GET_SITE_CATS        0x8  // Not used.
    DEFPROF_SUPPORT_FLAG 0x10 // Set this bit to get default stat data in all ad requsts (internal using).
    GET_UU_RANGE         0x20 // Set this bit to get UU in GetMonthDay reqests.

B<Exceptions>

    Adriver::DBI::Exceptions::ParamsValidation
    Adriver::DBI::Exceptions::Clients

=head2 GetTable($ADIDs, $ClientADRequestParamsHashRef)

    Get total stats for list of advertizing companies with specified identifiers.

B<ADIDs>

    ARRAYREF of INT companies identifiers.

B<ClientADRequestParamsHashRef>

    This is the same hash reference as described in GetTotal() method.

B<Exceptions>

    Adriver::DBI::Exceptions::ParamsValidation
    Adriver::DBI::Exceptions::Clients

=head2 GetGeo($GeoIDs, $ClientADRequestParamsHashRef)

    Get geo stat for advertizing company.
    If GeoIDs specified only for this GeoIDs.
    If GeoIDs empty for all GeoIDs.

B<GeoIDs>

    ARRAYREF of INT GeoIDs.

B<ClientADRequestParamsHashRef>

    This is the same hash reference as described in GetTotal() method.

B<Exceptions>

    Adriver::DBI::Exceptions::ParamsValidation
    Adriver::DBI::Exceptions::Clients

=head2 GetMonthDay($ClientADRequestParamsHashRef)

    Get statistics for company by days.

B<ClientADRequestParamsHashRef>

    This is the same hash reference as described in GetTotal() method.

B<Exceptions>

    Adriver::DBI::Exceptions::ParamsValidation
    Adriver::DBI::Exceptions::Clients

=head2 GetWeekDay($ClientADRequestParamsHashRef)

    Get average statistics for company by weekday.

B<ClientADRequestParamsHashRef>

    This is the same hash reference as described in GetTotal() method.

B<Exceptions>

    Adriver::DBI::Exceptions::ParamsValidation
    Adriver::DBI::Exceptions::Clients

=head2 GetDayHour($ClientADRequestParamsHashRef)

    Get average statistics for company by dayhour.

B<ClientADRequestParamsHashRef>

    This is the same hash reference as described in GetTotal() method.

B<Exceptions>

    Adriver::DBI::Exceptions::ParamsValidation
    Adriver::DBI::Exceptions::Clients

=head2 GetUniStat($ClientADRequestParamsHashRef)

    Universal stat request.

B<ClientADRequestParamsHashRef>

    This is the same hash reference as described in GetTotal() method.

B<Exceptions>

    Adriver::DBI::Exceptions::ParamsValidation
    Adriver::DBI::Exceptions::Clients

=head2 GetGeoDays($ClientADRequestParamsHashRef)

    Geo stat by days.

B<ClientADRequestParamsHashRef>

    This is the same hash reference as described in GetTotal() method.

B<Exceptions>

    Adriver::DBI::Exceptions::ParamsValidation
    Adriver::DBI::Exceptions::Clients

=head2 GetDaysCount($ClientADRequestParamsHashRef)

    Get begindate, enddate and diff (in weeks).

B<ClientADRequestParamsHashRef>

    This is the same hash reference as described in GetTotal() method.

B<Exceptions>

    Adriver::DBI::Exceptions::ParamsValidation
    Adriver::DBI::Exceptions::Clients


=head1 OBJECT INTERFACE

=head2 GetUserADs($ClientADRequestParamsHashRef)

    Get stat for all advertizing companies of the user.

B<ClientADRequestParamsHashRef>

    This is the same hash reference as described in GetTotal() method.

B<Exceptions>

    Adriver::DBI::Exceptions::ParamsValidation
    Adriver::DBI::Exceptions::Clients

=head2 GetNetworkADs($ClientADRequestParamsHashRef)

    Get stat for all advertizing companies of the network.

B<ClientADRequestParamsHashRef>

    This is the same hash reference as described in GetTotal() method.

B<Exceptions>

    Adriver::DBI::Exceptions::ParamsValidation
    Adriver::DBI::Exceptions::Clients

=head2 GetSites($ClientADRequestParamsHashRef)

    Get statistics by sites.

B<ClientADRequestParamsHashRef>

    This is the same hash reference as described in GetTotal() method.

B<Exceptions>

    Adriver::DBI::Exceptions::ParamsValidation
    Adriver::DBI::Exceptions::Clients

=head2 GetSiteCat($ADIDs, $ClientADRequestParamsHashRef)

    By categories (for network ads).

B<ADIDs>

    ARRAYREF of INT companies identifiers.

B<ClientADRequestParamsHashRef>

    This is the same hash reference as described in GetTotal() method.

B<Exceptions>

    Adriver::DBI::Exceptions::ParamsValidation
    Adriver::DBI::Exceptions::Clients

=head2 GetSiteCatMonthDay($ClientADRequestParamsHashRef)

    By days adn categories.

B<ClientADRequestParamsHashRef>

    This is the same hash reference as described in GetTotal() method.

B<Exceptions>

    Adriver::DBI::Exceptions::ParamsValidation
    Adriver::DBI::Exceptions::Clients

=head2 GetDefProfileTotal($ClientADRequestParamsHashRef)

    Get total for all default banners of the advertizing company.

B<ClientADRequestParamsHashRef>

    This is the same hash reference as described in GetTotal() method.

B<Exceptions>

    Adriver::DBI::Exceptions::ParamsValidation
    Adriver::DBI::Exceptions::Clients

=head2 GetDefProfileGeo($ClientADRequestParamsHashRef)

    Get geo for all default banners of the advertizing company.

B<ClientADRequestParamsHashRef>

    This is the same hash reference as described in GetTotal() method.

B<Exceptions>

    Adriver::DBI::Exceptions::ParamsValidation
    Adriver::DBI::Exceptions::Clients

=head2 GetDefProfileMonthDay($ClientADRequestParamsHashRef)

    By days for all default banners of the advertizing company.

B<ClientADRequestParamsHashRef>

    This is the same hash reference as described in GetTotal() method.

B<Exceptions>

    Adriver::DBI::Exceptions::ParamsValidation
    Adriver::DBI::Exceptions::Clients

=head2 GetDefProfileWeekDay($ClientADRequestParamsHashRef)

    Average by weekday for all default banners of the advertizing company.

B<ClientADRequestParamsHashRef>

    This is the same hash reference as described in GetTotal() method.

B<Exceptions>

    Adriver::DBI::Exceptions::ParamsValidation
    Adriver::DBI::Exceptions::Clients

=head2 GetDefProfileDayHour($ClientADRequestParamsHashRef)

    Average by dayhour for all default banners of the advertizing company.

B<ClientADRequestParamsHashRef>

    This is the same hash reference as described in GetTotal() method.

B<Exceptions>

    Adriver::DBI::Exceptions::ParamsValidation
    Adriver::DBI::Exceptions::Clients


=head1 SEE ALSO

    Adriver::DBI::Clients::BaseStatClient
    Adriver::DBI::Exceptions

