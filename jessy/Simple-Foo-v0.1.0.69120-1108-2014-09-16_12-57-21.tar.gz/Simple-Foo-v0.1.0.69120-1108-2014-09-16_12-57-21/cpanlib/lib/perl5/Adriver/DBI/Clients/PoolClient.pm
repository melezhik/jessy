package Adriver::DBI::Clients::PoolClient;

use strict;
our $VERSION = '0.0300';
use Carp;
use Params::Validate qw(:all);
use base qw ( Adriver::DBI::Clients::BaseID );

validation_options(on_fail => sub { Adriver::DBI::Exceptions::ParamsValidation->throw( error => $_[0]); } );

sub package { 'RLE::PoolClient' }

#### Generic BaseID Functions
#
# get(INT PoolID)
# getids()
# getlist(ARRAYREF of INT PoolIDs)
# set(HASHREF PoolHashRef)
# add(HASHREF PoolHashRef)
# remove(INT PoolID)
#
#### Other Functions
#
## Increment exposures or click in pool with PoolID
## DONOT USE THIS METHODS IN IFACES! SPECIAL SYSTEM CALLS!
#
# (INT PoolID) exposure(INT PoolID)
# (INT PoolID) click(INT PoolID)
#
## Sets exposures or click counter in pool with PoolID
#
# (INT PoolID) set_exposures_counter(INT PoolID, HASHREF CounterHashRef)
# (INT PoolID) set_clicks_counter(INT PoolID, HASHREF CounterHashRef)
#
#### Input Data Info
#
# CounterHashRef =>
# {
#     'today'     => INT
#     'yesterday' => INT
#     'week'      => INT
#     'last_week' => INT
#     'total'     => INT
# }
#
# PoolHashRef =>
# {
#     'poolID'       => INT
#     'poolName'     => STRING
#     'shortName'    => STRING
#     'enables'      => ARRAYREF(32) BOOL
#     'creationTime' => INT
#     'exposures'    => HourlyCounterHashRef
#     'clicks'       => HourlyCounterHashRef
# }
#
####

sub exposure
{
    validate_pos(@_, { type => OBJECT },
        { type => SCALAR, regex => qr/^\d+$/ }, # INT PoolID
    );
    my ($self, @args) = @_;

    my $result;
    eval { $result = $self->{client}->exposure(@args); };
    if (my $e = Adriver::DBI::Exceptions::DBError->caught())
    {
        Adriver::DBI::Exceptions::Clients->throw(
            error  => Adriver::ErrorMessage::error_message($e),
            code   => $e->{code},
            method => 'exposure',
            args   => \@args
        );
    }

    return $result;
}

sub click
{
    validate_pos(@_, { type => OBJECT },
        { type => SCALAR, regex => qr/^\d+$/ }, # INT PoolID
    );
    my ($self, @args) = @_;

    my $result;
    eval { $result = $self->{client}->click(@args); };
    if (my $e = Adriver::DBI::Exceptions::DBError->caught())
    {
        Adriver::DBI::Exceptions::Clients->throw(
            error  => Adriver::ErrorMessage::error_message($e),
            code   => $e->{code},
            method => 'click',
            args   => \@args
        );
    }

    return $result;
}

sub set_exposures_counter
{
    validate_pos(@_, { type => OBJECT },
        { type => SCALAR, regex => qr/^\d+$/ }, # INT PoolID
        { type => HASHREF },                    # HASHREF CounterHashRef
    );
    my ($self, @args) = @_;

    my $result;
    eval { $result = $self->{client}->set_exposures_counter(@args); };
    if (my $e = Adriver::DBI::Exceptions::DBError->caught())
    {
        Adriver::DBI::Exceptions::Clients->throw(
            error  => Adriver::ErrorMessage::error_message($e),
            code   => $e->{code},
            method => 'set_exposures_counter',
            args   => \@args
        );
    }

    return $result;
}

sub set_clicks_counter
{
    validate_pos(@_, { type => OBJECT },
        { type => SCALAR, regex => qr/^\d+$/ }, # INT PoolID
        { type => HASHREF },                    # HASHREF CounterHashRef
    );
    my ($self, @args) = @_;

    my $result;
    eval { $result = $self->{client}->set_clicks_counter(@args); };
    if (my $e = Adriver::DBI::Exceptions::DBError->caught())
    {
        Adriver::DBI::Exceptions::Clients->throw(
            error  => Adriver::ErrorMessage::error_message($e),
            code   => $e->{code},
            method => 'set_clicks_counter',
            args   => \@args
        );
    }

    return $result;
}

1;


__END__


=head1 NAME

    Adriver::DBI::Clients::PoolClient - this module provides methods to work with
    Adriver pools database.


=head1 DESCRIPTION

    This module is inherited from Adriver::DBI::Clients::BaseID class.


=head1 SYNOPSIS

    use Adriver::DBI;
    use Adriver::DatabaseConnect::Adriver;
    use Adriver::Exceptions;

    my $host = 'f2.x';
    my $port = 16000;

    eval
    {
        my $dbh = Adriver::DBI->new( Adriver::DatabaseConnect::Adriver->new({host => $host, port => $port}) );

        my $pool_id = 592;
        my $pool = $dbh->Pool->get($pool_id);
        print Dumper($pool);

        my $db_info = $dbh->Pool->GetCaps();
        print Dumper($db_info);

        my $ids = $dbh->Pool->getids();
        print Dumper($ids);

        my @pool_ids = (583, 598, 619);
        my $pools = $dbh->Pool->getlist(\@pool_ids);
        print Dumper($pools);

        $dbh->Pool->set($pool);
    };

    if (my $e = Exception::Class->caught('Adriver::Exceptions'))
    {
        die "Caught Adriver::Exceptions: '", $e->error, "'\n", $e->trace->as_string, "\n";
    }
    elsif ($e = Exception::Class->caught('Exception::Class::Base'))
    {
        die "Caught unknown exception: '", $e->error, "'\n", $e->trace->as_string, "\n";
    }
    elsif ($e = Exception::Class->caught)
    {
        die "$e";
    }


=head1 INHERITED OBJECT INTERFACE

=head2 get($pool_id) : $PoolHashRef

    Get certain pool from database by it's identifier.

B<pool_id>

    This is the integer identifier of pool.

B<PoolHashRef>

    This is a hash reference with next structure:

    PoolHashRef =>
    {
        'poolID'       => INT
        'poolName'     => STRING
        'shortName'    => STRING
        'enables'      => ARRAYREF(32) BOOL
        'creationTime' => INT
        'exposures'    => HourlyCounterHashRef
        'clicks'       => HourlyCounterHashRef
    }

    where

    HourlyCounterHashRef =>
    {
        'today'     => INT
        'yesterday' => INT
        'week'      => INT
        'last_week' => INT
        'total'     => INT
        'last_hour' => INT
    }

B<Exceptions>

    Adriver::DBI::Exceptions::ParamsValidation
    Adriver::DBI::Exceptions::Clients

=head2 getids() : $pool_ids

    This method returns a list of all pool identifiers from database.

B<pool_ids>

    This is the array reference with obtained pool identifiers.

B<Exceptions>

    Adriver::DBI::Exceptions::ParamsValidation
    Adriver::DBI::Exceptions::Clients

=head2 getlist(\@pool_ids) : ARRAYREF of $PoolHashRef

    This method returns a list of pools from database by their identifiers.

B<pool_ids>

    This is the array reference with pool identifiers you want to get.

B<PoolHashRef>

    This is the same hash reference as described in get() method.

B<Exceptions>

    Adriver::DBI::Exceptions::ParamsValidation
    Adriver::DBI::Exceptions::Clients

=head2 set($PoolHashRef) : undef

    This method updates given pool in database.

B<PoolHashRef>

    This is the same hash reference as described in get() method.

B<Exceptions>

    Adriver::DBI::Exceptions::ParamsValidation
    Adriver::DBI::Exceptions::Clients

=head2 add($PoolHashRef) : $pool_id

    This method adds the new pool in database and returns it's identifier.

B<PoolHashRef>

    This is the same hash reference as described in get() method.

B<pool_id>

    This is the integer identifier of added pool.

B<Exceptions>

    Adriver::DBI::Exceptions::ParamsValidation
    Adriver::DBI::Exceptions::Clients

=head2 remove($pool_id) : undef

    This method removes pool from database by it's identifier.

B<pool_id>

    This is the pool identifier you want to remove.

B<Exceptions>

    Adriver::DBI::Exceptions::ParamsValidation
    Adriver::DBI::Exceptions::Clients


=head1 OBJECT INTERFACE

=head2 exposure($pool_id) : $pool_id

    This method icrements the number of pool exposures.
    DONOT USE THIS METHODS IN IFACES! SPECIAL SYSTEM CALLS!

B<pool_id>

    This is the pool identifier which exposures counter you want to increase.

B<Exceptions>

    Adriver::DBI::Exceptions::ParamsValidation
    Adriver::DBI::Exceptions::Clients

=head2 click($pool_id) : $pool_id

    This method icrements the number of pool clicks.
    DONOT USE THIS METHODS IN IFACES! SPECIAL SYSTEM CALLS!

B<pool_id>

    This is the pool identifier which clicks counter you want to increase.

B<Exceptions>

    Adriver::DBI::Exceptions::ParamsValidation
    Adriver::DBI::Exceptions::Clients

=head2 set_exposures_counter($pool_id, $HourlyCounterHashRef) : $pool_id

    This method sets the counter of pool exposures.

B<pool_id>

    This is the pool identifier which exposures counter you want to set.

B<HourlyCounterHashRef>

    This is the same hash reference as described in get() method.

B<Exceptions>

    Adriver::DBI::Exceptions::ParamsValidation
    Adriver::DBI::Exceptions::Clients

=head2 set_clicks_counter($pool_id, $HourlyCounterHashRef) : $pool_id

    This method sets the counter of pool clicks.

B<pool_id>

    This is the pool identifier which clicks counter you want to set.

B<HourlyCounterHashRef>

    This is the same hash reference as described in get() method.

B<Exceptions>

    Adriver::DBI::Exceptions::ParamsValidation
    Adriver::DBI::Exceptions::Clients


=head1 SEE ALSO

    Adriver::DBI::Clients::BaseID
    Adriver::DBI::Exceptions

