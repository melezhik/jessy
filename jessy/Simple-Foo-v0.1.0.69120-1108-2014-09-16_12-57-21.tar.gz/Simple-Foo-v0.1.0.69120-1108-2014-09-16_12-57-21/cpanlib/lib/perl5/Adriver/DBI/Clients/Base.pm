package Adriver::DBI::Clients::Base;

use strict;
our $VERSION = '0.0300';
use Carp;
use Adriver::Loader;
use Adriver::ErrorMessage;
use Adriver::DBI::Exceptions;

sub version { undef }

sub new
{
    my $self = {};
    my $that = shift;
    my $class = ref($that) || $that;
    bless($self, $class);

    my @args = @_;
    my $package = $self->package;
    my $version = $self->version;
    client_so_loader($package,$version);
    $self->{'client'} = new $package(@args);
    $self->{'client'}->{'ERRHAND'} = \&ExceptionHandler;

    return $self;
}

sub ExceptionHandler
{
    # my $ec = $_[0];
    Adriver::DBI::Exceptions::DBError->throw(
        'code'     => $_[0]->{'code'},
        'messages' => $_[0]->{'messages'},
        # 'what'    => $_[0]->{'what'},
        # 'type'    => $_[0]->{'type'},
        # 'catch'   => $_[0]->{'catch'},
    );
    return;
}

sub GetCaps
{
    my $self = shift;

    my $db_info;
    eval {
        $db_info =  $self->{'client'}->GetCaps();
    };

    return $db_info;
}


1;

__END__


=head1 NAME

    Adriver::DBI::Clients::Base - this module contains some common methods for all Adriver::DBI::Clients modules.


=head1 DESCRIPTION

    You should not use this module directly. It's used like as a basic class for all Adriver::DBI::Clients modules
    and implemets some common methods for them.


=head1 CLASS AND OBJECT INTERFACE

=head2 new(@args) : some Adriver::DBI::Clients object

    Create the new object of some Adriver::DBI::Clients class. We use Adriver::Loader module and its client_so_loader()
    procedure to load appropriate binary C++ class.

B<args>

    This is an array of input parameters passed to constructor of loaded C++ binary class.

B<Exceptions>

    Adriver::DBI::Exceptions::ParamsValidation

=head2 GetCaps() : $InfoHashRef

    This method returns information about server database and client.

B<InfoHashRef>

    This is a hash reference with getted information.

=head2 ExceptionHandler($error)

    This is exception handler method. It's used to translate C++ code exceptions into perl Exception::Class exceptions.
    When you call this method it initiates exception of Adriver::DBI::Exceptions::DBError class.

B<error>

    This is a hash reference with two keys:
    <code> - error code;
    <messages> - error message.


=head1 SEE ALSO

    Adriver::Loader
    Adriver::DBI::Exceptions

