package Adriver::DBI::TT;

use strict;
our $VERSION = '0.0300';
use Carp;
use Adriver::Socket::FakeSocket;
use Params::Validate qw(:all);

use base qw( Adriver::DBI::Base );

validation_options(on_fail => sub { Adriver::DBI::Exceptions::ParamsValidation->throw(error => $_[0]); });

my $accessors = {
   TT => { class_name => 'Adriver::DBI::Clients::TtClient' },
};

# Generate DB accessors methods
__PACKAGE__->ACCESSORS($accessors);

sub new
{
    validate_pos(@_, { type => SCALAR }, { type => OBJECT, isa => 'Adriver::DatabaseConnect::TT'});
    my ($self, $connect) = @_;
    my $dbh = bless {}, $self;
    # we cant work without connection
    #     unless ($connect) {
    #         Adriver::DBI::Exceptions->throw(error => 'Connection is needed for Adriver::DBI::TT::new(Adriver::DatabaseConnect::TT()).');
    #     }
    # store connection
    $dbh->{'connect'} = $connect;
    return $dbh;
}

sub get_client
{
    validate_pos(@_, { type => OBJECT }, { type => SCALAR });
    my ($self, $name) = @_;
    if (!$self->{'dbclient_inst'}->{$name}) {
        $self->{'connect'}->connect();
        my $fakeSocket = new Adriver::Socket::FakeSocket($self->{'connect'}->{'connect'});
        $self->{'dbclient_inst'}->{$name} = Adriver::Client->new({'class' => $name, 'socket' => $fakeSocket});
    }
    return $self->{'dbclient_inst'}->{$name}->client();
}

1;


__END__


=head1 NAME

    Adriver::DBI::TT - this module provides an interface for communication with Trait database.


=head1 DESCRIPTION

    This module contains a list of Trait database clients which can get all needed information from it.
    What you need to know that is which client can get information you want to get. For each database client
    there is accessor method. When you call accessor you get control under the object of corresponded client
    class. This module is inherited from Adriver::DBI::Base class.


=head1 SYNOPSIS

    use Adriver::DBI::TT;
    use Adriver::DatabaseConnect::TT;
    use Adriver::Exceptions;

    my $trait_id = 8;
    my @db_servers;
    push @db_servers, {host => 'trait1.adriver.x', port => 6660, 'num' => 1};

    eval
    {
        my $dbh = Adriver::DBI::TT->new( Adriver::DatabaseConnect::TT->new(\@db_servers) );

        my $counters = $dbh->TT->GetTraitCounters($trait_id);
        print Dumper($counters);
    };

    if (my $e = Exception::Class->caught('Adriver::Exceptions'))
    {
        die "Caught Adriver::Exceptions: '", $e->error, "\n", $e->trace->as_string, "\n";
    }
    elsif ($e = Exception::Class->caught('Exception::Class::Base'))
    {
        die "Caught unknown exception: '", $e->error, "\n", $e->trace->as_string, "\n";
    }
    elsif ($e = Exception::Class->caught)
    {
        die "$e";
    }


=head1 ACCESSORS AND CORRESPONDED CLIENTS

    TT  =>  Adriver::DBI::Clients::TtClient


=head1 CLASS INTERFACE

=head2 new($tt_connect) : Adriver::DBI::TT object

    Create the new object of class.

B<tt_connect>

    This is Adriver::DatabaseConnect::TT object or it's child.

B<Exceptions>

    Adriver::DBI::Exceptions::ParamsValidation


=head1 OBJECT PRIVATE INTERFACE

=head2 get_client($class_name) : some Adriver::DBI::Client class object 

    This method overrides the method of the same name from Adriver::DBI::Base class object.
    We can't use method of Adriver::DBI::Base class because for communication with Trait database
    we don't use any real socket class, so we override it to use fake socket from
    Adriver::Socket::FakeSocket class.


=head1 SEE ALSO

    Adriver::DatabaseConnect::TT
    Adriver::Socket::FakeSocket
    Adriver::Exceptions
    Adriver::DBI::Exceptions
    Adriver::DBI::Base
    Adriver::Client
    Database clients classes

