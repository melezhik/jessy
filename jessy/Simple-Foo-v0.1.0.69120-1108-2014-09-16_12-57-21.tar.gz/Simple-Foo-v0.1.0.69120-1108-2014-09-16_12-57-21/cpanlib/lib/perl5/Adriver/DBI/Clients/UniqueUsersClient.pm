package Adriver::DBI::Clients::UniqueUsersClient;

use strict;
our $VERSION = '0.0300';
use Carp;
use Params::Validate qw(:all);
use base qw ( Adriver::DBI::Clients::Base );

validation_options(on_fail => sub { Adriver::DBI::Exceptions::ParamsValidation->throw( error => $_[0]); } );

sub package { 'RLE::UniqueUsersClient' }

#####################################
############## AHTUNG! ##############
#### This client may not work :) ####
#### Use it on your own risk     ####
#### Better don't use at it all  ####
########## Have a nice day ##########
#####################################

1;
