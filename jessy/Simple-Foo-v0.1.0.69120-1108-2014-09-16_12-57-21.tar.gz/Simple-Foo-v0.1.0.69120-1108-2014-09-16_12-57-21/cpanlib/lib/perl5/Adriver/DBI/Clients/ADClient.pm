package Adriver::DBI::Clients::ADClient;

use strict;
our $VERSION = '0.0300';
use Carp;
use Params::Validate qw(:all);
use base qw ( Adriver::DBI::Clients::BaseID );

validation_options(on_fail => sub { Adriver::DBI::Exceptions::ParamsValidation->throw( error => $_[0]); } );

sub package { 'RLE::ADClient' }

#### Generic BaseID Functions
#
# get(INT ADID)
# getids()
# getlist(ARRAYREF of INT ADIDs)
# set(HASHREF ADHashRef)
# add(HASHREF ADHashRef)
# remove(INT ADID)
#
#### Other Functions
#
## Increment exposures or click in ad with ADID
## DONOT USE THIS METHODS IN IFACES! SPECIAL SYSTEM CALLS!
#
# (INT 1) exposure(INT ADID)
# (INT 1) click(INT ADID)
#
## Sets exposures or click counter in ad with ADID
#
# (INT 1) set_exposures_counter(INT ADID, HASHREF CounterHashRef)
# (INT 1) set_clicks_counter(INT ADID, HASHREF CounterHashRef)
#
## Set or add Amount credits for AD
#
# (INT NewAmount) add_credit(INT ADID, INT Amount)
# (INT NewAmount) set_credit(INT ADID, INT Amount)
#
## Get top-list for counter, specified in CounterHashRefMask ("counter" => 1)
## Input param Number is the number of elements in the top-list
## Its highly recommended to set to 1 only one counter
## (if you set many, func will use only one)
## If list of the ADIDs is specified, func get toplist from this list
#
# (ARRAYREF of HASHREF ADs) get_top_exposures(HASHREF CounterHashRefMask, INT Number[, ARRAYREF of INT ADIDs])
# (ARRAYREF of HASHREF ADs) get_top_clicks(HASHREF CounterHashRefMask, INT Number[, ARRAYREF of INT ADIDs])
#
## Get ADs for mask ADHashRefMask
## Elements in mask is substrs for search in base
## If list of the ADIDs is specified, func get ADs from this list
#
# (ARRAYREF of HASHREF ADs) get_ex(HASHREF ADHashRefMask[, ARRAYREF of INT ADIDs])
#
## Rotate counter in all ads
## DONOT USE THIS METHODS IN IFACES! SPECIAL SYSTEM CALLS!
#
# (void) rotate_daily()
# (void) rotate_weekly()
#
#### Input Data Info
#
# CounterHashRef =>
# {
#     'today'     => INT
#     'yesterday' => INT
#     'week'      => INT
#     'last_week' => INT
#     'total'     => INT
# }
#
# CounterHashRefMask =>
# {
#     'today'     => BOOL
#     'yesterday' => BOOL
#     'week'      => BOOL
#     'last_week' => BOOL
#     'total'     => BOOL
# }
#
# ADHashRefMask =>
# {
#     'adName'      => STRING
#     'email'       => STRING
#     'supportName' => STRING
#     'shortName'   => STRINT
# }
#
# ADHashRef =>
# {
#     'adID'                  => INT
#     'adName'                => STRING
#     'shortName'             => STRING
#     'supportName'           => STRING
#     'email'                 => STRING
#     'credit'                => INT
#     'can_borrow'            => BOOL
#     'uniqueUserMinInterval' => INT
#     'creationTime'          => INT (?)
#     'enable'                => BOOL
#     'enables'               => ARRAYREF(128) BOOL
#     'exposures'             => CounterHashRef
#     'clicks'                => CounterHashRef
#     'uniqueUserMaxShows'    => ARRAYREF(3) INT
#     'uniqueUserMaxClicks'   => INT
#     'retargetingInfo'       =>
#     {
#       'objectID'   => 0,
#       'options'    => ARRAYREF(32) INT (?BOOL)
#       'objectType' => 0
#     },
#    'reach' =>
#     {
#       'period' => 0,
#       'limit' => 0,
#       'total' => 0
#     },
# }
#
####

sub exposure
{
    validate_pos(@_, { type => OBJECT },
        { type => SCALAR, regex => qr/^\d+$/ }, # INT ADID
    );
    my ($self, @args) = @_;

    my $result;
    eval { $result = $self->{client}->exposure(@args); };
    if (my $e = Adriver::DBI::Exceptions::DBError->caught())
    {
        Adriver::DBI::Exceptions::Clients->throw(
            error  => Adriver::ErrorMessage::error_message($e),
            code   => $e->{code},
            method => 'exposure',
            args   => \@args
        );
    }

    return $result;
}

sub click
{
    validate_pos(@_, { type => OBJECT },
        { type => SCALAR, regex => qr/^\d+$/ }, # INT ADID
    );
    my ($self, @args) = @_;

    my $result;
    eval { $result = $self->{client}->click(@args); };
    if (my $e = Adriver::DBI::Exceptions::DBError->caught())
    {
        Adriver::DBI::Exceptions::Clients->throw(
            error  => Adriver::ErrorMessage::error_message($e),
            code   => $e->{code},
            method => 'click',
            args   => \@args
        );
    }

    return $result;
}

sub set_reach_counter
{
    # set_reach_counter($Id, {period => 2, limit => 100, total => 100})
    validate_pos(@_, { type => OBJECT },
        { type => SCALAR, regex => qr/^\d+$/ }, # INT ADID
        { type => HASHREF },                    # HASHREF ReachCounterHashRef
                                                # {period => , limit => , total => }
    );
    my ($self, @args) = @_;

    my $result;
    eval { $result = $self->{client}->set_reach_counter(@args); };
    if (my $e = Adriver::DBI::Exceptions::DBError->caught())
    {
        Adriver::DBI::Exceptions::Clients->throw(
            error  => Adriver::ErrorMessage::error_message($e),
            code   => $e->{code},
            method => 'set_reach_counter',
            args   => \@args
        );
    }

    return $result;
}

sub set_exposures_counter
{
    validate_pos(@_, { type => OBJECT },
        { type => SCALAR, regex => qr/^\d+$/ }, # INT ADID
        { type => HASHREF },                    # HASHREF CounterHashRef
    );
    my ($self, @args) = @_;

    my $result;
    eval { $result = $self->{client}->set_exposures_counter(@args); };
    if (my $e = Adriver::DBI::Exceptions::DBError->caught())
    {
        Adriver::DBI::Exceptions::Clients->throw(
            error  => Adriver::ErrorMessage::error_message($e),
            code   => $e->{code},
            method => 'set_exposures_counter',
            args   => \@args
        );
    }

    return $result;
}

sub set_clicks_counter
{
    validate_pos(@_, { type => OBJECT },
        { type => SCALAR, regex => qr/^\d+$/ }, # INT ADID
        { type => HASHREF },                    # HASHREF CounterHashRef
    );
    my ($self, @args) = @_;

    my $result;
    eval { $result = $self->{client}->set_clicks_counter(@args); };
    if (my $e = Adriver::DBI::Exceptions::DBError->caught())
    {
        Adriver::DBI::Exceptions::Clients->throw(
            error  => Adriver::ErrorMessage::error_message($e),
            code   => $e->{code},
            method => 'set_clicks_counter',
            args   => \@args
        );
    }

    return $result;
}

sub add_credit
{
    validate_pos(@_, { type => OBJECT },
        { type => SCALAR, regex => qr/^\d+$/ }, # INT ADID
        { type => SCALAR, regex => qr/^\d+$/ }, # INT Amount
    );
    my ($self, @args) = @_;

    my $result;
    eval { $result = $self->{client}->add_credit(@args); };
    if (my $e = Adriver::DBI::Exceptions::DBError->caught())
    {
        Adriver::DBI::Exceptions::Clients->throw(
            error  => Adriver::ErrorMessage::error_message($e),
            code   => $e->{code},
            method => 'add_credit',
            args   => \@args
        );
    }

    return $result;
}

sub set_credit
{
    validate_pos(@_, { type => OBJECT },
        { type => SCALAR, regex => qr/^\d+$/ }, # INT ADID
        { type => SCALAR, regex => qr/^\d+$/ }, # INT Amount
    );
    my ($self, @args) = @_;

    my $result;
    eval { $result = $self->{client}->set_credit(@args); };
    if (my $e = Adriver::DBI::Exceptions::DBError->caught())
    {
        Adriver::DBI::Exceptions::Clients->throw(
            error  => Adriver::ErrorMessage::error_message($e),
            code   => $e->{code},
            method => 'set_credit',
            args   => \@args
        );
    }

    return $result;
}

sub get_top_exposures
{
    validate_pos(@_, { type => OBJECT },
        { type => HASHREF },                    # HASHREF CounterHashRefMask
        { type => SCALAR, regex => qr/^\d+$/ }, # INT Number
        { type => ARRAYREF, optional => 1 },    # ARRAYREF of INT ADIDs
    );
    my ($self, @args) = @_;

    my $result;
    eval { $result = $self->{client}->get_top_exposures(@args); };
    if (my $e = Adriver::DBI::Exceptions::DBError->caught())
    {
        Adriver::DBI::Exceptions::Clients->throw(
            error  => Adriver::ErrorMessage::error_message($e),
            code   => $e->{code},
            method => 'get_top_exposures',
            args   => \@args
        );
    }

    return $result;
}

sub get_top_clicks
{
    validate_pos(@_, { type => OBJECT },
        { type => HASHREF },                    # HASHREF CounterHashRefMask
        { type => SCALAR, regex => qr/^\d+$/ }, # INT Number
        { type => ARRAYREF, optional => 1 },    # ARRAYREF of INT ADIDs
    );
    my ($self, @args) = @_;

    my $result;
    eval { $result = $self->{client}->get_top_clicks(@args); };
    if (my $e = Adriver::DBI::Exceptions::DBError->caught())
    {
        Adriver::DBI::Exceptions::Clients->throw(
            error  => Adriver::ErrorMessage::error_message($e),
            code   => $e->{code},
            method => 'get_top_clicks',
            args   => \@args
        );
    }

    return $result;
}

sub get_ex
{
    validate_pos(@_, { type => OBJECT },
        { type => HASHREF },                 # HASHREF ADHashRefMask
        { type => ARRAYREF, optional => 1 }, # ARRAYREF of INT ADIDs
    );
    my ($self, @args) = @_;

    my $result;
    eval { $result = $self->{client}->get_ex(@args); };
    if (my $e = Adriver::DBI::Exceptions::DBError->caught())
    {
        Adriver::DBI::Exceptions::Clients->throw(
            error  => Adriver::ErrorMessage::error_message($e),
            code   => $e->{code},
            method => 'get_ex',
            args   => \@args
        );
    }

    return $result;
}

sub rotate_daily
{
    validate_pos(@_, { type => OBJECT });
    my ($self, @args) = @_;

    my $result;
    eval { $result = $self->{client}->rotate_daily(@args); };
    if (my $e = Adriver::DBI::Exceptions::DBError->caught())
    {
        Adriver::DBI::Exceptions::Clients->throw(
            error  => Adriver::ErrorMessage::error_message($e),
            code   => $e->{code},
            method => 'rotate_daily',
            args   => \@args
        );
    }

    return $result;
}

sub rotate_weekly
{
    validate_pos(@_, { type => OBJECT });
    my ($self, @args) = @_;

    my $result;
    eval { $result = $self->{client}->rotate_weekly(@args); };
    if (my $e = Adriver::DBI::Exceptions::DBError->caught())
    {
        Adriver::DBI::Exceptions::Clients->throw(
            error  => Adriver::ErrorMessage::error_message($e),
            code   => $e->{code},
            method => 'rotate_weekly',
            args   => \@args
        );
    }

    return $result;
}

1;


__END__


=head1 NAME

    Adriver::DBI::Clients::ADClient - this module provides methods to work with
    Adriver advertizing companies database.


=head1 DESCRIPTION

    Using this module you can modify advertizing companies and their properties.
    This module is inherited from Adriver::DBI::Clients::BaseID class.


=head1 SYNOPSIS

    use Adriver::DBI;
    use Adriver::DatabaseConnect::Adriver;
    use Adriver::Exceptions;

    my $host = 'f2.x';
    my $port = 16000;

    eval
    {
        my $dbh = Adriver::DBI->new( Adriver::DatabaseConnect::Adriver->new({host => $host, port => $port}) );

        my $ad_id = 84990;
        my $ad = $dbh->AD->get($ad_id);
        print Dumper($ad);

        my $db_info = $dbh->AD->GetCaps();
        print Dumper($db_info);

        my $ids = $dbh->AD->getids();
        print Dumper($ids);

        $dbh->AD->set($ad);
    };

    if (my $e = Exception::Class->caught('Adriver::Exceptions'))
    {
        die "Caught Adriver::Exceptions: '", $e->error, "'\n", $e->trace->as_string, "\n";
    }
    elsif ($e = Exception::Class->caught('Exception::Class::Base'))
    {
        die "Caught unknown exception: '", $e->error, "'\n", $e->trace->as_string, "\n";
    }
    elsif ($e = Exception::Class->caught)
    {
        die "$e";
    }


=head1 INHERITED OBJECT INTERFACE

=head2 get($ad_id) : $ADHashRef

    Get certain advertizing company from database by it's identifier.

B<ad_id>

    This is the identifier of advertizing company.

B<ADHashRef>

    This is a hash reference with next structure:

    ADHashRef =>
    {
        'adID'                  => INT
        'adName'                => STRING
        'shortName'             => STRING
        'supportName'           => STRING
        'email'                 => STRING
        'credit'                => INT
        'can_borrow'            => BOOL
        'uniqueUserMinInterval' => INT
        'creationTime'          => INT (?)
        'enable'                => BOOL
        'enables'               => ARRAYREF(128) BOOL
        'exposures'             => CounterHashRef
        'clicks'                => CounterHashRef
        'uniqueUserMaxShows'    => ARRAYREF(3) INT
        'uniqueUserMaxClicks'   => INT
        'retargetingInfo'       =>
        {
            'objectID'   => INT,
            'options'    => ARRAYREF(32) INT (?BOOL)
            'objectType' => INT
        },
        'reach' =>
        {
            'period' => INT,
            'limit'  => INT,
            'total'  => INT
        },
    }

    where

    CounterHashRef =>
    {
        'today'     => INT
        'yesterday' => INT
        'week'      => INT
        'last_week' => INT
        'total'     => INT
    }

B<Exceptions>

    Adriver::DBI::Exceptions::ParamsValidation
    Adriver::DBI::Exceptions::Clients

=head2 getids() : $ad_ids

    This method returns a list of all advertizing companies identifiers from database.

B<ad_ids>

    This is the array reference with obtained advertizing companies identifiers.

B<Exceptions>

    Adriver::DBI::Exceptions::ParamsValidation
    Adriver::DBI::Exceptions::Clients

=head2 getlist(\@ad_ids) : ARRAYREF of $ADHashRef

    This method returns a list of advertizing companies with specified identifiers.

B<ad_ids>

    This is the array reference with advertizing companies identifiers you want to get.

B<ADHashRef>

    This is the same hash reference as described in get() method.

B<Exceptions>

    Adriver::DBI::Exceptions::ParamsValidation
    Adriver::DBI::Exceptions::Clients

=head2 set($ADHashRef) : undef

    This method updates given advertizing company in database.

B<ADHashRef>

    This is the same hash reference as described in get() method.

B<Exceptions>

    Adriver::DBI::Exceptions::ParamsValidation
    Adriver::DBI::Exceptions::Clients

=head2 add($ADHashRef) : $ad_id

    This method adds the new advertizing company in database and returns it's identifier.

B<ADHashRef>

    This is the same hash reference as described in get() method.

B<ad_id>

    This is the integer identifier of added company.

B<Exceptions>

    Adriver::DBI::Exceptions::ParamsValidation
    Adriver::DBI::Exceptions::Clients

=head2 remove($ad_id) : undef

    This method removes advertizing company from database by it's identifier.

B<ad_id>

    This is the company identifier you want to remove.

B<Exceptions>

    Adriver::DBI::Exceptions::ParamsValidation
    Adriver::DBI::Exceptions::Clients


=head1 OBJECT INTERFACE

=head2 exposure($ad_id) : 1

    This method icrements the number of banner exposures for certain advertizing company.
    DONOT USE THIS METHODS IN IFACES! SPECIAL SYSTEM CALLS!

B<ad_id>

    This is the identifier of company which banner exposures counter you want to increase.

B<Exceptions>

    Adriver::DBI::Exceptions::ParamsValidation
    Adriver::DBI::Exceptions::Clients

=head2 click($ad_id) : 1

    This method icrements the number of banner clicks for certain advertizing company.
    DONOT USE THIS METHODS IN IFACES! SPECIAL SYSTEM CALLS!

B<ad_id>

    This is the identifier of company which banner clicks counter you want to increase.

B<Exceptions>

    Adriver::DBI::Exceptions::ParamsValidation
    Adriver::DBI::Exceptions::Clients

=head2 set_reach_counter($ad_id, $ReachCounterHashRef) : 1

    This method sets the reach counter.

B<ad_id>

    This is the company identifier which reach counter you want to set.

B<ReachCounterHashRef>

    This is the hash reference with next structure:

    ReachCounterHashRef =>
    {
        'period' => INT,
        'limit'  => INT,
        'total'  => INT
    }

B<Exceptions>

    Adriver::DBI::Exceptions::ParamsValidation
    Adriver::DBI::Exceptions::Clients

=head2 set_exposures_counter($ad_id, $CounterHashRef) : 1

    This method sets the counter of banner exposures for certain advertizing company.

B<ad_id>

    This is the company identifier which banner exposures counter you want to set.

B<CounterHashRef>

    This is the same hash reference as described in get() method.

B<Exceptions>

    Adriver::DBI::Exceptions::ParamsValidation
    Adriver::DBI::Exceptions::Clients

=head2 set_clicks_counter($ad_id, $CounterHashRef) : 1

    This method sets the counter of banner clicks for advertizing company.

B<ad_id>

    This is the company identifier which banner clicks counter you want to set.

B<CounterHashRef>

    This is the same hash reference as described in get() method.

B<Exceptions>

    Adriver::DBI::Exceptions::ParamsValidation
    Adriver::DBI::Exceptions::Clients

=head2 add_credit($ad_id, $amount) : $new_amount

    This method adds specified amount of credits to the company.

B<ad_id>

    This is the company's identifier which amount of credits you want to increase.

B<amount>

    This is the amount of credits you want to add to the company.

B<new_amount>

    This is the new amount of credits of the company.

B<Exceptions>

    Adriver::DBI::Exceptions::ParamsValidation
    Adriver::DBI::Exceptions::Clients

=head2 set_credit($ad_id, $new_amount) : $new_amount

    This method sets the new amount of credits to the company.

B<ad_id>

    This is the company's identifier which amount of credits you want to set.

B<new_amount>

    This is the new amount of credits of the company.

B<Exceptions>

    Adriver::DBI::Exceptions::ParamsValidation
    Adriver::DBI::Exceptions::Clients

=head2 get_top_exposures($CounterHashRefMask, $number[, ARRAYREF of INT ADIDs]) : ARRAYREF of ADHashRef

    This method returns the top-list of advertizing companies sorted by exposures counter.
    If list of the ADIDs is specified, procedure gets toplist from this list.

B<CounterHashRefMask>

    This is a hash reference. Procedure gets top-list for counter, specified in CounterHashRefMask ("counter" => 1).
    Its highly recommended to set to 1 only one counter, if you set many, procedure will use only one anyway.
    The structure of CounterHashRefMask specified below:

    CounterHashRefMask =>
    {
        'today'     => BOOL
        'yesterday' => BOOL
        'week'      => BOOL
        'last_week' => BOOL
        'total'     => BOOL
    }

B<number>

    This is the number of elements in the top-list.

B<ADHashRef>

    This is the same hash reference as described in get() method.

B<Exceptions>

    Adriver::DBI::Exceptions::ParamsValidation
    Adriver::DBI::Exceptions::Clients

=head2 get_top_clicks($CounterHashRefMask, $number[, ARRAYREF of INT ADIDs]) : ARRAYREF of ADHashRef

    This method returns the top-list of advertizing companies sorted by clicks counter.
    If list of the ADIDs is specified, procedure gets toplist from this list.

B<CounterHashRefMask>

    This is a hash reference. Procedure gets top-list for counter, specified in CounterHashRefMask ("counter" => 1).
    Its highly recommended to set to 1 only one counter, if you set many, procedure will use only one anyway.
    The structure of CounterHashRefMask specified below:

    CounterHashRefMask =>
    {
        'today'     => BOOL
        'yesterday' => BOOL
        'week'      => BOOL
        'last_week' => BOOL
        'total'     => BOOL
    }

B<number>

    This is the number of elements in the top-list.

B<ADHashRef>

    This is the same hash reference as described in get() method.

B<Exceptions>

    Adriver::DBI::Exceptions::ParamsValidation
    Adriver::DBI::Exceptions::Clients

=head2 get_ex($ADHashRefMask[, ARRAYREF of INT ADIDs]) : ARRAYREF of ADHashRef

    This method gets advertizing companies appropriate to mask ADHashRefMask.
    If list of the ADIDs is specified, procedure searchs companies from this list.

B<ADHashRefMask>

    This is a hash reference. Elements in mask is substrs for search in base.
    The structure of ADHashRefMask specified below:

    ADHashRefMask =>
    {
        'adName'      => STRING
        'email'       => STRING
        'supportName' => STRING
        'shortName'   => STRINT
    }

B<ADHashRef>

    This is the same hash reference as described in get() method.

B<Exceptions>

    Adriver::DBI::Exceptions::ParamsValidation
    Adriver::DBI::Exceptions::Clients

=head2 rotate_daily() : undef

    This procedure rotates daily counters in all advertizing companies.
    DONOT USE THIS METHODS IN IFACES! SPECIAL SYSTEM CALLS!

B<Exceptions>

    Adriver::DBI::Exceptions::ParamsValidation
    Adriver::DBI::Exceptions::Clients

=head2 rotate_weekly() : undef

    This procedure rotates weekly counters in all advertizing companies.
    DONOT USE THIS METHODS IN IFACES! SPECIAL SYSTEM CALLS!

B<Exceptions>

    Adriver::DBI::Exceptions::ParamsValidation
    Adriver::DBI::Exceptions::Clients


=head1 SEE ALSO

    Adriver::DBI::Clients::BaseID
    Adriver::DBI::Exceptions

