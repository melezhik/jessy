package Adriver::DBI::Clients::ObjectOwnersClient;

use strict;
our $VERSION = '0.0300';
use Carp;
use Params::Validate qw(:all);
use base qw ( Adriver::DBI::Clients::Base );

validation_options(on_fail => sub { Adriver::DBI::Exceptions::ParamsValidation->throw( error => $_[0]); } );

sub package { 'RLE::ObjectOwnersClient' }

#### Functions
#
## Get ObjectOwner for the ObjectID with ObjectType
#
# (HASHREF ObjectOwnerHashRef) get(INT ObjectID, INT ObjectType)
#
## Get list of the ObjectOwners of UserID (with optional ObjectType)
#
# (ARRAYREF of HASHREF ObjectOwnerHashRef) get_list(INT UserID [, INT ObjectType])
#
## Add or Remove ObjectOwner
#
# (INT 1) add(HASHREF ObjectOwnerHashRef)
# (INT 1) remove(HASHREF ObjectOwnerHashRef)
#
## Get all Links
## DONOT USE THIS METHOD IN IFACES!
## YOU WILL BE DOOMED!
#
# getall()
#
#### Input Data Info
#
# ObjectOwnerHashRef =>
# {
#     'userID'     => INT
#     'objectID'   => INT
#     'objectType' => INT
# }
#
####

sub get
{
    validate_pos(@_, { type => OBJECT },
        { type => SCALAR, regex => qr/^\d+$/ }, # INT ObjectID
        { type => SCALAR, regex => qr/^\d+$/ }, # INT ObjectType
    );
    my ($self, @args) = @_;

    my $result;
    eval { $result = $self->{client}->get(@args); };
    if (my $e = Adriver::DBI::Exceptions::DBError->caught())
    {
        Adriver::DBI::Exceptions::Clients->throw(
            error  => Adriver::ErrorMessage::error_message($e),
            code   => $e->{code},
            method => 'get',
            args   => \@args
        );
    }

    return $result;
}

sub get_list
{
    validate_pos(@_, { type => OBJECT },
        { type => SCALAR, regex => qr/^\d+$/ },                # INT UserID
        { type => SCALAR, regex => qr/^\d+$/, optional => 1 }, # INT ObjectType
    );
    my ($self, @args) = @_;

    my $result;
    eval { $result = $self->{client}->get_list(@args); };
    if (my $e = Adriver::DBI::Exceptions::DBError->caught())
    {
        Adriver::DBI::Exceptions::Clients->throw(
            error  => Adriver::ErrorMessage::error_message($e),
            code   => $e->{code},
            method => 'get_list',
            args   => \@args
        );
    }

    return $result;
}

sub add
{
    validate_pos(@_, { type => OBJECT },
        { type => HASHREF }, # HASHREF ObjectOwnerHashRef
    );
    my ($self, @args) = @_;

    my $result;
    eval { $result = $self->{client}->add(@args); };
    if (my $e = Adriver::DBI::Exceptions::DBError->caught())
    {
        Adriver::DBI::Exceptions::Clients->throw(
            error  => Adriver::ErrorMessage::error_message($e),
            code   => $e->{code},
            method => 'add',
            args   => \@args
        );
    }

    return $result;
}

sub remove
{
    validate_pos(@_, { type => OBJECT },
        { type => HASHREF }, # HASHREF ObjectOwnerHashRef
    );
    my ($self, @args) = @_;

    my $result;
    eval { $result = $self->{client}->remove(@args); };
    if (my $e = Adriver::DBI::Exceptions::DBError->caught())
    {
        Adriver::DBI::Exceptions::Clients->throw(
            error  => Adriver::ErrorMessage::error_message($e),
            code   => $e->{code},
            method => 'remove',
            args   => \@args
        );
    }

    return $result;
}

sub getall
{
    validate_pos(@_, { type => OBJECT },
        { type => OBJECT, isa => 'Adriver::DBI::ForceGetall', optional => 1 }, # FORCE GETALL
    );
    my ($self, @args) = @_;

    unless (scalar @args == 1 and (pop @args)->access_granted)
    {
        Adriver::DBI::Exceptions->throw( error => 'Calling getall method' );
    }

    my $result;
    eval { $result = $self->{client}->getall(@args); };
    if (my $e = Adriver::DBI::Exceptions::DBError->caught())
    {
        Adriver::DBI::Exceptions::Clients->throw(
            error  => Adriver::ErrorMessage::error_message($e),
            code   => $e->{code},
            method => 'getall',
            args   => \@args
        );
    }

    return $result;
}

1;

__END__


=head1 NAME

    Adriver::DBI::Clients::ObjectOwnersClient - this module provides methods to work with
    Adriver object ownership database.


=head1 DESCRIPTION

    Using this module each object can be associated with his owner.
    This module is inherited from Adriver::DBI::Clients::Base class.


=head1 SYNOPSIS

    use Adriver::DBI;
    use Adriver::DatabaseConnect::Adriver;
    use Adriver::DBI::ForceGetall;
    use Adriver::Exceptions;

    my $host = 'f2.x';
    my $port = 16000;

    eval
    {
        my $dbh = Adriver::DBI->new( Adriver::DatabaseConnect::Adriver->new({host => $host, port => $port}) );

        my $object_id = 76743;
        my $object_type = 14;
        my $object_owner = $dbh->ObjectOwners->get($object_id, $object_type);
        print Dumper($owner);

        my $user_id = 2;
        my $objects = $dbh->ObjectOwners->get_list($user_id, $object_type);
        print Dumper($objects);

        $dbh->ObjectOwners->add($object_owner);
        $dbh->ObjectOwners->remove($object_owner);

        $objects = $dbh->ObjectOwners->getall(FORCE_GETALL);
        print Dumper($objects);
    };

    if (my $e = Exception::Class->caught('Adriver::Exceptions'))
    {
        die "Caught Adriver::Exceptions: '", $e->error, "\n", $e->trace->as_string, "\n";
    }
    elsif ($e = Exception::Class->caught('Exception::Class::Base'))
    {
        die "Caught unknown exception: '", $e->error, "\n", $e->trace->as_string, "\n";
    }
    elsif ($e = Exception::Class->caught)
    {
        die "$e";
    }


=head1 OBJECT INTERFACE

=head2 get($object_id, $object_type) : $ObjectOwnerHashRef

    Get certain object ownership from database by object identifier and object type.

B<object_id>

    Integer.

B<object_type>

    Integer. All available object types listed in Adriver::ObjectType module, see it's documentation
    for more information.

B<ObjectOwnerHashRef>

    This is a hash reference with next structure:

    ObjectOwnerHashRef =>
    {
        'userID'     => INT
        'objectID'   => INT
        'objectType' => INT
    }

B<Exceptions>

    Adriver::DBI::Exceptions::ParamsValidation
    Adriver::DBI::Exceptions::Clients

=head2 get_list($user_id, $object_type) : ARRAYREF of $ObjectOwnerHashRef

    This method returns a list of objects ownerships related with specified user.

B<user_id>

    Integer.

B<object_type>

    Integer.

B<Exceptions>

    Adriver::DBI::Exceptions::ParamsValidation
    Adriver::DBI::Exceptions::Clients

=head2 add($ObjectOwnerHashRef) : 1

    This method adds the new object ownership for user.

B<ObjectOwnerHashRef>

    This is the same hash reference as described in get() method.

B<Exceptions>

    Adriver::DBI::Exceptions::ParamsValidation
    Adriver::DBI::Exceptions::Clients

=head2 remove($ObjectOwnerHashRef) : 1

    This method removes object ownership from database.

B<ObjectOwnerHashRef>

    This is the same hash reference as described in get() method.

B<Exceptions>

    Adriver::DBI::Exceptions::ParamsValidation
    Adriver::DBI::Exceptions::Clients

=head2 getall($object) : ARRAYREF of $ObjectOwnerHashRef

    This method can get all objects ownerships in database. Be careful the amount of data can be significant.

B<object>

    This is object of Adriver::DBI::ForceGetall class.

B<ObjectOwnerHashRef>

    This is the same hash reference as described in get() method.

B<Exceptions>

    Adriver::DBI::Exceptions::ParamsValidation
    Adriver::DBI::Exceptions::Clients


=head1 SEE ALSO

    Adriver::DBI::Clients::Base
    Adriver::DBI::Exceptions
    Adriver::ObjectType
    Adriver::DBI::ForceGetall

