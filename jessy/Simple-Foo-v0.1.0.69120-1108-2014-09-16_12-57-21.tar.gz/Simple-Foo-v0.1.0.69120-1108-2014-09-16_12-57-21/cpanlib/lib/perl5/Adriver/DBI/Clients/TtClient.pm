package Adriver::DBI::Clients::TtClient;

use strict;
use Carp;
use Params::Validate qw(:all);
use base qw ( Adriver::DBI::Clients::BaseNoSocket );

validation_options(on_fail => sub { Adriver::DBI::Exceptions::ParamsValidation->throw( error => $_[0]); } );

# sub package { 'RLE::TtClient' }

#### Functions
#
# Get                             ( INT UID                                                                     )
# GetFilteredByTime               ( INT UID, INT Timeout                                                        )
# Set                             ( INT UID, INT Current Time, INT Storage Time, ARRAYREF Traits                )
# SetWithSumWeight                ( INT UID, INT Current Time, INT Storage Time, ARRAYREF Traits                )
#
# Delete                          ( INT UID, HASHREF Trait                                                      )
# DeleteUser                      ( INT UID                                                                     )
# DeleteTrait                     ( INT TraitID                                                                 )
# DeleteProfile                   ( INT ProfileID                                                               )
#
# GetTraitCounters                ( INT TraitID                                                                 )
# GetTraitSubeventCounters        ( INT TraitID, INT SubeventID                                                 )
# GetTraitProfileCounters         ( INT TraitID, INT ProfileID                                                  )
# GetTraitProfileSubeventCounters ( INT TraitID, INT ProfileID, INT SubeventID                                  )
#
# SetTraitExposures               ( INT UID, INT TraitID, INT ProfileID, HASHREF CounterHashRef                 )
# SetTraitClicks                  ( INT UID, INT TraitID, INT ProfileID, HASHREF CounterHashRef                 )
# SetTraitSubevent                ( INT UID, INT TraitID, INT ProfileID, INT SubeventID, HASHREF CounterHashRef )
#
#### Input Data Info
#
# TraitHashRef =>
# {
#     'traitId'       => INT
#     'traitSourceId' => INT
#     'traitWeight'   => INT
# }
#
# CounterHashRef =>
# {
#     'today'     => INT
#     'yesterday' => INT
#     'week'      => INT
#     'last_week' => INT
#     'total'     => INT
# }
#
####

sub Get {
    validate_pos(@_, { type => OBJECT },
        { type => SCALAR, regex => qr/^\d+$/ }, # INT UID
    );
    my ($self, @args) = @_;

    my $result;
    eval { $result = $self->{client}->Get(@args); };
    if (my $e = Adriver::DBI::Exceptions::DBError->caught())
    {
        Adriver::DBI::Exceptions::Clients->throw(
            error  => Adriver::ErrorMessage::error_message($e),
            code   => $e->{code},
            method => 'Get',
            args   => \@args
        );
    }

    return $result;
}

sub GetFilteredByTime {
    validate_pos(@_, { type => OBJECT },
        { type => SCALAR, regex => qr/^\d+$/ }, # INT UID
        { type => SCALAR, regex => qr/^\d+$/ }, # INT Timeout
    );
    my ($self, @args) = @_;

    my $result;
    eval { $result = $self->{client}->GetFilteredByTime(@args); };
    if (my $e = Adriver::DBI::Exceptions::DBError->caught())
    {
        Adriver::DBI::Exceptions::Clients->throw(
            error  => Adriver::ErrorMessage::error_message($e),
            code   => $e->{code},
            method => 'GetFilteredByTime',
            args   => \@args
        );
    }

    return $result;
}

sub Set {
    validate_pos(@_, { type => OBJECT },
        { type => SCALAR, regex => qr/^\d+$/ }, # INT UID
        { type => SCALAR, regex => qr/^\d+$/ }, # INT Current Time
        { type => SCALAR, regex => qr/^\d+$/ }, # INT Storage Time
        { type => ARRAYREF                   }, # ARRAYREF of TraitHashRef
    );
    my ($self, @args) = @_;

    my $result;
    eval { $result = $self->{client}->Set(@args); };
    if (my $e = Adriver::DBI::Exceptions::DBError->caught())
    {
        Adriver::DBI::Exceptions::Clients->throw(
            error  => Adriver::ErrorMessage::error_message($e),
            code   => $e->{code},
            method => 'Set',
            args   => \@args
        );
    }

    return $result;
}

sub SetWithSumWeight {
    validate_pos(@_, { type => OBJECT },
        { type => SCALAR, regex => qr/^\d+$/ }, # INT UID
        { type => SCALAR, regex => qr/^\d+$/ }, # INT Current Time
        { type => SCALAR, regex => qr/^\d+$/ }, # INT Storage Time
        { type => ARRAYREF                   }, # ARRAYREF of TraitHashRef
    );
    my ($self, @args) = @_;

    my $result;
    eval { $result = $self->{client}->SetWithSumWeight(@args); };
    if (my $e = Adriver::DBI::Exceptions::DBError->caught())
    {
        Adriver::DBI::Exceptions::Clients->throw(
            error  => Adriver::ErrorMessage::error_message($e),
            code   => $e->{code},
            method => 'SetWithSumWeight',
            args   => \@args
        );
    }

    return $result;
}

sub Delete {
    validate_pos(@_, { type => OBJECT },
        { type => SCALAR, regex => qr/^\d+$/ }, # INT UID
        { type => ARRAYREF                   }, # ARRAYREF of TraitHashRef
    );
    my ($self, @args) = @_;

    my $result;
    eval { $result = $self->{client}->Delete(@args); };
    if (my $e = Adriver::DBI::Exceptions::DBError->caught())
    {
        Adriver::DBI::Exceptions::Clients->throw(
            error  => Adriver::ErrorMessage::error_message($e),
            code   => $e->{code},
            method => 'Delete',
            args   => \@args
        );
    }

    return $result;
}

sub DeleteUser {
    validate_pos(@_, { type => OBJECT },
        { type => SCALAR, regex => qr/^\d+$/ }, # INT UID
    );
    my ($self, @args) = @_;

    my $result;
    eval { $result = $self->{client}->DeleteUser(@args); };
    if (my $e = Adriver::DBI::Exceptions::DBError->caught())
    {
        Adriver::DBI::Exceptions::Clients->throw(
            error  => Adriver::ErrorMessage::error_message($e),
            code   => $e->{code},
            method => 'DeleteUser',
            args   => \@args
        );
    }

    return $result;
}

sub DeleteTrait {
    validate_pos(@_, { type => OBJECT },
        { type => SCALAR, regex => qr/^\d+$/ }, # INT TraitID
    );
    my ($self, @args) = @_;

    my $result;
    eval { $result = $self->{client}->DeleteTrait(@args); };
    if (my $e = Adriver::DBI::Exceptions::DBError->caught())
    {
        Adriver::DBI::Exceptions::Clients->throw(
            error  => Adriver::ErrorMessage::error_message($e),
            code   => $e->{code},
            method => 'DeleteTrait',
            args   => \@args
        );
    }

    return $result;
}

sub DeleteProfile {
    validate_pos(@_, { type => OBJECT },
        { type => SCALAR, regex => qr/^\d+$/ }, # INT ProfileID
    );
    my ($self, @args) = @_;

    my $result;
    eval { $result = $self->{client}->DeleteProfile(@args); };
    if (my $e = Adriver::DBI::Exceptions::DBError->caught())
    {
        Adriver::DBI::Exceptions::Clients->throw(
            error  => Adriver::ErrorMessage::error_message($e),
            code   => $e->{code},
            method => 'DeleteProfile',
            args   => \@args
        );
    }

    return $result;
}

sub GetTraitCounters {
    validate_pos(@_, { type => OBJECT },
        { type => SCALAR, regex => qr/^\d+$/ }, # INT TraitID
    );
    my ($self, @args) = @_;

    my $result;
    eval { $result = $self->{client}->GetTraitCounters(@args); };
    if (my $e = Adriver::DBI::Exceptions::DBError->caught())
    {
        Adriver::DBI::Exceptions::Clients->throw(
            error  => Adriver::ErrorMessage::error_message($e),
            code   => $e->{code},
            method => 'GetTraitCounters',
            args   => \@args
        );
    }

    return $result;
}

sub GetTraitSubeventCounters {
    validate_pos(@_, { type => OBJECT },
        { type => SCALAR, regex => qr/^\d+$/ }, # INT TraitID
        { type => SCALAR, regex => qr/^\d+$/ }, # INT SubeventID
    );
    my ($self, @args) = @_;

    my $result;
    eval { $result = $self->{client}->GetTraitSubeventCounters(@args); };
    if (my $e = Adriver::DBI::Exceptions::DBError->caught())
    {
        Adriver::DBI::Exceptions::Clients->throw(
            error  => Adriver::ErrorMessage::error_message($e),
            code   => $e->{code},
            method => 'GetTraitSubeventCounters',
            args   => \@args
        );
    }

    return $result;
}

sub GetTraitProfileCounters {
    validate_pos(@_, { type => OBJECT },
        { type => SCALAR, regex => qr/^\d+$/ }, # INT TraitID
        { type => SCALAR, regex => qr/^\d+$/ }, # INT ProfileID
    );
    my ($self, @args) = @_;

    my $result;
    eval { $result = $self->{client}->GetTraitProfileCounters(@args); };
    if (my $e = Adriver::DBI::Exceptions::DBError->caught())
    {
        Adriver::DBI::Exceptions::Clients->throw(
            error  => Adriver::ErrorMessage::error_message($e),
            code   => $e->{code},
            method => 'GetTraitProfileCounters',
            args   => \@args
        );
    }

    return $result;
}

sub GetTraitProfileSubeventCounters {
    validate_pos(@_, { type => OBJECT },
        { type => SCALAR, regex => qr/^\d+$/ }, # INT TraitID
        { type => SCALAR, regex => qr/^\d+$/ }, # INT ProfileID
        { type => SCALAR, regex => qr/^\d+$/ }, # INT SubeventID
    );
    my ($self, @args) = @_;

    my $result;
    eval { $result = $self->{client}->GetTraitProfileSubeventCounters(@args); };
    if (my $e = Adriver::DBI::Exceptions::DBError->caught())
    {
        Adriver::DBI::Exceptions::Clients->throw(
            error  => Adriver::ErrorMessage::error_message($e),
            code   => $e->{code},
            method => 'GetTraitProfileSubeventCounters',
            args   => \@args
        );
    }

    return $result;
}

sub SetTraitExposures {
    validate_pos(@_, { type => OBJECT },
        { type => SCALAR, regex => qr/^\d+$/ }, # INT UID
        { type => SCALAR, regex => qr/^\d+$/ }, # INT TraitID
        { type => SCALAR, regex => qr/^\d+$/ }, # INT ProfileID
        { type => HASHREF                    }, # HASHREF CounterHashRef
    );
    my ($self, @args) = @_;

    my $result;
    eval { $result = $self->{client}->SetTraitExposures(@args); };
    if (my $e = Adriver::DBI::Exceptions::DBError->caught())
    {
        Adriver::DBI::Exceptions::Clients->throw(
            error  => Adriver::ErrorMessage::error_message($e),
            code   => $e->{code},
            method => 'SetTraitExposures',
            args   => \@args
        );
    }

    return $result;
}

sub SetTraitClicks {
    validate_pos(@_, { type => OBJECT },
        { type => SCALAR, regex => qr/^\d+$/ }, # INT UID
        { type => SCALAR, regex => qr/^\d+$/ }, # INT TraitID
        { type => SCALAR, regex => qr/^\d+$/ }, # INT ProfileID
        { type => HASHREF                    }, # HASHREF CounterHashRef
    );
    my ($self, @args) = @_;

    my $result;
    eval { $result = $self->{client}->SetTraitClicks(@args); };
    if (my $e = Adriver::DBI::Exceptions::DBError->caught())
    {
        Adriver::DBI::Exceptions::Clients->throw(
            error  => Adriver::ErrorMessage::error_message($e),
            code   => $e->{code},
            method => 'SetTraitClicks',
            args   => \@args
        );
    }

    return $result;
}

sub SetTraitSubevent {
    validate_pos(@_, { type => OBJECT },
        { type => SCALAR, regex => qr/^\d+$/ }, # INT UID
        { type => SCALAR, regex => qr/^\d+$/ }, # INT TraitID
        { type => SCALAR, regex => qr/^\d+$/ }, # INT ProfileID
        { type => SCALAR, regex => qr/^\d+$/ }, # INT SubeventID
        { type => HASHREF                    }, # HASHREF CounterHashRef
    );
    my ($self, @args) = @_;

    my $result;
    eval { $result = $self->{client}->SetTraitSubevent(@args); };
    if (my $e = Adriver::DBI::Exceptions::DBError->caught())
    {
        Adriver::DBI::Exceptions::Clients->throw(
            error  => Adriver::ErrorMessage::error_message($e),
            code   => $e->{code},
            method => 'SetTraitSubevent',
            args   => \@args
        );
    }

    return $result;
}
1;


__END__


=head1 NAME

    Adriver::DBI::Clients::TtClient - 


=head1 DESCRIPTION

    This module is inherited from Adriver::DBI::Clients::BaseNoSocket class.


=head1 SYNOPSIS

    use Adriver::DBI::TT;
    use Adriver::DatabaseConnect::TT;
    use Adriver::Exceptions;
    use Data::Dumper;

    my @db_servers;
    push @db_servers, {host=>'trait1.adriver.x', port=>6660, num=>1};

    eval
    {
        my $dbh = Adriver::DBI::TT->new(Adriver::DatabaseConnect::TT->new(\@db_servers));
        print "Connected!\n";

        my $base_info = $dbh->TT->GetCaps();
        print Dumper($base_info);

        my $trait_id = 50331653;
        my $counters = $dbh->TT->GetTraitCounters($trait_id);
        print Dumper($counters);
    };

    if (my $e = Exception::Class->caught('Adriver::Exceptions'))
    {
        die "Caught Adriver::Exceptions: '", $e->error, "'\n", $e->trace->as_string, "\n";
    }
    elsif ($e = Exception::Class->caught('Exception::Class::Base'))
    {
        die "Caught unknown exception: '", $e->error, "'\n", $e->trace->as_string, "\n";
    }
    elsif ($e = Exception::Class->caught)
    {
        die "$e";
    }


=head1 OBJECT INTERFACE

=head2 GetTraitCounters($trait_id) : $data

    Get certain trait from database by it's identifier.

B<trait_ip>

    Integer trait identifier.

B<Exceptions>

    Adriver::DBI::Exceptions::ParamsValidation
    Adriver::DBI::Exceptions::Clients

=head2 GetTraitProfileCounters($trait_id, $profile_id) : $data

    This method returns TraitProfileCounters from database.

B<trait_id>

    Integer trait identifier.

B<profile_id>

    Integer profile identifier.

B<Exceptions>

    Adriver::DBI::Exceptions::ParamsValidation
    Adriver::DBI::Exceptions::Clients


=head1 SEE ALSO

    Adriver::DBI::Clients::BaseNoSocket
    Adriver::DBI::Exceptions

