package Adriver::DBI::Clients::BadIPClient;

use strict;
our $VERSION = '0.0300';
use Carp;
use Params::Validate qw(:all);
use base qw ( Adriver::DBI::Clients::Base );

validation_options(on_fail => sub { Adriver::DBI::Exceptions::ParamsValidation->throw( error => $_[0]); } );

sub package { 'RLE::BadIPClient' }

#### Functions
#
## INT IP = 16777216*IP[0] + 65536*IP[1] + 256*IP[2] + IP[3]
## IP[0,1,2,3] - ip octets
#
# (HASHREF BadIPHashRefs) get(INT IP)
# (INT 1) set(HASHREF BadIPHashRef)
# (INT 1) add(HASHREF BadIPHashRef)
# (INT 1) remove(HASHREF BadIPHashRef)
#
## List BadIPs in [start_IP, stop_IP] with same enables as in request
#
# (ARRAYREF of BadIPHashRefs) get_list(HASHREF BadIPHashRef)
#
#### Input Data Info
#
# BadIPHashRef =>
# {
#     'stop_IP'  => INT
#     'start_IP' => INT
#     'enables'  => ARRAYREF(32) of BOOL
# }
#
####

sub get
{
    validate_pos(@_, { type => OBJECT },
        { type => SCALAR, regex => qr/^\d+$/ }, # INT IP
    );
    my ($self, @args) = @_;

    my $result;
    eval { $result = $self->{client}->get(@args); };
    if (my $e = Adriver::DBI::Exceptions::DBError->caught())
    {
        Adriver::DBI::Exceptions::Clients->throw(
            error  => Adriver::ErrorMessage::error_message($e),
            code   => $e->{code},
            method => 'get',
            args   => \@args
        );
    }

    return $result;
}

sub set
{
    validate_pos(@_, { type => OBJECT },
        { type => HASHREF }, # HASHREF BadIPHashRef
    );
    my ($self, @args) = @_;

    my $result;
    eval { $result = $self->{client}->set(@args); };
    if (my $e = Adriver::DBI::Exceptions::DBError->caught())
    {
        Adriver::DBI::Exceptions::Clients->throw(
            error  => Adriver::ErrorMessage::error_message($e),
            code   => $e->{code},
            method => 'set',
            args   => \@args
        );
    }

    return $result;
}

sub add
{
    validate_pos(@_, { type => OBJECT },
        { type => HASHREF }, # HASHREF BadIPHashRef
    );
    my ($self, @args) = @_;

    my $result;
    eval { $result = $self->{client}->add(@args); };
    if (my $e = Adriver::DBI::Exceptions::DBError->caught())
    {
        Adriver::DBI::Exceptions::Clients->throw(
            error  => Adriver::ErrorMessage::error_message($e),
            code   => $e->{code},
            method => 'add',
            args   => \@args
        );
    }

    return $result;
}

sub remove
{
    validate_pos(@_, { type => OBJECT },
        { type => HASHREF }, # HASHREF BadIPHashRef
    );
    my ($self, @args) = @_;

    my $result;
    eval { $result = $self->{client}->remove(@args); };
    if (my $e = Adriver::DBI::Exceptions::DBError->caught())
    {
        Adriver::DBI::Exceptions::Clients->throw(
            error  => Adriver::ErrorMessage::error_message($e),
            code   => $e->{code},
            method => 'remove',
            args   => \@args
        );
    }

    return $result;
}

sub get_list
{
    validate_pos(@_, { type => OBJECT },
        { type => HASHREF }, # HASHREF BadIPHashRef
    );
    my ($self, @args) = @_;

    my $result;
    eval { $result = $self->{client}->get_list(@args); };
    if (my $e = Adriver::DBI::Exceptions::DBError->caught())
    {
        Adriver::DBI::Exceptions::Clients->throw(
            error  => Adriver::ErrorMessage::error_message($e),
            code   => $e->{code},
            method => 'get_list',
            args   => \@args
        );
    }

    return $result;
}

1;


__END__


=head1 NAME

    Adriver::DBI::Clients::BadIPClient - this module provides methods to work with
    Adriver bad ip addresses database.


=head1 DESCRIPTION

    Using this module you can work with database of bad ip addresses.
    This module is inherited from Adriver::DBI::Clients::Base class.


=head1 SYNOPSIS

    use Adriver::DBI;
    use Adriver::DatabaseConnect::Adriver;
    use Adriver::Exceptions;

    sub get_ip_int
    {
        my $ip = shift;

        my @ip_cut = split /\./, $ip;
        $ip = 16777216*$ip_cut[0] + 65536*$ip_cut[1] + 256*$ip_cut[2] + $ip_cut[3];

        return $ip;
    }

    my $host = 'f2.x';
    my $port = 16000;

    eval
    {
        my $dbh = Adriver::DBI->new( Adriver::DatabaseConnect::Adriver->new({host => $host, port => $port}) );

        my $bad_ip = $dbh->BadIP->get(get_ip_int("217.170.90.1"));
        print Dumper($bad_ip);

        my $db_info = $dbh->BadIP->GetCaps();
        print Dumper($db_info);

        my $bad_ips = $dbh->BadIP->get_list({start_IP => 0, stop_IP => 256**4});
        print Dumper($bad_ips);
    };

    if (my $e = Exception::Class->caught('Adriver::Exceptions'))
    {
        die "Caught Adriver::Exceptions: '", $e->error, "'\n", $e->trace->as_string, "\n";
    }
    elsif ($e = Exception::Class->caught('Exception::Class::Base'))
    {
        die "Caught unknown exception: '", $e->error, "'\n", $e->trace->as_string, "\n";
    }
    elsif ($e = Exception::Class->caught)
    {
        die "$e";
    }


=head1 OBJECT INTERFACE

=head2 get($int_ip) : $BadIPHashRef

    Get certain bad ip address from database.

B<int_ip>

    This is the integer representation of ip address.
    INT IP = 16777216*IP[0] + 65536*IP[1] + 256*IP[2] + IP[3]

B<BadIPHashRef>

    This is a hash reference with next structure:

    BadIPHashRef =>
    {
        'stop_IP'  => INT
        'start_IP' => INT
        'enables'  => ARRAYREF(32) of BOOL
    }

B<Exceptions>

    Adriver::DBI::Exceptions::ParamsValidation
    Adriver::DBI::Exceptions::Clients

=head2 set($BadIPHashRef) : 1

    This method updates given bad ip address in database.

B<BadIPHashRef>

    This is the same hash reference as described in get() method.

B<Exceptions>

    Adriver::DBI::Exceptions::ParamsValidation
    Adriver::DBI::Exceptions::Clients

=head2 add($BadIPHashRef) : 1

    This method adds the new bad ip address in database.

B<BadIPHashRef>

    This is the same hash reference as described in get() method.

B<Exceptions>

    Adriver::DBI::Exceptions::ParamsValidation
    Adriver::DBI::Exceptions::Clients

=head2 remove($BadIPHashRef) : 1

    This method removes given bad ip address from database.

B<BadIPHashRef>

    This is the same hash reference as described in get() method.

B<Exceptions>

    Adriver::DBI::Exceptions::ParamsValidation
    Adriver::DBI::Exceptions::Clients

=head2 get_list($BadIPHashRef) : ARRAYREF of BadIPHashRef

    This method returns the list of bad ip addresses in [start_IP, stop_IP] with same enables as in request.

B<BadIPHashRef>

    This is the same hash reference as described in get() method.

B<Exceptions>

    Adriver::DBI::Exceptions::ParamsValidation
    Adriver::DBI::Exceptions::Clients


=head1 SEE ALSO

    Adriver::DBI::Clients::Base
    Adriver::DBI::Exceptions

