package Adriver::DBI::Exceptions;

use Adriver::Exceptions;

use Exception::Class (

    # DBI Exceptions
    'Adriver::DBI::Exceptions' =>
    {
        isa         => 'Adriver::Exceptions',
        description => 'DBI Errors',
    },
        # Exceptions if Params Validation
        'Adriver::DBI::Exceptions::ParamsValidation' =>
        {
            isa         => 'Adriver::DBI::Exceptions',
            description => 'Exception evaluated from Params::Validate',
        },
        # Exceptions in DBI clients
        'Adriver::DBI::Exceptions::Clients' =>
        {
            isa         => 'Adriver::DBI::Exceptions',
            fields      => ['code', 'messages','method', 'args'],
            description => 'DB client error',
        },
        # Exceptions, caused by errors in so libs
        'Adriver::DBI::Exceptions::DBError' =>
        {
            isa         => 'Adriver::DBI::Exceptions',
            fields      => ['code', 'messages'],
            description => 'DB error',
        },

);

1;

__END__



=head1 NAME

    Adriver::DBI::Exceptions - this module describes some database communication exceptions.
    This class is inherited from Adriver::Exceptions class.


=head1 SYNOPSIS

    use Adriver::DBI::Exceptions;


=head1 EXCEPTIONS API

B<Adriver::DBI::Exceptions>

    Base exception class for database communication errors.

B<Adriver::DBI::Exceptions::ParamsValidation>

    Params::Validate exceptions.

B<Adriver::DBI::Exceptions::Clients>

    Exceptions arisen in database clients.

B<Adriver::DBI::Exceptions::DBError>

    Exceptions arisen on database side.


=head1 SEE ALSO

    Adriver::Exceptions

