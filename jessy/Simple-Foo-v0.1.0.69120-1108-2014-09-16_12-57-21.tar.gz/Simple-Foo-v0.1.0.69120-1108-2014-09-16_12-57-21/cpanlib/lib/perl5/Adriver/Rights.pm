package Adriver::Rights;

use strict;
use warnings;

use Readonly;

Readonly my %RIGHTS => (

    COMMON_READ            => 0,
    COMMON_WRITE           => 1,
    AD_ANKETA              => 2,
    AD_STAT                => 3,

    BANNER_ADD             => 4,
    BANNER_READ            => 5,
    BANNER_CHANGE_PROFILE  => 6,
    BANNER_EDIT            => 7,
    BANNER_UPLOAD          => 8,
    BANNER_DELETE          => 9,
    BANNER_STAT            => 10,

    SLICE_ADD              => 11,
    SLICE_READ             => 12,
    SLICE_EDIT             => 13,
    SLICE_RELEASE          => 14,
    SLICE_DELETE           => 15,
    SLICE_STAT             => 16,

    PROFILE_ADD            => 17,
    PROFILE_READ           => 18,
    PROFILE_EDIT           => 19,
    PROFILE_COPY           => 20,
    PROFILE_DELETE         => 21,
    PROFILE_EXPORT         => 22,

    TRANSFER_CREDIT        => 23,

    SITE_ANKETA            => 24,
    SITE_STAT              => 25,

    SITEZONE_ADD           => 26,
    SITEZONE_READ          => 27,
    SITEZONE_EDIT          => 28,
    SITEZONE_DELETE        => 29,
    SITEZONE_STAT          => 30,

    AD_SITE_GENERAL_STAT   => 31,
    AD_BANNER_GENERAL_STAT => 32,

);

Readonly my %RIGHT_NAMES => reverse %RIGHTS;

sub GET_RIGHT_NAME {
    my $index = shift;
    return $RIGHT_NAMES{$index};
}

sub GET_RIGHT_INDEX {
    my $name = shift;
    return $RIGHTS{$name};
}


# AD_FULL ( 1,1,1,1,1,1,1,1,1,1,1,1,1,0,1,0,1,1,1,1,1,1,1,0,0,0,0,0,0,0,0,1,1 )

Readonly our @AD => @RIGHTS{qw/
    COMMON_READ COMMON_WRITE
    AD_ANKETA AD_STAT
    BANNER_ADD BANNER_READ BANNER_CHANGE_PROFILE BANNER_EDIT BANNER_UPLOAD BANNER_DELETE BANNER_STAT
    SLICE_ADD SLICE_READ SLICE_RELEASE SLICE_STAT
    PROFILE_ADD PROFILE_READ PROFILE_EDIT PROFILE_COPY PROFILE_DELETE PROFILE_EXPORT
    AD_SITE_GENERAL_STAT AD_BANNER_GENERAL_STAT
/};

Readonly our @SALE_DISABLED => @RIGHTS{qw/
    COMMON_WRITE
    BANNER_ADD BANNER_READ BANNER_CHANGE_PROFILE BANNER_EDIT BANNER_UPLOAD BANNER_DELETE BANNER_STAT
    PROFILE_ADD PROFILE_READ PROFILE_EDIT PROFILE_COPY PROFILE_DELETE PROFILE_EXPORT
/};

Readonly our @SITE => ();

# Readonly @EMPTY => ( (0) x 33 );
Readonly our @EMPTY => ( (0) x 256 );

{
    no strict 'refs';
    foreach my $right (keys %RIGHTS)
    {
        *{__PACKAGE__ . "::$right"} = sub () { $RIGHTS{$right} };
    }

    *{__PACKAGE__ . "::AD"}            = sub () { @AD };
    *{__PACKAGE__ . "::SALE_DISABLED"} = sub () { @SALE_DISABLED };
    *{__PACKAGE__ . "::SITE"}          = sub () { @SITE };
    *{__PACKAGE__ . "::EMPTY"}         = sub () { @EMPTY };
}

1;
