package Adriver::User;

use strict;
use warnings;

use Readonly;

use constant
{
    INTERFACE_PATH_NEWMAIN     => 'newmain/',
    INTERFACE_PATH_MAIN        => 'main/',
    INTERFACE_PATH_NEWRLE      => 'newrle/',
    INTERFACE_PATH_RLE         => 'rle/',
    INTERFACE_PATH_NEWADMIN    => 'newadmin/',
    INTERFACE_PATH_SIMPLEADMIN => 'simpleadmin/',
    INTERFACE_PATH_ADMEDIAPUB  => 'admediapub/',
};

# Engine enables ( ENABLES_USER_ )
Readonly my %ENABLES => (

  CAN_USE_POOL                               => 0,
  CAN_USE_SIMPLE_NETWORK                     => 1,
  CAN_USE_PUBLIC_NETWORK                     => 2,
  CAN_ADD_SIMPLE_NETWORK                     => 3,
  CAN_ADD_PUBLIC_NETWORK                     => 4,
  ADMIN_CHANGE_MENU_STATUS_POOL              => 5,
  HIDE_MENU_POOL                             => 6,
  ADMIN_CHANGE_MENU_STATUS_NETWORK           => 7,
  HIDE_MENU_NETWORK                          => 8,
  ADMIN_CHANGE_MENU_STATUS_SLICE             => 9,
  HIDE_MENU_SLICE                            => 10,
  ADMIN_CHANGE_MENU_STATUS_DELEGATED         => 11,
  HIDE_MENU_DELEGATED                        => 12,
  ADMIN_CHANGE_MENU_STATUS_INFO              => 13,
  HIDE_MENU_INFO                             => 14,
  ADMIN_CHANGE_MENU_STATUS_SITE_INFO         => 15,
  HIDE_MENU_SITE_INFO                        => 16,
  ADMIN_CHANGE_MENU_STATUS_AA_SLICE_MANAGER  => 17,
  HIDE_MENU_AA_SLICE_MANAGER                 => 18,
  ADMIN_CHANGE_MENU_STATUS_AA                => 19,
  HIDE_MENU_AA                               => 20,
  ADMIN_CHANGE_MENU_STATUS_STAT_SITE         => 21,
  HIDE_MENU_STAT_SITE                        => 22,
  AD_RETARGETING                             => 23,
  PAY_METHOD_WEBMONEY                        => 24,
  PAY_METHOD_OFFLINE                         => 25,
  HIDE_FILTER                                => 26,
  VIEW_HTML_CODE                             => 27,
  MAY_USE_ADMEDIA_LOGO                       => 28,
  HIDE_PROFILE_PROBLEM_ICONS                 => 29,
  DEF_AD_TARG_IP                             => 30,
  DEF_AD_MAY_USE_NETVIDEO                    => 31,
  MAY_USE_UNLIMITED_BN                       => 32,
  MAYNOT_USE_COMMISSION_TRAFFIC              => 33,
  MAY_CHECK_SWF                              => 34,
  MAY_EXCEED_BANNER_SIZE_LIMIT               => 35,
  ALWAYS_BORROW                              => 36,
  SHORT_BANNER_TYPES                         => 37,
  MAY_USE_TRAIT_TARGETING                    => 38,
  MAY_AUTO_GENERATE_HTML_CODE                => 39,
  SIMPLE_SITE_TARG                           => 40,
  VIEW_DELEGATION_IN_LIST                    => 41,
  UU_IN_PUB_AD                               => 42,
  MAY_USE_TARG_ORG                           => 43,
  NO_MOBILE_OSES_DEFAULT                     => 44,
  IP_RESTRICTED_IFACE                        => 45,
  MAY_IP_RESTRICT_IFACE                      => 46,
  SAFE_SITE_DEFAULT_BANNERS                  => 47,
  HIDE_LONG_TELEPORT                         => 48,
  AD_MAY_USE_CLICK_BANNERS                   => 49,
  MORE_PAGEZONES                             => 50,
  USE_JS_SITE_PLUGINS                        => 51,
  USE_LEAD_AD                                => 52,
  USE_CUSTOM_TARG                            => 53,
  ADGRAVITY_ADMIN                            => 54,
  USE_AUDIT_TARG                             => 55,
  USE_SEARCH_TARG                            => 56,
  USE_REGION_MIRRORS                         => 57,
  ALWAYS_USE_LEAD_AD                         => 58,
  SHOW_BANNER_PUNYCODE_DISABLER              => 59,
  DELEGATE_POOL                              => 60,
  USE_SHADOW_PROFILES                        => 61,
  SHOW_AD_UU_REACH                           => 62,
  AD_TT_REPORT                               => 63,
  USE_SLICE_TYPES                            => 64,
  USE_SLICE_AA                               => 65,
  OBSOLETE_SLICE_EDIT                        => 66,
  CAN_ADD_SPECIAL_BANNER_SPECS               => 67,
  USE_SUBDOMEN_PATH_SITEZONE                 => 68,
  SORT_PROFILES_BY_NAME                      => 69,
  CAN_USE_AD_SHADOW_PROFILE                  => 70,
  STAT_REPORTS_PUB                           => 71,
  STAT_REPORTS_AA                            => 72,
  DEF_AD_USE_UTM                             => 73,
  USE_DSP                                    => 74,
  CAN_EDIT_PROFILE_PRICE                     => 75,
  USE_ROBOTIC_PROFILES                       => 76,
  SITE_TT_REPORT                             => 77,
  MAY_USE_BANNER_LOCATION                    => 78,

);

Readonly my %ENABLE_NAMES => reverse %ENABLES;

sub GET_ENABLE_NAME {
    my $index = shift;
    return $ENABLE_NAMES{$index};
}

sub GET_ENABLE_INDEX {
    my $name = shift;
    return $ENABLES{$name};
}

{
    no strict 'refs';
    foreach my $enable (keys %ENABLES)
    {
        *{__PACKAGE__ . "::$enable"} = sub () { $ENABLES{$enable} };
    }
}

1;
