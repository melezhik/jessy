package Adriver::Banner;

use strict;
use warnings;

use Readonly;

use constant
{

    SENS_CAT_NONE             => 0,
    SENS_CAT_POLITICS         => 1,
    SENS_CAT_DATING           => 2,
    SENS_CAT_RELIGION         => 3,
    SENS_CAT_VIDEOGAME        => 4,
    SENS_CAT_RINGTONES        => 5,
    SENS_CAT_RICHQUICK        => 6,
    SENS_CAT_WEIGHTLOSS       => 7,
    SENS_CAT_COSMETIC         => 8,
    SENS_CAT_DRUGS            => 9,
    SENS_CAT_SEXUALHEALTH     => 10,
    SENS_CAT_LOANS            => 11,
    SENS_CAT_FREEGIFTS        => 12,
    SENS_CAT_MISLEADINGCLAIMS => 13,
    SENS_CAT_SEX              => 14,
    SENS_CAT_GAMBLING         => 15,

    BAN_ATTR_TEXT             => 1,  # (google attr 1)
    BAN_ATTR_IMAGERICH        => 2,  # (google attr 2)
    BAN_ATTR_HTML             => 3,  # (google attr 21)
    BAN_ATTR_EXPANDUP         => 4,  # (google attr 13)
    BAN_ATTR_EXPANDDOWN       => 5,  # (google attr 14)
    BAN_ATTR_EXPANDLEFT       => 6,  # (google attr 15)
    BAN_ATTR_EXPANDRIGHT      => 7,  # (google attr 16)
    BAN_ATTR_EXPANDUPLEFT     => 8,  # (google attr 17)
    BAN_ATTR_EXPANDUPRIGHT    => 9,  # (google attr 18)
    BAN_ATTR_EXPANDDOWNLEFT   => 10, # (google attr 19)
    BAN_ATTR_EXPANDDOWNRIGHT  => 11, # (google attr 20)
    BAN_ATTR_EXPANDROLLOVER   => 12, # (google attr 28)
    BAN_ATTR_RICHHTML4        => 13, # (google attr 33)
    BAN_ATTR_RICHFLASH        => 14, # (google attr 34)
    BAN_ATTR_RETARGETING      => 15, # (google attr 8)
    BAN_ATTR_TAGGING          => 16, # (google attr 7)
    BAN_ATTR_NONSSL           => 17, # (google attr 48)
    BAN_ATTR_SSL              => 18, # (google attr 47)

};

# Engine enables ( ENABLES_BANNER_ )
Readonly my %ENABLES => (

    ADMIN_ENABLE        => 0,
    USER_ENABLE         => 1,
    STANDART_FLASH      => 2,
    AUTOMATE_CATEGORIE  => 3,
    IS_CREATIVE         => 4,
    DISABLED_BY_ROBOT   => 5,
    PROMPTED_TO_ENABLE  => 6,
    DONT_PUNYCODE_URL   => 7,
    ONLY_ADMIN_EDITABLE => 8,
    DSP                 => 9,
    TRAITED             => 28,
    ONLY_CLICK_BANNERS  => 29,
    UU_REPORT           => 30,
    TARGET              => 31,

);

Readonly my %ENABLE_NAMES => reverse %ENABLES;

sub GET_ENABLE_NAME {
    my $index = shift;
    return $ENABLE_NAMES{$index};
}

sub GET_ENABLE_INDEX {
    my $name = shift;
    return $ENABLES{$name};
}

sub SET_UU_REPORTING {
    my $banner = shift;
    $banner->{enables}->[$ENABLES{UU_REPORT}] = (
            $banner->{uniqueUserMaxShows}->[0]
         or $banner->{uniqueUserMaxShows}->[1]
         or $banner->{uniqueUserMaxShows}->[2]
         or $banner->{uniqueUserMaxClicks}
         or $banner->{uniqueUserMinInterval} ) ? 1 : 0;
    return $banner;
}

{
    no strict 'refs';
    foreach my $enable (keys %ENABLES)
    {
        *{__PACKAGE__ . "::$enable"} = sub () { $ENABLES{$enable} };
    }
}

1;
