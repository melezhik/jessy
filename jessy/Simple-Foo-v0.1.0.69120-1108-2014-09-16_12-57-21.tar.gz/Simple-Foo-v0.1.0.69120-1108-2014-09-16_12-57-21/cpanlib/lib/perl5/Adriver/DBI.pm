package Adriver::DBI;

use strict;
use warnings;

use version; our $VERSION = qv('0.2.44');

use Carp;
use Params::Validate qw(:all);

use base qw( Adriver::DBI::Base );

validation_options(on_fail => sub { Adriver::DBI::Exceptions::ParamsValidation->throw(error => $_[0]); });

my $accessors = {
     User             => { class_name => 'Adriver::DBI::Clients::UserClient',             },
     RLENetwork       => { class_name => 'Adriver::DBI::Clients::RLENetworkClient',       },
     RLENetworkAD     => { class_name => 'Adriver::DBI::Clients::RLENetworkADClient',     },
     RLENetworkSite   => { class_name => 'Adriver::DBI::Clients::RLENetworkSiteClient',   },
     AD               => { class_name => 'Adriver::DBI::Clients::ADClient',               },
     Banner           => { class_name => 'Adriver::DBI::Clients::BannerClient',           },
     BadIP            => { class_name => 'Adriver::DBI::Clients::BadIPClient',            },
     City             => { class_name => 'Adriver::DBI::Clients::CityClient',             },
     Country          => { class_name => 'Adriver::DBI::Clients::CountryClient',          },
     Region           => { class_name => 'Adriver::DBI::Clients::RegionClient',           },
     Org              => { class_name => 'Adriver::DBI::Clients::OrgClient',              },
     ISP              => { class_name => 'Adriver::DBI::Clients::ISPClient',              },
     DelegatedObjects => { class_name => 'Adriver::DBI::Clients::DelegatedObjectsClient', },
     GeoHour          => { class_name => 'Adriver::DBI::Clients::GeoHourClient',          },
     GeoStat          => { class_name => 'Adriver::DBI::Clients::GeoStatClient',          },
     Links            => { class_name => 'Adriver::DBI::Clients::LinksClient',            },
     ObjectOwners     => { class_name => 'Adriver::DBI::Clients::ObjectOwnersClient',     },
     Profile          => { class_name => 'Adriver::DBI::Clients::ProfileClient',          },
     Site             => { class_name => 'Adriver::DBI::Clients::SiteClient',             },
     SiteZone         => { class_name => 'Adriver::DBI::Clients::SiteZoneClient',         },
     Slice            => { class_name => 'Adriver::DBI::Clients::SliceClient',            },
     StatOptions      => { class_name => 'Adriver::DBI::Clients::StatOptionsClient',      },
     Pool             => { class_name => 'Adriver::DBI::Clients::PoolClient',             },
     SimpleNetwork    => { class_name => 'Adriver::DBI::Clients::SimpleNetworkClient',    },
     SimpleNetworkAD  => { class_name => 'Adriver::DBI::Clients::SimpleNetworkADClient',  },
     SiteTargeting    => { class_name => 'Adriver::DBI::Clients::SiteTargetingClient',    },
     KeywordTargeting => { class_name => 'Adriver::DBI::Clients::KeywordTargetingClient', },
     DatesTargeting   => { class_name => 'Adriver::DBI::Clients::DatesTargetingClient',   },
     Comment          => { class_name => 'Adriver::DBI::Clients::CommentClient',          },
     Macro            => { class_name => 'Adriver::DBI::Clients::MacroClient',            },
     MirrorRouting    => { class_name => 'Adriver::DBI::Clients::MirrorRoutingClient',    },
     RLE3Config       => { class_name => 'Adriver::DBI::Clients::RLE3ConfigClient',       },
     IPTargeting      => { class_name => 'Adriver::DBI::Clients::IPTargetingClient',      },
     TraitTargeting   => { class_name => 'Adriver::DBI::Clients::TraitTargetingClient',   },
     CustomTargeting  => { class_name => 'Adriver::DBI::Clients::CustomTargetingClient',  },
};

## Generate DB accessors methods
__PACKAGE__->ACCESSORS($accessors);

sub new
{
    validate_pos(@_, { type => SCALAR }, { type => OBJECT, isa => 'Adriver::DatabaseConnect::Adriver' });

    my ($self, $connect) = @_;
    my $dbh = bless {}, $self;
    # We cant work without connection
    if (ref $connect ne 'Adriver::DatabaseConnect::Adriver')
    {
        Adriver::DBI::Exceptions->throw(error => 'Connection is needed for Adriver::DBI::new(Adriver::DatabaseConnect::Adriver()).');
    }
    # Store connection
    $dbh->{'connect'} = $connect;
    return $dbh;
}

sub DESTROY
{
}

1;


__END__

=head1 NAME

    Adriver::DBI - this module provides an interface for communication with Adriver database.


=head1 DESCRIPTION

    This module contains a list of Adriver database clients which can get all needed information from it.
    What you need to know that is which client can get information you want to get. For each database client
    there is accessor method. When you call accessor you get control under the object of corresponded client
    class. This module is inherited from Adriver::DBI::Base class.


=head1 SYNOPSIS

    use Adriver::DBI;
    use Adriver::DatabaseConnect::Adriver;
    use Adriver::Exceptions;

    my $host = 'f2.x';
    my $port = 16000;
    my $banner_id = 515088;

    eval
    {
        my $dbh = Adriver::DBI->new( Adriver::DatabaseConnect::Adriver->new({host => $host, port => $port}) );

        my $banner = $dbh->Banner->get($banner_id);
        print Dumper($banner);

        my $db_info = $dbh->Banner->GetCaps();
        print Dumper($db_info);

        $dbh->Banner->set($banner);
    };

    if (my $e = Exception::Class->caught('Adriver::Exceptions'))
    {
        die "Caught Adriver::Exceptions: '", $e->error, "\n", $e->trace->as_string, "\n";
    }
    elsif ($e = Exception::Class->caught('Exception::Class::Base'))
    {
        die "Caught unknown exception: '", $e->error, "\n", $e->trace->as_string, "\n";
    }
    elsif ($e = Exception::Class->caught)
    {
        die "$e";
    }


=head1 ACCESSORS AND CORRESPONDED CLIENTS

    User              =>  Adriver::DBI::Clients::UserClient
    RLENetwork        =>  Adriver::DBI::Clients::RLENetworkClient
    RLENetworkAD      =>  Adriver::DBI::Clients::RLENetworkADClient
    RLENetworkSite    =>  Adriver::DBI::Clients::RLENetworkSiteClient
    AD                =>  Adriver::DBI::Clients::ADClient
    Banner            =>  Adriver::DBI::Clients::BannerClient
    BadIP             =>  Adriver::DBI::Clients::BadIPClient
    City              =>  Adriver::DBI::Clients::CityClient
    Country           =>  Adriver::DBI::Clients::CountryClient
    Region            =>  Adriver::DBI::Clients::RegionClient
    Org               =>  Adriver::DBI::Clients::OrgClient
    ISP               =>  Adriver::DBI::Clients::ISPClient
    DelegatedObjects  =>  Adriver::DBI::Clients::DelegatedObjectsClient
    GeoHour           =>  Adriver::DBI::Clients::GeoHourClient
    GeoStat           =>  Adriver::DBI::Clients::GeoStatClient
    Links             =>  Adriver::DBI::Clients::LinksClient
    ObjectOwners      =>  Adriver::DBI::Clients::ObjectOwnersClient
    Profile           =>  Adriver::DBI::Clients::ProfileClient
    Site              =>  Adriver::DBI::Clients::SiteClient
    SiteZone          =>  Adriver::DBI::Clients::SiteZoneClient
    Slice             =>  Adriver::DBI::Clients::SliceClient
    StatOptions       =>  Adriver::DBI::Clients::StatOptionsClient
    Pool              =>  Adriver::DBI::Clients::PoolClient
    SimpleNetwork     =>  Adriver::DBI::Clients::SimpleNetworkClient
    SimpleNetworkAD   =>  Adriver::DBI::Clients::SimpleNetworkADClient
    SiteTargeting     =>  Adriver::DBI::Clients::SiteTargetingClient
    KeywordTargeting  =>  Adriver::DBI::Clients::KeywordTargetingClient
    DatesTargeting    =>  Adriver::DBI::Clients::DatesTargetingClient
    Comment           =>  Adriver::DBI::Clients::CommentClient
    Macro             =>  Adriver::DBI::Clients::MacroClient
    MirrorRouting     =>  Adriver::DBI::Clients::MirrorRoutingClient
    RLE3Config        =>  Adriver::DBI::Clients::RLE3ConfigClient
    IPTargeting       =>  Adriver::DBI::Clients::IPTargetingClient
    TraitTargeting    =>  Adriver::DBI::Clients::TraitTargetingClient


=head1 CLASS INTERFACE

=head2 new($adriver_connect) : Adriver::DBI object

    Create the new object of class.

B<adriver_connect>

    This is Adriver::DatabaseConnect::Adriver object or it's child.

B<Exceptions>

    Adriver::DBI::Exceptions::ParamsValidation


=head1 SEE ALSO

    Adriver::DatabaseConnect::Adriver
    Adriver::DBI::Exceptions
    Adriver::DBI::Base
    Database clients classes

