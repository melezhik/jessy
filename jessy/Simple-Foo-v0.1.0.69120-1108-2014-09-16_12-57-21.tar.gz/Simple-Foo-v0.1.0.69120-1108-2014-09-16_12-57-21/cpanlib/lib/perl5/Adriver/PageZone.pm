package Adriver::PageZone;

use strict;
use warnings;

use constant DEFAULT => 0;
use constant TOP     => 1;
use constant MIDDLE  => 2;
use constant BOTTOM  => 3;

1;
