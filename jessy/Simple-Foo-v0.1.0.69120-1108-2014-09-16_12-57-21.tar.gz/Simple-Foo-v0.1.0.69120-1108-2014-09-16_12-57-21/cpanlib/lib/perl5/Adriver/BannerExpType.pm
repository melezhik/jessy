package Adriver::BannerExpType;

use strict;
use warnings;

use constant EXPOSURE  => 0;
use constant SUBEVENT0 => 1;

1;
