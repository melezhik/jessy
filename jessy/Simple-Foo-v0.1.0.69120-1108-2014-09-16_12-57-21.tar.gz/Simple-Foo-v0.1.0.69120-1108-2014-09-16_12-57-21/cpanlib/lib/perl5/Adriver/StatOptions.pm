package Adriver::StatOptions;

use strict;
use warnings;

# Engine enables ( ENABLES_STAT_OPTIONS_ | ENABLES_STAT_ ( for NO_INTERFACE_UPDATE ) )
use constant
{

  FROM_LAST_EXPOSURE  => 0,
  FROM_YESTERDAY      => 1,
  KIT_ALGORITHM       => 2,
  NO_INTERFACE_UPDATE => 3,

};

use constant STAT_OPTIONS_FROM_LAST_EXPOSURE  => 0;
use constant STAT_OPTIONS_FROM_YESTERDAY      => 1;
use constant STAT_OPTIONS_KIT_ALGORITHM       => 2;
use constant STAT_NO_INTERFACE_UPDATE         => 3;

sub DEFAULT {
    my $statOpt = {
        objectID          => 0,
        objectType        => 0,
        statStoragePeriod => 30,
        uuStoragePeriod   => -1,
        enables           => [(0) x 32],
    };
    $statOpt->{enables}->[STAT_OPTIONS_FROM_LAST_EXPOSURE()] = 1;
    return $statOpt;
}

1;
