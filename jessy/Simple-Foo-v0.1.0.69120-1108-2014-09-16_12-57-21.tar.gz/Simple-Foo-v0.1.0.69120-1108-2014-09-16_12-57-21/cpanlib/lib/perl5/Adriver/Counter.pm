package Adriver::Counter;

use strict;
use warnings;

# copy from RLE::Adriver::Const
use constant EXP_TYPE_SUBE0   => 'subE0';
use constant EXP_TYPE_EXP     => 'exp';
use constant EXP_TYPE_CLICK   => 'clk';

sub EventCounter {
    my $object      = shift;
    my $eventTypeName = shift; # RLE::Adriver::RLE3Config::EXP_TYPE_EXP or ...::EXP_TYPE_SUBE0 or ...::EXP_TYPE_CLICK
    my $counter;

    if    ($eventTypeName eq EXP_TYPE_EXP())   { $counter = $object->{exposures};      }
    elsif ($eventTypeName eq EXP_TYPE_SUBE0()) { $counter = $object->{subevents}->[0]; }
    elsif ($eventTypeName eq EXP_TYPE_CLICK()) { $counter = $object->{clicks};         }

    return $counter;
}

sub CounterPeriod {
    my $counter = shift;
    my $period  = shift;
    my $events;

    if (exists HOURLY_COUNTER()->{$period} or exists COUNTER()->{$period}) {
        $events = $counter->{$period};
    }
    elsif ($period eq PERIOD_PAST())   {
        $events = $counter->{PERIOD_TOTAL()} - $counter->{PERIOD_TODAY()};
    }
    elsif ($period eq PERIOD_UNDATED_PAST())   {
        $events = $counter->{PERIOD_TOTAL()} - $counter->{PERIOD_TODAY()} - $counter->{PERIOD_YESTERDAY()};
    }
    elsif ($period eq PERIOD_FUTURE()) { $events = 0; }

    return $events;
}

###### extended periods #######
use constant PERIOD_PAST         => 'past';
use constant PERIOD_UNDATED_PAST => 'undatedPast';
use constant PERIOD_FUTURE       => 'future';

###### counter periods #######
use constant PERIOD_TODAY        => 'today';
use constant PERIOD_TOTAL        => 'total';
use constant PERIOD_YESTERDAY    => 'yesterday';
use constant PERIOD_WEEK         => 'week';
use constant PERIOD_LAST_WEEK    => 'last_week';
use constant PERIOD_LAST_HOUR    => 'last_hour';

sub HOURLY_COUNTER {
    return {
        PERIOD_TODAY()     => 0,
        PERIOD_WEEK()      => 0,
        PERIOD_LAST_WEEK() => 0,
        PERIOD_TOTAL()     => 0,
        PERIOD_YESTERDAY() => 0,
        PERIOD_LAST_HOUR() => 0,
    };
}

sub COUNTER {
    return {
        PERIOD_TODAY()     => 0,
        PERIOD_WEEK()      => 0,
        PERIOD_LAST_WEEK() => 0,
        PERIOD_TOTAL()     => 0,
        PERIOD_YESTERDAY() => 0,
    };
}

1;
