package Adriver::DatabaseConnect::Adriver;

use strict;
our $VERSION = '0.0300';
use Carp;
use Params::Validate qw(:all);
use Adriver::Socket::ClientSocket;
use base qw( Adriver::DatabaseConnect::BaseConnect );

validation_options(on_fail => sub { Adriver::DatabaseConnect::Exceptions::ParamsValidation->throw(error => $_[0]); } );

sub new
{
    my $self = shift;

    my %args = validate(@_,
    {
        host => { type => SCALAR, regex => qr/^([-\@\w.])+$/ },
        port => { type => SCALAR, regex => qr/^\d+$/, optional => 1 },
    });

    my $adriver_db = bless {}, $self;
    # set params
    $adriver_db->{'host'} = $args{'host'};
    $adriver_db->{'port'} = $args{'port'};
    return $adriver_db;
}

# Accessors
sub host
{
    validate_pos(@_, { type => OBJECT });
    return shift->{'host'};
}

sub port
{
    validate_pos(@_, { type => OBJECT });
    return shift->{'port'};
}

# Can throw exception on socket creation
# Can throw exception on connect
sub _impl_connect
{
    validate_pos(@_, { type => OBJECT });
    my $self = shift;
    $self->{'connect'} = new Adriver::Socket::ClientSocket($self->host, $self->port);
    $self->{'connect'}->connect();
    return 1; # return true
}

1;

__END__


=head1 NAME

    Adriver::DatabaseConnect::Adriver - this module works as a driver for communication with Adriver database.


=head1 SYNOPSIS

    use Adriver::DatabaseConnect::Adriver;
    use Adriver::DatabaseConnect::Exceptions;

    eval
    {
        my $db_connect = new Adriver::DatabaseConnect::Adriver(host=>$host, port=>$port);

        $db_connect->connect;
        if ($db_connect->is_connected)
        {
            print "Successfully connected to '${\($db_connect->host)}::${\($db_connect->port)}'\n";
        }
        else
        {
            print "Couldn't connected to '${\($db_connect->host)}::${\($db_connect->port)}'\n";
        }

        my $client_socket = $db_connect->get_connect;
    };

    if (my $e = Exception::Class->caught('Adriver::Socket::Exceptions'))
    {
        die "Caught Adriver::Socket::Exceptions: '", $e->error, "\n", $e->trace->as_string, "\n";
    }
    elsif ($e = Exception::Class->caught('Adriver::DatabaseConnect::Exceptions'))
    {
        die "Caught Adriver::DatabaseConnect::Exceptions: '", $e->error, "\n", $e->trace->as_string, "\n";
    }
    elsif ($e = Exception::Class->caught('Exception::Class::Base'))
    {
        die "Caught unknown exception: '", $e->error, "\n", $e->trace->as_string, "\n";
    }
    elsif ($e = Exception::Class->caught)
    {
        die "$e";
    }


=head1 DESCRIPTION

    This module is inherited from Adriver::DatabaseConnect::BaseConnect and provides connection to Adriver database via
    Adriver::Socket::ClientSocket.


=head1 CLASS INTERFACE

=head2 new(host=>$host, port=>$port) : Adriver::DatabaseConnect::Adriver object

    Create the new object of class.

B<host>

    This is a host address where database is accessible.

B<port>

    This is a port number on which listeners of the database is accessible. This is optional parameter,
    for more information see documentation on module Adriver::Socket::ClientSocket.

B<Exceptions>

    Adriver::DatabaseConnect::Exceptions::ParamsValidation


=head1 OBJECT INTERFACE

=head2 connect() : 1

    This method inherits from Adriver::DatabaseConnect::BaseConnect and perform connection to
    Adriver database via socket Adriver::Socket::ClientSocket.

=head2 host() : $host_address

    This method returns host address with which this object was created.

B<Exceptions>

    Adriver::DatabaseConnect::Exceptions::ParamsValidation

=head2 port() : $port_number

    This method returns port number with which this object was created.

B<Exceptions>

    Adriver::DatabaseConnect::Exceptions::ParamsValidation


=head1 PRIVATE OBJECT INTERFACE

=head2 _impl_connect() : 1

    This method is an internal implementation of connect() method. In fact when you call
    connect() method it's translated into call of this method. It uses Adriver::Socket::ClientSocket
    to establish connection with Adriver database.

B<Exceptions>

    Adriver::DatabaseConnect::Exceptions::ParamsValidation
    Adriver::Socket::Exceptions


=head1 SEE ALSO

    Adriver::DatabaseConnect::BaseConnect
    Adriver::Socket::ClientSocket

