package Adriver::DatabaseConnect::Stat;

use strict;
our $VERSION = '0.0300';
use Carp;
use Adriver::Socket::StatSocket;
use Params::Validate qw(:all);
use base qw( Adriver::DatabaseConnect::BaseConnect );

validation_options(on_fail => sub { Adriver::DatabaseConnect::Exceptions::ParamsValidation->throw(error => $_[0]); } );

sub new
{
    my $self = shift;

    my %args = validate(@_,
    {
        config_file => 1
    });

    my $stat_db = bless {}, $self;
    # set params
    $stat_db->{'connect'} = Adriver::Socket::StatSocket->new($args{'config_file'});
    unless ($stat_db->{'connect'}) {
        Adriver::DatabaseConnect::Exceptions->throw(error => "Can not create Adriver::Socket::StatSocket");
    }

    return $stat_db;
}

# connect is an array ==>  [{'socket'=>$socket->fd, 'start_IP'=>0, 'stop_IP'=>4294967295}]
sub _impl_connect
{
    validate_pos(@_, { type => OBJECT }, (0) x (@_ - 1));
    return 1; # return true
}

1;


__END__


=head1 NAME

    Adriver::DatabaseConnect::Stat - this module works as a driver for communication with Stat database.


=head1 SYNOPSIS

    use Data::Dumper;
    use Adriver::DatabaseConnect::Stat;
    use Adriver::DatabaseConnect::Exceptions;

    eval
    {
        my $stat_connect = new Adriver::DatabaseConnect::Stat(config_file => $config_file);

        $stat_connect->connect;
        my $stat_socket = $stat_connect->get_connect;
        if ($stat_connect->is_connected)
        {
            print "Successfully connected to Stat database with config '${\($stat_socket->config)}'.\n";
        }
        else
        {
            print "Couldn't connect to Stat database with config '${\($stat_socket->config)}'\n";
        }
    };

    if (my $e = Exception::Class->caught('Adriver::Socket::Exceptions'))
    {
        die "Caught Adriver::Socket::Exceptions: '", $e->error, "\n", $e->trace->as_string, "\n";
    }
    elsif ($e = Exception::Class->caught('Adriver::DatabaseConnect::Exceptions'))
    {
        die "Caught Adriver::DatabaseConnect::Exceptions: '", $e->error, "\n", $e->trace->as_string, "\n";
    }
    elsif ($e = Exception::Class->caught('Exception::Class::Base'))
    {
        die "Caught unknown exception: '", $e->error, "\n", $e->trace->as_string, "\n";
    }
    elsif ($e = Exception::Class->caught)
    {
        die "$e";
    }


=head1 DESCRIPTION

    This module is inherited from Adriver::DatabaseConnect::BaseConnect and provides connection to Stat database via
    Adriver::Socket::StatSocket.


=head1 CLASS INTERFACE

=head2 new(config_file=>$config_file) : Adriver::DatabaseConnect::Stat object

    Create the new object of class.

B<config_file>

    This is a path to configuration file with connection parameters.

B<Exceptions>

    Adriver::DatabaseConnect::Exceptions::ParamsValidation
    Adriver::DatabaseConnect::Exceptions


=head1 OBJECT INTERFACE

=head2 connect() : 1

    This method inherits from Adriver::DatabaseConnect::BaseConnect and performs connection to
    Stat database via socket Adriver::Socket::StatSocket.


=head1 PRIVATE OBJECT INTERFACE

=head2 _impl_connect() : 1

    This method is an internal implementation of connect() method. In fact when you call
    connect() method it's translated into call of this method. It uses Adriver::Socket::StatSocket
    to establish connection with Stat database.

B<Exceptions>

    Adriver::DatabaseConnect::Exceptions::ParamsValidation


=head1 SEE ALSO

    Adriver::DatabaseConnect::BaseConnect
    Adriver::Socket::StatSocket

