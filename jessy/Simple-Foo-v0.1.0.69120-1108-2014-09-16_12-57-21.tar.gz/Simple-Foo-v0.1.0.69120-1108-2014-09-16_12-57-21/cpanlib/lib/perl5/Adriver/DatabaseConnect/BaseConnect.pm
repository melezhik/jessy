package Adriver::DatabaseConnect::BaseConnect;

use strict;
our $VERSION = '0.0300';
use Carp;
use Params::Validate qw(:all);
use Adriver::DatabaseConnect::Exceptions;

validation_options(on_fail => sub { Adriver::DatabaseConnect::Exceptions::ParamsValidation->throw(error => $_[0]); } );

sub is_connected
{
    validate_pos(@_, { type => OBJECT });
    return shift->{'connect'}
}

sub get_connect
{
    validate_pos(@_, { type => OBJECT });
    my $self = shift;
    $self->connect() unless $self->is_connected();
    return $self->{'connect'};
}

sub connect
{
    validate_pos(@_, { type => OBJECT }, (0) x (@_ - 1));
    my ($self, @arg) = @_;
    return $self->_impl_connect(@arg);
}

sub _impl_connect {
    Adriver::DatabaseConnect::Exceptions->throw(error => "Adriver::DatabaseConnect::impl_connect is abstract method"); 
}


1;

__END__


=head1 NAME

    Adriver::DatabaseConnect::BaseConnect - this module represents a common interface for all BaseConnect
    modules needed to establish connection and perform communication with various databases.


=head1 DESCRIPTION

    You should not use this module directly. It's used like as an common interface for various BaseConnect modules.
    Besides it implemets some common methods for them.


=head1 OBJECT INTERFACE

=head2 connect()

    This method translates call to _impl_connect method and does nothing more.

B<Exceptions>

    Adriver::DatabaseConnect::Exceptions::ParamsValidation

=head2 is_connected() : $connect_object or undef

    This method lets to determine if connect() method was called or not.

B<Exceptions>

    Adriver::DatabaseConnect::Exceptions::ParamsValidation

=head2 get_connect() : $connect_object

    This method returns internal connect_object which inherits low level implementation of
    communication with database. For example, when we use Adriver::DatabaseConnect::Adriver
    this will be Adriver::Socket::ClientSocket object.

B<Exceptions>

    Adriver::DatabaseConnect::Exceptions::ParamsValidation


=head1 PRIVATE OBJECT INTERFACE

=head2 _impl_connect()

    This is an abstract method and all BaseConnect modules should implement it. If they don't
    exception will be arisen.

B<Exceptions>

    Adriver::DatabaseConnect::Exceptions


=head1 SEE ALSO

    Adriver::DatabaseConnect::Exceptions

