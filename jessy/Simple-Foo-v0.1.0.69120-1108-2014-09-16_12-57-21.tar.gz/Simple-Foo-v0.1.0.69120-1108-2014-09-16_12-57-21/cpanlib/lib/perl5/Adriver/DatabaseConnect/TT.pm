package Adriver::DatabaseConnect::TT;

use strict;
our $VERSION = '0.0300';
use Adriver::Loader;
use Carp;
use Params::Validate qw(:all);
use base qw( Adriver::DatabaseConnect::BaseConnect );

validation_options(on_fail => sub { Adriver::DatabaseConnect::Exceptions::ParamsValidation->throw(error => $_[0]); } );

sub new
{
    my $self = shift;

    validate_pos(@_,
    {
        type      => ARRAYREF,
        callbacks => {
            'Host' => sub { my $ok = 0; foreach my $tri (@{$_[0]}) {$ok = 1 if $tri->{'host'} =~ m/^([-\@\w.])+$/}; return $ok; },
            'Port' => sub { my $ok = 0; foreach my $tri (@{$_[0]}) {$ok = 1 if $tri->{'port'} =~ m/^\d+$/};         return $ok; },
            'Num'  => sub { my $ok = 0; foreach my $tri (@{$_[0]}) {$ok = 1 if $tri->{'num'} =~ m/^\d+$/};          return $ok; },
        },
    });

    my $tt_db = bless {}, $self;
    # set params
    $tt_db->{'tri_list'} = shift;

    return $tt_db;
}

# Accessors
sub tri_list
{
    validate_pos(@_, { type => OBJECT });
    return shift->{'tri_list'};
}

# Can throw exception on connect
sub _impl_connect
{
    validate_pos(@_, { type => OBJECT });
    my $self = shift;
    client_so_loader('RLE::TtClient');
    my $tt = RLE::TtClient->new( scalar @{$self->tri_list} ) or Adriver::DatabaseConnect::Exceptions->throw(error => "Can't create TtClient");
    $tt->{'ERRHAND'} = \&ExceptionHandler;
    foreach my $tri (@{$self->tri_list}) {
        $tt->add( $tri->{'host'}, $tri->{'port'}, $tri->{'num'} );
    }
    $tt->Connect() or Adriver::DatabaseConnect::Exceptions->throw(error => "Can't connect TtClient");
    $self->{'connect'} = $tt;
    return 1; # return true
}

sub ExceptionHandler
{
    # my $ec = $_[0];
    Adriver::DBI::Exceptions::DBError->throw(
        'code'     => $_[0]->{'code'},
        'messages' => $_[0]->{'messages'},
        # 'what'     => $_[0]->{what},
        # 'type'     => $_[0]->{type},
        # 'catch'    => $_[0]->{catch},
    );
    return;
}

1;


__END__


=head1 NAME

    Adriver::DatabaseConnect::TT - this module works as a driver for communication with Trait database.


=head1 SYNOPSIS

    use Data::Dumper;
    use Adriver::DatabaseConnect::TT;
    use Adriver::DatabaseConnect::Exceptions;

    eval
    {
        my @db_servers;
        push @db_servers, {host=>$host, port=>$port, num=>$num};

        my $tt_connect = new Adriver::DatabaseConnect::TT(\@db_servers);

        $tt_connect->connect;
        if ($tt_connect->is_connected)
        {
            print "Successfully connected to '${host}::${port}'\n";
        }
        else
        {
            print "Couldn't connected to '${host}::${port}'\n";
        }

        my $tt_client = $tt_connect->get_connect;
        print Dumper($tt_client);

        my $tri_list = $tt_connect->tri_list;
        print Dumper($tri_list);
    };

    if (my $e = Exception::Class->caught('Adriver::DBI::Exceptions::DBError'))
    {
        die "Caught Adriver::DBI::Exceptions::DBError: '", $e->error, "\n", $e->trace->as_string, "\n";
    }
    elsif ($e = Exception::Class->caught('Adriver::DatabaseConnect::Exceptions'))
    {
        die "Caught Adriver::DatabaseConnect::Exceptions: '", $e->error, "\n", $e->trace->as_string, "\n";
    }
    elsif ($e = Exception::Class->caught('Exception::Class::Base'))
    {
        die "Caught unknown exception: '", $e->error, "\n", $e->trace->as_string, "\n";
    }
    elsif ($e = Exception::Class->caught)
    {
        die "$e";
    }


=head1 DESCRIPTION

    This module is inherited from Adriver::DatabaseConnect::BaseConnect and provides connection to Trait database
    via RLE::TtClient.


=head1 CLASS INTERFACE

=head2 new(\@db_servers) : Adriver::DatabaseConnect::TT object

    Create the new object of class.

=head3 db_servers

    This is array reference with connection parameters to each separate host of Trait database.
    This configuration array is used as input parameter when we create internal
    RLE::TtClient object. Each array element is a hash reference with next keys.

B<host>

    This is a host address where database is accessible.

B<port>

    This is a port number on which listeners of the database is accessible. This is optional parameter,
    default port number determined into RLE::ClientSocket module.

B<num>

    This is a identification number of host.

=head3 Exceptions

    Adriver::DatabaseConnect::Exceptions::ParamsValidation
    Adriver::DatabaseConnect::Exceptions


=head1 OBJECT INTERFACE

=head2 connect() : 1

    This method inherits from Adriver::DatabaseConnect::BaseConnect and performs connection to
    Trait database with RLE::TtClient module help.

=head2 config() : $array_ref

    This method returns a reference on array. This is the same config array that you passed
    when was creating this object.

B<Exceptions>

    Adriver::DatabaseConnect::Exceptions::ParamsValidation


=head1 PRIVATE OBJECT INTERFACE

=head2 _impl_connect() : 1

    This method is an internal implementation of connect() method. In fact when you call
    connect() method it's translated into call of this method. It uses RLE::TtClient module
    to establish connection with Trait database.

B<Exceptions>

    Adriver::DatabaseConnect::Exceptions::ParamsValidation
    Adriver::DatabaseConnect::Exceptions
    Adriver::DBI::Exceptions::DBError


=head1 SEE ALSO

    Adriver::DatabaseConnect::BaseConnect
    RLE::TtClient

