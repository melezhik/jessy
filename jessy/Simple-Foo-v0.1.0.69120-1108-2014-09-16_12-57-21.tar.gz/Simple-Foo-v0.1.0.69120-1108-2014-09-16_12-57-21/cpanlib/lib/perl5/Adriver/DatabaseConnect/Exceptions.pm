package Adriver::DatabaseConnect::Exceptions;

use Adriver::Exceptions;

use Exception::Class (

    # DB Connection Exceptions
    'Adriver::DatabaseConnect::Exceptions' =>
    {
        isa         => 'Adriver::Exceptions',
        description => 'Database Connection errors',
    },
        # Exceptions if Params Validation
        'Adriver::DatabaseConnect::Exceptions::ParamsValidation' =>
        {
            isa         => 'Adriver::DatabaseConnect::Exceptions',
            description => 'Exception evaluated from Params::Validate',
        },

);

1;

__END__


=head1 NAME

    Adriver::DatabaseConnect::Exceptions - this module describes some database connection exceptions.
    This class is inherited from Adriver::Exceptions class.


=head1 SYNOPSIS

    use Adriver::DatabaseConnect::Exceptions;


=head1 EXCEPTIONS API

B<Adriver::DatabaseConnect::Exceptions>

    Base exception class for database connection errors.

B<Adriver::DatabaseConnect::Exceptions::ParamsValidation>

    Params::Validate exception.


=head1 SEE ALSO

    Adriver::Exceptions

