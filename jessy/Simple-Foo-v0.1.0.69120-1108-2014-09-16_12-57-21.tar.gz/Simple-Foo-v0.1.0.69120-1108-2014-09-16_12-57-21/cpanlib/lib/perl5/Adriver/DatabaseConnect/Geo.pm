package Adriver::DatabaseConnect::Geo;

use strict;
our $VERSION = '0.0300';
use Carp;
use Adriver::Socket::GeoSocket;
use Params::Validate qw(:all);
use base qw( Adriver::DatabaseConnect::BaseConnect );

validation_options(on_fail => sub { Adriver::DatabaseConnect::Exceptions::ParamsValidation->throw(error => $_[0]); } );

#
# Geo config
#   [{'host' =>, 'port'=>, 'start_IP'=>, 'stop_IP' =>},...]
#

sub new
{
    my $self = shift;

    my %args = validate(@_,
    {
        config => { type => ARRAYREF }
    });

    my $geo_db = bless {}, $self;
    # Set params
    $geo_db->{'connect'} = Adriver::Socket::GeoSocket->new($args{'config'});
    unless ($geo_db->{'connect'})
    {
        Adriver::DatabaseConnect::Exceptions->throw(error => "Can not create Adriver::Socket::GeoSocket");
    }

    return $geo_db;
}

sub is_connected
{
    validate_pos(@_, { type => OBJECT });
    return shift->{'connect'}->is_connected();
}

# Connect is an array ==>  [{'socket'=>$socket->fd, 'start_IP'=>0, 'stop_IP'=>4294967295}]
sub _impl_connect
{
    validate_pos(@_, { type => OBJECT });
    my $self = shift;
    $self->{'connect'}->connect();
    return 1; # return true
}

1;


__END__


=head1 NAME

    Adriver::DatabaseConnect::Geo - this module works as a driver for communication with Geo database.


=head1 SYNOPSIS

    use Data::Dumper;
    use Adriver::DatabaseConnect::Geo;
    use Adriver::DatabaseConnect::Exceptions;

    eval
    {
        my @db_servers;
        push @db_servers, {host => 'f2.x', port => 16000, 'start_IP'=> 0, 'stop_IP' => 4294967295};
        my $geo_connect = Adriver::DatabaseConnect::Geo->new(config => \@db_servers);
        print Dumper($geo_connect);

        $geo_connect->connect;
        if ($geo_connect->is_connected)
        {
            print "Successfully connected to Geo DB\n";
        }
        else
        {
            print "Couldn't connected to Geo DB with your config\n";
            my $geo_socket = $geo_connect->get_connect;
            print Dumper($geo_socket->config);
        }
        print Dumper($geo_connect);
    };

    if (my $e = Exception::Class->caught('Adriver::Socket::Exceptions'))
    {
        die "Caught Adriver::Socket::Exceptions: '", $e->error, "\n", $e->trace->as_string, "\n";
    }
    elsif ($e = Exception::Class->caught('Adriver::DatabaseConnect::Exceptions'))
    {
        die "Caught Adriver::DatabaseConnect::Exceptions: '", $e->error, "\n", $e->trace->as_string, "\n";
    }
    elsif ($e = Exception::Class->caught('Exception::Class::Base'))
    {
        die "Caught unknown exception: '", $e->error, "\n", $e->trace->as_string, "\n";
    }
    elsif ($e = Exception::Class->caught)
    {
        die "$e";
    }


=head1 DESCRIPTION

    This module is inherited from Adriver::DatabaseConnect::BaseConnect and provides connection to Geo database via
    Adriver::Socket::GeoSocket.


=head1 CLASS INTERFACE

=head2 new(config => $array_ref) : Adriver::DatabaseConnect::Geo object

    Create the new object of class.

=head3 config

    This is array reference with connect parameters to each separate host of Geo database.
    This configuration array passed as input parameter to create internal
    Adriver::Socket::GeoSocket object. Each array element is a hash reference with next keys.

B<host>

    This is a host address where database is accessible.

B<port>

    This is a port number on which listeners of the database is accessible. This is optional parameter,
    default port number determined into RLE::ClientSocket module.

B<start_IP>

    This is lower bound of IP addresses range available on separate database host.

B<stop_IP>

    This is upper bound of IP addresses range available on separate database host.

=head3 Exceptions

    Adriver::DatabaseConnect::Exceptions::ParamsValidation


=head1 OBJECT INTERFACE

=head2 connect() : 1

    This method inherits from Adriver::DatabaseConnect::BaseConnect and perform connection to
    Geo database via socket Adriver::Socket::GeoSocket.

=head2 is_connected() : 1 or 0

    This method returns result of calling method is_connected() of Adriver::Socket::GeoSocket internal object.


=head1 PRIVATE OBJECT INTERFACE

=head2 _impl_connect() : 1

    This method is an internal implementation of connect() method. In fact when you call
    connect method it's translated into call of this method. By-turn this method calls connect() method of
    Adriver::Socket::GeoSocket object to establish connection with Geo database.

B<Exceptions>

    Adriver::DatabaseConnect::Exceptions::ParamsValidation
    Adriver::Socket::Exceptions


=head1 SEE ALSO

    Adriver::DatabaseConnect::BaseConnect
    Adriver::Socket::GeoSocket

