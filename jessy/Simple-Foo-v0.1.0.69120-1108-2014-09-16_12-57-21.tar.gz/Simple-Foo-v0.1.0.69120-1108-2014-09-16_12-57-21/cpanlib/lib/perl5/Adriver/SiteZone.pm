package Adriver::SiteZone;

use strict;
use warnings;

#define SITE_ZONE_NAME_SIZE 32
#define SITE_ZONE_URL_REQ_SIZE 128
#define SITE_ZONE_URL_SIZE 64
#define SITE_ZONE_URLS_NUM 10
use constant
{
    NAME_SIZE => 31,
    URL_SIZE  => 63,
    URLS_NUM  => 10,
};

#enum StrOp { NULL_OP, OR, AND };
use constant
{
    NOP => 0,
    OR  => 1,
    AND => 2,
};

# Engine enables ( ENABLES_SITE_ )
use constant
{

    TT_REPORT => 31,

};

1;
