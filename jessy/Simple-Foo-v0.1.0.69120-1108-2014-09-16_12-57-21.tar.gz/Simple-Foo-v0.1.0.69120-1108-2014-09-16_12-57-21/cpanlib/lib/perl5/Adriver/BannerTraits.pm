package Adriver::BannerTraits;

use strict;
use warnings;

use Adriver::Banner;
use Adriver::BannerType;
use Adriver::BannerSpec;
use Adriver::BannerComponentType;
use Adriver::BannerExpType;

my %type_info =
(
    Adriver::BannerType::BAN_468x60 =>
    {
        'size' => { 'width' => 468, 'height' => 60 },
        'name' => '468x60',
    },
    Adriver::BannerType::BAN_100x100 =>
    {
        'size' => { 'width' => 100, 'height' => 100 },
        'name' => '100x100',
    },
    Adriver::BannerType::BAN_234x60 =>
    {
        'size' => { 'width' => 234, 'height' => 60 },
        'name' => '234x60',
    },
    Adriver::BannerType::BAN_125x125 =>
    {
        'size' => { 'width' => 125, 'height' => 125 },
        'name' => '125x125',
    },
    Adriver::BannerType::BAN_120x60 =>
    {
        'size' => { 'width' => 120, 'height' => 60 },
        'name' => '120x60',
    },
    Adriver::BannerType::BAN_120x40 =>
    {
        'size' => { 'width' => 120, 'height' => 40 },
        'name' => '120x40',
    },
    Adriver::BannerType::BAN_131x190 =>
    {
        'size' => { 'width' => 131, 'height' => 190 },
        'name' => '131x190',
    },
    Adriver::BannerType::BAN_240x120 =>
    {
        'size' => { 'width' => 240, 'height' => 120 },
        'name' => '240x120',
    },
    Adriver::BannerType::BAN_150x60 =>
    {
        'size' => { 'width' => 150, 'height' => 60 },
        'name' => '150x60',
    },
    Adriver::BannerType::BAN_150x80 =>
    {
        'size' => { 'width' => 150, 'height' => 80 },
        'name' => '150x80',
    },
    Adriver::BannerType::BAN_180x60 =>
    {
        'size' => { 'width' => 180, 'height' => 60 },
        'name' => '180x60',
    },
    Adriver::BannerType::BAN_179x69 =>
    {
        'size' => { 'width' => 179, 'height' => 69 },
        'name' => '179x69',
    },
    Adriver::BannerType::BAN_180x180 =>
    {
        'size' => { 'width' => 180, 'height' => 180 },
        'name' => '180x180',
    },
    Adriver::BannerType::BAN_468x200 =>
    {
        'size' => { 'width' => 468, 'height' => 200 },
        'name' => '468x200',
    },
    Adriver::BannerType::BAN_120x240 =>
    {
        'size' => { 'width' => 120, 'height' => 240 },
        'name' => '120x240',
    },
    Adriver::BannerType::JAVASCRIPT =>
    {
        'size' => { 'width' => 0, 'height' => 0 },
        'name' => 'javascript',
    },
    Adriver::BannerType::BAN_120x600 =>
    {
        'size' => { 'width' => 120, 'height' => 600 },
        'name' => '120x600',
    },
    Adriver::BannerType::BAN_125x300 =>
    {
        'size' => { 'width' => 125, 'height' => 300 },
        'name' => '125x300',
    },
    Adriver::BannerType::BAN_600x90 =>
    {
        'size' => { 'width' => 600, 'height' => 90 },
        'name' => '600x90',
    },
    Adriver::BannerType::BAN_600x120 =>
    {
        'size' => { 'width' => 600 , 'height' => 120 },
        'name' => '600x120',
    },
    Adriver::BannerType::ZEROPIXEL =>
    {
        'size' => { 'width' => 0, 'height' => 0 },
        'name' => 'ZeroPixel',
    },
    Adriver::BannerType::BAN_240x400 =>
    {
        'size' => { 'width' => 240, 'height' => 400 },
        'name' => '240x400',
    },
    Adriver::BannerType::BAN_234x120 =>
    {
        'size' => { 'width' => 234, 'height' => 120 },
        'name' => '234x120',
    },
    Adriver::BannerType::BAN_120x400 =>
    {
        'size' => { 'width' => 120, 'height' => 400 },
        'name' => '120x400',
    },
    Adriver::BannerType::BAN_120x90 =>
    {
        'size' => { 'width' => 120, 'height' => 90 },
        'name' => '120x90',
    },
    Adriver::BannerType::BAN_234x100 =>
    {
        'size' => { 'width' => 234, 'height' => 100 },
        'name' => '234x100',
    },
    Adriver::BannerType::BAN_336x280 =>
    {
        'size' => { 'width' => 336, 'height' => 280 },
        'name' => '336x280',
    },
    Adriver::BannerType::BAN_320x180 =>
    {
        'size' => { 'width' => 320, 'height' => 180 },
        'name' => '320x180',
    },
    Adriver::BannerType::BAN_160x600 =>
    {
        'size' => { 'width' => 160, 'height' => 600 },
        'name' => '160x600',
    },
    Adriver::BannerType::BAN_120x300 =>
    {
        'size' => { 'width' => 120, 'height' => 300 },
        'name' => '120x300',
    },
    Adriver::BannerType::BAN_160x100 =>
    {
        'size' => { 'width' => 160, 'height' => 100 },
        'name' => '160x100',
    },
    Adriver::BannerType::BAN_200x120 =>
    {
        'size' => { 'width' => 200, 'height' => 120 },
        'name' => '200x120',
    },
    Adriver::BannerType::BAN_200x350 =>
    {
        'size' => { 'width' => 200, 'height' => 350 },
        'name' => '200x350',
    },
    Adriver::BannerType::BAN_300x120 =>
    {
        'size' => { 'width' => 300, 'height' => 120 },
        'name' => '300x120',
    },
    Adriver::BannerType::BAN_180x140 =>
    {
        'size' => { 'width' => 180, 'height' => 140 },
        'name' => '180x140',
    },
    Adriver::BannerType::BAN_728x90 =>
    {
        'size' => { 'width' => 728, 'height' => 90 },
        'name' => '728x90',
    },
    Adriver::BannerType::BAN_800x40 =>
    {
        'size' => { 'width' => 800, 'height' => 40 },
        'name' => '800x40',
    },
    Adriver::BannerType::BAN_350x100 =>
    {
        'size' => { 'width' => 350, 'height' => 100 },
        'name' => '350x100',
    },
    Adriver::BannerType::BAN_375x70 =>
    {
        'size' => { 'width' => 375, 'height' => 70 },
        'name' => '375x70',
    },
    Adriver::BannerType::BAN_300x250 =>
    {
        'size' => { 'width' => 300, 'height' => 250 },
        'name' => '300x250',
    },
    Adriver::BannerType::BAN_970x90 =>
    {
        'size' => { 'width' => 970, 'height' => 90 },
        'name' => '970x90',
    },
    Adriver::BannerType::BAN_200x300 =>
    {
        'size' => { 'width' => 200, 'height' => 300 },
        'name' => '200x300',
    },
    Adriver::BannerType::EXTENSION =>
    {
        'size' => { 'width' => 0, 'height' => 0 },
        'name' => 'extension',
    },
    Adriver::BannerType::REDIRECT_240x400 =>
    {
        'size' => { 'width' => 240, 'height' => 400 },
        'name' => 'Redirect240x400',
    },
    Adriver::BannerType::REDIRECT_500x200 =>
    {
        'size' => { 'width' => 500, 'height' => 200 },
        'name' => 'Redirect500x200',
    },
    Adriver::BannerType::REDIRECT_600x90 =>
    {
        'size' => { 'width' => 600, 'height' => 90 },
        'name' => 'Redirect600x90',
    },
    Adriver::BannerType::BAN_350x120 =>
    {
        'size' => { 'width' => 350, 'height' => 120 },
        'name' => '350x120',
    },
    Adriver::BannerType::BAN_160x300 =>
    {
        'size' => { 'width' => 160, 'height' => 300 },
        'name' => '160x300',
    },
    Adriver::BannerType::POSTER =>
    {
        'size' => { 'width' => 0, 'height' => 0 },
        'name' => 'poster',
    },
    Adriver::BannerType::BAN_240x350 =>
    {
        'size' => { 'width' => 240, 'height' => 350 },
        'name' => '240x350',
    },
    Adriver::BannerType::BAN_500x200 =>
    {
        'size' => { 'width' => 500, 'height' => 200 },
        'name' => '500x200',
    },
    Adriver::BannerType::AJAX_JS =>
    {
        'size' => { 'width' => 0, 'height' => 0 },
        'name' => 'AjaxJS',
    },
    Adriver::BannerType::FLV_VIDEO =>
    {
        'size' => { 'width' => 0, 'height' => 0 },
        'name' => 'Flv video',
    },
    Adriver::BannerType::XML_BANNER =>
    {
        'size' => { 'width' => 0, 'height' => 0 },
        'name' => 'xml banner',
    },
    Adriver::BannerType::AUDIT =>
    {
        'size' => { 'width' => 0, 'height' => 0 },
        'name' => 'audit',
    },
    Adriver::BannerType::TEASER =>
    {
        'size' => { 'width' => 1, 'height' => 1 },
        'name' => 'teaser',
    },
    Adriver::BannerType::BAN_200x200 =>
    {
        'size' => { 'width' => 200, 'height' => 200 },
        'name' => '200x200',
    },
    Adriver::BannerType::BAN_250x250 =>
    {
        'size' => { 'width' => 250, 'height' => 250 },
        'name' => '250x250',
    },
    Adriver::BannerType::BAN_220x100 =>
    {
        'size' => { 'width' => 220, 'height' => 100 },
        'name' => '220x100',
    },
    Adriver::BannerType::BAN_220x350 =>
    {
        'size' => { 'width' => 220, 'height' => 350 },
        'name' => '220x350',
    },
    Adriver::BannerType::VAST =>
    {
        'size' => { 'width' => 0, 'height' => 0 },
        'name' => 'VAST',
    },
    Adriver::BannerType::JS_COUNTER =>
    {
        'size' => { 'width' => 0, 'height' => 0 },
        'name' => 'JS-counter',
    },
    Adriver::BannerType::BAN_300x600 =>
    {
        'size' => { 'width' => 300, 'height' => 600 },
        'name' => '300x600',
    },
    Adriver::BannerType::BAN_970x50 =>
    {
        'size' => { 'width' => 970, 'height' => 50 },
        'name' => '970x50',
    },
    Adriver::BannerType::BAN_320x100 =>
    {
        'size' => { 'width' => 320, 'height' => 100 },
        'name' => '320x100',
    },
    Adriver::BannerType::BAN_480x70 =>
    {
        'size' => { 'width' => 480, 'height' => 70 },
        'name' => '480x70',
    },
    Adriver::BannerType::BAN_320x50 =>
    {
        'size' => { 'width' => 320, 'height' => 50 },
        'name' => '320x50',
    },
);

my %spec_info =
(
    Adriver::BannerSpec::IMG_468x60 =>
    {
        'type'     => Adriver::BannerType::BAN_468x60,
        #'size'     => { 'width' => 468, 'height' => 60  },
        'comp1'    => Adriver::BannerComponentType::PICTURE,
        'exp_type' => Adriver::BannerExpType::EXPOSURE,
        'name'     => 'img468x60',
    },
    Adriver::BannerSpec::IMG_100x100 =>
    {
        'type'     => Adriver::BannerType::BAN_100x100,
        #'size'     => { 'width' => 100, 'height' => 100 },
        'comp1'    => Adriver::BannerComponentType::PICTURE,
        'exp_type' => Adriver::BannerExpType::EXPOSURE,
        'name'     => 'img100x100',
    },
    Adriver::BannerSpec::IMG_234x60 =>
    {
        'type'     => Adriver::BannerType::BAN_234x60,
        #'size'     => { 'width' => 234, 'height' => 60  },
        'comp1'    => Adriver::BannerComponentType::PICTURE,
        'exp_type' => Adriver::BannerExpType::EXPOSURE,
        'name'     => 'img234x60',
    },
    Adriver::BannerSpec::IMG_125x125 =>
    {
        'type'     => Adriver::BannerType::BAN_125x125,
        #'size'     => { 'width' => 125, 'height' => 125 },
        'comp1'    => Adriver::BannerComponentType::PICTURE,
        'exp_type' => Adriver::BannerExpType::EXPOSURE,
        'name'     => 'img125x125',
    },
    Adriver::BannerSpec::IMG_120x60 =>
    {
        'type'     => Adriver::BannerType::BAN_120x60,
        #'size'     => { 'width' => 120, 'height' => 60  },
        'comp1'    => Adriver::BannerComponentType::PICTURE,
        'exp_type' => Adriver::BannerExpType::EXPOSURE,
        'name'     => 'img120x60',
    },
    Adriver::BannerSpec::IMG_120x40 =>
    {
        'type'     => Adriver::BannerType::BAN_120x40,
        #'size'     => { 'width' => 120, 'height' => 40  },
        'comp1'    => Adriver::BannerComponentType::PICTURE,
        'exp_type' => Adriver::BannerExpType::EXPOSURE,
        'name'     => 'img120x40',
    },
    Adriver::BannerSpec::IMG_131x190 =>
    {
        'type'     => Adriver::BannerType::BAN_131x190,
        #'size'     => { 'width' => 131, 'height' => 190 },
        'comp1'    => Adriver::BannerComponentType::PICTURE,
        'exp_type' => Adriver::BannerExpType::EXPOSURE,
        'name'     => 'img131x190',
    },
    Adriver::BannerSpec::IMG_240x120 =>
    {
        'type'     => Adriver::BannerType::BAN_240x120,
        #'size'     => { 'width' => 240, 'height' => 120 },
        'comp1'    => Adriver::BannerComponentType::PICTURE,
        'exp_type' => Adriver::BannerExpType::EXPOSURE,
        'name'     => 'img240x120',
    },
    Adriver::BannerSpec::IMG_150x60 =>
    {
        'type'     => Adriver::BannerType::BAN_150x60,
        #'size'     => { 'width' => 150, 'height' => 60  },
        'comp1'    => Adriver::BannerComponentType::PICTURE,
        'exp_type' => Adriver::BannerExpType::EXPOSURE,
        'name'     => 'img150x60',
    },
    Adriver::BannerSpec::IMG_150x80 =>
    {
        'type'     => Adriver::BannerType::BAN_150x80,
        #'size'     => { 'width' => 150, 'height' => 80  },
        'comp1'    => Adriver::BannerComponentType::PICTURE,
        'exp_type' => Adriver::BannerExpType::EXPOSURE,
        'name'     => 'img150x80',
    },
    Adriver::BannerSpec::IMG_180x60 =>
    {
        'type'     => Adriver::BannerType::BAN_180x60,
        #'size'     => { 'width' => 180, 'height' => 60  },
        'comp1'    => Adriver::BannerComponentType::PICTURE,
        'exp_type' => Adriver::BannerExpType::EXPOSURE,
        'name'     => 'img180x60',
    },
    Adriver::BannerSpec::IMG_179x69 =>
    {
        'type'     => Adriver::BannerType::BAN_179x69,
        #'size'     => { 'width' => 179, 'height' => 69  },
        'comp1'    => Adriver::BannerComponentType::PICTURE,
        'exp_type' => Adriver::BannerExpType::EXPOSURE,
        'name'     => 'img179x69',
    },
    Adriver::BannerSpec::HTML_180x180 =>
    {
        'type'     => Adriver::BannerType::BAN_180x180,
        #'size'     => { 'width' => 180, 'height' => 180 },
        'comp1'    => Adriver::BannerComponentType::HTML,
        'exp_type' => Adriver::BannerExpType::EXPOSURE,
        'name'     => 'html180x180',
    },
    Adriver::BannerSpec::IMG_180x180 =>
    {
        'type'     => Adriver::BannerType::BAN_180x180,
        #'size'     => { 'width' => 180, 'height' => 180 },
        'comp1'    => Adriver::BannerComponentType::PICTURE,
        'exp_type' => Adriver::BannerExpType::EXPOSURE,
        'name'     => 'img180x180',
    },
    Adriver::BannerSpec::IMG_468x200 =>
    {
        'type'     => Adriver::BannerType::BAN_468x200,
        #'size'     => { 'width' => 468, 'height' => 200 },
        'comp1'    => Adriver::BannerComponentType::PICTURE,
        'exp_type' => Adriver::BannerExpType::EXPOSURE,
        'name'     => 'img468x200',
    },
    Adriver::BannerSpec::HTML_468x200 =>
    {
        'type'     => Adriver::BannerType::BAN_468x200,
        #'size'     => { 'width' => 468, 'height' => 200 },
        'comp1'    => Adriver::BannerComponentType::HTML,
        'exp_type' => Adriver::BannerExpType::EXPOSURE,
        'name'     => 'html468x200',
    },
    Adriver::BannerSpec::HTML_468x60 =>
    {
        'type'     => Adriver::BannerType::BAN_468x60,
        #'size'     => { 'width' => 468, 'height' => 60  },
        'comp1'    => Adriver::BannerComponentType::HTML,
        'exp_type' => Adriver::BannerExpType::EXPOSURE,
        'name'     => 'html468x60',
    },
    Adriver::BannerSpec::IMG_120x240 =>
    {
        'type'     => Adriver::BannerType::BAN_120x240,
        #'size'     => { 'width' => 120, 'height' => 240 },
        'comp1'    => Adriver::BannerComponentType::PICTURE,
        'exp_type' => Adriver::BannerExpType::EXPOSURE,
        'name'     => 'img120x240',
    },
    Adriver::BannerSpec::HTML_234x60 =>
    {
        'type'     => Adriver::BannerType::BAN_234x60,
        #'size'     => { 'width' => 234, 'height' => 60  },
        'comp1'    => Adriver::BannerComponentType::HTML,
        'exp_type' => Adriver::BannerExpType::EXPOSURE,
        'name'     => 'html234x60',
    },
    Adriver::BannerSpec::JAVASCRIPT =>
    {
        'type'     => Adriver::BannerType::JAVASCRIPT,
        #'size'     => { 'width' => 0,   'height' => 0   },
        'comp1'    => Adriver::BannerComponentType::HTML,
        'exp_type' => Adriver::BannerExpType::EXPOSURE,
        'name'     => 'JavaScript',
    },
    Adriver::BannerSpec::IMG_120x600 =>
    {
        'type'     => Adriver::BannerType::BAN_120x600,
        #'size'     => { 'width' => 120, 'height' => 600 },
        'comp1'    => Adriver::BannerComponentType::PICTURE,
        'exp_type' => Adriver::BannerExpType::EXPOSURE,
        'name'     => 'img120x600',
    },
    Adriver::BannerSpec::HTML_120x600 =>
    {
        'type'     => Adriver::BannerType::BAN_120x600,
        #'size'     => { 'width' => 120, 'height' => 600 },
        'comp1'    => Adriver::BannerComponentType::HTML,
        'exp_type' => Adriver::BannerExpType::EXPOSURE,
        'name'     => 'html120x600',
    },
    Adriver::BannerSpec::HTML_100x100 =>
    {
        'type'     => Adriver::BannerType::BAN_100x100,
        #'size'     => { 'width' => 100, 'height' => 100 },
        'comp1'    => Adriver::BannerComponentType::HTML,
        'exp_type' => Adriver::BannerExpType::EXPOSURE,
        'name'     => 'html100x100',
    },
    Adriver::BannerSpec::IMG_125x300 =>
    {
        'type'     => Adriver::BannerType::BAN_125x300,
        #'size'     => { 'width' => 125, 'height' => 300 },
        'comp1'    => Adriver::BannerComponentType::PICTURE,
        'exp_type' => Adriver::BannerExpType::EXPOSURE,
        'name'     => 'img125x300',
    },
    Adriver::BannerSpec::HTML_125x300 =>
    {
        'type'     => Adriver::BannerType::BAN_125x300,
        #'size'     => { 'width' => 125, 'height' => 300 },
        'comp1'    => Adriver::BannerComponentType::HTML,
        'exp_type' => Adriver::BannerExpType::EXPOSURE,
        'name'     => 'html125x300',
    },
    Adriver::BannerSpec::HTML_120x60 =>
    {
        'type'     => Adriver::BannerType::BAN_120x60,
        #'size'     => { 'width' => 120, 'height' => 60  },
        'comp1'    => Adriver::BannerComponentType::HTML,
        'exp_type' => Adriver::BannerExpType::EXPOSURE,
        'name'     => 'html120x60',
    },
    Adriver::BannerSpec::IMG_600x90 =>
    {
        'type'     => Adriver::BannerType::BAN_600x90,
        #'size'     => { 'width' => 600, 'height' => 90  },
        'comp1'    => Adriver::BannerComponentType::PICTURE,
        'exp_type' => Adriver::BannerExpType::EXPOSURE,
        'name'     => 'img600x90',
    },
    Adriver::BannerSpec::HTML_600x90 =>
    {
        'type'     => Adriver::BannerType::BAN_600x90,
        #'size'     => { 'width' => 600, 'height' => 90  },
        'comp1'    => Adriver::BannerComponentType::HTML,
        'exp_type' => Adriver::BannerExpType::EXPOSURE,
        'name'     => 'html600x90',
    },
    Adriver::BannerSpec::IMG_600x120 =>
    {
        'type'     => Adriver::BannerType::BAN_600x120,
        #'size'     => { 'width' => 600, 'height' => 120 },
        'comp1'    => Adriver::BannerComponentType::PICTURE,
        'exp_type' => Adriver::BannerExpType::EXPOSURE,
        'name'     => 'img600x120',
    },
    Adriver::BannerSpec::HTML_600x120 =>
    {
        'type'     => Adriver::BannerType::BAN_600x120,
        #'size'     => { 'width' => 600, 'height' => 120 },
        'comp1'    => Adriver::BannerComponentType::HTML,
        'exp_type' => Adriver::BannerExpType::EXPOSURE,
        'name'     => 'html600x120',
    },
    Adriver::BannerSpec::ZEROPIXEL =>
    {
        'type'     => Adriver::BannerType::ZEROPIXEL,
        #'size'     => { 'width' => 0,   'height' => 0   },
        'comp1'    => Adriver::BannerComponentType::HTML,
        'exp_type' => Adriver::BannerExpType::EXPOSURE,
        'name'     => 'ZeroPixel',
    },
    Adriver::BannerSpec::IMG_240x400 =>
    {
        'type'     => Adriver::BannerType::BAN_240x400,
        #'size'     => { 'width' => 240, 'height' => 400 },
        'comp1'    => Adriver::BannerComponentType::PICTURE,
        'exp_type' => Adriver::BannerExpType::EXPOSURE,
        'name'     => 'img240x400',
    },
    Adriver::BannerSpec::HTML_240x400 =>
    {
        'type'     => Adriver::BannerType::BAN_240x400,
        #'size'     => { 'width' => 240, 'height' => 400 },
        'comp1'    => Adriver::BannerComponentType::HTML,
        'exp_type' => Adriver::BannerExpType::EXPOSURE,
        'name'     => 'html240x400',
    },
    Adriver::BannerSpec::HTML_120x240 =>
    {
        'type'     => Adriver::BannerType::BAN_120x240,
        #'size'     => { 'width' => 120, 'height' => 240 },
        'comp1'    => Adriver::BannerComponentType::HTML,
        'exp_type' => Adriver::BannerExpType::EXPOSURE,
        'name'     => 'html120x240',
    },
    Adriver::BannerSpec::IMG_234x120 =>
    {
        'type'     => Adriver::BannerType::BAN_234x120,
        #'size'     => { 'width' => 234, 'height' => 120 },
        'comp1'    => Adriver::BannerComponentType::PICTURE,
        'exp_type' => Adriver::BannerExpType::EXPOSURE,
        'name'     => 'img234x120',
    },
    Adriver::BannerSpec::HTML_234x120 =>
    {
        'type'     => Adriver::BannerType::BAN_234x120,
        #'size'     => { 'width' => 234, 'height' => 120 },
        'comp1'    => Adriver::BannerComponentType::HTML,
        'exp_type' => Adriver::BannerExpType::EXPOSURE,
        'name'     => 'html234x120',
    },
    Adriver::BannerSpec::HTML_150x60 =>
    {
        'type'     => Adriver::BannerType::BAN_150x60,
        #'size'     => { 'width' => 150, 'height' => 60  },
        'comp1'    => Adriver::BannerComponentType::HTML,
        'exp_type' => Adriver::BannerExpType::EXPOSURE,
        'name'     => 'html150x60',
    },
    Adriver::BannerSpec::IMG_120x400 =>
    {
        'type'     => Adriver::BannerType::BAN_120x400,
        #'size'     => { 'width' => 120, 'height' => 400 },
        'comp1'    => Adriver::BannerComponentType::PICTURE,
        'exp_type' => Adriver::BannerExpType::EXPOSURE,
        'name'     => 'img120x400',
    },
    Adriver::BannerSpec::HTML_120x400 =>
    {
        'type'     => Adriver::BannerType::BAN_120x400,
        #'size'     => { 'width' => 120, 'height' => 400 },
        'comp1'    => Adriver::BannerComponentType::HTML,
        'exp_type' => Adriver::BannerExpType::EXPOSURE,
        'name'     => 'html120x400',
    },
    Adriver::BannerSpec::IMG_120x90 =>
    {
        'type'     => Adriver::BannerType::BAN_120x90,
        #'size'     => { 'width' => 120, 'height' => 90  },
        'comp1'    => Adriver::BannerComponentType::PICTURE,
        'exp_type' => Adriver::BannerExpType::EXPOSURE,
        'name'     => 'img120x90',
    },
    Adriver::BannerSpec::HTML_120x90 =>
    {
        'type'     => Adriver::BannerType::BAN_120x90,
        #'size'     => { 'width' => 120, 'height' => 90  },
        'comp1'    => Adriver::BannerComponentType::HTML,
        'exp_type' => Adriver::BannerExpType::EXPOSURE,
        'name'     => 'html120x90',
    },
    Adriver::BannerSpec::IMG_234x100 =>
    {
        'type'     => Adriver::BannerType::BAN_234x100,
        #'size'     => { 'width' => 234, 'height' => 100 },
        'comp1'    => Adriver::BannerComponentType::PICTURE,
        'exp_type' => Adriver::BannerExpType::EXPOSURE,
        'name'     => 'img234x100',
    },
    Adriver::BannerSpec::HTML_234x100 =>
    {
        'type'     => Adriver::BannerType::BAN_234x100,
        #'size'     => { 'width' => 234, 'height' => 100 },
        'comp1'    => Adriver::BannerComponentType::HTML,
        'exp_type' => Adriver::BannerExpType::EXPOSURE,
        'name'     => 'html234x100',
    },
    Adriver::BannerSpec::IMG_336x280 =>
    {
        'type'     => Adriver::BannerType::BAN_336x280,
        #'size'     => { 'width' => 336, 'height' => 280 },
        'comp1'    => Adriver::BannerComponentType::PICTURE,
        'exp_type' => Adriver::BannerExpType::EXPOSURE,
        'name'     => 'img336x280',
    },
    Adriver::BannerSpec::HTML_336x280 =>
    {
        'type'     => Adriver::BannerType::BAN_336x280,
        #'size'     => { 'width' => 336, 'height' => 280 },
        'comp1'    => Adriver::BannerComponentType::HTML,
        'exp_type' => Adriver::BannerExpType::EXPOSURE,
        'name'     => 'html336x280',
    },
    Adriver::BannerSpec::IMG_320x180 =>
    {
        'type'     => Adriver::BannerType::BAN_320x180,
        #'size'     => { 'width' => 320, 'height' => 180 },
        'comp1'    => Adriver::BannerComponentType::PICTURE,
        'exp_type' => Adriver::BannerExpType::EXPOSURE,
        'name'     => 'img320x180',
    },
    Adriver::BannerSpec::HTML_320x180 =>
    {
        'type'     => Adriver::BannerType::BAN_320x180,
        #'size'     => { 'width' => 320, 'height' => 180 },
        'comp1'    => Adriver::BannerComponentType::HTML,
        'exp_type' => Adriver::BannerExpType::EXPOSURE,
        'name'     => 'html320x180',
    },
    Adriver::BannerSpec::IMG_160x600 =>
    {
        'type'     => Adriver::BannerType::BAN_160x600,
        #'size'     => { 'width' => 160, 'height' => 600 },
        'comp1'    => Adriver::BannerComponentType::PICTURE,
        'exp_type' => Adriver::BannerExpType::EXPOSURE,
        'name'     => 'img160x600',
    },
    Adriver::BannerSpec::HTML_160x600 =>
    {
        'type'     => Adriver::BannerType::BAN_160x600,
        #'size'     => { 'width' => 160, 'height' => 600 },
        'comp1'    => Adriver::BannerComponentType::HTML,
        'exp_type' => Adriver::BannerExpType::EXPOSURE,
        'name'     => 'html160x600',
    },
    Adriver::BannerSpec::IMG_120x300 =>
    {
        'type'     => Adriver::BannerType::BAN_120x300,
        #'size'     => { 'width' => 120, 'height' => 300 },
        'comp1'    => Adriver::BannerComponentType::PICTURE,
        'exp_type' => Adriver::BannerExpType::EXPOSURE,
        'name'     => 'img120x300',
    },
    Adriver::BannerSpec::HTML_120x300 =>
    {
        'type'     => Adriver::BannerType::BAN_120x300,
        #'size'     => { 'width' => 120, 'height' => 300 },
        'comp1'    => Adriver::BannerComponentType::HTML,
        'exp_type' => Adriver::BannerExpType::EXPOSURE,
        'name'     => 'html120x300',
    },
    Adriver::BannerSpec::HTML_125x125 =>
    {
        'type'     => Adriver::BannerType::BAN_125x125,
        #'size'     => { 'width' => 125, 'height' => 125 },
        'comp1'    => Adriver::BannerComponentType::HTML,
        'exp_type' => Adriver::BannerExpType::EXPOSURE,
        'name'     => 'html125x125',
    },
    Adriver::BannerSpec::IMG_160x100 =>
    {
        'type'     => Adriver::BannerType::BAN_160x100,
        #'size'     => { 'width' => 160, 'height' => 100 },
        'comp1'    => Adriver::BannerComponentType::PICTURE,
        'exp_type' => Adriver::BannerExpType::EXPOSURE,
        'name'     => 'img160x100',
    },
    Adriver::BannerSpec::HTML_160x100 =>
    {
        'type'     => Adriver::BannerType::BAN_160x100,
        #'size'     => { 'width' => 160, 'height' => 100 },
        'comp1'    => Adriver::BannerComponentType::HTML,
        'exp_type' => Adriver::BannerExpType::EXPOSURE,
        'name'     => 'html160x100',
    },
    Adriver::BannerSpec::IMG_200x120 =>
    {
        'type'     => Adriver::BannerType::BAN_200x120,
        #'size'     => { 'width' => 200, 'height' => 120 },
        'comp1'    => Adriver::BannerComponentType::PICTURE,
        'exp_type' => Adriver::BannerExpType::EXPOSURE,
        'name'     => 'img200x120',
    },
    Adriver::BannerSpec::HTML_200x120 =>
    {
        'type'     => Adriver::BannerType::BAN_200x120,
        #'size'     => { 'width' => 200, 'height' => 120 },
        'comp1'    => Adriver::BannerComponentType::HTML,
        'exp_type' => Adriver::BannerExpType::EXPOSURE,
        'name'     => 'html200x120',
    },
    Adriver::BannerSpec::IMG_200x350 =>
    {
        'type'     => Adriver::BannerType::BAN_200x350,
        #'size'     => { 'width' => 200, 'height' => 350 },
        'comp1'    => Adriver::BannerComponentType::PICTURE,
        'exp_type' => Adriver::BannerExpType::EXPOSURE,
        'name'     => 'img200x350',
    },
    Adriver::BannerSpec::HTML_200x350 =>
    {
        'type'     => Adriver::BannerType::BAN_200x350,
        #'size'     => { 'width' => 200, 'height' => 350 },
        'comp1'    => Adriver::BannerComponentType::HTML,
        'exp_type' => Adriver::BannerExpType::EXPOSURE,
        'name'     => 'html200x350',
    },
    Adriver::BannerSpec::POPUNDER =>
    {
        'type'     => Adriver::BannerType::JAVASCRIPT,
        #'size'     => { 'width' => 0,   'height' => 0   },
        'comp1'    => Adriver::BannerComponentType::HTML,
        'exp_type' => Adriver::BannerExpType::SUBEVENT0,
        'name'     => 'popunder',
    },
    Adriver::BannerSpec::IMG_300x120 =>
    {
        'type'     => Adriver::BannerType::BAN_300x120,
        #'size'     => { 'width' => 300, 'height' => 120 },
        'comp1'    => Adriver::BannerComponentType::PICTURE,
        'exp_type' => Adriver::BannerExpType::EXPOSURE,
        'name'     => 'img300x120',
    },
    Adriver::BannerSpec::HTML_300x120 =>
    {
        'type'     => Adriver::BannerType::BAN_300x120,
        #'size'     => { 'width' => 300, 'height' => 120 },
        'comp1'    => Adriver::BannerComponentType::HTML,
        'exp_type' => Adriver::BannerExpType::EXPOSURE,
        'name'     => 'html300x120',
    },
    Adriver::BannerSpec::IMG_180x140 =>
    {
        'type'     => Adriver::BannerType::BAN_180x140,
        #'size'     => { 'width' => 180, 'height' => 140 },
        'comp1'    => Adriver::BannerComponentType::PICTURE,
        'exp_type' => Adriver::BannerExpType::EXPOSURE,
        'name'     => 'img180x140',
    },
    Adriver::BannerSpec::HTML_180x140 =>
    {
        'type'     => Adriver::BannerType::BAN_180x140,
        #'size'     => { 'width' => 180, 'height' => 140 },
        'comp1'    => Adriver::BannerComponentType::HTML,
        'exp_type' => Adriver::BannerExpType::EXPOSURE,
        'name'     => 'html180x140',
    },
    Adriver::BannerSpec::IMG_728x90 =>
    {
        'type'     => Adriver::BannerType::BAN_728x90,
        #'size'     => { 'width' => 728, 'height' => 90  },
        'comp1'    => Adriver::BannerComponentType::PICTURE,
        'exp_type' => Adriver::BannerExpType::EXPOSURE,
        'name'     => 'img728x90',
    },
    Adriver::BannerSpec::HTML_728x90 =>
    {
        'type'     => Adriver::BannerType::BAN_728x90,
        #'size'     => { 'width' => 728, 'height' => 90  },
        'comp1'    => Adriver::BannerComponentType::HTML,
        'exp_type' => Adriver::BannerExpType::EXPOSURE,
        'name'     => 'html728x90',
    },
    Adriver::BannerSpec::IMG_800x40 =>
    {
        'type'     => Adriver::BannerType::BAN_800x40,
        #'size'     => { 'width' => 800, 'height' => 40  },
        'comp1'    => Adriver::BannerComponentType::PICTURE,
        'exp_type' => Adriver::BannerExpType::EXPOSURE,
        'name'     => 'img800x40',
    },
    Adriver::BannerSpec::HTML_800x40 =>
    {
        'type'     => Adriver::BannerType::BAN_800x40,
        #'size'     => { 'width' => 800, 'height' => 40  },
        'comp1'    => Adriver::BannerComponentType::HTML,
        'exp_type' => Adriver::BannerExpType::EXPOSURE,
        'name'     => 'html800x40',
    },
    Adriver::BannerSpec::IMG_350x100 =>
    {
        'type'     => Adriver::BannerType::BAN_350x100,
        #'size'     => { 'width' => 350, 'height' => 100 },
        'comp1'    => Adriver::BannerComponentType::PICTURE,
        'exp_type' => Adriver::BannerExpType::EXPOSURE,
        'name'     => 'img350x100',
    },
    Adriver::BannerSpec::HTML_350x100 =>
    {
        'type'     => Adriver::BannerType::BAN_350x100,
        #'size'     => { 'width' => 350, 'height' => 100 },
        'comp1'    => Adriver::BannerComponentType::HTML,
        'exp_type' => Adriver::BannerExpType::EXPOSURE,
        'name'     => 'html350x100',
    },
    Adriver::BannerSpec::IMG_375x70 =>
    {
        'type'     => Adriver::BannerType::BAN_375x70,
        #'size'     => { 'width' => 375, 'height' => 70  },
        'comp1'    => Adriver::BannerComponentType::PICTURE,
        'exp_type' => Adriver::BannerExpType::EXPOSURE,
        'name'     => 'img375x70',
    },
    Adriver::BannerSpec::HTML_375x70 =>
    {
        'type'     => Adriver::BannerType::BAN_375x70,
        #'size'     => { 'width' => 375, 'height' => 70  },
        'comp1'    => Adriver::BannerComponentType::HTML,
        'exp_type' => Adriver::BannerExpType::EXPOSURE,
        'name'     => 'html375x70',
    },
    Adriver::BannerSpec::HTML_240x120 =>
    {
        'type'     => Adriver::BannerType::BAN_240x120,
        #'size'     => { 'width' => 240, 'height' => 120 },
        'comp1'    => Adriver::BannerComponentType::HTML,
        'exp_type' => Adriver::BannerExpType::EXPOSURE,
        'name'     => 'html240x120',
    },
    Adriver::BannerSpec::HTML_150x80 =>
    {
        'type'     => Adriver::BannerType::BAN_150x80,
        #'size'     => { 'width' => 150, 'height' => 80  },
        'comp1'    => Adriver::BannerComponentType::HTML,
        'exp_type' => Adriver::BannerExpType::EXPOSURE,
        'name'     => 'html150x80',
    },
    Adriver::BannerSpec::IMG_300x250 =>
    {
        'type'     => Adriver::BannerType::BAN_300x250,
        #'size'     => { 'width' => 300, 'height' => 250 },
        'comp1'    => Adriver::BannerComponentType::PICTURE,
        'exp_type' => Adriver::BannerExpType::EXPOSURE,
        'name'     => 'img300x250',
    },
    Adriver::BannerSpec::HTML_300x250 =>
    {
        'type'     => Adriver::BannerType::BAN_300x250,
        #'size'     => { 'width' => 300, 'height' => 250 },
        'comp1'    => Adriver::BannerComponentType::HTML,
        'exp_type' => Adriver::BannerExpType::EXPOSURE,
        'name'     => 'html300x250',
    },
    Adriver::BannerSpec::RICHMEDIA =>
    {
        'type'     => Adriver::BannerType::JAVASCRIPT,
        #'size'     => { 'width' => 0,   'height' => 0   },
        'comp1'    => Adriver::BannerComponentType::HTML,
        'exp_type' => Adriver::BannerExpType::SUBEVENT0,
        'name'     => 'rich-media',
    },
    Adriver::BannerSpec::NETVIDEO =>
    {
        'type'     => Adriver::BannerType::EXTENSION,
        #'size'     => { 'width' => 0,   'height' => 0   },
        'comp1'    => Adriver::BannerComponentType::HTML,
        'exp_type' => Adriver::BannerExpType::SUBEVENT0,
        'name'     => 'netvideo',
    },
    Adriver::BannerSpec::IMG_200x300 =>
    {
        'type'     => Adriver::BannerType::BAN_200x300,
        #'size'     => { 'width' => 200, 'height' => 300 },
        'comp1'    => Adriver::BannerComponentType::PICTURE,
        'exp_type' => Adriver::BannerExpType::EXPOSURE,
        'name'     => 'img200x300',
    },
    Adriver::BannerSpec::HTML_200x300 =>
    {
        'type'     => Adriver::BannerType::BAN_200x300,
        #'size'     => { 'width' => 200, 'height' => 300 },
        'comp1'    => Adriver::BannerComponentType::HTML,
        'exp_type' => Adriver::BannerExpType::EXPOSURE,
        'name'     => 'html200x300',
    },
    Adriver::BannerSpec::EXTENSION =>
    {
        'type'     => Adriver::BannerType::EXTENSION,
        #'size'     => { 'width' => 0,   'height' => 0   },
        'comp1'    => Adriver::BannerComponentType::HTML,
        'exp_type' => Adriver::BannerExpType::EXPOSURE,
        'name'     => 'extension',
    },
    Adriver::BannerSpec::REDIRECT_FLASH_240x400 =>
    {
        'type'     => Adriver::BannerType::REDIRECT_240x400,
        #'size'     => { 'width' => 240, 'height' => 400 },
        'comp1'    => Adriver::BannerComponentType::HTML,
        'exp_type' => Adriver::BannerExpType::EXPOSURE,
        'name'     => 'redirect_flash240x400',
    },
    Adriver::BannerSpec::HTML_179x69 =>
    {
        'type'     => Adriver::BannerType::BAN_179x69,
        #'size'     => { 'width' => 179, 'height' => 69  },
        'comp1'    => Adriver::BannerComponentType::HTML,
        'exp_type' => Adriver::BannerExpType::EXPOSURE,
        'name'     => 'html179x69',
    },
    Adriver::BannerSpec::REDIRECT_FLASH_500x200 =>
    {
        'type'     => Adriver::BannerType::REDIRECT_500x200,
        #'size'     => { 'width' => 500, 'height' => 200 },
        'comp1'    => Adriver::BannerComponentType::HTML,
        'exp_type' => Adriver::BannerExpType::EXPOSURE,
        'name'     => 'redirect_flash500x200',
    },
    Adriver::BannerSpec::REDIRECT_FLASH_600x90 =>
    {
        'type'     => Adriver::BannerType::REDIRECT_600x90,
        #'size'     => { 'width' => 600, 'height' => 90  },
        'comp1'    => Adriver::BannerComponentType::HTML,
        'exp_type' => Adriver::BannerExpType::EXPOSURE,
        'name'     => 'redirect_flash600x90',
    },
    Adriver::BannerSpec::IMG_350x120 =>
    {
        'type'     => Adriver::BannerType::BAN_350x120,
        #'size'     => { 'width' => 350, 'height' => 120 },
        'comp1'    => Adriver::BannerComponentType::PICTURE,
        'exp_type' => Adriver::BannerExpType::EXPOSURE,
        'name'     => 'img350x120',
    },
    Adriver::BannerSpec::HTML_350x120 =>
    {
        'type'     => Adriver::BannerType::BAN_350x120,
        #'size'     => { 'width' => 350, 'height' => 120 },
        'comp1'    => Adriver::BannerComponentType::HTML,
        'exp_type' => Adriver::BannerExpType::EXPOSURE,
        'name'     => 'html350x120',
    },
    Adriver::BannerSpec::IMG_970x90 =>
    {
        'type'     => Adriver::BannerType::BAN_970x90,
        #'size'     => { 'width' => 970, 'height' => 90  },
        'comp1'    => Adriver::BannerComponentType::PICTURE,
        'exp_type' => Adriver::BannerExpType::EXPOSURE,
        'name'     => 'img970x90',
    },
    Adriver::BannerSpec::HTML_970x90 =>
    {
        'type'     => Adriver::BannerType::BAN_970x90,
        #'size'     => { 'width' => 970, 'height' => 90  },
        'comp1'    => Adriver::BannerComponentType::HTML,
        'exp_type' => Adriver::BannerExpType::EXPOSURE,
        'name'     => 'html970x90',
    },
    Adriver::BannerSpec::IMG_160x300 =>
    {
        'type'     => Adriver::BannerType::BAN_160x300,
        #'size'     => { 'width' => 160, 'height' => 300 },
        'comp1'    => Adriver::BannerComponentType::PICTURE,
        'exp_type' => Adriver::BannerExpType::EXPOSURE,
        'name'     => 'img160x300',
    },
    Adriver::BannerSpec::HTML_160x300 =>
    {
        'type'     => Adriver::BannerType::BAN_160x300,
        #'size'     => { 'width' => 160, 'height' => 300 },
        'comp1'    => Adriver::BannerComponentType::HTML,
        'exp_type' => Adriver::BannerExpType::EXPOSURE,
        'name'     => 'html160x300',
    },
    Adriver::BannerSpec::GENERIC_POSTER =>
    {
        'type'     => Adriver::BannerType::POSTER,
        #'size'     => { 'width' => 0,   'height' => 0   },
        'comp1'    => Adriver::BannerComponentType::HTML,
        'exp_type' => Adriver::BannerExpType::EXPOSURE,
        'name'     => 'genericposter',
    },
    Adriver::BannerSpec::FLASH_POSTER =>
    {
        'type'     => Adriver::BannerType::POSTER,
        #'size'     => { 'width' => 0,   'height' => 0   },
        'comp1'    => Adriver::BannerComponentType::HTML,
        'exp_type' => Adriver::BannerExpType::EXPOSURE,
        'name'     => 'flash_poster',
    },
    Adriver::BannerSpec::HTML_240x350 =>
    {
        'type'     => Adriver::BannerType::BAN_240x350,
        #'size'     => { 'width' => 240, 'height' => 350 },
        'comp1'    => Adriver::BannerComponentType::HTML,
        'exp_type' => Adriver::BannerExpType::EXPOSURE,
        'name'     => 'html240x350',
    },
    Adriver::BannerSpec::IMG_240x350 =>
    {
        'type'     => Adriver::BannerType::BAN_240x350,
        #'size'     => { 'width' => 240, 'height' => 350 },
        'comp1'    => Adriver::BannerComponentType::PICTURE,
        'exp_type' => Adriver::BannerExpType::EXPOSURE,
        'name'     => 'img240x350',
    },
    Adriver::BannerSpec::HTML_500x200 =>
    {
        'type'     => Adriver::BannerType::BAN_500x200,
        #'size'     => { 'width' => 500, 'height' => 200 },
        'comp1'    => Adriver::BannerComponentType::HTML,
        'exp_type' => Adriver::BannerExpType::EXPOSURE,
        'name'     => 'html500x200',
    },
    Adriver::BannerSpec::IMG_500x200 =>
    {
        'type'     => Adriver::BannerType::BAN_500x200,
        #'size'     => { 'width' => 500, 'height' => 200 },
        'comp1'    => Adriver::BannerComponentType::PICTURE,
        'exp_type' => Adriver::BannerExpType::EXPOSURE,
        'name'     => 'img500x200',
    },
    Adriver::BannerSpec::SCREENGLIDE =>
    {
        'type'     => Adriver::BannerType::EXTENSION,
        #'size'     => { 'width' => 0,   'height' => 0   },
        'comp1'    => Adriver::BannerComponentType::HTML,
        'exp_type' => Adriver::BannerExpType::EXPOSURE,
        'name'     => 'ScreenGlide',
    },
    Adriver::BannerSpec::SG_POSTER =>
    {
        'type'     => Adriver::BannerType::POSTER,
        #'size'     => { 'width' => 0,   'height' => 0   },
        'comp1'    => Adriver::BannerComponentType::HTML,
        'exp_type' => Adriver::BannerExpType::EXPOSURE,
        'name'     => 'SG-Poster',
    },
    Adriver::BannerSpec::GENERIC_EXTENSION =>
    {
        'type'     => Adriver::BannerType::EXTENSION,
        #'size'     => { 'width' => 0,   'height' => 0   },
        'comp1'    => Adriver::BannerComponentType::HTML,
        'exp_type' => Adriver::BannerExpType::EXPOSURE,
        'name'     => 'generic-extension',
    },
    Adriver::BannerSpec::GENERIC_AJAX_JS =>
    {
        'type'     => Adriver::BannerType::AJAX_JS,
        #'size'     => { 'width' => 0,   'height' => 0   },
        'comp1'    => Adriver::BannerComponentType::HTML,
        'exp_type' => Adriver::BannerExpType::EXPOSURE,
        'name'     => 'Generic AjaxJS',
    },
    Adriver::BannerSpec::FLASH_AJAX_JS =>
    {
        'type'     => Adriver::BannerType::AJAX_JS,
        #'size'     => { 'width' => 0,   'height' => 0   },
        'comp1'    => Adriver::BannerComponentType::HTML,
        'exp_type' => Adriver::BannerExpType::EXPOSURE,
        'name'     => 'Flash-AjaxJS',
    },
    Adriver::BannerSpec::SESSION_POSTER =>
    {
        'type'     => Adriver::BannerType::POSTER,
        #'size'     => { 'width' => 0,   'height' => 0   },
        'comp1'    => Adriver::BannerComponentType::HTML,
        'exp_type' => Adriver::BannerExpType::SUBEVENT0,
        'name'     => 'session_poster',
    },
    Adriver::BannerSpec::EMPTY_CLICK =>
    {
        'type'     => Adriver::BannerType::ZEROPIXEL,
        #'size'     => { 'width' => 0,   'height' => 0   },
        'comp1'    => Adriver::BannerComponentType::HTML,
        'exp_type' => Adriver::BannerExpType::EXPOSURE,
        'name'     => 'emptyclick',
    },
    Adriver::BannerSpec::FLV_VIDEO =>
    {
        'type'     => Adriver::BannerType::FLV_VIDEO,
        #'size'     => { 'width' => 0,   'height' => 0   },
        'comp1'    => Adriver::BannerComponentType::HTML,
        'exp_type' => Adriver::BannerExpType::EXPOSURE,
        'name'     => 'Flv video',
    },
    Adriver::BannerSpec::XML_BANNER =>
    {
        'type'     => Adriver::BannerType::XML_BANNER,
        #'size'     => { 'width' => 0,   'height' => 0   },
        'comp1'    => Adriver::BannerComponentType::HTML,
        'exp_type' => Adriver::BannerExpType::EXPOSURE,
        'name'     => 'xml banner',
    },
    Adriver::BannerSpec::REDIRECT_ZEROPIXEL =>
    {
        'type'     => Adriver::BannerType::ZEROPIXEL,
        #'size'     => { 'width' => 0,   'height' => 0   },
        'comp1'    => Adriver::BannerComponentType::HTML,
        'exp_type' => Adriver::BannerExpType::EXPOSURE,
        'name'     => 'redirect zeropixel',
    },
    Adriver::BannerSpec::FULLSCREEN =>
    {
        'type'     => Adriver::BannerType::EXTENSION,
        #'size'     => { 'width' => 0,   'height' => 0   },
        'comp1'    => Adriver::BannerComponentType::HTML,
        'exp_type' => Adriver::BannerExpType::EXPOSURE,
        'name'     => 'fullscreen',
    },
    Adriver::BannerSpec::VARIABLE_EXTENSION =>
    {
        'type'     => Adriver::BannerType::EXTENSION,
        #'size'     => { 'width' => 0,   'height' => 0   },
        'comp1'    => Adriver::BannerComponentType::HTML,
        'exp_type' => Adriver::BannerExpType::EXPOSURE,
        'name'     => 'variable_extension',
    },
    Adriver::BannerSpec::GENERIC_XML =>
    {
        'type'     => Adriver::BannerType::XML_BANNER,
        #'size'     => { 'width' => 0,   'height' => 0   },
        'comp1'    => Adriver::BannerComponentType::HTML,
        'exp_type' => Adriver::BannerExpType::EXPOSURE,
        'name'     => 'generic xml',
    },
    Adriver::BannerSpec::AUDIT =>
    {
        'type'     => Adriver::BannerType::AUDIT,
        #'size'     => { 'width' => 0,   'height' => 0   },
        'comp1'    => Adriver::BannerComponentType::HTML,
        'exp_type' => Adriver::BannerExpType::EXPOSURE,
        'name'     => 'audit',
    },
    Adriver::BannerSpec::REDIRECT_AUDIT =>
    {
        'type'     => Adriver::BannerType::AUDIT,
        #'size'     => { 'width' => 0,   'height' => 0   },
        'comp1'    => Adriver::BannerComponentType::HTML,
        'exp_type' => Adriver::BannerExpType::EXPOSURE,
        'name'     => 'audit redirect',
    },
    Adriver::BannerSpec::TEASER =>
    {
        'type'     => Adriver::BannerType::TEASER,
        #'size'     => { 'width' => 0,   'height' => 0   },
        'comp1'    => Adriver::BannerComponentType::PICTURE,
        'exp_type' => Adriver::BannerExpType::EXPOSURE,
        'name'     => 'teaser',
    },
    Adriver::BannerSpec::XML_FLASH_MODULE =>
    {
        'type'     => Adriver::BannerType::XML_BANNER,
        #'size'     => { 'width' => 0,   'height' => 0   },
        'comp1'    => Adriver::BannerComponentType::HTML,
        'exp_type' => Adriver::BannerExpType::SUBEVENT0,
        'name'     => 'xml flash module',
    },
    Adriver::BannerSpec::FULLSCREEN_AJAX_JS =>
    {
        'type'     => Adriver::BannerType::AJAX_JS,
        #'size'     => { 'width' => 0,   'height' => 0   },
        'comp1'    => Adriver::BannerComponentType::HTML,
        'exp_type' => Adriver::BannerExpType::EXPOSURE,
        'name'     => 'FullScreen-AjaxJS',
    },
    Adriver::BannerSpec::FLASH_EXTENSION =>
    {
        'type'     => Adriver::BannerType::EXTENSION,
        #'size'     => { 'width' => 0,   'height' => 0   },
        'comp1'    => Adriver::BannerComponentType::HTML,
        'exp_type' => Adriver::BannerExpType::EXPOSURE,
        'name'     => 'flash-extension',
    },
    Adriver::BannerSpec::XML_VAST_VIDEO =>
    {
        'type'     => Adriver::BannerType::XML_BANNER,
        #'size'     => { 'width' => 0,   'height' => 0   },
        'comp1'    => Adriver::BannerComponentType::HTML,
        'exp_type' => Adriver::BannerExpType::SUBEVENT0,
        'name'     => 'XML-VAST video',
    },
    Adriver::BannerSpec::XML_VAST_VIDEO_REDIRECT =>
    {
        'type'     => Adriver::BannerType::XML_BANNER,
        #'size'     => { 'width' => 0,   'height' => 0   },
        'comp1'    => Adriver::BannerComponentType::HTML,
        'exp_type' => Adriver::BannerExpType::SUBEVENT0,
        'name'     => 'XML-VAST video redirect',
    },
    Adriver::BannerSpec::IMG_200x200 =>
    {
        'type'     => Adriver::BannerType::BAN_200x200,
        #'size'     => { 'width' => 200, 'height' => 200 },
        'comp1'    => Adriver::BannerComponentType::PICTURE,
        'exp_type' => Adriver::BannerExpType::EXPOSURE,
        'name'     => 'img200x200',
    },
    Adriver::BannerSpec::IMG_250x250 =>
    {
        'type'     => Adriver::BannerType::BAN_250x250,
        #'size'     => { 'width' => 250, 'height' => 250 },
        'comp1'    => Adriver::BannerComponentType::PICTURE,
        'exp_type' => Adriver::BannerExpType::EXPOSURE,
        'name'     => 'img250x250',
    },
    Adriver::BannerSpec::HTML_220x100 =>
    {
        'type'     => Adriver::BannerType::BAN_220x100,
        #'size'     => { 'width' => 220, 'height' => 100 },
        'comp1'    => Adriver::BannerComponentType::HTML,
        'exp_type' => Adriver::BannerExpType::EXPOSURE,
        'name'     => 'html220x100',
    },
    Adriver::BannerSpec::HTML_220x350 =>
    {
        'type'     => Adriver::BannerType::BAN_220x350,
        #'size'     => { 'width' => 220, 'height' => 350 },
        'comp1'    => Adriver::BannerComponentType::HTML,
        'exp_type' => Adriver::BannerExpType::EXPOSURE,
        'name'     => 'html220x350',
    },
    Adriver::BannerSpec::SUBSTITUTION_RICH =>
    {
        'type'     => Adriver::BannerType::JAVASCRIPT,
        #'size'     => { 'width' => 1,   'height' => 1   },
        'comp1'    => Adriver::BannerComponentType::HTML,
        'exp_type' => Adriver::BannerExpType::SUBEVENT0,
        'name'     => 'SubstitutionRich',
    },
    Adriver::BannerSpec::HTML_200x200 =>
    {
        'type'     => Adriver::BannerType::BAN_200x200,
        #'size'     => { 'width' => 200, 'height' => 200 },
        'comp1'    => Adriver::BannerComponentType::HTML,
        'exp_type' => Adriver::BannerExpType::EXPOSURE,
        'name'     => 'html200x200',
    },
    Adriver::BannerSpec::VAST_VIDEO =>
    {
        'type'     => Adriver::BannerType::VAST,
        #'size'     => { 'width' => 0,   'height' => 0   },
        'comp1'    => Adriver::BannerComponentType::HTML,
        'exp_type' => Adriver::BannerExpType::SUBEVENT0,
        'name'     => 'VAST video',
    },
    Adriver::BannerSpec::VAST_VIDEO_REDIRECT =>
    {
        'type'     => Adriver::BannerType::VAST,
        #'size'     => { 'width' => 0,   'height' => 0   },
        'comp1'    => Adriver::BannerComponentType::HTML,
        'exp_type' => Adriver::BannerExpType::SUBEVENT0,
        'name'     => 'VAST video redirect',
    },
    Adriver::BannerSpec::JS_COUNTER =>
    {
        'type'     => Adriver::BannerType::JS_COUNTER,
        #'size'     => { 'width' => 0,   'height' => 0   },
        'comp1'    => Adriver::BannerComponentType::HTML,
        'exp_type' => Adriver::BannerExpType::EXPOSURE,
        'name'     => 'JS-couter',
    },
    Adriver::BannerSpec::HTML_250x250 =>
    {
        'type'     => Adriver::BannerType::BAN_250x250,
        #'size'     => { 'width' => 250, 'height' => 250 },
        'comp1'    => Adriver::BannerComponentType::HTML,
        'exp_type' => Adriver::BannerExpType::EXPOSURE,
        'name'     => 'html250x250',
    },
    Adriver::BannerSpec::HTML_300x600 =>
    {
        'type'     => Adriver::BannerType::BAN_300x600,
        #'size'     => { 'width' => 300, 'height' => 600 },
        'comp1'    => Adriver::BannerComponentType::HTML,
        'exp_type' => Adriver::BannerExpType::EXPOSURE,
        'name'     => 'html300x600',
    },
    Adriver::BannerSpec::IMG_300x600 =>
    {
        'type'     => Adriver::BannerType::BAN_300x600,
        #'size'     => { 'width' => 300, 'height' => 600 },
        'comp1'    => Adriver::BannerComponentType::PICTURE,
        'exp_type' => Adriver::BannerExpType::EXPOSURE,
        'name'     => 'img300x600',
    },
    Adriver::BannerSpec::IMG_970x50 =>
    {
        'type'     => Adriver::BannerType::BAN_970x50,
        #'size'     => { 'width' => 970, 'height' => 50  },
        'comp1'    => Adriver::BannerComponentType::PICTURE,
        'exp_type' => Adriver::BannerExpType::EXPOSURE,
        'name'     => 'img970x50',
    },
    Adriver::BannerSpec::HTML_970x50 =>
    {
        'type'     => Adriver::BannerType::BAN_970x50,
        #'size'     => { 'width' => 970, 'height' => 50  },
        'comp1'    => Adriver::BannerComponentType::HTML,
        'exp_type' => Adriver::BannerExpType::EXPOSURE,
        'name'     => 'html970x50',
    },
    Adriver::BannerSpec::IMG_320x100 =>
    {
        'type'     => Adriver::BannerType::BAN_320x100,
        #'size'     => { 'width' => 320, 'height' => 100 },
        'comp1'    => Adriver::BannerComponentType::PICTURE,
        'exp_type' => Adriver::BannerExpType::EXPOSURE,
        'name'     => 'img320x100',
    },
    Adriver::BannerSpec::HTML_320x100 =>
    {
        'type'     => Adriver::BannerType::BAN_320x100,
        #'size'     => { 'width' => 320, 'height' => 100 },
        'comp1'    => Adriver::BannerComponentType::HTML,
        'exp_type' => Adriver::BannerExpType::EXPOSURE,
        'name'     => 'html320x100',
    },
    Adriver::BannerSpec::IMG_480x70 =>
    {
        'type'     => Adriver::BannerType::BAN_480x70,
        #'size'     => { 'width' => 480, 'height' => 70  },
        'comp1'    => Adriver::BannerComponentType::PICTURE,
        'exp_type' => Adriver::BannerExpType::EXPOSURE,
        'name'     => 'img480x70',
    },
    Adriver::BannerSpec::HTML_480x70 =>
    {
        'type'     => Adriver::BannerType::BAN_480x70,
        #'size'     => { 'width' => 480, 'height' => 70  },
        'comp1'    => Adriver::BannerComponentType::HTML,
        'exp_type' => Adriver::BannerExpType::EXPOSURE,
        'name'     => 'html480x70',
    },
    Adriver::BannerSpec::IMG_320x50 =>
    {
        'type'     => Adriver::BannerType::BAN_320x50,
        #'size'     => { 'width' => 320, 'height' => 50  },
        'comp1'    => Adriver::BannerComponentType::PICTURE,
        'exp_type' => Adriver::BannerExpType::EXPOSURE,
        'name'     => 'img320x50',
    },
    Adriver::BannerSpec::HTML_320x50 =>
    {
        'type'     => Adriver::BannerType::BAN_320x50,
        #'size'     => { 'width' => 320, 'height' => 50  },
        'comp1'    => Adriver::BannerComponentType::HTML,
        'exp_type' => Adriver::BannerExpType::EXPOSURE,
        'name'     => 'html320x50',
    },
);

sub TYPE2SIZE
{
    my $type = shift;
    return $type_info{ $type }->{ 'size' };
};

sub TYPE2NAME
{
    my $type = shift;
    return $type_info{ $type }->{ 'name' };
}

sub SPEC2TYPE
{
    my $spec = shift;
    return $spec_info{ $spec }->{ 'type' };
};

sub SPEC2SIZE
{
    my $spec = shift;
    my $spec_info = $spec_info{ $spec };
    return ( exists $spec_info->{ 'size' } )
        ? $spec_info->{ 'size' }
        : TYPE2SIZE( $spec_info->{ 'type' } );
};

sub SPEC2COMPONENT
{
    my $spec = shift;
    return $spec_info{ $spec }->{ 'comp1' };
}

sub SPEC2EXP_TYPE
{
    my $spec = shift;
    return $spec_info{ $spec }->{ 'exp_type' };
}

sub SPEC2NAME
{
    my $spec = shift;
    return $spec_info{ $spec }->{ 'name' };
}

#####
# popunder      - [bid = 100951] [spec = 59]
# frontline     - [bid = 122479] [spec = 76]
# extension     - [bid = 152637] [spec = 80]
# standartflash - [bid = 154373] [spec = 13 16 17 19 22 23 25 26 28 30 33 34 36 37 39 41 43 45 47 49 51 52 54 56 58 61 63 65 67 69 71 72 73 75 79 82 86 88 90 93 95]
# (enable standartflash on, enable = 2)
# netvideo      - [bid = 204875] [spec = 77]
# flashposter   - [bid = 272731] [spec = 92]
# screenglide   - [bid = 318901] [spec = 97]
#####

use constant TEMPLATE_POPUNDER_BID           => 100951;
use constant TEMPLATE_RICHMEDIA_BID          => 122479;
use constant TEMPLATE_NETVIDEO_BID           => 204875;
use constant TEMPLATE_EXTENSION_BID          => 152637;
use constant TEMPLATE_FLASH_POSTER_BID       => 272731;
use constant TEMPLATE_SCREENGLIDE_BID        => 318901;
use constant TEMPLATE_STANDART_FLASH_BID     => 154373;
use constant TEMPLATE_FLASH_AJAX_JS_BID      => 512850;
use constant TEMPLATE_XML_BANNER_BID         => 764190;
use constant TEMPLATE_FULLSCREEN_BID         => 769138;
use constant TEMPLATE_VARIABLE_EXTENSION_BID => 769233;
use constant TEMPLATE_FULLSCREEN_AJAX_JS_BID => 1355825;
# use constant TEMPLATE_VAST_VIDEO_BID         => 1803402;

sub TEMPLATE_BANNER_ID
{
    my $spec = shift;
    my %spec2template =
    (
        Adriver::BannerSpec::POPUNDER           => TEMPLATE_POPUNDER_BID,
        Adriver::BannerSpec::RICHMEDIA          => TEMPLATE_RICHMEDIA_BID,
        Adriver::BannerSpec::NETVIDEO           => TEMPLATE_NETVIDEO_BID,
        Adriver::BannerSpec::EXTENSION          => TEMPLATE_EXTENSION_BID,
        Adriver::BannerSpec::FLASH_POSTER       => TEMPLATE_FLASH_POSTER_BID,
        Adriver::BannerSpec::SCREENGLIDE        => TEMPLATE_SCREENGLIDE_BID,
        Adriver::BannerSpec::SG_POSTER          => TEMPLATE_SCREENGLIDE_BID,
        Adriver::BannerSpec::FLASH_AJAX_JS      => TEMPLATE_FLASH_AJAX_JS_BID,
        Adriver::BannerSpec::XML_BANNER         => TEMPLATE_XML_BANNER_BID,
        Adriver::BannerSpec::FULLSCREEN         => TEMPLATE_FULLSCREEN_BID,
        Adriver::BannerSpec::VARIABLE_EXTENSION => TEMPLATE_VARIABLE_EXTENSION_BID,
        Adriver::BannerSpec::XML_FLASH_MODULE   => TEMPLATE_XML_BANNER_BID,
        Adriver::BannerSpec::FULLSCREEN_AJAX_JS => TEMPLATE_FULLSCREEN_AJAX_JS_BID,
        Adriver::BannerSpec::FLASH_EXTENSION    => TEMPLATE_FLASH_POSTER_BID,
        # Adriver::BannerSpec::VAST_VIDEO         => TEMPLATE_VAST_VIDEO_BID,
        # STANDART_FLASH
        Adriver::BannerSpec::HTML_180x180 => TEMPLATE_STANDART_FLASH_BID,
        Adriver::BannerSpec::HTML_468x200 => TEMPLATE_STANDART_FLASH_BID,
        Adriver::BannerSpec::HTML_468x60  => TEMPLATE_STANDART_FLASH_BID,
        Adriver::BannerSpec::HTML_234x60  => TEMPLATE_STANDART_FLASH_BID,
        Adriver::BannerSpec::HTML_120x600 => TEMPLATE_STANDART_FLASH_BID,
        Adriver::BannerSpec::HTML_100x100 => TEMPLATE_STANDART_FLASH_BID,
        Adriver::BannerSpec::HTML_125x300 => TEMPLATE_STANDART_FLASH_BID,
        Adriver::BannerSpec::HTML_120x60  => TEMPLATE_STANDART_FLASH_BID,
        Adriver::BannerSpec::HTML_600x90  => TEMPLATE_STANDART_FLASH_BID,
        Adriver::BannerSpec::HTML_600x120 => TEMPLATE_STANDART_FLASH_BID,
        Adriver::BannerSpec::HTML_240x400 => TEMPLATE_STANDART_FLASH_BID,
        Adriver::BannerSpec::HTML_120x240 => TEMPLATE_STANDART_FLASH_BID,
        Adriver::BannerSpec::HTML_234x120 => TEMPLATE_STANDART_FLASH_BID,
        Adriver::BannerSpec::HTML_150x60  => TEMPLATE_STANDART_FLASH_BID,
        Adriver::BannerSpec::HTML_120x400 => TEMPLATE_STANDART_FLASH_BID,
        Adriver::BannerSpec::HTML_120x90  => TEMPLATE_STANDART_FLASH_BID,
        Adriver::BannerSpec::HTML_234x100 => TEMPLATE_STANDART_FLASH_BID,
        Adriver::BannerSpec::HTML_336x280 => TEMPLATE_STANDART_FLASH_BID,
        Adriver::BannerSpec::HTML_320x180 => TEMPLATE_STANDART_FLASH_BID,
        Adriver::BannerSpec::HTML_160x600 => TEMPLATE_STANDART_FLASH_BID,
        Adriver::BannerSpec::HTML_120x300 => TEMPLATE_STANDART_FLASH_BID,
        Adriver::BannerSpec::HTML_125x125 => TEMPLATE_STANDART_FLASH_BID,
        Adriver::BannerSpec::HTML_160x100 => TEMPLATE_STANDART_FLASH_BID,
        Adriver::BannerSpec::HTML_200x120 => TEMPLATE_STANDART_FLASH_BID,
        Adriver::BannerSpec::HTML_200x350 => TEMPLATE_STANDART_FLASH_BID,
        Adriver::BannerSpec::HTML_300x120 => TEMPLATE_STANDART_FLASH_BID,
        Adriver::BannerSpec::HTML_180x140 => TEMPLATE_STANDART_FLASH_BID,
        Adriver::BannerSpec::HTML_728x90  => TEMPLATE_STANDART_FLASH_BID,
        Adriver::BannerSpec::HTML_800x40  => TEMPLATE_STANDART_FLASH_BID,
        Adriver::BannerSpec::HTML_350x100 => TEMPLATE_STANDART_FLASH_BID,
        Adriver::BannerSpec::HTML_375x70  => TEMPLATE_STANDART_FLASH_BID,
        Adriver::BannerSpec::HTML_240x120 => TEMPLATE_STANDART_FLASH_BID,
        Adriver::BannerSpec::HTML_150x80  => TEMPLATE_STANDART_FLASH_BID,
        Adriver::BannerSpec::HTML_300x250 => TEMPLATE_STANDART_FLASH_BID,
        Adriver::BannerSpec::HTML_200x300 => TEMPLATE_STANDART_FLASH_BID,
        Adriver::BannerSpec::HTML_179x69  => TEMPLATE_STANDART_FLASH_BID,
        Adriver::BannerSpec::HTML_350x120 => TEMPLATE_STANDART_FLASH_BID,
        Adriver::BannerSpec::HTML_970x90  => TEMPLATE_STANDART_FLASH_BID,
        Adriver::BannerSpec::HTML_160x300 => TEMPLATE_STANDART_FLASH_BID,
        Adriver::BannerSpec::HTML_240x350 => TEMPLATE_STANDART_FLASH_BID,
        Adriver::BannerSpec::HTML_500x200 => TEMPLATE_STANDART_FLASH_BID,
    );
    return $spec2template{ $spec };
};

sub IS_STDFLASH_SPEC
{
    my $banner_spec = shift;

    my $is_stdflash_spec   = 0;
    my $template_banner_id = TEMPLATE_BANNER_ID( $banner_spec );
    if ( defined $template_banner_id and $template_banner_id == TEMPLATE_STANDART_FLASH_BID )
    {
        $is_stdflash_spec = 1;
    }

    return $is_stdflash_spec;
}

sub IS_STDFLASH_BANNER
{
    my $banner = shift;

    my $is_stdflash = 0;
    if ( IS_STDFLASH_SPEC( $banner->{'bannerSpec'} ) )
    {
        if ( exists $banner->{'enables'} )
        {
            $is_stdflash = $banner->{'enables'}->[ Adriver::Banner::STANDART_FLASH ];
        }
    }

    return $is_stdflash;
}

sub SET_STDFLASH_ON
{
    my $banner = shift;

    if ( IS_STDFLASH_SPEC( $banner->{'bannerSpec'} ) )
    {
        unless ( exists $banner->{'enables'} )
        {
            $banner->{'enables'} = [ ( ( 0 ) x 32 ) ];
        }
        $banner->{'enables'}->[ Adriver::Banner::STANDART_FLASH ] = 1;
    }

    return 1;
}

sub SET_STDFLASH_OFF
{
    my $banner = shift;

    if ( IS_STDFLASH_SPEC( $banner->{'bannerSpec'} ) )
    {
        unless ( exists $banner->{'enables'} )
        {
            $banner->{'enables'} = [ ( ( 0 ) x 32 ) ];
        }
        $banner->{'enables'}->[ Adriver::Banner::STANDART_FLASH ] = 0;
    }

    return 1;
}

sub IS_PIXEL_SPEC
{
    my $banner_spec = shift;

    my $is_pixel_spec = 0;
    if (
           $banner_spec == Adriver::BannerSpec::ZEROPIXEL
        or $banner_spec == Adriver::BannerSpec::EMPTY_CLICK
        or $banner_spec == Adriver::BannerSpec::REDIRECT_ZEROPIXEL
        or $banner_spec == Adriver::BannerSpec::AUDIT
        or $banner_spec == Adriver::BannerSpec::REDIRECT_AUDIT
    ) { $is_pixel_spec = 1; }

    return $is_pixel_spec;
}

sub IS_REDIRECT_SPEC
{
    my $banner_spec = shift;

    my $is_redirect_spec = 0;
    if (
           $banner_spec == Adriver::BannerSpec::REDIRECT_FLASH_240x400
        or $banner_spec == Adriver::BannerSpec::REDIRECT_FLASH_500x200
        or $banner_spec == Adriver::BannerSpec::REDIRECT_FLASH_600x90
        or $banner_spec == Adriver::BannerSpec::REDIRECT_ZEROPIXEL
        or $banner_spec == Adriver::BannerSpec::REDIRECT_AUDIT
    ) { $is_redirect_spec = 1; }

    return $is_redirect_spec;
}

1;
