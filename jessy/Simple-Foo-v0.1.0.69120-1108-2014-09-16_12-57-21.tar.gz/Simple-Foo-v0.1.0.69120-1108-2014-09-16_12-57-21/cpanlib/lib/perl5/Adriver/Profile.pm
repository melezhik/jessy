package Adriver::Profile;

use strict;
use warnings;

use Readonly;

# Engine enables ( ENABLES_PROFILE_ )
Readonly my %ENABLES => (

    UU_REPORT             => 0,
    OF_SLICE              => 1,
    HIDDEN                => 2,
    MOBILE_TARGS_ONLY     => 3,
    OF_AD                 => 4,
    SCHEDULE_ROBOT        => 5,
    AUDITORY_MARKING      => 6,
    PERCENT_BY_CTR        => 7,
    PERCENT_BANNERS       => 28,
    DONT_UPDATE_COUNTERS  => 29,
    DSP_NEED_EXTERNAL_UID => 30,
    TT_REPORT             => 31,

);

Readonly my %ENABLE_NAMES => reverse %ENABLES;

sub GET_ENABLE_NAME {
    my $index = shift;
    return $ENABLE_NAMES{$index};
}

sub GET_ENABLE_INDEX {
    my $name = shift;
    return $ENABLES{$name};
}

sub SET_UU_REPORTING {
    my $profile = shift;
    $profile->{enables}->[$ENABLES{UU_REPORT}] = (
            $profile->{uniqueUserMaxShows}->[0]
         or $profile->{uniqueUserMaxShows}->[1]
         or $profile->{uniqueUserMaxShows}->[2]
         or $profile->{uniqueUserMaxClicks}
         or $profile->{uniqueUserMinInterval} ) ? 1 : 0;
    return $profile;
}

{
    no strict 'refs';
    foreach my $enable (keys %ENABLES)
    {
        *{__PACKAGE__ . "::$enable"} = sub () { $ENABLES{$enable} };
    }
}

1;
