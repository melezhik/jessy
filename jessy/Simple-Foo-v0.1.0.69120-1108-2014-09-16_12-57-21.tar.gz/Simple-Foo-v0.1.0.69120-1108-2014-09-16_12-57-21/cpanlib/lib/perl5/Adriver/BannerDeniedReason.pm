package Adriver::BannerDeniedReason;

use strict;
use warnings;

use utf8;

use Encode qw/decode_utf8/;
use Readonly;

Readonly my %REASON_BY_NAME => (
    EROTIC => {
        code => 0,
        desc => 'Порнографические и эротические баннеры (в том числе содержащие слова «эротика», «секс» т. п.).'
    },
    POLITICS => {
        code => 1,
        desc => 'Политический баннер.'
    },
    YELLOW => {
        code => 2,
        desc => 'Баннер в стиле желтой прессы.'
    },
    NETETIQ => {
        code => 3,
        desc => 'Баннер, не соответствующий нормам сетевого этикета.'
    },
    IRRITANT => {
        code => 4,
        desc => 'Баннер является физическим раздражителем.'
    },
    DECEITFUL => {
        code => 5,
        desc => 'Баннер вводящий посетителей сайта в заблуждение.'
    },
    AMBIGUOUS => {
        code => 6,
        desc => 'Баннер имеет двусмысленное толкование.'
    },
    NAKED => {
        code => 7,
        desc => 'Необоснованное использование изображений красивых (некрасивых) девушек (юношей).'
    },
    PARTNER => {
        code => 8,
        desc => 'Баннер партнерской программы.'
    },
    WRONGSITE => {
        code => 9,
        desc => 'Баннер рекламирует, либо производит впечатление рекламирующего, сайт, не подлежащий участию в обмене в данной категории.'
    },
    BADDESIGN => {
        code => 10,
        desc => 'Баннер не содержит рамку, фон (отличный от белого и прозрачного) либо URL рекламируемого сайта.'
    },
    BADFLASH => {
        code => 11,
        desc => 'Баннер не соответствует спецификациям flash-баннеров.'
    },
    TOOBIG  => {
        code => 12,
        desc => 'Суммарный размер файла(ов) баннера превышает допустимое в сети ограничение.'
    },
    NETADVERT => {
        code => 13,
        desc => 'Любые баннерные сети могут рекламироваться у нас в сети только в объеме показов, заработанных непосредственно на рекламирующемся сайте.'
    },
    LAW => {
        code => 14,
        desc => 'Баннеры, нарушающие законодательство РФ. Примечание: согласно ФЗ «О рекламе» от 13 марта 2006 г., в Интернете не допускается «реклама основанных на риске игр, пари» (казино, включая онлайн-казино, лотереи, тотализаторы и т.п.).'
    },

);

Readonly my %REASON_BY_CODE => map { $REASON_BY_NAME{$_}->{code} => { name => $_, desc => $REASON_BY_NAME{$_}->{desc} } } keys %REASON_BY_NAME;

{
    no strict 'refs';
    foreach my $reason (keys %REASON_BY_NAME)
    {
        *{__PACKAGE__ . "::$reason"} = sub () { $REASON_BY_NAME{$reason}->{code} };
    }
}


sub GET_REASON_NAME {
    my $code = shift;
    return $REASON_BY_CODE{$code}->{name};
}

sub GET_REASON_CODE {
    my $name = shift;
    return $REASON_BY_NAME{$name}->{code};
}

sub GET_REASON_DESC {
    my $param = shift;
    my $desc = ($param =~ /^\d+$/) ? $REASON_BY_CODE{$param}->{desc} : $REASON_BY_NAME{$param}->{desc};
    return decode_utf8($desc);
}

1;
